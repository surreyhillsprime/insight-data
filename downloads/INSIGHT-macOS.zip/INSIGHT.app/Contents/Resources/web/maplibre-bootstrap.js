if (typeof maplibregl !== "undefined") {
  maplibregl.setWorkerUrl("./maplibre-gl-csp-worker.js");
}
