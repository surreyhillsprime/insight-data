    (function () {
      window.INSIGHT_BOOT_STAGE = "data";
      const ladGeoJson = window.SURREY_LAD_GEOJSON || { type: "FeatureCollection", features: [] };
      const ladFeaturesByName = Object.fromEntries((ladGeoJson.features || []).map(feature => [feature.properties?.name, feature]));
      const districtPaths = window.SURREY_DISTRICT_PATHS || [];
      const transactionRows = (window.SURREY_LAND_REG_TRANSACTIONS || []).slice().sort((a, b) => b.date.localeCompare(a.date));
      const transactionRowsByProperty = groupTransactionRowsByProperty(transactionRows);
      const transactions = collapsePropertyTransactions(transactionRows);
      const salesHistoryRowsCache = new Map();
      const landRegMeta = window.SURREY_LAND_REG_META || {};
      const salesHistoryMeta = window.SURREY_SALES_HISTORY_META || {};
      const addressPoints = window.SURREY_ADDRESS_POINTS || {};
      const postcodePoints = window.SURREY_POSTCODE_POINTS || {};
      const schools = window.SURREY_SCHOOLS || [];
      const privateEstateRuntime = window.INSIGHT_PRIVATE_ESTATES && typeof window.INSIGHT_PRIVATE_ESTATES === "object"
        ? window.INSIGHT_PRIVATE_ESTATES
        : { definitions: [], rules: [], navigationAnchors: [], approvedPins: [], metadata: {} };
      let newsItems = Array.isArray(window.INSIGHT_NEWS_ITEMS) ? window.INSIGHT_NEWS_ITEMS.slice() : [];
      let newsMeta = window.INSIGHT_NEWS_META && typeof window.INSIGHT_NEWS_META === "object" ? { ...window.INSIGHT_NEWS_META } : {};
      let newsExpanded = false;
      const newsVisitKey = "insight-news-last-visit";
      const newsSessionKey = "insight-news-session-baseline";
      const newsPreviousVisit = (() => {
        try {
          const sessionBaseline = sessionStorage.getItem(newsSessionKey);
          if (sessionBaseline !== null) return sessionBaseline;
          const previous = localStorage.getItem(newsVisitKey) || "";
          sessionStorage.setItem(newsSessionKey, previous);
          return previous;
        } catch (_error) {
          return "";
        }
      })();
      const themeMedia = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : { matches: false, addEventListener: null };

      const marketDefinitions = [
        { id: "elmbridge-prime", name: "Elmbridge", short: "Elmbridge", district: "Elmbridge" },
        { id: "runnymede-wentworth", name: "Runnymede", short: "Runnymede", district: "Runnymede" },
        { id: "woking-district", name: "Woking", short: "Woking", district: "Woking" },
        { id: "surrey-heath", name: "Surrey Heath", short: "Surrey Heath", district: "Surrey Heath" },
        { id: "guildford-district", name: "Guildford", short: "Guildford", district: "Guildford" },
        { id: "mole-valley", name: "Mole Valley", short: "Mole Valley", district: "Mole Valley" },
        { id: "waverley-south-surrey", name: "Waverley", short: "Waverley", district: "Waverley" },
        { id: "reigate-banstead", name: "Reigate and Banstead", short: "Reigate and Banstead", district: "Reigate and Banstead" },
        { id: "epsom-ewell", name: "Epsom and Ewell", short: "Epsom and Ewell", district: "Epsom and Ewell" },
        { id: "tandridge-oxted", name: "Tandridge", short: "Tandridge", district: "Tandridge" },
        { id: "spelthorne", name: "Spelthorne", short: "Spelthorne", district: "Spelthorne" }
      ].map(market => ({
        ...market,
        geometry: ladFeaturesByName[market.district]?.geometry || null,
        fallbackPath: districtPaths.find(path => path.name === market.district)
      })).filter(market => market.geometry || market.fallbackPath);

      const districtGeoPoints = {
        "Elmbridge": [-0.3944, 51.36095],
        "Epsom and Ewell": [-0.26173, 51.33947],
        "Guildford": [-0.56258, 51.25366],
        "Mole Valley": [-0.30604, 51.2275],
        "Reigate and Banstead": [-0.19871, 51.25846],
        "Runnymede": [-0.53855, 51.39274],
        "Spelthorne": [-0.46254, 51.41553],
        "Surrey Heath": [-0.68984, 51.33612],
        "Tandridge": [-0.04809, 51.23585],
        "Waverley": [-0.62343, 51.15686],
        "Woking": [-0.57981, 51.3084]
      };

      const townGeoPoints = {
        ADDLESTONE: [-0.4931, 51.3714],
        ASCOT: [-0.6746, 51.4102],
        ASHTEAD: [-0.2997, 51.3085],
        BAGSHOT: [-0.688, 51.36],
        BANSTEAD: [-0.2043, 51.3221],
        BOOKHAM: [-0.3741, 51.2793],
        CAMBERLEY: [-0.7426, 51.3402],
        CATERHAM: [-0.0789, 51.282],
        CHERTSEY: [-0.507, 51.388],
        CHOBHAM: [-0.6043, 51.3482],
        CLAYGATE: [-0.3427, 51.3592],
        COBHAM: [-0.4117, 51.3291],
        CRANLEIGH: [-0.4858, 51.142],
        DORKING: [-0.3315, 51.232],
        EAST_HORSLEY: [-0.4325, 51.2731],
        EAST_MOLESEY: [-0.349, 51.398],
        EGHAM: [-0.5482, 51.4315],
        EPSOM: [-0.2674, 51.334],
        ESHER: [-0.3656, 51.3691],
        FARNHAM: [-0.798, 51.2143],
        FETCHAM: [-0.3551, 51.2882],
        GODALMING: [-0.6145, 51.1858],
        GUILDFORD: [-0.5703, 51.2362],
        HASLEMERE: [-0.7105, 51.089],
        HINDHEAD: [-0.735, 51.113],
        HORLEY: [-0.171, 51.174],
        KINGSWOOD: [-0.211, 51.286],
        LEATHERHEAD: [-0.3285, 51.2965],
        LINGFIELD: [-0.015, 51.176],
        OXTED: [-0.006, 51.257],
        REDHILL: [-0.1709, 51.2405],
        REIGATE: [-0.2058, 51.2376],
        RIPLEY: [-0.495, 51.299],
        SHEPPERTON: [-0.4479, 51.3958],
        STAINES_UPON_THAMES: [-0.5088, 51.4324],
        SUNBURY_ON_THAMES: [-0.4135, 51.4197],
        SURBITON: [-0.3037, 51.3939],
        TADWORTH: [-0.2357, 51.2918],
        THAMES_DITTON: [-0.3391, 51.3891],
        VIRGINIA_WATER: [-0.566, 51.403],
        WALTON_ON_THAMES: [-0.4146, 51.3868],
        WARLINGHAM: [-0.056, 51.309],
        WEST_BYFLEET: [-0.5064, 51.3384],
        WEYBRIDGE: [-0.4577, 51.3718],
        WINDLESHAM: [-0.654, 51.365],
        WOKING: [-0.559, 51.3168]
      };

      // Definitions and navigation anchors are deliberately separate. A
      // definition can classify transactions without implying a legal extent.
      const estatePins = (privateEstateRuntime.definitions || []).map(estate => ({
        ...estate,
        key: estate.id,
        aliases: Array.isArray(estate.aliases) ? estate.aliases : []
      }));
      const privateEstateRules = Array.isArray(privateEstateRuntime.rules) ? privateEstateRuntime.rules : [];
      const estateNavigationAnchors = (privateEstateRuntime.navigationAnchors || []).map(anchor => {
        const estate = estatePins.find(candidate => candidate.key === anchor.estateId);
        const coordinates = anchor?.geometry?.coordinates || [];
        return estate && Number.isFinite(Number(coordinates[0])) && Number.isFinite(Number(coordinates[1]))
          ? { ...estate, lon: Number(coordinates[0]), lat: Number(coordinates[1]), anchorBasis: anchor.anchorBasis || "", navigationOnly: true, legalExtent: false }
          : null;
      }).filter(Boolean);
      const approvedEstatePins = (privateEstateRuntime.approvedPins || []).map(pin => {
        const estate = estatePins.find(candidate => candidate.key === pin.estateId);
        const coordinates = pin?.geometry?.coordinates || [];
        return estate && Number.isFinite(Number(coordinates[0])) && Number.isFinite(Number(coordinates[1]))
          ? { ...estate, lon: Number(coordinates[0]), lat: Number(coordinates[1]), pinVersion: pin.pinVersion || privateEstateRuntime.metadata?.geometryVersion || "" }
          : null;
      }).filter(Boolean);
      const stationPins = [
        { id: "WOK", name: "Woking", crs: "WOK", lon: -0.5569, lat: 51.3185, london: "London Waterloo", fastestMins: 24, typicalMins: 28, operator: "South Western Railway" },
        { id: "GLD", name: "Guildford", crs: "GLD", lon: -0.5805, lat: 51.2369, london: "London Waterloo", fastestMins: 32, typicalMins: 38, operator: "South Western Railway" },
        { id: "WBR", name: "Weybridge", crs: "WYB", lon: -0.4577, lat: 51.3618, london: "London Waterloo", fastestMins: 29, typicalMins: 36, operator: "South Western Railway" },
        { id: "ESH", name: "Esher", crs: "ESH", lon: -0.3532, lat: 51.3790, london: "London Waterloo", fastestMins: 23, typicalMins: 29, operator: "South Western Railway" },
        { id: "CBS", name: "Cobham & Stoke d'Abernon", crs: "CSD", lon: -0.3899, lat: 51.3180, london: "London Waterloo", fastestMins: 38, typicalMins: 42, operator: "South Western Railway" },
        { id: "OXS", name: "Oxshott", crs: "OXS", lon: -0.3622, lat: 51.3364, london: "London Waterloo", fastestMins: 35, typicalMins: 40, operator: "South Western Railway" },
        { id: "WAL", name: "Walton-on-Thames", crs: "WAL", lon: -0.4146, lat: 51.3729, london: "London Waterloo", fastestMins: 25, typicalMins: 31, operator: "South Western Railway" },
        { id: "HER", name: "Hersham", crs: "HER", lon: -0.3899, lat: 51.3769, london: "London Waterloo", fastestMins: 30, typicalMins: 35, operator: "South Western Railway" },
        { id: "VIR", name: "Virginia Water", crs: "VIR", lon: -0.5623, lat: 51.4018, london: "London Waterloo", fastestMins: 43, typicalMins: 48, operator: "South Western Railway" },
        { id: "EGH", name: "Egham", crs: "EGH", lon: -0.5465, lat: 51.4296, london: "London Waterloo", fastestMins: 39, typicalMins: 45, operator: "South Western Railway" },
        { id: "SNS", name: "Staines", crs: "SNS", lon: -0.5039, lat: 51.4322, london: "London Waterloo", fastestMins: 35, typicalMins: 41, operator: "South Western Railway" },
        { id: "FNB", name: "Farnborough Main", crs: "FNB", lon: -0.7557, lat: 51.2967, london: "London Waterloo", fastestMins: 34, typicalMins: 39, operator: "South Western Railway" },
        { id: "FNH", name: "Farnham", crs: "FNH", lon: -0.7928, lat: 51.2119, london: "London Waterloo", fastestMins: 53, typicalMins: 60, operator: "South Western Railway" },
        { id: "GOD", name: "Godalming", crs: "GOD", lon: -0.6188, lat: 51.1866, london: "London Waterloo", fastestMins: 41, typicalMins: 47, operator: "South Western Railway" },
        { id: "HSL", name: "Haslemere", crs: "HSL", lon: -0.7190, lat: 51.0888, london: "London Waterloo", fastestMins: 49, typicalMins: 57, operator: "South Western Railway" },
        { id: "DKG", name: "Dorking", crs: "DKG", lon: -0.3241, lat: 51.2409, london: "London Victoria / Waterloo", fastestMins: 49, typicalMins: 58, operator: "Southern / South Western Railway" },
        { id: "LHD", name: "Leatherhead", crs: "LHD", lon: -0.3332, lat: 51.2988, london: "London Waterloo / Victoria", fastestMins: 43, typicalMins: 50, operator: "South Western Railway / Southern" },
        { id: "ASD", name: "Ashtead", crs: "AHD", lon: -0.3088, lat: 51.3175, london: "London Waterloo / Victoria", fastestMins: 38, typicalMins: 45, operator: "South Western Railway / Southern" },
        { id: "EPS", name: "Epsom", crs: "EPS", lon: -0.2693, lat: 51.3343, london: "London Waterloo / Victoria", fastestMins: 34, typicalMins: 41, operator: "South Western Railway / Southern" },
        { id: "RED", name: "Redhill", crs: "RDH", lon: -0.1658, lat: 51.2402, london: "London Bridge / Victoria", fastestMins: 29, typicalMins: 36, operator: "Southern / Thameslink" },
        { id: "REI", name: "Reigate", crs: "REI", lon: -0.2038, lat: 51.2419, london: "London Victoria / London Bridge", fastestMins: 42, typicalMins: 50, operator: "Southern / Great Western Railway" },
        { id: "GTW", name: "Gatwick Airport", crs: "GTW", lon: -0.1610, lat: 51.1566, london: "London Victoria / London Bridge", fastestMins: 29, typicalMins: 35, operator: "Gatwick Express / Southern / Thameslink" },
        { id: "HOR", name: "Horley", crs: "HOR", lon: -0.1610, lat: 51.1688, london: "London Victoria / London Bridge", fastestMins: 34, typicalMins: 41, operator: "Southern / Thameslink" },
        { id: "OXT", name: "Oxted", crs: "OXT", lon: -0.0048, lat: 51.2579, london: "London Victoria / London Bridge", fastestMins: 33, typicalMins: 39, operator: "Southern" },
        { id: "BYF", name: "West Byfleet", crs: "WBY", lon: -0.5055, lat: 51.3392, london: "London Waterloo", fastestMins: 31, typicalMins: 38, operator: "South Western Railway" }
      ];

      const airportPins = [
        { id: "LHR", name: "Heathrow Airport", lon: -0.4543, lat: 51.4700, type: "International airport", driveBaseMins: 22 },
        { id: "LGW", name: "Gatwick Airport", lon: -0.1821, lat: 51.1537, type: "International airport", driveBaseMins: 30 },
        { id: "FAB", name: "Farnborough Airport", lon: -0.7763, lat: 51.2758, type: "Business aviation airport", driveBaseMins: 18 }
      ];

      const addressPointRules = [
        { terms: ["OLD AVENUE"], lon: -0.456, lat: 51.351 },
        { terms: ["EAST ROAD"], lon: -0.454, lat: 51.349 },
        { terms: ["WEST ROAD"], lon: -0.462, lat: 51.354 },
        { terms: ["CAMP END ROAD", "TOR LANE"], lon: -0.466, lat: 51.346 },
        { terms: ["PORTNALL DRIVE", "PORTNALL RISE"], lon: -0.570, lat: 51.405 },
        { terms: ["NORTH DRIVE", "SOUTH DRIVE", "PINEWOOD ROAD"], lon: -0.590, lat: 51.398 },
        { terms: ["BLACKHILLS"], lon: -0.366, lat: 51.348 },
        { terms: ["ASHLEY PARK AVENUE", "ASHLEY RISE"], lon: -0.410, lat: 51.379 },
        { terms: ["PACHESHAM PARK"], lon: -0.351, lat: 51.302 },
        { terms: ["TYRRELLS WOOD"], lon: -0.321, lat: 51.289 },
        { terms: ["HOOK HEATH ROAD"], lon: -0.586, lat: 51.310 },
        { terms: ["CRANLEY ROAD", "INCE ROAD", "ONSLOW ROAD", "CHARGATE CLOSE", "FRIARS CLOSE"], lon: -0.402, lat: 51.369 },
        { terms: ["ESHER PARK AVENUE"], lon: -0.360, lat: 51.366 },
        { terms: ["FIRWOOD ROAD"], lon: -0.529, lat: 51.385 }
      ];

      const layerRegistry = [
        { id: "heatmaps", label: "Heat", detail: "Authority and town market intensity", defaultOn: true, layers: ["market-fill", "market-hover-glow", "market-hover-outline", "market-outline", "town-fill", "town-hover-glow", "town-hover-outline", "town-outline", "market-labels", "town-labels"] },
        { id: "properties", label: "Properties", detail: "Geocoded Land Registry transactions", defaultOn: true, layers: ["property-points", "property-halo", "selected-property-glow", "selected-property-ring", "selected-property-core"] },
        { id: "estates", label: "Private Estates", detail: "Private-estate locations and market cohorts", defaultOn: true, layers: ["estate-hover-glow", "estate-points", "estate-labels"] },
        { id: "stations", label: "Stations", detail: "Rail stations and London journey context", defaultOn: true, layers: ["station-points", "station-labels"] },
        { id: "airports", label: "Airports", detail: "Heathrow, Gatwick and Farnborough", defaultOn: true, layers: ["airport-points", "airport-labels"] },
        { id: "schools", label: "Schools", detail: "Open schools and nearby education context", defaultOn: true, layers: ["school-points", "school-labels"] }
      ];
      const renderModeLabels = {
        velocity: "Velocity",
        momentum: "Momentum",
        value: "Average value",
        ppsf: "£ per sqft",
        growth: "Real price movement",
        planning: "Planning density"
      };

      const state = {
        selectedType: "overview",
        selectedId: null,
        selectedRows: transactions,
        renderMode: "velocity",
        propertyRenderMode: "price",
        search: "",
        marketListExpanded: false,
        estateListExpanded: false,
        townListExpanded: false,
        ledgerExpanded: false,
        insightContext: null,
        insightAnswerCache: null,
        hoveredFeature: null,
        resolvedTheme: "light",
        layers: Object.fromEntries(layerRegistry.map(layer => [layer.id, layer.defaultOn]))
      };
      const zoomMin = 9.2;
      const zoomMax = 19;
      const defaultZoomLevel = 0;
      const overviewMapPadding = { top: 0, right: 306, bottom: 0, left: 0 };
      const selectionMapPadding = { top: 0, right: 0, bottom: 0, left: 0 };
      const selectionHistory = [{ type: "overview", id: null }];
      let selectionHistoryIndex = 0;
      let restoringSelectionHistory = false;

      const els = {
        layerList: document.getElementById("layerList"),
        dataFeedStatus: document.getElementById("dataFeedStatus"),
        insightLastUpdated: document.getElementById("insightLastUpdated"),
        newsPanel: document.getElementById("newsPanel"),
        newsList: document.getElementById("newsList"),
        newsNewCount: document.getElementById("newsNewCount"),
        newsFeedStatus: document.getElementById("newsFeedStatus"),
        newsMoreButton: document.getElementById("newsMoreButton"),
        marketList: document.getElementById("marketList"),
        marketTitle: document.getElementById("marketTitle"),
        marketRankNote: document.getElementById("marketRankNote"),
        estateList: document.getElementById("estateList"),
        estateTitle: document.getElementById("estateTitle"),
        estateRankNote: document.getElementById("estateRankNote"),
        townList: document.getElementById("townList"),
        townTitle: document.getElementById("townTitle"),
        townRankNote: document.getElementById("townRankNote"),
        summaryGrid: document.getElementById("summaryGrid"),
        summaryNote: document.getElementById("summaryNote"),
        legendMode: document.getElementById("legendMode"),
        keyModePicker: document.querySelector(".key-mode-picker"),
        keyModeOptions: document.getElementById("keyModeOptions"),
        legend: document.getElementById("legend"),
        propertyModePicker: document.querySelector(".property-mode-picker"),
        propertyModeOptions: document.getElementById("propertyModeOptions"),
        propertyLegendTitle: document.getElementById("propertyLegendTitle"),
        propertyLegend: document.getElementById("propertyLegend"),
        hoverTooltip: document.getElementById("mapHoverTooltip"),
        zoomSlider: document.getElementById("zoomSlider"),
        zoomReadout: document.getElementById("zoomReadout"),
        inspectorTitle: document.getElementById("inspectorTitle"),
        inspectorSubtitle: document.getElementById("inspectorSubtitle"),
        profileHeading: document.getElementById("profileHeading"),
        profileType: document.getElementById("profileType"),
        profilePanel: document.getElementById("profilePanel"),
        ledgerSection: document.getElementById("ledgerSection"),
        ledgerList: document.getElementById("ledgerList"),
        ledgerCount: document.getElementById("ledgerCount"),
        searchBox: document.getElementById("searchBox"),
        askForm: document.getElementById("askForm"),
        askSubmit: document.getElementById("askSubmit"),
        askStatus: document.getElementById("askStatus"),
        answerWorkspace: document.getElementById("answerWorkspace"),
        app: document.querySelector(".app"),
        mapKey: document.querySelector(".map-key"),
        mapTopbar: document.querySelector(".map-topbar"),
        brandTitle: document.querySelector(".brand h1"),
        mapDropdowns: Array.from(document.querySelectorAll("[data-map-dropdown]"))
      };

      window.INSIGHT_SET_DATA_STATUS = message => {
        if (els.dataFeedStatus) els.dataFeedStatus.textContent = String(message || "");
      };

      window.INSIGHT_SET_NEWS_FEED = (items, metadata) => {
        if (Array.isArray(items)) newsItems = items.slice();
        if (metadata && typeof metadata === "object") newsMeta = { ...metadata };
        renderNews();
      };

      window.INSIGHT_SET_NEWS_STATUS = message => {
        if (els.newsFeedStatus) els.newsFeedStatus.textContent = String(message || "");
      };

      renderNews();

      function latestInsightUpdate(value) {
        let latest = null;
        const visit = item => {
          if (!item || typeof item !== "object") return;
          Object.entries(item).forEach(([key, child]) => {
            if (key === "updatedAt" && typeof child === "string") {
              const date = new Date(child);
              if (!Number.isNaN(date.getTime()) && (!latest || date > latest)) latest = date;
            } else if (child && typeof child === "object") {
              visit(child);
            }
          });
        };
        visit(value);
        return latest;
      }

      const latestUpdate = latestInsightUpdate(landRegMeta);
      if (els.insightLastUpdated) {
        const formatted = latestUpdate
          ? new Intl.DateTimeFormat("en-GB", { dateStyle: "medium", timeStyle: "short" }).format(latestUpdate)
          : "Not supplied";
        els.insightLastUpdated.textContent = `INSIGHT updated: ${formatted}`;
      }

      function resolveTheme() {
        return themeMedia.matches ? "dark" : "light";
      }

      function setDocumentTheme() {
        state.resolvedTheme = resolveTheme();
        document.documentElement.dataset.theme = state.resolvedTheme;
      }

      function mapTextPaint() {
        const dark = state.resolvedTheme === "dark";
        return {
          label: dark ? "#e6edf3" : "#172033",
          secondary: dark ? "#c9d1d9" : "#243045",
          halo: dark ? "#0d1117" : "#ffffff",
          outline: dark ? "#b6ebff" : "#006ab6",
          propertyStroke: dark ? "#0d1117" : "#ffffff"
        };
      }

      function applyThemeToMap() {
        if (!mapStyleReady()) return;
        const dark = state.resolvedTheme === "dark";
        const paint = mapTextPaint();
        if (map.getLayer("carto-light-base")) map.setLayoutProperty("carto-light-base", "visibility", dark ? "none" : "visible");
        if (map.getLayer("carto-dark-base")) map.setLayoutProperty("carto-dark-base", "visibility", dark ? "visible" : "none");
        ["county-outline", "market-outline"].forEach(layer => {
          if (map.getLayer(layer)) map.setPaintProperty(layer, "line-color", paint.outline);
        });
        ["market-labels", "town-labels", "estate-labels", "station-labels", "airport-labels", "school-labels"].forEach(layer => {
          if (!map.getLayer(layer)) return;
          map.setPaintProperty(layer, "text-color", layer === "market-labels" ? paint.secondary : paint.label);
          map.setPaintProperty(layer, "text-halo-color", paint.halo);
        });
        if (map.getLayer("property-points")) map.setPaintProperty("property-points", "circle-stroke-color", paint.propertyStroke);
        refreshMapImages();
      }

      function applyTheme() {
        const previous = state.resolvedTheme;
        setDocumentTheme();
        if (previous !== state.resolvedTheme) applyThemeToMap();
      }

      setDocumentTheme();

      function normalise(value) {
        return String(value || "").toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim();
      }

      function normalisePostcode(value) {
        return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
      }

      function addressKey(value) {
        return normalise(value).replace(/\s+/g, " ");
      }

      function propertyAddressIdentity(value) {
        const parts = String(value || "")
          .split(",")
          .map(part => addressKey(part))
          .filter(Boolean)
          .filter(part => !/^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/.test(part));
        if (parts.length >= 2) return `${parts[0]}|${parts[1]}`;
        return parts[0] || addressKey(value);
      }

      function propertyRecordKey(item) {
        const address = propertyAddressIdentity(item?.address);
        const postcode = normalisePostcode(item?.postcode);
        // A nearest OS UPRN derived from a postcode centroid is useful context,
        // but it is not a safe property identity: distinct homes can share it.
        if (address || postcode) return `address:${address}|${postcode}`;
        const uprn = String(item?.ordnanceSurvey?.uprn || item?.uprn || "").trim();
        return uprn ? `uprn:${uprn}` : `id:${propertyId(item?.id)}`;
      }

      function collapsePropertyTransactions(rows) {
        const properties = new Map();
        rows.forEach(item => {
          const key = propertyRecordKey(item);
          const existing = properties.get(key);
          if (!existing || String(item.date || "").localeCompare(String(existing.date || "")) > 0) {
            properties.set(key, { ...item, propertyRecordKey: key });
          }
        });
        return Array.from(properties.values()).sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
      }

      function groupTransactionRowsByProperty(rows) {
        const grouped = new Map();
        rows.forEach(item => {
          const key = propertyRecordKey(item);
          if (!grouped.has(key)) grouped.set(key, []);
          grouped.get(key).push(item);
        });
        return grouped;
      }

      function propertyId(value) {
        return String(value ?? "");
      }

      function planningPropertyKey(item) {
        return `property:${addressKey(item?.address)}|${normalisePostcode(item?.postcode)}`;
      }

      function planningHistoryForTransaction(item) {
        if (!item) return {};
        const privatePlanning = window.SURREY_PLANNING_HISTORY || {};
        return item.planningHistory || privatePlanning[propertyId(item.id)] || privatePlanning[planningPropertyKey(item)] || {};
      }

      function planningApplicationCount(item) {
        const history = planningHistoryForTransaction(item);
        const applications = Array.isArray(history.applications) ? history.applications : [];
        const total = Number(history.totalApplications ?? applications.length);
        return Number.isFinite(total) && total > 0 ? total : 0;
      }

      function planningMetricsForRows(rows) {
        const propertyLinks = new Set();
        const matchedPropertyKeys = new Set();
        const uniqueCases = new Map();
        rows.forEach(item => {
          const history = planningHistoryForTransaction(item);
          const applications = Array.isArray(history.applications) && history.applications.length
            ? history.applications
            : Array.isArray(item.planning?.recentApplications) ? item.planning.recentApplications : [];
          if (applications.length || planningApplicationCount(item) > 0) matchedPropertyKeys.add(propertyRecordKey(item));
          applications.forEach((application, index) => {
            const authority = normalise(application.authority || item.district || "");
            const reference = normalise(application.reference || application.applicationNumber || "");
            const fallback = normalise([application.proposal, application.description, application.siteAddress, application.receivedDate, application.decisionDate].filter(Boolean).join("|"));
            const caseKey = reference ? `${authority}|${reference}` : `${authority}|${fallback || index}`;
            const confidence = Number(application.matchConfidence ?? history.matchConfidence ?? item.planningMatchConfidence ?? 1);
            propertyLinks.add(`${propertyRecordKey(item)}|${caseKey}`);
            if (!uniqueCases.has(caseKey) || confidence > uniqueCases.get(caseKey).confidence) uniqueCases.set(caseKey, { application, confidence });
          });
        });
        const cases = Array.from(uniqueCases.values());
        return {
          uniqueCases: uniqueCases.size,
          propertyLinks: propertyLinks.size,
          matchedProperties: matchedPropertyKeys.size,
          highConfidenceCases: cases.filter(item => item.confidence >= .9).length,
          lowConfidenceCases: cases.filter(item => item.confidence < .7).length
        };
      }

      function planningApplicationVolumeForRows(rows) {
        const metrics = planningMetricsForRows(rows);
        // Use unique authority/reference cases for area totals so the same
        // application linked to neighbouring properties is not double-counted.
        if (metrics.uniqueCases) return metrics.uniqueCases;
        const seen = new Set();
        return rows.reduce((total, item) => {
          const key = propertyRecordKey(item);
          if (seen.has(key)) return total;
          seen.add(key);
          return total + planningApplicationCount(item);
        }, 0);
      }

      function townKey(value) {
        return normalise(value).replace(/\s+/g, "_");
      }

      function compactPrice(value) {
        const number = Number(value);
        if (!Number.isFinite(number) || number <= 0) return "£--";
        if (number >= 10000000) return "£" + (number / 1000000).toFixed(1).replace(/\.0$/, "") + "m";
        return "£" + (number / 1000000).toFixed(2).replace(/0$/, "").replace(/\.0$/, "") + "m";
      }

      function formatNumber(value) {
        return new Intl.NumberFormat("en-GB").format(Math.round(Number(value) || 0));
      }

      function compactSqft(value) {
        const number = Number(value);
        if (!Number.isFinite(number) || number <= 0) return "";
        return formatNumber(number) + " sq ft";
      }

      function compactPpsf(value) {
        const number = Number(value);
        if (!Number.isFinite(number) || number <= 0) return "";
        return "£" + formatNumber(number) + "/sq ft";
      }

      function formatDate(value) {
        if (!value) return "";
        const text = String(value);
        const date = new Date(/^\d{4}-\d{2}-\d{2}$/.test(text) ? text + "T00:00:00Z" : text);
        if (Number.isNaN(date.getTime())) return text;
        return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(date);
      }

      function parseIso(value) {
        const date = new Date(value + "T00:00:00Z");
        return Number.isNaN(date.getTime()) ? null : date;
      }

      function clamp(min, max, value) {
        return Math.max(min, Math.min(max, value));
      }

      function mapZoomFromDisplay(value) {
        return zoomMin + (clamp(0, 100, Number(value) || 0) / 100) * (zoomMax - zoomMin);
      }

      function displayZoomFromMap(value) {
        const percent = clamp(0, 100, ((Number(value) - zoomMin) / (zoomMax - zoomMin)) * 100);
        return percent < 5 ? 0 : Math.round(percent);
      }

      function addMonths(date, months) {
        const copy = new Date(date.getTime());
        copy.setUTCMonth(copy.getUTCMonth() + months);
        return copy;
      }

      function addDays(date, days) {
        return new Date(date.getTime() + days * 24 * 60 * 60 * 1000);
      }

      function monthsBetween(start, end) {
        return Math.max(1, (end - start) / (1000 * 60 * 60 * 24 * 30.4375));
      }

      function median(values) {
        if (!values.length) return 0;
        const sorted = values.slice().sort((a, b) => a - b);
        const mid = Math.floor(sorted.length / 2);
        return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
      }

      function average(values) {
        return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
      }

      function signedPercent(value, confidence = 1) {
        if (!confidence || !Number.isFinite(value)) return "--";
        const percent = Math.round(value * 100);
        if (Math.abs(percent) < 1) return "flat";
        return (percent > 0 ? "+" : "") + percent + "%";
      }

      function preciseSignedPercent(value, confidence = 1) {
        if (!confidence || !Number.isFinite(value)) return "--";
        const percent = value * 100;
        if (Math.abs(percent) < .05) return "flat";
        return `${percent > 0 ? "+" : ""}${percent.toFixed(1)}%`;
      }

      function priceMovementLabel(stats) {
        if (!(Number(stats?.priceConfidence) > 0)) return "Insufficient evidence";
        return `${preciseSignedPercent(Number(stats.priceChange), 1)} real p.a.`;
      }

      function priceMovementConfidenceLabel(stats) {
        const confidence = Number(stats?.priceConfidence) || 0;
        if (confidence >= .75) return "High confidence";
        if (confidence >= .45) return "Medium confidence";
        if (confidence > 0) return "Low confidence";
        return "Insufficient evidence";
      }

      function priceMovementEvidenceLabel(stats) {
        const localPairs = Number(stats?.pricePairCount) || 0;
        const parentPairs = Number(stats?.priceParentPairCount) || 0;
        const parentLabel = String(stats?.priceParentLabel || "Authority").toLowerCase();
        if (!localPairs && parentPairs) return `${formatNumber(parentPairs)} ${parentLabel} pairs · contextual`;
        if (!localPairs) return "No qualifying repeat-sale pairs";
        const local = `${formatNumber(localPairs)} repeat-sale ${localPairs === 1 ? "pair" : "pairs"}`;
        return parentPairs ? `${local} + ${parentLabel} context` : local;
      }

      function velocityRating(score) {
        const value = Number(score) || 0;
        if (value >= 70) return "Hot";
        if (value >= 58) return "Active";
        if (value >= 45) return "Steady";
        if (value >= 30) return "Slow";
        return "Cold";
      }

      function velocityLabel(stats) {
        if (!(Number(stats?.count) > 0)) return "No qualifying sales";
        const score = Number(stats?.velocityScore) || 0;
        return `${score}/100 · ${velocityRating(score)}`;
      }

      function velocityConfidenceLabel(stats) {
        if (!(Number(stats?.count) > 0)) return "Insufficient evidence";
        const confidence = Number(stats?.velocityConfidence) || 0;
        if (confidence >= .75) return "High confidence";
        if (confidence >= .45) return "Medium confidence";
        return "Low confidence";
      }

      function accelerationLabel(stats) {
        if ((Number(stats?.accelerationConfidence) || 0) < .35) return "Low signal";
        const acceleration = Number(stats?.acceleration) || 1;
        if (acceleration >= 1.25) return "Accelerating";
        if (acceleration <= .8) return "Slowing";
        return "Stable";
      }

      function momentumRating(score) {
        const value = Number(score) || 0;
        if (value >= 70) return "Strong";
        if (value >= 58) return "Building";
        if (value >= 45) return "Balanced";
        return "Cooling";
      }

      function momentumLabel(stats) {
        if (!(Number(stats?.count) > 0)) return "Insufficient evidence";
        const score = Number(stats?.momentumScore) || 0;
        return `${score}/100 · ${momentumRating(score)}`;
      }

      function distanceKm(a, b) {
        if (!a || !b) return Infinity;
        const toRad = value => value * Math.PI / 180;
        const radius = 6371;
        const dLat = toRad(b[1] - a[1]);
        const dLon = toRad(b[0] - a[0]);
        const lat1 = toRad(a[1]);
        const lat2 = toRad(b[1]);
        const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
        return radius * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
      }

      function formatDistanceKm(value) {
        if (!Number.isFinite(value)) return "";
        return value < 1 ? Math.round(value * 1000) + "m" : value.toFixed(1) + "km";
      }

      function formatMinutes(value) {
        const minutes = Math.round(Number(value) || 0);
        if (!minutes) return "";
        if (minutes < 60) return `${minutes} min`;
        const hours = Math.floor(minutes / 60);
        const remainder = minutes % 60;
        return remainder ? `${hours}h ${remainder}m` : `${hours}h`;
      }

      const velocityWindowMonths = 12;
      const activityContextMonths = 24;
      const accelerationWindowDays = 90;
      const priceMovementWindowMonths = 24;
      const minimumRepeatHoldingDays = 365;
      const maximumAnnualRealMovement = .25;
      const cpihAnnualIndex = {
        1995: 66.6, 1996: 68.5, 1997: 70.0, 1998: 71.3, 1999: 72.6,
        2000: 73.4, 2001: 74.6, 2002: 75.7, 2003: 76.7, 2004: 77.8,
        2005: 79.4, 2006: 81.4, 2007: 83.3, 2008: 86.2, 2009: 87.9,
        2010: 90.1, 2011: 93.6, 2012: 96.0, 2013: 98.2, 2014: 99.6,
        2015: 100.0, 2016: 101.0, 2017: 103.6, 2018: 106.0, 2019: 107.8,
        2020: 108.9, 2021: 111.6, 2022: 120.5, 2023: 128.6, 2024: 132.9,
        2025: 138.0, 2026: 142.1
      };
      const analysisEnd = parseIso(landRegMeta.to || transactions[0]?.date || "2026-06-30");
      const coverageYear = String(landRegMeta.from || salesHistoryMeta.coverageFrom || "1995").slice(0, 4);
      const analysisStart = parseIso(`${coverageYear}-01-01`);
      const velocityStart = addMonths(analysisEnd, -velocityWindowMonths);
      const activityContextStart = addMonths(analysisEnd, -activityContextMonths);
      const accelerationStart = addDays(analysisEnd, -accelerationWindowDays);

      function marketById(id) {
        return marketDefinitions.find(market => market.id === id);
      }

      function rowsForMarket(id) {
        return transactions.filter(item => item.market === id);
      }

      function rowsForTownKey(key) {
        return transactions.filter(item => townKey(item.town) === key);
      }

      function activityRowsForProperties(rows) {
        const seen = new Set();
        const activity = [];
        rows.forEach(property => {
          const sales = transactionRowsByProperty.get(propertyRecordKey(property)) || [property];
          (sales.length ? sales : [property]).forEach(sale => {
            const identity = `${propertyRecordKey(property)}|${String(sale.date || "").slice(0, 10)}|${Number(sale.price || 0)}|${String(sale.id || "")}`;
            if (seen.has(identity)) return;
            seen.add(identity);
            const activityRow = {
              ...property,
              ...sale,
              market: sale.market || property.market,
              district: sale.district || property.district,
              town: sale.town || property.town,
              propertyRecordKey: propertyRecordKey(property),
              __insightGrain: "transaction"
            };
            const price = Number(activityRow.price || 0);
            const floorArea = Number(activityRow.floorAreaSqft || 0);
            // Historical title rows often omit the derived field. Never carry
            // the latest sale's £/sq ft backwards into an earlier transaction.
            activityRow.pricePerSqft = price > 0 && floorArea > 0 ? Math.round(price / floorArea) : 0;
            activity.push(activityRow);
          });
        });
        return activity.sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
      }

      function isTransactionGrain(rows) {
        return Boolean(rows.length) && rows.every(item => item?.__insightGrain === "transaction");
      }

      function cpihIndexForDate(value) {
        const year = Number(String(value || "").slice(0, 4));
        return cpihAnnualIndex[year] || cpihAnnualIndex[2026];
      }

      function inflationAdjustedPrice(item) {
        const price = Number(item?.price || 0);
        const sourceIndex = cpihIndexForDate(item?.date);
        return price > 0 && sourceIndex > 0 ? price * cpihAnnualIndex[2026] / sourceIndex : 0;
      }

      function repeatSaleConfidence(pairCount) {
        const count = Math.max(0, Number(pairCount) || 0);
        return count < 3 ? 0 : Math.min(1, count / 12);
      }

      function quantileInclusive(values, ratio) {
        const sorted = values.filter(Number.isFinite).sort((left, right) => left - right);
        if (!sorted.length) return 0;
        const index = (sorted.length - 1) * ratio;
        const low = Math.floor(index);
        const high = Math.ceil(index);
        const weight = index - low;
        return sorted[low] * (1 - weight) + sorted[high] * weight;
      }

      function repeatSalePriceMovement(rows) {
        const seen = new Set();
        const pairs = [];
        rows.forEach(property => {
          const recordKey = propertyRecordKey(property);
          if (seen.has(recordKey)) return;
          seen.add(recordKey);
          const sales = salesHistoryForTransaction(property)
            .filter(sale => Number(sale.price) > 0 && parseIso(String(sale.date || "").slice(0, 10)))
            .sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
          if (sales.length < 2) return;
          const pricesByDate = new Map();
          let conflictingSaleDate = false;
          sales.forEach(sale => {
            const date = String(sale.date || "").slice(0, 10);
            const price = Number(sale.price || 0);
            if (pricesByDate.has(date) && pricesByDate.get(date) !== price) conflictingSaleDate = true;
            pricesByDate.set(date, price);
          });
          if (conflictingSaleDate) return;
          const latest = sales[0];
          const prior = sales[1];
          if (String(latest.category || "").toUpperCase() === "B" || String(prior.category || "").toUpperCase() === "B") return;
          const latestType = normalise(latest.propertyType);
          const priorType = normalise(prior.propertyType);
          if (latestType && priorType && latestType !== priorType) return;
          const latestDate = parseIso(String(latest.date || "").slice(0, 10));
          const priorDate = parseIso(String(prior.date || "").slice(0, 10));
          if (!latestDate || !priorDate || latestDate < activityContextStart || latestDate > analysisEnd) return;
          const holdingDays = Math.round((latestDate - priorDate) / (24 * 60 * 60 * 1000));
          if (holdingDays < minimumRepeatHoldingDays) return;
          const latestPrice = inflationAdjustedPrice(latest);
          const priorPrice = inflationAdjustedPrice(prior);
          if (!(latestPrice > 0 && priorPrice > 0)) return;
          const ratio = latestPrice / priorPrice;
          const annualised = Math.pow(ratio, 365.25 / holdingDays) - 1;
          if (!Number.isFinite(annualised)) return;
          pairs.push({
            recordKey,
            latest,
            prior,
            holdingYears: holdingDays / 365.25,
            annualised,
            boundedAnnualised: clamp(-maximumAnnualRealMovement, maximumAnnualRealMovement, annualised)
          });
        });

        const bounded = pairs.map(pair => pair.boundedAnnualised);
        const lower = bounded.length >= 8 ? quantileInclusive(bounded, .1) : -maximumAnnualRealMovement;
        const upper = bounded.length >= 8 ? quantileInclusive(bounded, .9) : maximumAnnualRealMovement;
        const winsorised = bounded.map(value => clamp(lower, upper, value));
        const pairCount = pairs.length;
        const priceChange = pairCount >= 3 ? median(winsorised) : 0;
        const medianHoldYears = pairCount ? median(pairs.map(pair => pair.holdingYears)) : 0;
        return {
          priceChange,
          priceLocalChange: priceChange,
          priceConfidence: repeatSaleConfidence(pairCount),
          pricePairCount: pairCount,
          priceEvidencePairCount: pairCount,
          priceParentPairCount: 0,
          priceParentLabel: "",
          priceMedianHoldYears: medianHoldYears,
          priceMovementWindowMonths,
          priceSource: pairCount >= 3 ? "Local repeat sales" : "Insufficient repeat-sales evidence",
          priceComparisonLabel: pairCount >= 3
            ? `${formatNumber(pairCount)} repeat-sale ${pairCount === 1 ? "pair" : "pairs"} · CPIH adjusted · annualised`
            : `Only ${formatNumber(pairCount)} qualifying repeat-sale ${pairCount === 1 ? "pair" : "pairs"} · minimum 3 required`
        };
      }

      function velocityScoreForRatio(value) {
        const ratio = Math.max(0, Number(value) || 0);
        const points = [[0, 8], [.5, 32], [.75, 45], [1.1, 58], [1.45, 70], [2, 78], [3, 82]];
        for (let index = 1; index < points.length; index++) {
          const [upperRatio, upperScore] = points[index];
          if (ratio <= upperRatio) {
            const [lowerRatio, lowerScore] = points[index - 1];
            const position = (ratio - lowerRatio) / Math.max(.001, upperRatio - lowerRatio);
            return lowerScore + (upperScore - lowerScore) * position;
          }
        }
        return points[points.length - 1][1];
      }

      function momentumScoreForSignals(velocityScore, accelerationScore, priceChange, priceConfidence) {
        const confidence = clamp(0, 1, Number(priceConfidence) || 0);
        const priceMomentumScore = 50 + clamp(-25, 25, Number(priceChange || 0) * 250);
        const missingPriceWeight = 1 - confidence;
        const velocityWeight = .6 + .15 * missingPriceWeight;
        const accelerationWeight = .2 + .05 * missingPriceWeight;
        const priceWeight = .2 * confidence;
        return Math.round(clamp(8, 82,
          velocityScore * velocityWeight + accelerationScore * accelerationWeight + priceMomentumScore * priceWeight
        ));
      }

      function statsForRows(rows, activityOverride = null) {
        const hasActivityOverride = Array.isArray(activityOverride);
        const transactionGrain = !hasActivityOverride && isTransactionGrain(rows);
        const activityRows = hasActivityOverride ? activityOverride.slice() : transactionGrain ? rows.slice() : activityRowsForProperties(rows);
        const hasActivity = activityRows.length > 0;
        const sorted = activityRows.slice().sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));
        const prices = rows.map(item => Number(item.price)).filter(Number.isFinite);
        const ppsf = rows.map(item => Number(item.pricePerSqft)).filter(value => Number.isFinite(value) && value > 0);
        const recent = activityRows.filter(item => {
          const date = parseIso(item.date);
          return date && date >= velocityStart && date <= analysisEnd;
        });
        const context24 = activityRows.filter(item => {
          const date = parseIso(item.date);
          return date && date >= activityContextStart && date <= analysisEnd;
        });
        const context24Prices = context24.map(item => Number(item.price)).filter(value => Number.isFinite(value) && value > 0);
        const context24Ppsf = context24.map(item => Number(item.pricePerSqft)).filter(value => Number.isFinite(value) && value > 0);
        const baseline = activityRows.filter(item => {
          const date = parseIso(item.date);
          return date && date >= analysisStart && date < velocityStart;
        });
        const fiveYearStart = addMonths(velocityStart, -60);
        const fiveYearBaseline = baseline.filter(item => {
          const date = parseIso(item.date);
          return date && date >= fiveYearStart;
        });
        const longRunAnnual = baseline.length / Math.max(1, monthsBetween(analysisStart, velocityStart)) * 12;
        const fiveYearAnnual = fiveYearBaseline.length / 5;
        const baselineAnnual = fiveYearAnnual > 0 && longRunAnnual > 0
          ? fiveYearAnnual * .65 + longRunAnnual * .35
          : fiveYearAnnual || longRunAnnual;
        const recentAnnual = recent.length;
        const rawVelocity = baselineAnnual > 0 ? recentAnnual / baselineAnnual : recent.length ? 1 : 0;
        const velocityConfidence = hasActivity ? clamp(.15, 1, (recent.length + baselineAnnual) / 12) : 0;
        const velocity = hasActivity ? Math.max(0, 1 + (rawVelocity - 1) * velocityConfidence) : 0;
        const recent90 = recent.filter(item => {
          const date = parseIso(item.date);
          return date && date >= accelerationStart;
        });
        const priorNineMonths = recent.filter(item => {
          const date = parseIso(item.date);
          return date && date < accelerationStart;
        });
        const expected90 = baselineAnnual * accelerationWindowDays / 365.25;
        const expectedPriorNineMonths = baselineAnnual * (365.25 - accelerationWindowDays) / 365.25;
        const rate90 = expected90 > 0 ? (recent90.length + expected90 * .5) / (expected90 * 1.5) : 1;
        const ratePriorNineMonths = expectedPriorNineMonths > 0
          ? (priorNineMonths.length + expectedPriorNineMonths * .5) / (expectedPriorNineMonths * 1.5)
          : 1;
        const rawAcceleration = clamp(.25, 4, rate90 / Math.max(.05, ratePriorNineMonths));
        const accelerationConfidence = hasActivity ? clamp(.15, 1, (recent.length + baselineAnnual) / 16) : 0;
        const acceleration = hasActivity ? 1 + (rawAcceleration - 1) * accelerationConfidence : 0;
        const accelerationScore = hasActivity ? Math.round(clamp(20, 80, 50 + Math.log2(Math.max(.25, acceleration)) * 12)) : 0;
        const accelerationNudge = clamp(-6, 6, (accelerationScore - 50) * .3);
        let velocityScore = velocityScoreForRatio(velocity) + accelerationNudge;
        if (velocityConfidence < .45 || recent.length < 2) velocityScore = Math.min(57, velocityScore);
        else if (velocityConfidence < .65 || recent.length < 3) velocityScore = Math.min(69, velocityScore);
        if (recent.length === 0) velocityScore = Math.min(24, velocityScore);
        velocityScore = hasActivity ? Math.round(clamp(8, 82, velocityScore)) : 0;
        const priceMovement = transactionGrain ? {
          priceChange: 0,
          priceLocalChange: 0,
          priceConfidence: 0,
          pricePairCount: 0,
          priceEvidencePairCount: 0,
          priceParentPairCount: 0,
          priceMedianHoldYears: 0,
          priceMovementWindowMonths,
          priceSource: "Not calculated for a historical transaction slice",
          priceComparisonLabel: "Historical transaction slice"
        } : repeatSalePriceMovement(rows);
        const momentumScore = hasActivity ? momentumScoreForSignals(
          velocityScore, accelerationScore, priceMovement.priceChange, priceMovement.priceConfidence
        ) : 0;
        return {
          count: activityRows.length,
          propertyCount: transactionGrain ? new Set(rows.map(propertyRecordKey)).size : rows.length,
          transactionGrain,
          avg: average(prices),
          max: prices.length ? Math.max(...prices) : 0,
          latest: sorted[0] || null,
          recent: recent.length,
          context24: context24.length,
          context24Avg: average(context24Prices),
          context24PpsfAvg: average(context24Ppsf),
          recent90: recent90.length,
          prior: baseline.length,
          baselineAnnual,
          recentAnnual,
          fiveYearAnnual,
          longRunAnnual,
          velocityWindowMonths,
          velocity,
          rawVelocity,
          velocityConfidence,
          acceleration,
          accelerationConfidence,
          accelerationScore,
          momentumScore,
          ppsfAvg: average(ppsf),
          priceChange: priceMovement.priceChange,
          priceLocalChange: priceMovement.priceLocalChange,
          priceConfidence: priceMovement.priceConfidence,
          pricePairCount: priceMovement.pricePairCount,
          priceEvidencePairCount: priceMovement.priceEvidencePairCount,
          priceParentPairCount: priceMovement.priceParentPairCount,
          priceMedianHoldYears: priceMovement.priceMedianHoldYears,
          priceMovementWindowMonths: priceMovement.priceMovementWindowMonths,
          priceSource: priceMovement.priceSource,
          priceComparisonLabel: priceMovement.priceComparisonLabel,
          velocityScore,
          planningApplications: planningApplicationVolumeForRows(rows)
        };
      }

      function withParentPriceMovement(stats, parentStats, parentLabel = "Authority") {
        if (!stats || !parentStats || !(parentStats.priceConfidence > 0)) return stats;
        const localPairs = Number(stats.pricePairCount) || 0;
        if (localPairs < 3 || localPairs >= 8) return stats;
        const parentPairs = Number(parentStats.priceEvidencePairCount || parentStats.pricePairCount) || 0;
        if (!parentPairs) return stats;
        const localWeight = localPairs / 8;
        const priceChange = stats.priceLocalChange * localWeight + parentStats.priceChange * (1 - localWeight);
        return {
          ...stats,
          priceChange,
          momentumScore: momentumScoreForSignals(stats.velocityScore, stats.accelerationScore, priceChange, stats.priceConfidence),
          priceEvidencePairCount: localPairs,
          priceParentPairCount: parentPairs,
          priceParentLabel: parentLabel,
          priceSource: `Local repeat sales + ${parentLabel.toLowerCase()} context`,
          priceComparisonLabel: `${formatNumber(localPairs)} local ${localPairs === 1 ? "pair" : "pairs"} · confidence-weighted with ${parentLabel.toLowerCase()} context`
        };
      }

      const overallStats = statsForRows(transactions);
      const marketStats = Object.fromEntries(marketDefinitions.map(market => [market.id, statsForRows(rowsForMarket(market.id))]));
      const townStats = Object.fromEntries(Object.keys(townGeoPoints).map(key => {
        const rows = rowsForTownKey(key);
        const localStats = statsForRows(rows);
        return [key, withParentPriceMovement(localStats, marketStats[rows[0]?.market])];
      }));

      function statsForEstate(pin) {
        const rows = estateTransactions(pin);
        const activityRows = estateActivityRows(pin);
        return withParentPriceMovement(statsForRows(rows, activityRows), marketStats[pin?.market]);
      }
      const heatColours = ["#557aa0", "#728d79", "#b08a58", "#9f4549"];
      const velocityColours = ["#006ab6", "#3f8f68", "#d5a53a", "#b63d42"];

      function metricForStats(stats, mode) {
        if (!stats) return 0;
        if (mode === "momentum") return stats.momentumScore;
        if (mode === "value") return stats.avg;
        if (mode === "ppsf") return stats.ppsfAvg;
        if (mode === "growth") return stats.priceChange;
        if (mode === "planning") return stats.planningApplications;
        return stats.velocityScore;
      }

      function quantile(values, ratio) {
        const sorted = values.filter(value => Number.isFinite(value) && value !== 0).sort((a, b) => a - b);
        if (!sorted.length) return 0;
        const index = (sorted.length - 1) * ratio;
        const low = Math.floor(index);
        const high = Math.ceil(index);
        const weight = index - low;
        return sorted[low] * (1 - weight) + sorted[high] * weight;
      }

      function breaksFor(mode) {
        if (mode === "velocity" || mode === "momentum") return [45, 58, 70];
        if (mode === "ppsf") return [500, 850, 1200];
        if (mode === "growth") return [-.03, .03, .08];
        const statsList = [
          ...Object.values(marketStats),
          ...Object.values(townStats),
          ...estatePins.map(statsForEstate)
        ].filter(stats => stats.count > 0);
        const values = statsList.map(stats => metricForStats(stats, mode));
        const fallback = {
          velocity: [35, 50, 65],
          value: [3500000, 4500000, 6000000],
          growth: [-.04, .04, .12],
          planning: [1, 4, 8]
        }[mode] || [35, 50, 65];
        if (values.filter(value => Number.isFinite(value) && value !== 0).length < 4) return fallback;
        return [quantile(values, .32), quantile(values, .62), quantile(values, .84)];
      }

      function colourExpression(mode) {
        const property = mode === "value" ? "avg"
          : mode === "ppsf" ? "ppsfAvg"
          : mode === "growth" ? "priceChange"
          : mode === "planning" ? "planningScore"
          : mode === "momentum" ? "momentumScore"
          : "velocityScore";
        const breaks = breaksFor(mode);
        if (mode === "growth") {
          return ["case",
            ["<=", ["to-number", ["get", "priceConfidence"]], 0], "#64748b",
            [">=", ["to-number", ["get", property]], breaks[2]], heatColours[3],
            [">=", ["to-number", ["get", property]], breaks[1]], heatColours[2],
            [">=", ["to-number", ["get", property]], breaks[0]], heatColours[1],
            heatColours[0]
          ];
        }
        if (mode === "planning") {
          return ["case",
            [">=", ["to-number", ["get", property]], breaks[2]], "#7c3aed",
            [">=", ["to-number", ["get", property]], breaks[1]], "#c19a58",
            [">=", ["to-number", ["get", property]], breaks[0]], "#6f967b",
            "#64748b"
          ];
        }
        const colours = mode === "velocity" || mode === "momentum" ? velocityColours : heatColours;
        return ["case",
          [">=", ["to-number", ["get", property]], breaks[2]], colours[3],
          [">=", ["to-number", ["get", property]], breaks[1]], colours[2],
          [">=", ["to-number", ["get", property]], breaks[0]], colours[1],
          colours[0]
        ];
      }

      function propertyPriceColourExpression() {
        return ["case",
          ["<=", ["to-number", ["get", "price"]], 0], "#64748b",
          [">=", ["to-number", ["get", "price"]], 10000000], "#b63d42",
          [">=", ["to-number", ["get", "price"]], 5000000], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyPpsfColourExpression() {
        return ["case",
          ["<=", ["to-number", ["get", "pricePerSqft"]], 0], "#64748b",
          [">=", ["to-number", ["get", "pricePerSqft"]], 1500], "#b63d42",
          [">=", ["to-number", ["get", "pricePerSqft"]], 1000], "#d5a53a",
          [">=", ["to-number", ["get", "pricePerSqft"]], 750], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyPlanningColourExpression() {
        return ["case",
          [">=", ["to-number", ["get", "planningCount"]], 4], "#b63d42",
          [">=", ["to-number", ["get", "planningCount"]], 2], "#c19a58",
          [">=", ["to-number", ["get", "planningCount"]], 1], "#6f967b",
          "#64748b"
        ];
      }

      function propertyEpcColourExpression() {
        return ["match", ["get", "epcRating"],
          "A", "#287a50",
          "B", "#3f8f68",
          "C", "#d5a53a",
          "D", "#db7f35",
          "E", "#b63d42",
          "F", "#93323b",
          "G", "#6f2430",
          "#64748b"
        ];
      }

      function propertyRecencyColourExpression() {
        return ["case",
          ["<", ["to-number", ["get", "saleAgeDays"]], 0], "#64748b",
          ["<=", ["to-number", ["get", "saleAgeDays"]], 90], "#b63d42",
          ["<=", ["to-number", ["get", "saleAgeDays"]], 365], "#d5a53a",
          ["<=", ["to-number", ["get", "saleAgeDays"]], 730], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyUpliftColourExpression() {
        return ["case",
          ["!", ["boolean", ["get", "hasPriorSale"], false]], "#64748b",
          [">=", ["to-number", ["get", "valueUplift"]], .25], "#b63d42",
          [">=", ["to-number", ["get", "valueUplift"]], .1], "#d5a53a",
          [">=", ["to-number", ["get", "valueUplift"]], 0], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyColourExpression() {
        if (state.propertyRenderMode === "ppsf") return propertyPpsfColourExpression();
        if (state.propertyRenderMode === "planning") return propertyPlanningColourExpression();
        if (state.propertyRenderMode === "epc") return propertyEpcColourExpression();
        if (state.propertyRenderMode === "recency") return propertyRecencyColourExpression();
        if (state.propertyRenderMode === "uplift") return propertyUpliftColourExpression();
        return propertyPriceColourExpression();
      }

      function propertyPointOpacityExpression() {
        const base = ["interpolate", ["linear"], ["zoom"], 10.4, 0, 11, 0, 12, .58, 14, .92];
        if (state.selectedType !== "property" || !state.selectedId) return base;
        return ["*", base, .25];
      }

      function propertyHaloOpacityExpression() {
        const base = ["interpolate", ["linear"], ["zoom"], 10.4, 0, 11.2, .12, 13.5, .28, 18, .48];
        if (state.selectedType !== "property" || !state.selectedId) return 0;
        return base;
      }

      function inverseProject(x, y) {
        const xScale = 970.0475576048453;
        const xOffset = 883.5010614469987;
        const yScale = -1550.5137800225802;
        const yOffset = 79857.18293281777;
        return [(x - xOffset) / xScale, (y - yOffset) / yScale];
      }

      function pathToCoordinates(path) {
        const coords = [];
        const pattern = /[ML]\s*(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)/g;
        let match;
        while ((match = pattern.exec(path))) {
          coords.push(inverseProject(Number(match[1]), Number(match[2])));
        }
        if (coords.length && (coords[0][0] !== coords[coords.length - 1][0] || coords[0][1] !== coords[coords.length - 1][1])) {
          coords.push(coords[0]);
        }
        return coords;
      }

      function cloneGeometry(geometry) {
        return JSON.parse(JSON.stringify(geometry));
      }

      function marketGeoJson() {
        return {
          type: "FeatureCollection",
          features: marketDefinitions.map(market => {
            const stats = marketStats[market.id];
            return {
              type: "Feature",
              id: market.id,
              properties: {
                id: market.id,
                name: market.short,
                fullName: market.name,
                district: market.district,
                count: stats.count,
                avg: Math.round(stats.avg),
                max: stats.max,
                recent: stats.recent,
                recent90: stats.recent90,
                context24: stats.context24,
                velocity: Number(stats.velocity.toFixed(2)),
                velocityConfidence: Number(stats.velocityConfidence.toFixed(2)),
                acceleration: Number(stats.acceleration.toFixed(2)),
                accelerationConfidence: Number(stats.accelerationConfidence.toFixed(2)),
                ppsfAvg: Math.round(stats.ppsfAvg),
                priceChange: Number(stats.priceChange.toFixed(3)),
                priceConfidence: Number(stats.priceConfidence.toFixed(2)),
                pricePairCount: stats.pricePairCount,
                priceParentPairCount: stats.priceParentPairCount,
                priceParentLabel: stats.priceParentLabel,
                priceMedianHoldYears: Number(stats.priceMedianHoldYears.toFixed(1)),
                priceSource: stats.priceSource,
                velocityScore: stats.velocityScore,
                momentumScore: stats.momentumScore,
                planningScore: stats.planningApplications
              },
              geometry: market.geometry
                ? cloneGeometry(market.geometry)
                : { type: "Polygon", coordinates: [pathToCoordinates(market.fallbackPath.path)] }
            };
          })
        };
      }

      function polygonRings(geometry) {
        if (!geometry) return [];
        if (geometry.type === "Polygon") return geometry.coordinates || [];
        if (geometry.type === "MultiPolygon") return (geometry.coordinates || []).flat();
        return [];
      }

      function countyOutlineGeoJson() {
        const edgeMap = new Map();
        const precision = 1000000;
        const keyFor = point => `${Math.round(point[0] * precision)},${Math.round(point[1] * precision)}`;
        (ladGeoJson.features || []).forEach(feature => {
          polygonRings(feature.geometry).forEach(ring => {
            for (let i = 0; i < ring.length - 1; i++) {
              const a = ring[i];
              const b = ring[i + 1];
              const ak = keyFor(a);
              const bk = keyFor(b);
              const key = ak < bk ? `${ak}|${bk}` : `${bk}|${ak}`;
              const existing = edgeMap.get(key);
              if (existing) {
                existing.count += 1;
              } else {
                edgeMap.set(key, { count: 1, segment: [a, b] });
              }
            }
          });
        });
        return {
          type: "FeatureCollection",
          features: Array.from(edgeMap.values())
            .filter(edge => edge.count === 1)
            .map((edge, index) => ({
              type: "Feature",
              id: "county-edge-" + index,
              properties: {},
              geometry: { type: "LineString", coordinates: edge.segment }
            }))
        };
      }

      function circlePolygon(lon, lat, radiusKm, steps = 42) {
        const coordinates = [];
        const latDelta = radiusKm / 111.32;
        const lonDelta = radiusKm / (111.32 * Math.cos(lat * Math.PI / 180));
        for (let i = 0; i <= steps; i++) {
          const angle = (i / steps) * Math.PI * 2;
          coordinates.push([
            lon + Math.cos(angle) * lonDelta,
            lat + Math.sin(angle) * latDelta
          ]);
        }
        return coordinates;
      }

      function townDisplayName(key) {
        const sample = transactions.find(item => townKey(item.town) === key);
        const value = sample?.town || key.replace(/_/g, " ");
        return String(value).toLowerCase().replace(/\b[a-z]/g, letter => letter.toUpperCase());
      }

      function townRadiusKm(stats) {
        return clamp(1.7, 5.4, 2 + Math.log10(stats.count + 1) * 1.35);
      }

      function townGeoJson() {
        return {
          type: "FeatureCollection",
          features: Object.entries(townGeoPoints).map(([key, point]) => {
            const stats = townStats[key];
            if (!stats || !stats.count) return null;
            return {
              type: "Feature",
              id: key,
              properties: {
                id: key,
                name: townDisplayName(key),
                count: stats.count,
                avg: Math.round(stats.avg),
                max: stats.max,
                recent: stats.recent,
                recent90: stats.recent90,
                context24: stats.context24,
                velocity: Number(stats.velocity.toFixed(2)),
                velocityConfidence: Number(stats.velocityConfidence.toFixed(2)),
                acceleration: Number(stats.acceleration.toFixed(2)),
                accelerationConfidence: Number(stats.accelerationConfidence.toFixed(2)),
                ppsfAvg: Math.round(stats.ppsfAvg),
                priceChange: Number(stats.priceChange.toFixed(3)),
                priceConfidence: Number(stats.priceConfidence.toFixed(2)),
                pricePairCount: stats.pricePairCount,
                priceParentPairCount: stats.priceParentPairCount,
                priceParentLabel: stats.priceParentLabel,
                priceMedianHoldYears: Number(stats.priceMedianHoldYears.toFixed(1)),
                priceSource: stats.priceSource,
                velocityScore: stats.velocityScore,
                momentumScore: stats.momentumScore,
                planningScore: stats.planningApplications
              },
              geometry: { type: "Polygon", coordinates: [circlePolygon(point[0], point[1], townRadiusKm(stats))] }
            };
          }).filter(Boolean)
        };
      }

      function deterministicJitter(id, scale) {
        let hash = 0;
        const text = String(id || "");
        for (let i = 0; i < text.length; i++) hash = ((hash << 5) - hash + text.charCodeAt(i)) | 0;
        const a = ((hash % 997) / 997) * Math.PI * 2;
        const b = (((hash >> 3) % 389) / 389) * scale;
        return [Math.cos(a) * b, Math.sin(a) * b * .7];
      }

      function spreadPoint(point, id, scale) {
        const jitter = deterministicJitter(id, scale);
        return [point[0] + jitter[0], point[1] + jitter[1]];
      }

      function addressRuleForTransaction(item) {
        const addressText = normalise([item.address, item.postcode].join(" "));
        return addressPointRules.find(rule => rule.terms.some(term => addressText.includes(normalise(term))));
      }

      function estateForTransaction(item) {
        // The collector owns classification. Never revive the legacy free-text
        // `estate` field or attempt a second substring classifier in the UI.
        const estateId = String(item?.estateId || "");
        if (!estateId) return null;
        return estatePins.find(estate => estate.key === estateId) || null;
      }

      function schoolId(school) {
        return String(school?.urn || school?.name || "");
      }

      function schoolById(id) {
        const target = String(id || "");
        return schools.find(school => schoolId(school) === target);
      }

      function schoolSector(school) {
        const type = normalise(school?.type);
        if (type.includes("INDEPENDENT")) return "Private";
        if (type.includes("ACADEMY") || type.includes("COMMUNITY") || type.includes("FOUNDATION") || type.includes("VOLUNTARY") || type.includes("FREE SCHOOL")) return "State";
        if (type.includes("LOCAL AUTHORITY")) return "State";
        return school?.type || "School";
      }

      function schoolAgeRange(school) {
        const low = Number(school?.lowAge);
        const high = Number(school?.highAge);
        if (Number.isFinite(low) && Number.isFinite(high) && high > 0) return `${low}-${high}`;
        return school?.phase || "";
      }

      function schoolCoordinate(school) {
        const lon = Number(school?.lon);
        const lat = Number(school?.lat);
        return Number.isFinite(lon) && Number.isFinite(lat) ? [lon, lat] : null;
      }

      function stationById(id) {
        return stationPins.find(station => station.id === id || station.crs === id);
      }

      function airportById(id) {
        return airportPins.find(airport => airport.id === id);
      }

      function stationCoordinate(station) {
        return station ? [Number(station.lon), Number(station.lat)] : null;
      }

      function airportCoordinate(airport) {
        return airport ? [Number(airport.lon), Number(airport.lat)] : null;
      }

      function nearestStations(point, limit = 3) {
        if (!point) return [];
        return stationPins
          .map(station => {
            const distance = distanceKm(point, stationCoordinate(station));
            return { ...station, distanceKm: distance };
          })
          .filter(station => Number.isFinite(station.distanceKm))
          .sort((a, b) => a.distanceKm - b.distanceKm)
          .slice(0, limit);
      }

      function airportDriveMinutes(distance, airport) {
        if (!Number.isFinite(distance)) return 0;
        return Math.round((Number(airport?.driveBaseMins) || 20) + distance * 1.35);
      }

      function nearestAirports(point, limit = 3) {
        if (!point) return [];
        return airportPins
          .map(airport => {
            const distance = distanceKm(point, airportCoordinate(airport));
            return { ...airport, distanceKm: distance, driveMins: airportDriveMinutes(distance, airport) };
          })
          .filter(airport => Number.isFinite(airport.distanceKm))
          .sort((a, b) => a.driveMins - b.driveMins)
          .slice(0, limit);
      }

      function nearbyTransactionsForPoint(point, radiusKm = 2.5) {
        if (!point) return [];
        return transactions
          .map(item => ({ item, distance: distanceKm(point, transactionGeoPoint(item)) }))
          .filter(entry => Number.isFinite(entry.distance) && entry.distance <= radiusKm)
          .sort((a, b) => a.distance - b.distance || b.item.date.localeCompare(a.item.date))
          .map(entry => ({ ...entry.item, distanceFromSelection: entry.distance }));
      }

      function addressPointForTransaction(item) {
        const candidates = [
          item.id,
          addressKey(`${item.address}|${item.postcode}`),
          addressKey(`${item.address} ${item.postcode}`),
          addressKey(item.address)
        ].filter(Boolean);
        for (const key of candidates) {
          const point = addressPoints[key];
          if (!point) continue;
          const lon = Number(point.lon ?? point.longitude);
          const lat = Number(point.lat ?? point.latitude);
          if (!Number.isFinite(lon) || !Number.isFinite(lat)) continue;
          return [lon, lat, point.quality || point.source || "address geocode", "address"];
        }
        return null;
      }

      function postcodePointForTransaction(item) {
        const point = postcodePoints[normalisePostcode(item.postcode)];
        if (!point) return null;
        const lon = Number(point.lon ?? point.longitude);
        const lat = Number(point.lat ?? point.latitude);
        if (!Number.isFinite(lon) || !Number.isFinite(lat)) return null;
        return [lon, lat, point.uprnCount ? `postcode centroid (${point.uprnCount} UPRNs)` : "postcode centroid", "postcode"];
      }

      function transactionGeoPoint(item) {
        const addressPoint = addressPointForTransaction(item);
        if (addressPoint) return addressPoint;
        const lon = Number(item.longitude ?? item.lon ?? item.geocode?.longitude ?? item.location?.longitude);
        const lat = Number(item.latitude ?? item.lat ?? item.geocode?.latitude ?? item.location?.latitude);
        if (Number.isFinite(lon) && Number.isFinite(lat)) {
          const precision = normalise(item.coordinatePrecision || item.geocode?.precision || item.location?.precision);
          if (precision.includes("POSTCODE") || precision.includes("CENTROID")) {
            const spread = spreadPoint([lon, lat], item.id, .0018);
            return [spread[0], spread[1], "postcode centroid", "approximate"];
          }
          return [lon, lat, item.coordinateSource || item.geocode?.source || "enriched coordinate", "exact"];
        }
        const postcodePoint = postcodePointForTransaction(item);
        if (postcodePoint) {
          const spread = spreadPoint([postcodePoint[0], postcodePoint[1]], item.id, .0018);
          return [spread[0], spread[1], postcodePoint[2], "approximate"];
        }
        const estate = estateForTransaction(item);
        const estateAnchor = estate ? estateNavigationAnchors.find(anchor => anchor.key === estate.key) : null;
        if (estateAnchor) {
          const spread = spreadPoint([estateAnchor.lon, estateAnchor.lat], item.id, .006);
          return [spread[0], spread[1], "estate approximation", "approximate"];
        }
        const addressRule = addressRuleForTransaction(item);
        if (addressRule) {
          const spread = spreadPoint([addressRule.lon, addressRule.lat], item.id, .0035);
          return [spread[0], spread[1], "address-pattern approximation", "approximate"];
        }
        const town = townGeoPoints[townKey(item.town)];
        if (town) {
          const jitter = deterministicJitter(item.id, .012);
          return [town[0] + jitter[0], town[1] + jitter[1], "town approximation", "approximate"];
        }
        const market = marketById(item.market);
        const centroid = market ? districtGeoPoints[market.district] : null;
        if (centroid) {
          const jitter = deterministicJitter(item.id, .028);
          return [centroid[0] + jitter[0], centroid[1] + jitter[1], "market approximation", "approximate"];
        }
        return [-0.42, 51.28, "fallback approximation", "approximate"];
      }

      function propertyValueUplift(item) {
        const sales = salesHistoryForTransaction(item)
          .filter(sale => Number(sale.price) > 0 && parseIso(String(sale.date || "").slice(0, 10)))
          .sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
        if (sales.length < 2) return null;
        const latestPrice = inflationAdjustedPrice(sales[0]);
        const priorPrice = inflationAdjustedPrice(sales[1]);
        return latestPrice > 0 && priorPrice > 0 ? latestPrice / priorPrice - 1 : null;
      }

      function saleAgeDays(item) {
        const saleDate = parseIso(String(item?.date || "").slice(0, 10));
        if (!saleDate || !analysisEnd) return -1;
        return Math.max(0, Math.round((analysisEnd - saleDate) / (24 * 60 * 60 * 1000)));
      }

      function saleRecencyLabel(days) {
        const value = Number(days);
        if (!Number.isFinite(value) || value < 0) return "Sale date unavailable";
        if (value <= 90) return "Sold within 90 days";
        if (value <= 365) return "Sold within 12 months";
        if (value <= 730) return "Sold 1–2 years ago";
        return "Sold over 2 years ago";
      }

      function propertyFeature(item) {
        const point = transactionGeoPoint(item);
        const marketStatsForItem = marketStats[item.market] || overallStats;
        const planningCount = planningApplicationCount(item);
        const ppsf = Number(item.pricePerSqft || 0);
        const uplift = propertyValueUplift(item);
        const id = propertyId(item.id);
        return {
          type: "Feature",
          id,
          properties: {
            id,
            address: item.address,
            postcode: item.postcode,
            town: item.town,
            market: item.market,
            district: item.district,
            price: item.price,
            priceText: item.priceText,
            date: item.date,
            propertyType: item.propertyType,
            estate: estateForTransaction(item)?.name || "",
            coordinateQuality: point[2],
            coordinateClass: point[3],
            pricePerSqft: ppsf,
            epcRating: String(item.epcRating || "").slice(0, 1).toUpperCase(),
            saleAgeDays: saleAgeDays(item),
            valueUplift: uplift ?? 0,
            hasPriorSale: uplift !== null,
            ppsfAvg: ppsf || marketStatsForItem.ppsfAvg,
            velocityScore: marketStatsForItem.velocityScore,
            momentumScore: marketStatsForItem.momentumScore,
            planningCount,
            planningScore: planningCount,
            priceChange: marketStatsForItem.priceChange,
            avg: item.price
          },
          geometry: { type: "Point", coordinates: [point[0], point[1]] }
        };
      }

      function emptyFeatureCollection() {
        return { type: "FeatureCollection", features: [] };
      }

      function propertyGeoJson() {
        return {
          type: "FeatureCollection",
          features: insightMapRows().map(propertyFeature)
        };
      }

      function insightMapRows() {
        const query = insightQuestion();
        if (!query) return transactions;
        const answer = currentInsightAnswer();
        if (answer?.preserveMap) return transactions;
        if (Array.isArray(answer?.mapRows)) return answer.mapRows;
        return Array.isArray(answer?.rows) ? answer.rows : transactions;
      }

      function updatePropertyMapSource() {
        if (!map) return;
        const source = map.getSource("properties");
        if (source) source.setData(propertyGeoJson());
        updateSelectedPropertyHighlight();
      }

      function selectedPropertyGeoJson() {
        const item = selectedPropertyItem();
        const visible = item && insightMapRows().some(row => propertyId(row.id) === propertyId(item.id));
        return visible ? { type: "FeatureCollection", features: [propertyFeature(item)] } : emptyFeatureCollection();
      }

      function schoolGeoJson() {
        return {
          type: "FeatureCollection",
          features: schools.map(school => ({
            type: "Feature",
            id: schoolId(school),
            properties: {
              id: schoolId(school),
              urn: school.urn || "",
              name: school.name || "School",
              phase: school.phase || "",
              type: school.type || "",
              status: school.status || "",
              postcode: school.postcode || "",
              town: school.town || "",
              pupils: Number(school.pupils || 0),
              capacity: Number(school.capacity || 0),
              lowAge: school.lowAge || "",
              highAge: school.highAge || "",
              gender: school.gender || "",
              admissions: school.admissions || "",
              website: school.website || "",
              lastInspection: school.lastInspection || "",
              inspectorate: school.inspectorate || ""
            },
            geometry: { type: "Point", coordinates: [Number(school.lon), Number(school.lat)] }
          })).filter(feature => Number.isFinite(feature.geometry.coordinates[0]) && Number.isFinite(feature.geometry.coordinates[1]))
        };
      }

      function stationGeoJson() {
        return {
          type: "FeatureCollection",
          features: stationPins.map(station => ({
            type: "Feature",
            id: station.id,
            properties: {
              id: station.id,
              name: station.name,
              crs: station.crs,
              london: station.london,
              fastestMins: station.fastestMins,
              typicalMins: station.typicalMins,
              operator: station.operator
            },
            geometry: { type: "Point", coordinates: [station.lon, station.lat] }
          }))
        };
      }

      function airportGeoJson() {
        return {
          type: "FeatureCollection",
          features: airportPins.map(airport => ({
            type: "Feature",
            id: airport.id,
            properties: {
              id: airport.id,
              name: airport.name,
              type: airport.type,
              driveBaseMins: airport.driveBaseMins
            },
            geometry: { type: "Point", coordinates: [airport.lon, airport.lat] }
          }))
        };
      }

      function estateTransactions(pinOrKey) {
        const key = typeof pinOrKey === "string" ? pinOrKey : pinOrKey.key;
        return transactions.filter(item => estateForTransaction(item)?.key === key);
      }

      function estateActivityRows(pinOrKey) {
        const key = typeof pinOrKey === "string" ? pinOrKey : pinOrKey.key;
        return transactionRows.filter(item => String(item?.estateId || "") === key);
      }

      function estateCenter(pin) {
        return pin && Number.isFinite(Number(pin.lon)) && Number.isFinite(Number(pin.lat))
          ? [Number(pin.lon), Number(pin.lat)]
          : null;
      }

      function estateGeoJson() {
        return {
          type: "FeatureCollection",
          features: estateNavigationAnchors.map(pin => {
            const rows = estateTransactions(pin);
            const stats = statsForEstate(pin);
            const center = estateCenter(pin);
            return {
              type: "Feature",
              id: pin.key,
              properties: {
                id: pin.key,
                name: pin.name,
                market: pin.market,
                count: stats.count,
                avg: Math.round(stats.avg),
                recent: stats.recent,
                recent90: stats.recent90,
                context24: stats.context24,
                velocity: Number(stats.velocity.toFixed(2)),
                velocityConfidence: Number(stats.velocityConfidence.toFixed(2)),
                acceleration: Number(stats.acceleration.toFixed(2)),
                accelerationConfidence: Number(stats.accelerationConfidence.toFixed(2)),
                velocityScore: stats.velocityScore,
                momentumScore: stats.momentumScore,
                ppsfAvg: Math.round(stats.ppsfAvg),
                planningScore: stats.planningApplications,
                priceChange: Number(stats.priceChange.toFixed(3)),
                priceConfidence: Number(stats.priceConfidence.toFixed(2)),
                pricePairCount: stats.pricePairCount,
                priceParentPairCount: stats.priceParentPairCount,
                priceParentLabel: stats.priceParentLabel,
                priceMedianHoldYears: Number(stats.priceMedianHoldYears.toFixed(1)),
                priceSource: stats.priceSource
              },
              geometry: { type: "Point", coordinates: center }
            };
          }).filter(feature => Array.isArray(feature.geometry.coordinates))
        };
      }

      let map;
      let selectedEstatePointId = null;
      window.INSIGHT_BOOT_STAGE = "map";

      if (typeof maplibregl === "undefined") {
        document.getElementById("map").innerHTML = '<div class="empty">Map engine could not load. Check the internet connection for MapLibre.</div>';
      } else {
        map = new maplibregl.Map({
          container: "map",
          style: {
            version: 8,
            glyphs: "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
            sources: {
              cartoLight: {
                type: "raster",
                tiles: [
                  "https://a.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}.png",
                  "https://b.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}.png",
                  "https://c.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}.png"
                ],
                tileSize: 256,
                attribution: "Map data OpenStreetMap and CARTO"
              },
              cartoDark: {
                type: "raster",
                tiles: [
                  "https://a.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}.png",
                  "https://b.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}.png",
                  "https://c.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}.png"
                ],
                tileSize: 256,
                attribution: "Map data OpenStreetMap and CARTO"
              }
            },
            layers: [
              { id: "carto-light-base", type: "raster", source: "cartoLight", layout: { visibility: state.resolvedTheme === "dark" ? "none" : "visible" } },
              { id: "carto-dark-base", type: "raster", source: "cartoDark", layout: { visibility: state.resolvedTheme === "dark" ? "visible" : "none" } }
            ]
          },
          center: [-0.43, 51.29],
          zoom: mapZoomFromDisplay(defaultZoomLevel),
          padding: overviewMapPadding,
          minZoom: zoomMin,
          maxZoom: zoomMax,
          maxBounds: [[-1.05, 50.98], [0.22, 51.56]]
        });

        map.on("load", () => {
          addMapImages();
          addInsightSources();
          addInsightLayers();
          raiseSelectedPropertyLayers();
          bindMapEvents();
          applyLayerVisibility();
          applyThemeToMap();
          renderAll();
        });

        map.on("zoom", updateZoomUi);
        map.on("moveend", applyMapStateToMap);
      }
      window.INSIGHT_BOOT_STAGE = "analyst";

      function refreshMapImages() {
        if (!mapStyleReady()) return;
        ["estate-gate", "school-book", "station-rail", "airport-plane"].forEach(name => {
          if (map.hasImage(name)) map.removeImage(name);
        });
        addMapImages();
      }

      function addMapImages() {
        const size = 96;
        const stroke = state.resolvedTheme === "dark" ? "#7bbcff" : "#005f9f";
        const shadow = state.resolvedTheme === "dark" ? "rgba(0,0,0,.34)" : "rgba(15,23,42,.14)";

        function roundedRect(context, x, y, width, height, radius) {
          context.moveTo(x + radius, y);
          context.lineTo(x + width - radius, y);
          context.quadraticCurveTo(x + width, y, x + width, y + radius);
          context.lineTo(x + width, y + height - radius);
          context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
          context.lineTo(x + radius, y + height);
          context.quadraticCurveTo(x, y + height, x, y + height - radius);
          context.lineTo(x, y + radius);
          context.quadraticCurveTo(x, y, x + radius, y);
        }

        function markerCanvas() {
          const canvas = document.createElement("canvas");
          canvas.width = size;
          canvas.height = size;
          const context = canvas.getContext("2d");
          context.clearRect(0, 0, size, size);
          context.save();
          context.shadowColor = shadow;
          context.shadowBlur = 8;
          context.shadowOffsetY = 3;
          context.strokeStyle = stroke;
          context.lineWidth = 4;
          context.lineCap = "round";
          context.lineJoin = "round";
          context.beginPath();
          context.moveTo(48, 86);
          context.bezierCurveTo(44, 81, 23, 61, 23, 39);
          context.bezierCurveTo(23, 25, 34, 14, 48, 14);
          context.bezierCurveTo(62, 14, 73, 25, 73, 39);
          context.bezierCurveTo(73, 61, 52, 81, 48, 86);
          context.closePath();
          context.stroke();
          context.restore();
          context.strokeStyle = stroke;
          context.lineWidth = 3;
          context.lineCap = "round";
          context.lineJoin = "round";
          context.stroke();
          return context;
        }

        if (!map.hasImage("estate-gate")) {
          const context = markerCanvas();
          context.beginPath();
          context.moveTo(35, 43);
          context.lineTo(48, 31);
          context.lineTo(61, 43);
          context.lineTo(61, 57);
          context.lineTo(35, 57);
          context.closePath();
          context.moveTo(43, 57);
          context.lineTo(43, 47);
          context.lineTo(53, 47);
          context.lineTo(53, 57);
          context.stroke();
          map.addImage("estate-gate", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
        if (!map.hasImage("school-book")) {
          const context = markerCanvas();
          context.beginPath();
          context.moveTo(34, 39);
          context.lineTo(48, 33);
          context.lineTo(62, 39);
          context.lineTo(48, 45);
          context.closePath();
          context.moveTo(39, 43);
          context.lineTo(39, 51);
          context.quadraticCurveTo(48, 58, 57, 51);
          context.lineTo(57, 43);
          context.moveTo(62, 40);
          context.lineTo(62, 52);
          context.stroke();
          map.addImage("school-book", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
        if (!map.hasImage("station-rail")) {
          const context = markerCanvas();
          context.beginPath();
          roundedRect(context, 37, 28, 22, 29, 5);
          context.stroke();
          context.beginPath();
          context.moveTo(42, 36);
          context.lineTo(54, 36);
          context.moveTo(41, 46);
          context.lineTo(55, 46);
          context.stroke();
          context.fillStyle = stroke;
          context.beginPath();
          context.arc(42, 52, 2.2, 0, Math.PI * 2);
          context.arc(54, 52, 2.2, 0, Math.PI * 2);
          context.fill();
          context.strokeStyle = stroke;
          context.lineWidth = 2.3;
          context.beginPath();
          context.moveTo(42, 59);
          context.lineTo(38, 63);
          context.moveTo(54, 59);
          context.lineTo(58, 63);
          context.stroke();
          map.addImage("station-rail", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
        if (!map.hasImage("airport-plane")) {
          const context = markerCanvas();
          context.fillStyle = stroke;
          context.beginPath();
          context.moveTo(48, 27);
          context.bezierCurveTo(50, 27, 51, 29, 51, 31);
          context.lineTo(51, 41);
          context.lineTo(62, 48);
          context.lineTo(62, 52);
          context.lineTo(51, 49);
          context.lineTo(51, 56);
          context.lineTo(55, 59);
          context.lineTo(55, 62);
          context.lineTo(48, 60);
          context.lineTo(41, 62);
          context.lineTo(41, 59);
          context.lineTo(45, 56);
          context.lineTo(45, 49);
          context.lineTo(34, 52);
          context.lineTo(34, 48);
          context.lineTo(45, 41);
          context.lineTo(45, 31);
          context.bezierCurveTo(45, 29, 46, 27, 48, 27);
          context.closePath();
          context.fill();
          map.addImage("airport-plane", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
      }

      function addInsightSources() {
        map.addSource("county-outline", { type: "geojson", data: countyOutlineGeoJson(), tolerance: 0, buffer: 128, maxzoom: 18 });
        map.addSource("markets", { type: "geojson", data: marketGeoJson(), promoteId: "id", tolerance: 0, buffer: 256, maxzoom: 18 });
        map.addSource("towns", { type: "geojson", data: townGeoJson(), promoteId: "id", tolerance: 0, buffer: 128, maxzoom: 18 });
        map.addSource("properties", { type: "geojson", data: propertyGeoJson(), promoteId: "id" });
        map.addSource("selected-property", { type: "geojson", data: selectedPropertyGeoJson(), promoteId: "id" });
        map.addSource("estates", { type: "geojson", data: estateGeoJson(), promoteId: "id" });
        map.addSource("stations", { type: "geojson", data: stationGeoJson(), promoteId: "id" });
        map.addSource("airports", { type: "geojson", data: airportGeoJson(), promoteId: "id" });
        map.addSource("schools", { type: "geojson", data: schoolGeoJson(), promoteId: "id" });
      }

      function addInsightLayers() {
        map.addLayer({
          id: "county-outline",
          type: "line",
          source: "county-outline",
          paint: {
            "line-color": mapTextPaint().outline,
            "line-opacity": ["interpolate", ["linear"], ["zoom"], 7, .18, 12, .24, 17, .16],
            "line-width": ["interpolate", ["linear"], ["zoom"], 7, 1.1, 13, 1.7, 17, 1.2]
          }
        });
        map.addLayer({
          id: "market-fill",
          type: "fill",
          source: "markets",
          maxzoom: 13.6,
          paint: {
            "fill-color": colourExpression(state.renderMode),
            "fill-opacity": ["interpolate", ["linear"], ["zoom"], 7, .25, 10, .2, 11.6, .08, 13.2, 0]
          }
        });
        map.addLayer({
          id: "market-hover-glow",
          type: "fill",
          source: "markets",
          maxzoom: 13.6,
          paint: {
            "fill-color": colourExpression(state.renderMode),
            "fill-opacity": ["interpolate", ["linear"], ["zoom"],
              7, ["case", ["boolean", ["feature-state", "hover"], false], .125, 0],
              10, ["case", ["boolean", ["feature-state", "hover"], false], .1, 0],
              11.6, ["case", ["boolean", ["feature-state", "hover"], false], .04, 0],
              13.2, 0]
          }
        });
        map.addLayer({
          id: "market-hover-outline",
          type: "line",
          source: "markets",
          paint: {
            "line-color": colourExpression(state.renderMode),
            "line-opacity": ["interpolate", ["linear"], ["zoom"],
              7, ["case", ["boolean", ["feature-state", "hover"], false], .62, 0],
              13, ["case", ["boolean", ["feature-state", "hover"], false], .36, 0],
              16, ["case", ["boolean", ["feature-state", "hover"], false], .18, 0]],
            "line-width": ["interpolate", ["linear"], ["zoom"], 7, 2.4, 12, 3.2, 16, 2],
            "line-blur": 1.4
          }
        });
        map.addLayer({
          id: "market-outline",
          type: "line",
          source: "markets",
          paint: {
            "line-color": mapTextPaint().outline,
            "line-opacity": ["interpolate", ["linear"], ["zoom"], 7, .28, 12, .24, 15, .12],
            "line-width": ["interpolate", ["linear"], ["zoom"], 7, .65, 12, 1.1, 16, .65]
          }
        });
        map.addLayer({
          id: "town-fill",
          type: "fill",
          source: "towns",
          minzoom: 10.4,
          maxzoom: 14.2,
          paint: {
            "fill-color": colourExpression(state.renderMode),
            "fill-opacity": ["interpolate", ["linear"], ["zoom"], 10.4, 0, 11.4, .1, 12.8, .13, 13.8, 0]
          }
        });
        map.addLayer({
          id: "town-hover-glow",
          type: "fill",
          source: "towns",
          minzoom: 10.4,
          maxzoom: 14.2,
          paint: {
            "fill-color": colourExpression(state.renderMode),
            "fill-opacity": ["interpolate", ["linear"], ["zoom"],
              10.4, 0,
              11.4, ["case", ["boolean", ["feature-state", "hover"], false], .05, 0],
              12.8, ["case", ["boolean", ["feature-state", "hover"], false], .065, 0],
              13.8, 0]
          }
        });
        map.addLayer({
          id: "town-hover-outline",
          type: "line",
          source: "towns",
          minzoom: 10.4,
          maxzoom: 14.7,
          paint: {
            "line-color": colourExpression(state.renderMode),
            "line-opacity": ["interpolate", ["linear"], ["zoom"],
              10.4, 0,
              11.5, ["case", ["boolean", ["feature-state", "hover"], false], .58, 0],
              14.6, 0],
            "line-width": ["interpolate", ["linear"], ["zoom"], 10.4, 1.7, 14, 2.8],
            "line-blur": 1.2
          }
        });
        map.addLayer({
          id: "town-outline",
          type: "line",
          source: "towns",
          minzoom: 10.4,
          maxzoom: 14.7,
          paint: {
            "line-color": colourExpression(state.renderMode),
            "line-opacity": ["interpolate", ["linear"], ["zoom"], 10.4, 0, 11.5, .34, 13.8, .18, 14.6, 0],
            "line-width": ["interpolate", ["linear"], ["zoom"], 10.4, .6, 14, 1.4]
          }
        });
        map.addLayer({
          id: "market-labels",
          type: "symbol",
          source: "markets",
          minzoom: 7,
          maxzoom: 12.8,
          layout: {
            "text-field": ["concat", ["get", "name"], "\n", ["to-string", ["get", "count"]], " sales"],
            "text-font": ["Open Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 7, 11, 11, 13],
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#243045",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.5,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 7, .9, 12, .65, 13, 0]
          }
        });
        map.addLayer({
          id: "town-labels",
          type: "symbol",
          source: "towns",
          minzoom: 10.8,
          maxzoom: 15.2,
          layout: {
            "text-field": ["concat", ["get", "name"], "\n", ["to-string", ["get", "count"]], " sales"],
            "text-font": ["Open Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 10.8, 10.5, 14, 12],
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#1f2937",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.35,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 10.8, .0, 11.5, .85, 15.2, .2]
          }
        });
        map.addLayer({
          id: "property-halo",
          type: "circle",
          source: "selected-property",
          minzoom: 10.4,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 10.4, 3.8, 11.8, 5.4, 15, 8.2, 18, 11],
            "circle-color": "#ffffff",
            "circle-opacity": propertyHaloOpacityExpression(),
            "circle-blur": .48
          }
        });
        map.addLayer({
          id: "property-points",
          type: "circle",
          source: "properties",
          minzoom: 10.4,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 10.4, 1, 11.4, 2.2, 14, 4.2, 17, 6.5],
            "circle-color": propertyColourExpression(),
            "circle-stroke-color": "#ffffff",
            "circle-stroke-width": ["interpolate", ["linear"], ["zoom"], 10.4, 0, 11.6, .8, 16, 1.5],
            "circle-opacity": propertyPointOpacityExpression()
          }
        });
        map.addLayer({
          id: "selected-property-glow",
          type: "circle",
          source: "selected-property",
          minzoom: 10.4,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 10.4, 4.8, 13, 7.4, 16, 10.8, 18, 14.4],
            "circle-color": "#ffffff",
            "circle-opacity": ["interpolate", ["linear"], ["zoom"], 10.4, .38, 14, .46, 18, .54],
            "circle-blur": .72
          }
        });
        map.addLayer({
          id: "selected-property-ring",
          type: "circle",
          source: "selected-property",
          minzoom: 10.4,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 10.4, 3.6, 13, 6.2, 16, 8.8, 18, 11.5],
            "circle-color": "rgba(255, 255, 255, .08)",
            "circle-stroke-color": "#ffffff",
            "circle-stroke-width": ["interpolate", ["linear"], ["zoom"], 10.4, 1.2, 14, 1.8, 18, 2.3],
            "circle-opacity": .92
          }
        });
        map.addLayer({
          id: "selected-property-core",
          type: "circle",
          source: "selected-property",
          minzoom: 10.4,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 10.4, 3.2, 14, 5.2, 18, 8],
            "circle-color": propertyColourExpression(),
            "circle-stroke-color": "#ffffff",
            "circle-stroke-width": ["interpolate", ["linear"], ["zoom"], 10.4, 1.1, 16, 1.8],
            "circle-opacity": 1
          }
        });
        map.addLayer({
          id: "estate-hover-glow",
          type: "circle",
          source: "estates",
          minzoom: 8.7,
          maxzoom: 15,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 8.7, 15, 12, 24, 15, 34],
            "circle-color": "#ffffff",
            "circle-opacity": ["interpolate", ["linear"], ["zoom"],
              8.7, ["case", ["any", ["boolean", ["feature-state", "hover"], false], ["boolean", ["feature-state", "selected"], false]], .46, 0],
              12, ["case", ["any", ["boolean", ["feature-state", "hover"], false], ["boolean", ["feature-state", "selected"], false]], .58, 0],
              15, 0],
            "circle-blur": .8
          }
        });
        map.addLayer({
          id: "estate-points",
          type: "symbol",
          source: "estates",
          minzoom: 8.7,
          maxzoom: 15,
          layout: {
            "icon-image": "estate-gate",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 8.7, .8, 13, 1.16, 15, 1.36],
            "icon-allow-overlap": true,
            "icon-ignore-placement": true
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 8.7, .92, 14.4, .92, 15, 0]
          }
        });
        map.addLayer({
          id: "estate-labels",
          type: "symbol",
          source: "estates",
          minzoom: 9.4,
          maxzoom: 15,
          layout: {
            "text-field": ["get", "name"],
            "text-font": ["Open Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 9.4, 10, 15, 12],
            "text-offset": [0, 1.25],
            "text-anchor": "top",
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#172033",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.25
          }
        });
        map.addLayer({
          id: "station-points",
          type: "symbol",
          source: "stations",
          minzoom: 11.2,
          layout: {
            "icon-image": "station-rail",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 11.2, .8, 13, 1.04, 16, 1.28],
            "icon-allow-overlap": false,
            "icon-ignore-placement": false
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 11.2, .78, 14, .94]
          }
        });
        map.addLayer({
          id: "station-labels",
          type: "symbol",
          source: "stations",
          minzoom: 12.8,
          layout: {
            "text-field": ["get", "name"],
            "text-font": ["Open Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 12.8, 10, 16, 11.5],
            "text-offset": [0, 1.15],
            "text-anchor": "top",
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#172033",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.25,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 12.8, .62, 16, .92]
          }
        });
        map.addLayer({
          id: "airport-points",
          type: "symbol",
          source: "airports",
          minzoom: 8.8,
          layout: {
            "icon-image": "airport-plane",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 8.8, .76, 12, 1, 15, 1.24],
            "icon-allow-overlap": true,
            "icon-ignore-placement": true
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 8.8, .86, 14, .95]
          }
        });
        map.addLayer({
          id: "airport-labels",
          type: "symbol",
          source: "airports",
          minzoom: 9.6,
          layout: {
            "text-field": ["get", "name"],
            "text-font": ["Open Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 9.6, 10, 15, 12],
            "text-offset": [0, 1.15],
            "text-anchor": "top",
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#172033",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.25,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 9.6, .72, 15, .92]
          }
        });
        map.addLayer({
          id: "school-points",
          type: "symbol",
          source: "schools",
          minzoom: 13,
          layout: {
            "icon-image": "school-book",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 13, .84, 14.5, 1.04, 16, 1.24],
            "icon-allow-overlap": false,
            "icon-ignore-placement": false
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 13, .9, 15, .96]
          }
        });
        map.addLayer({
          id: "school-labels",
          type: "symbol",
          source: "schools",
          minzoom: 14.2,
          layout: {
            "text-field": ["get", "name"],
            "text-font": ["Open Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 14.2, 10, 16, 11.5],
            "text-offset": [0, 1.15],
            "text-anchor": "top",
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#172033",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.25,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 14.2, .65, 16, .92]
          }
        });
      }

      function bindMapEvents() {
        const hoverLayers = ["selected-property-core", "property-points", "estate-points", "station-points", "airport-points", "school-points", "town-fill", "market-fill"];
        hoverLayers.forEach(layer => {
          map.on("mouseenter", layer, () => { map.getCanvas().style.cursor = "pointer"; });
          map.on("mouseleave", layer, () => { map.getCanvas().style.cursor = ""; });
        });
        map.on("mousemove", event => {
          const availableHoverLayers = hoverLayers.filter(layer => map.getLayer(layer));
          const features = map.queryRenderedFeatures(event.point, { layers: availableHoverLayers });
          const feature = features[0];
          if (!feature) {
            clearHoveredMapFeature();
            hideMapTooltip();
            return;
          }
          const glowFeature = features.find(item => hoverSourceForFeature(item));
          setHoveredMapFeature(glowFeature || feature);
          showMapTooltip(event.point, hoverContentForFeature(feature));
        });
        map.on("mouseout", () => {
          clearHoveredMapFeature();
          hideMapTooltip();
        });
        map.on("click", event => {
          const features = map.queryRenderedFeatures(event.point, { layers: ["property-points", "station-points", "airport-points", "school-points", "estate-points", "town-fill", "market-fill"] });
          if (!features.length) {
            resetMap();
            return;
          }
          const feature = features[0];
          if (feature.layer.id === "property-points") selectProperty(feature.properties.id);
          if (feature.layer.id === "station-points") selectStation(feature.properties.id);
          if (feature.layer.id === "airport-points") selectAirport(feature.properties.id);
          if (feature.layer.id === "school-points") selectSchool(feature.properties.id);
          if (feature.layer.id === "estate-points") selectEstate(feature.properties.id);
          if (feature.layer.id === "town-fill") selectTown(feature.properties.id);
          if (feature.layer.id === "market-fill") selectMarket(feature.properties.id);
        });
      }

      function hoverSourceForFeature(feature) {
        const layer = feature?.layer?.id || "";
        if (layer === "market-fill") return "markets";
        if (layer === "town-fill") return "towns";
        if (layer === "estate-points") return "estates";
        return "";
      }

      function clearHoveredMapFeature() {
        if (!state.hoveredFeature || !map) return;
        map.setFeatureState(state.hoveredFeature, { hover: false });
        state.hoveredFeature = null;
      }

      function setHoveredMapFeature(feature) {
        const source = hoverSourceForFeature(feature);
        const id = feature?.id ?? feature?.properties?.id;
        if (!source || id === undefined || id === null) {
          clearHoveredMapFeature();
          return;
        }
        const next = { source, id };
        if (state.hoveredFeature && state.hoveredFeature.source === source && String(state.hoveredFeature.id) === String(id)) return;
        clearHoveredMapFeature();
        state.hoveredFeature = next;
        map.setFeatureState(next, { hover: true });
      }

      function showMapTooltip(point, content) {
        if (!els.hoverTooltip || !content) {
          hideMapTooltip();
          return;
        }
        els.hoverTooltip.innerHTML = `<strong>${escapeHtml(content.title)}</strong><span>${escapeHtml(content.detail)}</span>`;
        els.hoverTooltip.classList.add("visible");
        els.hoverTooltip.setAttribute("aria-hidden", "false");
        const bounds = map.getContainer().getBoundingClientRect();
        const x = Math.min(point.x + 14, Math.max(14, bounds.width - 236));
        const y = Math.min(Math.max(14, point.y + 14), Math.max(14, bounds.height - 96));
        els.hoverTooltip.style.transform = `translate(${x}px, ${y}px)`;
      }

      function hideMapTooltip() {
        if (!els.hoverTooltip) return;
        els.hoverTooltip.classList.remove("visible");
        els.hoverTooltip.setAttribute("aria-hidden", "true");
        els.hoverTooltip.style.transform = "translate(-999px, -999px)";
      }

      function currentRenderModeLabel() {
        return renderModeLabels[state.renderMode] || "Velocity";
      }

      function modeDetailForProperties(properties) {
        const mode = state.renderMode;
        if (mode === "value") return `Average ${compactPrice(properties.avg)}`;
        if (mode === "ppsf") return Number(properties.ppsfAvg) > 0 ? `${compactPpsf(properties.ppsfAvg)} average` : "Awaiting EPC";
        if (mode === "growth") return `${priceMovementLabel(properties)} · ${priceMovementEvidenceLabel(properties)}`;
        if (mode === "planning") return `${formatNumber(properties.planningScore || 0)} matched property applications`;
        if (mode === "momentum") return `${Number(properties.momentumScore || 0)}/100 · ${momentumRating(properties.momentumScore)}`;
        return `${Number(properties.velocityScore || 0)}/100 · ${velocityRating(properties.velocityScore)} · ${Number(properties.velocity || 0).toFixed(2)}x normal · ${accelerationLabel(properties)} · ${velocityConfidenceLabel(properties)}`;
      }

      function hoverContentForFeature(feature) {
        const props = feature.properties || {};
        const layer = feature.layer?.id || "";
        if (layer.includes("property")) {
          const title = String(props.address || "").split(",")[0].trim() || props.postcode || "Property";
          if (state.propertyRenderMode === "planning") {
            const count = Number(props.planningCount || 0);
            return { title, detail: `${formatNumber(count)} matched planning ${count === 1 ? "application" : "applications"} on this property file` };
          }
          if (state.propertyRenderMode === "ppsf") {
            return { title, detail: Number(props.pricePerSqft) > 0 ? compactPpsf(props.pricePerSqft) : "Price per sqft unavailable · awaiting EPC floor area" };
          }
          if (state.propertyRenderMode === "epc") {
            return { title, detail: props.epcRating ? `EPC rating ${props.epcRating}` : "EPC rating unavailable" };
          }
          if (state.propertyRenderMode === "recency") {
            return { title, detail: `${saleRecencyLabel(props.saleAgeDays)}${props.date ? ` · ${formatDate(props.date)}` : ""}` };
          }
          if (state.propertyRenderMode === "uplift") {
            return { title, detail: props.hasPriorSale ? `${signedPercent(Number(props.valueUplift), 1)} real uplift since prior sale` : "No prior sale loaded" };
          }
          const meta = [props.priceText, props.date ? formatDate(props.date) : "", props.pricePerSqft ? compactPpsf(props.pricePerSqft) : ""].filter(Boolean).join(" · ");
          return { title, detail: meta || "Land Registry sale" };
        }
        if (layer === "estate-points") {
          return { title: props.name || "Private Estate", detail: `${currentRenderModeLabel()} · ${modeDetailForProperties(props)}` };
        }
        if (layer === "town-fill" || layer === "market-fill") {
          return { title: props.name || "Market", detail: `${currentRenderModeLabel()} · ${modeDetailForProperties(props)}` };
        }
        if (layer === "school-points") {
          return { title: props.name || "School", detail: [props.type, props.phase, props.postcode].filter(Boolean).join(" · ") || "School" };
        }
        if (layer === "station-points") {
          return { title: props.name || "Station", detail: `${props.london || "London"} · c. ${formatMinutes(props.fastestMins)} fastest` };
        }
        if (layer === "airport-points") {
          return { title: props.name || "Airport", detail: props.type || "Airport" };
        }
        return null;
      }

      function applyLayerVisibility() {
        if (!map) return;
        layerRegistry.forEach(group => {
          const visible = state.layers[group.id] ? "visible" : "none";
          group.layers.forEach(layerId => {
            if (map.getLayer(layerId)) map.setLayoutProperty(layerId, "visibility", visible);
          });
        });
      }

      function applyRenderMode() {
        if (!map) {
          renderLegend();
          return;
        }
        const expression = colourExpression(state.renderMode);
        ["market-fill", "market-hover-glow", "town-fill", "town-hover-glow"].forEach(layer => {
          if (map.getLayer(layer)) map.setPaintProperty(layer, "fill-color", expression);
        });
        ["market-hover-outline", "town-outline", "town-hover-outline"].forEach(layer => {
          if (map.getLayer(layer)) map.setPaintProperty(layer, "line-color", expression);
        });
        const propertyExpression = propertyColourExpression();
        if (map.getLayer("property-points")) map.setPaintProperty("property-points", "circle-color", propertyExpression);
        if (map.getLayer("selected-property-core")) map.setPaintProperty("selected-property-core", "circle-color", propertyExpression);
        if (map.getLayer("property-halo")) map.setPaintProperty("property-halo", "circle-color", "#ffffff");
        applyPropertySelectionOpacity();
        renderLegend();
      }

      function applyPropertySelectionOpacity() {
        if (map.getLayer("property-points")) map.setPaintProperty("property-points", "circle-opacity", propertyPointOpacityExpression());
        if (map.getLayer("property-halo")) map.setPaintProperty("property-halo", "circle-opacity", propertyHaloOpacityExpression());
      }

      function updateSelectedPropertyHighlight() {
        if (!map) return;
        const source = map.getSource("selected-property");
        if (source) source.setData(selectedPropertyGeoJson());
        raiseSelectedPropertyLayers();
      }

      function raiseSelectedPropertyLayers() {
        ["property-halo", "selected-property-glow", "selected-property-ring", "selected-property-core"].forEach(layer => {
          if (map.getLayer(layer)) map.moveLayer(layer);
        });
      }

      function insightQuestion() {
        return String(state.search || "").trim();
      }

      function outwardPostcode(value) {
        return normalisePostcode(value).replace(/\d[A-Z]{2}$/, "");
      }

      function rowInsightText(item) {
        const estate = estateForTransaction(item);
        const schoolNames = (item.ofsted?.nearestSchools || []).map(school => school.name).join(" ");
        const planningText = (item.planning?.recentApplications || []).map(app => [app.description, app.reference, app.status, app.decision].join(" ")).join(" ");
        return normalise([
          item.address,
          item.postcode,
          outwardPostcode(item.postcode),
          item.town,
          item.district,
          marketById(item.market)?.short,
          marketById(item.market)?.name,
          estate?.name,
          item.propertyType,
          item.epcRating,
          item.environmentAgency?.floodStatus,
          item.planning?.latestApplication,
          item.planning?.latestDecision,
          schoolNames,
          planningText
        ].filter(Boolean).join(" "));
      }

      function moneyToNumber(value, unit = "", assumeMillions = false) {
        const number = Number(value);
        if (!Number.isFinite(number)) return 0;
        const cleanUnit = normalise(unit);
        if (cleanUnit.includes("M") || cleanUnit.includes("MILLION")) return Math.round(number * 1000000);
        if (cleanUnit.includes("K")) return Math.round(number * 1000);
        if (number >= 1000000) return Math.round(number);
        if (assumeMillions && number < 100) return Math.round(number * 1000000);
        return Math.round(number);
      }

      function moneyValuesFromQuery(query, assumeMillions = false) {
        const values = [];
        const text = String(query || "");
        let match;
        const explicit = /£\s*(\d[\d,]*(?:\.\d+)?)\s*(m|mn|million|k)?|\b(\d[\d,]*(?:\.\d+)?)\s*(m|mn|million|k)\b/gi;
        while ((match = explicit.exec(text))) {
          const raw = String(match[1] || match[3]).replace(/,/g, "");
          const unit = match[2] || match[4] || "";
          const numeric = Number(raw);
          const explicitlyMoney = match[0].includes("£") || Boolean(unit);
          if (!explicitlyMoney && Number.isInteger(numeric) && numeric >= 1900 && numeric <= 2099) continue;
          const value = moneyToNumber(raw, unit, assumeMillions);
          if (value) values.push(value);
        }
        const large = /\b(\d{1,3}(?:,\d{3}){2,}|\d{7,})\b/g;
        while ((match = large.exec(text))) {
          const value = Number(match[1].replace(/,/g, ""));
          if (Number.isFinite(value)) values.push(value);
        }
        return Array.from(new Set(values)).sort((a, b) => a - b);
      }

      function ppsfValuesFromQuery(query) {
        const qn = normalise(query);
        if (!qn.includes("PSF") && !qn.includes("PER SQ") && !qn.includes("PRICE PER") && !(String(query).includes("£") && (qn.includes("SQFT") || qn.includes("SQ FT")))) return [];
        const values = [];
        let match;
        const pattern = /£?\s*(\d[\d,]{2,6})(?:\s*(?:\/|per)?\s*(?:sq\s*ft|sqft|square\s*foot|psf))/gi;
        while ((match = pattern.exec(query))) {
          const value = Number(match[1].replace(/,/g, ""));
          if (Number.isFinite(value)) values.push(value);
        }
        return Array.from(new Set(values)).sort((a, b) => a - b);
      }

      function sqftValuesFromQuery(query) {
        const values = [];
        let match;
        const pattern = /\b(\d[\d,]{2,7})\s*(?:sq\s*ft|sqft|square\s*feet)\b/gi;
        while ((match = pattern.exec(query))) {
          const value = Number(match[1].replace(/,/g, ""));
          if (Number.isFinite(value)) values.push(value);
        }
        return Array.from(new Set(values)).sort((a, b) => a - b);
      }

      function rangeFromValues(query, values) {
        const qn = normalise(query);
        if (!values.length) return null;
        if ((qn.includes("BETWEEN") || qn.includes("FROM")) && values.length >= 2) {
          return { min: values[0], max: values[values.length - 1] };
        }
        if (qn.includes("UNDER") || qn.includes("BELOW") || qn.includes("LESS THAN") || qn.includes("UP TO") || qn.includes("CHEAPER THAN")) {
          return { max: values[0] };
        }
        if (qn.includes("OVER") || qn.includes("ABOVE") || qn.includes("MORE THAN") || qn.includes("GREATER THAN") || qn.includes("PLUS") || query.includes("+")) {
          return { min: values[0] };
        }
        return values.length >= 2 ? { min: values[0], max: values[values.length - 1] } : { exact: values[0] };
      }

      function dateRangeFromQuery(query) {
        const qn = normalise(query);
        const years = Array.from(new Set((query.match(/\b(?:19[5-9]\d|20\d{2})\b/g) || []).map(Number))).sort((a, b) => a - b);
        const rolling = String(query || "").match(/\b(?:last|past|previous)\s+(\d{1,3})\s*(months?|years?)\b/i);
        if (rolling) {
          const count = Number(rolling[1]);
          const months = /^year/i.test(rolling[2]) ? count * 12 : count;
          return { from: addMonths(analysisEnd, -months), to: analysisEnd, label: `last ${count} ${rolling[2].toLowerCase()}` };
        }
        if (qn.includes("LAST 12") || qn.includes("PAST 12") || qn.includes("PAST YEAR") || qn.includes("LAST YEAR")) {
          return { from: addMonths(analysisEnd, -12), to: analysisEnd, label: "last 12 months" };
        }
        if (!years.length) return null;
        if (years.length >= 2 && (qn.includes("BETWEEN") || qn.includes("FROM") || /\b(?:19[5-9]\d|20\d{2})\s*(?:TO|-|–)\s*(?:19[5-9]\d|20\d{2})\b/i.test(query))) {
          return { from: parseIso(`${years[0]}-01-01`), to: parseIso(`${years[years.length - 1]}-12-31`), label: `${years[0]}-${years[years.length - 1]}` };
        }
        const year = years[0];
        if (qn.includes("SINCE") || qn.includes("AFTER") || qn.includes("FROM")) {
          return { from: parseIso(`${year}-01-01`), to: analysisEnd, label: `since ${year}` };
        }
        if (qn.includes("BEFORE") || qn.includes("PRIOR TO") || qn.includes("OLDER THAN")) {
          return { from: analysisStart, to: parseIso(`${year}-01-01`), label: `before ${year}` };
        }
        return { from: parseIso(`${year}-01-01`), to: parseIso(`${year}-12-31`), label: String(year) };
      }

      function propertyTypeFromQuery(query) {
        const qn = normalise(query);
        if (qn.includes("APARTMENT") || qn.includes("APARTMENTS") || qn.includes("FLAT") || qn.includes("FLATS")) return { label: "apartments", test: item => normalise(item.propertyType).includes("FLAT") || normalise(item.propertyType).includes("APARTMENT") };
        if (qn.includes("SEMI")) return { label: "semi-detached", test: item => normalise(item.propertyType).includes("SEMI") };
        if (qn.includes("DETACHED") || qn.includes("DETATCHED")) return { label: "detached", test: item => normalise(item.propertyType).includes("DETACHED") && !normalise(item.propertyType).includes("SEMI") };
        if (qn.includes("TERRACE") || qn.includes("TERRACED")) return { label: "terraced", test: item => normalise(item.propertyType).includes("TERRACE") };
        return null;
      }

      const insightQueryStopWords = new Set(normalise("a an and are as at be by can could did do does for from give has have how i in is it me most of on only or please properties property sale sales show than that the their there these this to was were what when where which who with would you").split(" "));

      function insightQueryTokens(value) {
        return normalise(value).split(" ").filter(token => token.length > 1 && !insightQueryStopWords.has(token));
      }

      function editDistance(left, right) {
        const a = normalise(left).replace(/\s+/g, "");
        const b = normalise(right).replace(/\s+/g, "");
        if (!a) return b.length;
        if (!b) return a.length;
        const row = Array.from({ length: b.length + 1 }, (_, index) => index);
        for (let i = 1; i <= a.length; i += 1) {
          let previous = row[0];
          row[0] = i;
          for (let j = 1; j <= b.length; j += 1) {
            const current = row[j];
            row[j] = Math.min(row[j] + 1, row[j - 1] + 1, previous + (a[i - 1] === b[j - 1] ? 0 : 1));
            previous = current;
          }
        }
        return row[b.length];
      }

      function fuzzyEntityMention(query, candidate) {
        const qn = normalise(query);
        const name = normalise(candidate);
        if (!name || name.length < 4) return false;
        if (qn.includes(name)) return true;
        const queryTokens = qn.split(" ").filter(Boolean);
        const nameTokens = name.split(" ").filter(token => token.length > 2);
        if (!nameTokens.length) return false;
        return nameTokens.every(nameToken => queryTokens.some(queryToken => {
          if (queryToken.length < 4 || Math.abs(queryToken.length - nameToken.length) > 2) return false;
          return editDistance(queryToken, nameToken) <= Math.max(1, Math.floor(nameToken.length / 7));
        }));
      }

      function distanceRadiusKmFromQuery(query, fallback) {
        const match = String(query || "").match(/\b(?:within|inside|under|less than)?\s*(\d+(?:\.\d+)?)\s*(km|kilomet(?:er|re)s?|mi|mile|miles)\b/i);
        if (!match) return fallback;
        const value = Number(match[1]);
        return /^(mi|mile)/i.test(match[2]) ? value * 1.609344 : value;
      }

      function topCountFromQuery(query, fallback = 8) {
        const match = normalise(query).match(/\b(?:TOP|BOTTOM|FIRST|BEST|WORST)\s+(\d{1,2})\b/);
        return match ? clamp(1, 20, Number(match[1])) : fallback;
      }

      function minimumSampleFromQuery(query, fallback = 0) {
        const match = String(query || "").match(/\b(?:at least|minimum|min\.?|requiring)\s+(\d{1,3})\b/i);
        return match ? Number(match[1]) : fallback;
      }

      function ppsfRequested(query) {
        const qn = normalise(query);
        return qn.includes("PSF") || qn.includes("PER SQ") || qn.includes("PRICE PER") || ((String(query).includes("£") || qn.includes("POUND")) && (qn.includes("SQFT") || qn.includes("SQ FT") || qn.includes("SQUARE FOOT")));
      }

      function insightIntent(query) {
        const qn = normalise(query);
        if (qn.includes("MOMENTUM")) return "momentum";
        if (qn.includes("VELOCITY") || qn.includes("PACE") || qn.includes("FASTEST SELLING") || qn.includes("MOST ACTIVE")) return "velocity";
        if (qn.includes("GROWTH") || qn.includes("PRICE MOVEMENT") || qn.includes("APPRECIAT") || qn.includes("RISEN") || qn.includes("FALLEN")) return "growth";
        if (ppsfRequested(query)) return "ppsf";
        if (qn.includes("PLANNING")) return "planning";
        if (qn.includes("FLOOD")) return "flood";
        if (qn.includes("FLOOR AREA") || qn.includes("SQFT") || qn.includes("SQ FT") || qn.includes("SIZE")) return "size";
        if (qn.includes("EPC") || qn.includes("ENERGY")) return "epc";
        if (qn.includes("COUNT") || qn.includes("HOW MANY") || qn.includes("NUMBER OF") || qn.includes("VOLUME")) return "count";
        if (qn.includes("LATEST") || qn.includes("NEWEST") || qn.includes("RECENT")) return "latest";
        return "price";
      }

      function comparisonRequested(query, locations) {
        const qn = normalise(query);
        return locations.length >= 2 && ["COMPARE", "VERSUS", " VS ", "DIFFERENCE", "BETTER", "WHICH", "BETWEEN"].some(term => (` ${qn} `).includes(term));
      }

      function trendRequested(query) {
        const qn = normalise(query);
        return ["TREND", "OVER TIME", "BY YEAR", "YEAR BY YEAR", "YEAR ON YEAR", "BY QUARTER", "QUARTERLY", "BY MONTH", "MONTHLY", "ANNUAL", "TIME SERIES", "HISTORY", "HISTORICAL", "CHANGED", "CHANGE SINCE"].some(term => qn.includes(term));
      }

      function distributionRequested(query) {
        const qn = normalise(query);
        return ["BREAKDOWN", "DISTRIBUTION", "MIX", "PROPORTION", "PERCENTAGE", "SHARE"].some(term => qn.includes(term));
      }

      function repeatSalesRequested(query) {
        const qn = normalise(query);
        return ["SOLD MORE THAN ONCE", "REPEAT SALE", "REPEAT SALES", "RESOLD", "SOLD AGAIN", "SALES HISTORY"].some(term => qn.includes(term));
      }

      function capabilityRequested(query) {
        const qn = normalise(query);
        return qn === "HELP" || qn.includes("WHAT CAN YOU DO") || qn.includes("WHAT CAN I ASK") || qn.includes("EXAMPLE QUESTIONS");
      }

      function coverageRequested(query) {
        const qn = normalise(query);
        return ["DATA COVERAGE", "DATA QUALITY", "HOW COMPLETE", "MISSING DATA", "COVERAGE"].some(term => qn.includes(term));
      }

      function comparableRequested(query) {
        const qn = normalise(query);
        if (["COMPARABLE", "COMPARABLES", "COMPS", "SIMILAR SALES", "WHAT IS IT WORTH", "WHAT S IT WORTH", "WHAT IS THIS WORTH"].some(term => qn.includes(term))) return true;
        if (!["VALUE RANGE", "VALUATION"].some(term => qn.includes(term))) return false;
        const hasPropertyReference = ["PROPERTY", "HOUSE", "HOME", "ADDRESS", "SELECTED", "THIS"].some(term => queryContainsTerm(query, term)) || /\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})\b/i.test(query);
        return hasPropertyReference || fuzzyPropertyRows(transactions, query).length > 0 || state.selectedType === "property" && !resolvedInsightLocations(query).length;
      }

      function outlierRequested(query) {
        const qn = normalise(query);
        return ["UNDERVALUED", "OVERVALUED", "OUTLIER", "ANOMAL", "VALUE SIGNAL", "RELATIVE VALUE", "INEXPENSIVE", "DISCOUNT", "OPPORTUNIT"].some(term => qn.includes(term));
      }

      function relationshipRequested(query) {
        const qn = normalise(query);
        return ["CORRELATION", "RELATIONSHIP", "PREMIUM", "IMPACT OF", "EFFECT OF", "AFFECT", "ASSOCIATED WITH"].some(term => qn.includes(term));
      }

      function briefingRequested(query) {
        const qn = normalise(query);
        return ["DEEP DIVE", "MARKET REPORT", "VALUATION REPORT", "EXECUTIVE", "ASSESSMENT", "ASSESS ", "ANALYSE", "ANALYZE", "BRIEF", "OUTLOOK", "TELL ME ABOUT", "OVERVIEW OF", "FULL REPORT", "CLIENT NOTE"].some(term => qn.includes(term));
      }

      function explicitAnalysisTopics(query) {
        const qn = normalise(query);
        const topics = [];
        const add = (id, label, terms) => {
          if (terms.some(term => qn.includes(term))) topics.push({ id, label });
        };
        add("price", "Price", ["PRICE", "VALUE", "MEDIAN", "AVERAGE"]);
        add("velocity", "Activity", ["VELOCITY", "PACE", "ACTIVITY", "MOMENTUM"]);
        add("epc", "EPC", ["EPC", "ENERGY", "FLOOR AREA", "SQFT", "SQ FT"]);
        add("planning", "Planning", ["PLANNING", "APPLICATION"]);
        add("flood", "Flood", ["FLOOD"]);
        add("transport", "Transport", ["STATION", "TRAIN", "COMMUTE", "AIRPORT"]);
        add("schools", "Schools", ["SCHOOL", "EDUCATION"]);
        return topics;
      }

      function compositeAnalysisRequested(query) {
        return explicitAnalysisTopics(query).length >= 2 && normalise(query).includes("AND");
      }

      function rankingRequested(query) {
        const qn = normalise(query);
        return ["TOP ", "BOTTOM ", "RANK", "RANKING", "WHICH AREA", "WHICH ESTATE", "WHICH MARKET", "WHICH TOWN", "BEST ", "WORST ", "HIGHEST ", "LOWEST ", "MOST ACTIVE", "LEAST ACTIVE", "BY AREA", "BY ESTATE", "BY MARKET", "BY TOWN", "BY POSTCODE"].some(term => qn.includes(term));
      }

      function followUpRequested(query) {
        const qn = normalise(query);
        return ["WHAT ABOUT", "HOW ABOUT", "AND WHAT", "AND FOR", "SAME FOR", "INSTEAD", "DETACHED ONLY", "SEMI DETACHED ONLY", "TERRACED ONLY", "APARTMENTS ONLY"].some(term => qn.includes(term)) || /^AND\b/.test(qn);
      }

      function queryContainsTerm(query, term) {
        const padded = ` ${normalise(query)} `;
        return padded.includes(` ${normalise(term)} `);
      }

      function stripInsightLocationTerms(query) {
        let text = String(query || "");
        const names = [
          ...estatePins.flatMap(pin => [pin.name, pin.key, ...(pin.aliases || [])]),
          ...marketDefinitions.flatMap(market => [market.short, market.name, market.district]),
          ...transactions.map(item => item.town).filter(Boolean),
          ...stationPins.flatMap(station => [station.name, station.crs]),
          ...airportPins.flatMap(airport => [airport.name, airport.id])
        ].filter(Boolean).sort((a, b) => b.length - a.length);
        names.forEach(name => {
          const escaped = String(name).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          text = text.replace(new RegExp(`\\b${escaped.replace(/\\\s+/g, "\\s+")}\\b`, "ig"), " ");
        });
        return text.replace(/\s+/g, " ").trim();
      }

      function effectiveInsightQuery(query) {
        const previous = state.insightContext?.query;
        if (!previous || normalise(previous) === normalise(query) || !followUpRequested(query)) return query;
        let inherited = previous;
        if (insightLocationFilters(query).length) inherited = stripInsightLocationTerms(inherited);
        if (propertyTypeFromQuery(query)) inherited = inherited.replace(/\b(?:detatched|detached|semi(?:-detached)?|terraced?|apartments?|flats?)\b/gi, " ");
        if (dateRangeFromQuery(query)) inherited = inherited.replace(/\b(?:last|past|since|before|after|from|between)?\s*(?:12|24|36)?\s*(?:months?|years?)?\s*20\d{2}\b/gi, " ");
        return `${inherited} ${query}`.replace(/\s+/g, " ").trim();
      }

      function insightLocationFilters(query) {
        const qn = normalise(query);
        const filters = [];
        const add = (kind, label, test) => {
          if (!filters.some(filter => filter.kind === kind && filter.label === label)) filters.push({ kind, label, test });
        };
        estatePins.forEach(pin => {
          const names = [pin.name, pin.key, ...(pin.aliases || [])].map(normalise).filter(value => value.length > 3);
          if (names.some(name => qn.includes(name)) || fuzzyEntityMention(query, pin.name) || fuzzyEntityMention(query, pin.key)) add("estate", pin.name, item => estateForTransaction(item)?.key === pin.key);
        });
        marketDefinitions.forEach(market => {
          const names = [market.short, market.name, market.district].map(normalise).filter(value => value.length > 3);
          if (names.some(name => qn.includes(name)) || fuzzyEntityMention(query, market.short)) add("market", market.short, item => item.market === market.id || item.district === market.district);
        });
        Array.from(new Set(transactions.map(item => item.town).filter(Boolean))).forEach(town => {
          const name = normalise(town);
          if (name.length > 3 && (qn.includes(name) || fuzzyEntityMention(query, town))) add("town", townDisplayName(townKey(town)), item => townKey(item.town) === townKey(town));
        });
        const postcodeMatches = query.match(/\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})?\b/gi) || [];
        postcodeMatches.forEach(postcode => {
          const clean = normalisePostcode(postcode);
          if (clean.length >= 3) add("postcode", postcode.toUpperCase(), item => normalisePostcode(item.postcode).startsWith(clean) || outwardPostcode(item.postcode) === clean);
        });
        const wantsStation = ["STATION", "TRAIN", "RAIL", "COMMUTE", "NEAR", "WITHIN"].some(term => qn.includes(term));
        stationPins.forEach(station => {
          const names = [station.name, station.crs].map(normalise).filter(value => value.length > 2);
          const exactCode = normalise(query) === normalise(station.crs);
          if ((wantsStation || exactCode) && names.some(name => qn.includes(name))) {
            const point = stationCoordinate(station);
            const radiusKm = distanceRadiusKmFromQuery(query, 3);
            add("station", `${station.name} (${formatDistanceKm(radiusKm)})`, item => distanceKm(transactionGeoPoint(item), point) <= radiusKm);
          }
        });
        airportPins.forEach(airport => {
          const names = [airport.name, airport.id].map(normalise).filter(value => value.length > 2);
          if (names.some(name => qn.includes(name))) {
            const point = airportCoordinate(airport);
            const radiusKm = distanceRadiusKmFromQuery(query, 18);
            add("airport", `${airport.name} (${formatDistanceKm(radiusKm)})`, item => distanceKm(transactionGeoPoint(item), point) <= radiusKm);
          }
        });
        schools.forEach(school => {
          const name = normalise(school.name);
          if (name.length > 5 && qn.includes(name)) {
            const point = schoolCoordinate(school);
            const radiusKm = distanceRadiusKmFromQuery(query, 2.5);
            add("school", `${school.name} (${formatDistanceKm(radiusKm)})`, item => distanceKm(transactionGeoPoint(item), point) <= radiusKm);
          }
        });
        return filters;
      }

      function resolvedInsightLocations(query) {
        const qn = normalise(query);
        let locations = insightLocationFilters(query);
        const locationKindWanted = qn.includes("AUTHORITY") || qn.includes("COUNCIL") || qn.includes("BOROUGH") || qn.includes("DISTRICT") || qn.includes("MARKET")
          ? "market"
          : qn.includes("TOWN") ? "town" : "";
        const ambiguousLabels = new Set(locations.filter(location => locations.some(other => other.kind !== location.kind && normalise(other.label) === normalise(location.label))).map(location => normalise(location.label)));
        if (ambiguousLabels.size) {
          locations = locations.filter(location => {
            if (!ambiguousLabels.has(normalise(location.label))) return true;
            if (locationKindWanted) return location.kind === locationKindWanted;
            // A bare place name in a property question normally means the town,
            // while explicit authority/market wording selects the wider district.
            return location.kind === "town";
          });
        }
        return locations;
      }

      function insightLocationScopeLabel(locations, comparison = false) {
        if (!locations.length) return "";
        if (comparison) return locations.map(location => location.label).join(" or ");
        const byKind = new Map();
        locations.forEach(location => {
          if (!byKind.has(location.kind)) byKind.set(location.kind, []);
          byKind.get(location.kind).push(location.label);
        });
        return Array.from(byKind.values(), labels => labels.join(" or ")).join(" and ");
      }

      function filterRowsByInsightLocations(rows, locations, useAlternatives = false) {
        if (!locations.length) return rows;
        if (useAlternatives) return rows.filter(item => locations.some(location => location.test(item)));
        const groups = new Map();
        locations.forEach(location => {
          if (!groups.has(location.kind)) groups.set(location.kind, []);
          groups.get(location.kind).push(location);
        });
        return rows.filter(item => Array.from(groups.values()).every(group => group.some(location => location.test(item))));
      }

      function guardrailResponse(query, allowFollowUp = true) {
        const qn = normalise(query);
        const domainSignals = ["PROPERTY", "PROPERTIES", "HOUSE", "HOUSES", "HOME", "HOMES", "SALE", "SALES", "PRICE", "PRICES", "VALUE", "VALUES", "MARKET", "ESTATE", "VELOCITY", "MOMENTUM", "LAND REGISTRY", "EPC", "PLANNING", "FLOOD", "SCHOOL", "STATION", "AIRPORT", "POSTCODE", "SURREY", "INSIGHT", "COMPARABLE", "COMPARABLES", "COMPS", "VALUATION", "OUTLIER", "CORRELATION", "RELATIVE VALUE", "DETACHED", "TERRACED", "APARTMENT", "APARTMENTS", "SQFT", "SQ FT"];
        const namedLocation = resolvedInsightLocations(query).length > 0;
        const postcodeOrAddress = /\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})?\b/i.test(query) || fuzzyPropertyRows(transactions, query).length > 0;
        const activeFollowUp = allowFollowUp && Boolean(state.insightContext?.query) && followUpRequested(query);
        const isDomainQuestion = namedLocation || postcodeOrAddress || activeFollowUp || domainSignals.some(term => queryContainsTerm(query, term));
        const unrelated = ["POEM", "RECIPE", "WEATHER", "FOOTBALL", "STOCK MARKET", "TRANSLATE", "CODING", "JAVASCRIPT", "MEDICAL ADVICE", "LEGAL ADVICE", "HOLIDAY ITINERARY", "CAPITAL OF"].some(term => qn.includes(term));
        const genericWriting = ["WRITE AN EMAIL", "DRAFT AN EMAIL", "WRITE A LETTER", "DRAFT A LETTER"].some(term => qn.includes(term));
        const outside = unrelated || !isDomainQuestion || (genericWriting && !isDomainQuestion);
        if (!outside) return null;
        return {
          title: "Ask INSIGHT",
          subtitle: "Dataset only",
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: textSection("Answer", "That falls outside Ask INSIGHT's property-intelligence role, or I could not connect it reliably to the loaded evidence. I can analyse or write from INSIGHT property, Land Registry, EPC, planning, school, station, airport and flood data.")
        };
      }

      function unavailableDataResponse(query) {
        const qn = normalise(query);
        const constrained = (subtitle, answer) => ({
          title: "Ask INSIGHT",
          subtitle,
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: insightLead(answer) + insightCaveat(insightUniverseBoundary())
        });
        if (["BEST SCHOOL", "SCHOOL QUALITY", "TOP SCHOOL", "CATCHMENT"].some(term => qn.includes(term))) {
          return constrained("School evidence boundary", "INSIGHT can compare school proximity, phase, type, age range and supplied capacity. It cannot rank the ‘best’ schools or infer catchments or performance from the currently loaded evidence.");
        }
        if ((qn.includes("SAFEST") || qn.includes("LOWEST RISK")) && qn.includes("FLOOD")) {
          return constrained("Flood evidence boundary", "INSIGHT has current flood-alert context within the configured radius, not a complete long-term property flood-risk model. It cannot defensibly rank the safest area from that evidence alone.");
        }
        if (["NEXT YEAR", "FORECAST", "PREDICT", "WILL RISE", "WILL FALL"].some(term => qn.includes(term))) {
          return constrained("Forecast boundary", "INSIGHT can report current momentum, transaction pace, repeat-sale movement and transparent scenarios. It will not present an unsupported future price forecast as fact.");
        }
        if (["SHOULD I BUY", "SHOULD WE BUY", "FINANCIAL ADVICE"].some(term => qn.includes(term))) {
          return constrained("Decision support only", "INSIGHT can assemble property evidence, comparables, risks and uncertainties, but it cannot make a personal purchase decision or provide financial advice.");
        }
        const missing = ["OWNER", "OWNERSHIP", "COMPANY", "COMPANIES HOUSE", "TITLE NUMBER", "FREEHOLD", "LEASEHOLD", "COVENANT", "MORTGAGE", "CHARGE"].filter(term => qn.includes(term));
        if (!missing.length) return null;
        return {
          title: "Ask INSIGHT",
          subtitle: "Not in loaded data",
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: textSection("Answer", "That field is not present in the currently loaded INSIGHT dataset. I can answer from Land Registry sales, EPC, mapped location, planning context, flood status, schools, stations and airports.")
        };
      }

      function sortRowsForQuery(rows, query) {
        const qn = normalise(query);
        const copy = rows.slice();
        if (qn.includes("CHEAPEST") || qn.includes("LOWEST PRICE")) return copy.sort((a, b) => Number(a.price) - Number(b.price));
        if (qn.includes("OLDEST") || qn.includes("FIRST SALE")) return copy.sort((a, b) => a.date.localeCompare(b.date));
        if (qn.includes("LATEST") || qn.includes("NEWEST") || qn.includes("RECENT")) return copy.sort((a, b) => b.date.localeCompare(a.date));
        if (ppsfRequested(query)) return copy.sort((a, b) => Number(b.pricePerSqft || 0) - Number(a.pricePerSqft || 0));
        if (qn.includes("LARGEST") || qn.includes("BIGGEST") || qn.includes("SQFT") || qn.includes("SQ FT")) return copy.sort((a, b) => Number(b.floorAreaSqft || 0) - Number(a.floorAreaSqft || 0));
        return copy.sort((a, b) => Number(b.price || 0) - Number(a.price || 0) || b.date.localeCompare(a.date));
      }

      function groupDimensionFromQuery(query) {
        const qn = normalise(query);
        if (!rankingRequested(query)) return "";
        if (qn.includes("PRIVATE ESTATE") || qn.includes("ESTATE")) return "estate";
        if (qn.includes("LOCAL AUTH") || qn.includes("AUTHORITY") || qn.includes("MARKET") || qn.includes("BY AREA") || qn.includes("WHICH AREA")) return "market";
        if (qn.includes("POSTCODE")) return "postcode";
        if (qn.includes("TOWN")) return "town";
        return "";
      }

      function groupRowsForInsight(rows, dimension) {
        const groups = new Map();
        const add = (key, label, item) => {
          if (!key) return;
          if (!groups.has(key)) groups.set(key, { key, label, rows: [] });
          groups.get(key).rows.push(item);
        };
        rows.forEach(item => {
          if (dimension === "estate") {
            const estate = estateForTransaction(item);
            if (estate) add(estate.key, estate.name, item);
          } else if (dimension === "market") {
            const market = marketById(item.market);
            add(item.market || item.district, market?.short || item.district, item);
          } else if (dimension === "postcode") {
            const outcode = outwardPostcode(item.postcode);
            add(outcode, outcode, item);
          } else {
            add(townKey(item.town), townDisplayName(townKey(item.town)), item);
          }
        });
        return Array.from(groups.values());
      }

      function insightStatsForGroup(group, dimension) {
        // Always calculate from the exact matched cohort. Reusing the cached
        // all-date/all-type area stats here leaks unfiltered figures into
        // filtered questions such as "detached homes in 2022".
        return statsForRows(group.rows);
      }

      function insightMetricForGroup(group, query, typeFilter, dimension) {
        const qn = normalise(query);
        const rows = group.rows;
        const stats = insightStatsForGroup(group, dimension);
        if ((qn.includes("DENSITY") || qn.includes("SHARE") || qn.includes("CONCENTRATION")) && typeFilter) {
          const matched = rows.filter(typeFilter.test).length;
          return { value: rows.length ? matched / rows.length : 0, label: `${formatNumber(matched)} of ${formatNumber(rows.length)} (${Math.round((rows.length ? matched / rows.length : 0) * 100)}%)` };
        }
        const intent = insightIntent(query);
        if (intent === "momentum") return { value: stats.momentumScore, label: momentumLabel(stats) };
        if (intent === "velocity") return stats.transactionGrain
          ? { value: rows.length, label: `${formatNumber(rows.length)} period transactions` }
          : { value: stats.velocityScore, label: velocityLabel(stats) };
        if (intent === "growth") return {
          value: stats.priceConfidence > 0 ? stats.priceChange : NaN,
          label: `${priceMovementLabel(stats)} · ${priceMovementEvidenceLabel(stats)}`
        };
        if (intent === "ppsf") {
          const values = rows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0);
          const value = qn.includes("MEDIAN") ? median(values) : average(values);
          return { value, label: compactPpsf(value) || "Awaiting EPC", sampleCount: values.length };
        }
        if (intent === "size") {
          const values = rows.map(item => Number(item.floorAreaSqft || 0)).filter(value => value > 0);
          const value = qn.includes("MEDIAN") ? median(values) : average(values);
          return { value, label: compactSqft(value) || "Awaiting EPC", sampleCount: values.length };
        }
        if (qn.includes("MEDIAN")) {
          const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
          const value = median(prices);
          return { value, label: compactPrice(value), sampleCount: prices.length };
        }
        if (qn.includes("AVERAGE") || qn.includes("AVG") || qn.includes("MEAN")) return { value: stats.avg, label: compactPrice(stats.avg) };
        if (qn.includes("PLANNING")) {
          const total = planningApplicationVolumeForRows(rows);
          return { value: total, label: `${formatNumber(total)} property applications` };
        }
        if (qn.includes("FLOOD")) {
          const total = rows.reduce((sum, item) => sum + Number(item.environmentAgency?.currentFloodAlertCount || 0), 0);
          return { value: total, label: `${formatNumber(total)} current alerts` };
        }
        if (qn.includes("MAX") || qn.includes("HIGHEST") || qn.includes("MOST EXPENSIVE")) return { value: stats.max, label: compactPrice(stats.max) };
        return { value: rows.length, label: `${formatNumber(rows.length)} sales` };
      }

      function lowRankingRequested(query) {
        const qn = normalise(query).replace(/\bAT LEAST\b/g, "");
        return ["LOWEST", "COLDEST", "BOTTOM", "WORST", "CHEAPEST", "LEAST ACTIVE", "LEAST EXPENSIVE"].some(term => queryContainsTerm(qn, term));
      }

      function insightGroupAnswer(rows, query, typeFilter) {
        const dimension = groupDimensionFromQuery(query);
        if (!dimension) return null;
        const intent = insightIntent(query);
        const defaultMinimum = ["planning", "flood", "count", "latest"].includes(intent) ? 1 : 5;
        const minimumSample = minimumSampleFromQuery(query, defaultMinimum);
        const groups = groupRowsForInsight(rows, dimension)
          .map(group => ({ ...group, metric: insightMetricForGroup(group, query, typeFilter, dimension) }))
          .filter(group => Number.isFinite(group.metric.value) && (group.metric.sampleCount ?? group.rows.length) >= minimumSample)
          .sort((a, b) => lowRankingRequested(query) ? a.metric.value - b.metric.value : b.metric.value - a.metric.value);
        if (!groups.length) return null;
        const limit = topCountFromQuery(query, 8);
        const ranked = groups.slice(0, limit);
        const leader = groups[0];
        return {
          title: "Ask INSIGHT",
          subtitle: `${humaniseKey(dimension)} ranking`,
          layout: "analysis",
          showLedger: false,
          rows: leader.rows,
          mapRows: groups.slice(0, limit).flatMap(group => group.rows),
          html: insightLead(`${leader.label} ranks first for this question at ${leader.metric.label}, based on ${formatNumber(leader.metric.sampleCount ?? leader.rows.length)} usable records.`) + insightBarList(ranked.map(group => ({ label: group.label, value: group.metric.value, formatted: `${group.metric.label} · n=${formatNumber(group.metric.sampleCount ?? group.rows.length)}` }))) + insightCaveat(`${insightUniverseBoundary()} Rankings use the exact requested cohort and exclude groups below ${formatNumber(minimumSample)} usable records.`)
        };
      }

      function insightMetricForRows(rows, query, suppliedStats = null) {
        const intent = insightIntent(query);
        const stats = suppliedStats || statsForRows(rows);
        const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
        const floorAreas = rows.map(item => Number(item.floorAreaSqft || 0)).filter(value => value > 0);
        const floodAffected = rows.filter(item => Number(item.environmentAgency?.currentFloodAlertCount || 0) > 0).length;
        if (intent === "momentum") return { value: stats.momentumScore, label: momentumLabel(stats), noun: "momentum" };
        if (intent === "velocity") return stats.transactionGrain
          ? { value: rows.length, label: `${formatNumber(rows.length)} period transactions`, noun: "historical transaction volume" }
          : { value: stats.velocityScore, label: velocityLabel(stats), noun: "velocity" };
        if (intent === "growth") return {
          value: stats.priceConfidence > 0 ? stats.priceChange : NaN,
          label: `${priceMovementLabel(stats)} · ${priceMovementEvidenceLabel(stats)}`,
          noun: "real annualised price movement"
        };
        if (intent === "ppsf") {
          const values = rows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0);
          const useMedian = normalise(query).includes("MEDIAN");
          const value = useMedian ? median(values) : average(values);
          return { value, label: compactPpsf(value) || "Awaiting EPC", noun: `${useMedian ? "median" : "average"} £/sq ft` };
        }
        if (intent === "planning") {
          const total = planningApplicationVolumeForRows(rows);
          return { value: rows.length ? total / rows.length : 0, label: `${formatNumber(total)} applications across ${formatNumber(rows.length)} properties`, noun: "planning activity" };
        }
        if (intent === "flood") return { value: rows.length ? floodAffected / rows.length : 0, label: `${formatNumber(floodAffected)} of ${formatNumber(rows.length)} properties with current alerts`, noun: "current flood exposure" };
        if (intent === "size") {
          const useMedian = normalise(query).includes("MEDIAN");
          const value = useMedian ? median(floorAreas) : average(floorAreas);
          return { value, label: compactSqft(value) || "Awaiting EPC", noun: `${useMedian ? "median" : "average"} EPC floor area` };
        }
        if (intent === "count") return { value: rows.length, label: `${formatNumber(rows.length)} properties`, noun: "matched volume" };
        if (intent === "latest") {
          const latest = rows.slice().sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")))[0];
          return { value: latest?.date ? Number(latest.date.replace(/-/g, "")) : 0, label: latest ? formatDate(latest.date) : "No sale", noun: "latest sale" };
        }
        const useMedian = normalise(query).includes("MEDIAN");
        return { value: useMedian ? median(prices) : average(prices), label: compactPrice(useMedian ? median(prices) : average(prices)), noun: useMedian ? "median sale price" : "average sale price" };
      }

      function insightStatsForLocation(location, rows) {
        return statsForRows(rows);
      }

      function insightComparisonAnswer(rows, query, locations) {
        if (!comparisonRequested(query, locations)) return null;
        const qn = normalise(query);
        const comparisons = locations.map(location => {
          const matchedRows = rows.filter(location.test);
          const stats = insightStatsForLocation(location, matchedRows);
          const prices = matchedRows.map(item => Number(item.price || 0)).filter(value => value > 0);
          return {
            ...location,
            rows: matchedRows,
            stats,
            metric: insightMetricForRows(matchedRows, query, stats),
            medianPrice: median(prices),
            averagePrice: average(prices),
            velocity: stats.velocityScore,
            velocityLabel: stats.transactionGrain ? `${formatNumber(matchedRows.length)} period sales` : velocityLabel(stats),
            momentum: stats.momentumScore,
            movement: stats.priceChange,
            movementConfidence: stats.priceConfidence,
            ppsf: qn.includes("MEDIAN") ? median(matchedRows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0)) : stats.ppsfAvg,
            planning: planningApplicationVolumeForRows(matchedRows)
          };
        }).filter(group => group.rows.length && Number.isFinite(group.metric.value));
        if (comparisons.length < 2) return null;
        const lowerWins = lowRankingRequested(query) || queryContainsTerm(query, "LOWER");
        comparisons.sort((a, b) => lowerWins ? a.metric.value - b.metric.value : b.metric.value - a.metric.value);
        const leader = comparisons[0];
        const runnerUp = comparisons[1];
        const difference = runnerUp.metric.value ? Math.abs(leader.metric.value / runnerUp.metric.value - 1) : 0;
        const closeResult = difference < .08 && [leader.rows.length, runnerUp.rows.length].some(count => count < 15);
        const answers = [closeResult
          ? `${leader.label} and ${runnerUp.label} are broadly similar on ${leader.metric.noun} within the precision of these samples: ${leader.metric.label} versus ${runnerUp.metric.label}.`
          : `${leader.label} leads on ${leader.metric.noun}: ${leader.metric.label}, compared with ${runnerUp.metric.label} for ${runnerUp.label}${difference && insightIntent(query) !== "latest" ? ` (a ${Math.round(difference * 100)}% difference)` : ""}.`];
        const metricLeader = (key, formatter, noun) => {
          const ranked = comparisons.slice().sort((a, b) => Number(b[key] || 0) - Number(a[key] || 0));
          return `${ranked[0].label} leads on ${noun} at ${formatter(ranked[0])}, versus ${formatter(ranked[1])} for ${ranked[1].label}.`;
        };
        if (qn.includes("MEDIAN") && insightIntent(query) !== "price") answers.push(metricLeader("medianPrice", group => compactPrice(group.medianPrice), "median sale price"));
        else if (qn.includes("PRICE") && insightIntent(query) !== "price") answers.push(metricLeader("averagePrice", group => compactPrice(group.averagePrice), "average sale price"));
        if ((qn.includes("VELOCITY") || qn.includes("PACE")) && insightIntent(query) !== "velocity") answers.push(metricLeader("velocity", group => group.velocityLabel, "market velocity"));
        if ((qn.includes("PSF") || qn.includes("PER SQ")) && insightIntent(query) !== "ppsf") answers.push(metricLeader("ppsf", group => compactPpsf(group.ppsf) || "unavailable", "average price per square foot"));
        if (qn.includes("PLANNING") && insightIntent(query) !== "planning") answers.push(metricLeader("planning", group => `${formatNumber(group.planning)} applications`, "loaded planning activity"));
        const table = insightTable(
          ["Area", "Records", "Median", "Average", "£/sq ft", "Velocity", "Momentum", "Real movement"],
          comparisons.map(group => [group.label, formatNumber(group.rows.length), compactPrice(group.medianPrice), compactPrice(group.averagePrice), compactPpsf(group.ppsf) || "—", group.velocityLabel, group.stats.transactionGrain ? "Historical slice" : momentumLabel(group.stats), group.stats.transactionGrain ? "Not calculated" : priceMovementLabel(group.stats)])
        );
        return {
          title: "Ask INSIGHT",
          subtitle: `${comparisons.length}-area comparison`,
          layout: "report",
          showLedger: false,
          rows: comparisons.flatMap(group => group.rows),
          mapRows: comparisons.flatMap(group => group.rows),
          html: insightLead(answers) + table + insightCaveat(`${insightUniverseBoundary()} Comparisons use each exact matched cohort. A lead is softened when the difference is small and either sample is thin.`)
        };
      }

      function insightTrendAnswer(rows, query, dateRange) {
        if (!trendRequested(query)) return null;
        let activityRows = rows.slice();
        if (dateRange) {
          activityRows = activityRows.filter(item => {
            const date = parseIso(item.date);
            return date && (!dateRange.from || date >= dateRange.from) && (!dateRange.to || date <= dateRange.to);
          });
        }
        const qn = normalise(query);
        const period = qn.includes("MONTH") ? "month" : qn.includes("QUARTER") ? "quarter" : "year";
        const groups = new Map();
        activityRows.forEach(item => {
          const date = parseIso(String(item.date || "").slice(0, 10));
          if (!date) return;
          const year = date.getUTCFullYear();
          const month = date.getUTCMonth() + 1;
          const key = period === "month" ? `${year}-${String(month).padStart(2, "0")}` : period === "quarter" ? `${year} Q${Math.ceil(month / 3)}` : String(year);
          if (!groups.has(key)) groups.set(key, []);
          groups.get(key).push(item);
        });
        const periods = Array.from(groups, ([key, periodRows]) => {
          const prices = periodRows.map(item => Number(item.price || 0)).filter(value => value > 0);
          const realPrices = periodRows.map(realPriceForSale).filter(value => value > 0);
          const ppsf = periodRows.map(realPpsfForSale).filter(value => value > 0);
          const currentYear = String(analysisEnd.getUTCFullYear());
          const label = period === "year" && key === currentYear && analysisEnd.getUTCMonth() < 11 ? `${key} YTD` : key;
          return { key, label, rows: periodRows, median: median(prices), realMedian: median(realPrices), ppsf: median(ppsf), confidence: insightSampleConfidence(periodRows.length) };
        }).filter(item => item.rows.length).sort((a, b) => a.key.localeCompare(b.key));
        if (periods.length < 2) return null;
        const defensible = periods.filter(item => item.rows.length >= 5);
        const comparisonPeriods = defensible.length >= 2 ? defensible : periods;
        const first = comparisonPeriods[0];
        const last = comparisonPeriods[comparisonPeriods.length - 1];
        const change = first.realMedian ? last.realMedian / first.realMedian - 1 : 0;
        const direction = change >= 0 ? "higher" : "lower";
        const answer = `The CPIH-adjusted loaded median moved from ${compactPrice(first.realMedian)} in ${first.label} to ${compactPrice(last.realMedian)} in ${last.label}, ${Math.abs(change) < .005 ? "broadly unchanged" : `${Math.abs(change * 100).toFixed(1)}% ${direction}`}. Recorded volume moved from ${formatNumber(first.rows.length)} to ${formatNumber(last.rows.length)} sales.`;
        return {
          title: "Ask INSIGHT",
          subtitle: `${first.label}–${last.label} ${period} trend`,
          layout: "report",
          showLedger: false,
          rows: activityRows,
          mapRows: rows,
          html: insightLead(answer) + insightMetricGrid([
            { label: "Real median change", value: preciseSignedPercent(change), detail: `${first.label} to ${last.label}` },
            { label: "Starting median", value: compactPrice(first.realMedian), detail: `${formatNumber(first.rows.length)} records` },
            { label: "Latest median", value: compactPrice(last.realMedian), detail: `${formatNumber(last.rows.length)} records` },
            { label: "Usable periods", value: formatNumber(comparisonPeriods.length), detail: defensible.length >= 2 ? "At least five records each" : "Includes thin indicative periods" }
          ]) + insightTable(
            [period === "year" ? "Year" : period === "quarter" ? "Quarter" : "Month", "Sales", "Nominal median", "Real median", "Real £/sq ft", "Strength"],
            periods.slice(-16).reverse().map(item => [item.label, formatNumber(item.rows.length), compactPrice(item.median), compactPrice(item.realMedian), compactPpsf(item.ppsf) || "—", item.confidence])
          ) + insightCaveat(`${insightUniverseBoundary("CPIH adjustment uses INSIGHT's internal annual index through 2026.")} Period medians remain sensitive to changing property mix; current-year figures are year-to-date.`)
        };
      }

      function insightCoverageAnswer(rows, query) {
        if (!coverageRequested(query)) return null;
        const count = rows.length || 1;
        const coverage = (label, matched) => [label, `${formatNumber(matched)} of ${formatNumber(rows.length)} (${Math.round(matched / count * 100)}%)`];
        const epc = rows.filter(item => Number(item.floorAreaSqft || 0) > 0 || item.epcRating).length;
        const planning = rows.filter(item => planningApplicationCount(item) > 0 || item.planning?.latestApplication).length;
        const flood = rows.filter(item => item.environmentAgency?.floodStatus).length;
        const coordinatePoints = rows.map(transactionGeoPoint).filter(Boolean);
        const coordinates = coordinatePoints.length;
        const exactCoordinates = coordinatePoints.filter(point => point[3] === "exact" || point[3] === "address").length;
        const schoolsCovered = rows.filter(item => Array.isArray(item.ofsted?.nearestSchools) && item.ofsted.nearestSchools.length).length;
        const weakest = [["EPC", epc], ["Planning", planning], ["Flood", flood], ["Coordinates", coordinates], ["Schools", schoolsCovered]].sort((a, b) => a[1] - b[1])[0];
        return {
          title: "Ask INSIGHT",
          subtitle: "Data coverage audit",
          layout: "analysis",
          showLedger: false,
          rows,
          html: textSection("Answer", `${weakest[0]} is the thinnest of these loaded evidence layers, covering ${formatNumber(weakest[1])} of ${formatNumber(rows.length)} matched properties. Missing fields are reported as unavailable rather than inferred.`) + dataRows([
            coverage("Sale price and date", rows.filter(item => item.price && item.date).length),
            coverage("Mapped coordinates", coordinates),
            coverage("Address-level coordinates", exactCoordinates),
            coverage("EPC area or rating", epc),
            coverage("Planning context", planning),
            coverage("Flood context", flood),
            coverage("Nearby schools", schoolsCovered)
          ])
        };
      }

      function insightDistributionAnswer(rows, query) {
        if (!distributionRequested(query)) return null;
        const qn = normalise(query);
        const groups = new Map();
        rows.forEach(item => {
          let label;
          if (qn.includes("EPC") || qn.includes("ENERGY")) label = String(item.epcRating || "Unknown").slice(0, 1).toUpperCase();
          else if (qn.includes("FLOOD")) label = item.environmentAgency?.floodStatus || "No status";
          else label = item.propertyType || "Unknown type";
          groups.set(label, (groups.get(label) || 0) + 1);
        });
        const ranked = Array.from(groups, ([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count);
        if (!ranked.length) return null;
        const leader = ranked[0];
        const list = ranked.map(group => contextItem(group.label, `${formatNumber(group.count)} properties · ${Math.round(group.count / rows.length * 100)}%`));
        return {
          title: "Ask INSIGHT",
          subtitle: "Matched-property breakdown",
          layout: "analysis",
          showLedger: false,
          rows,
          html: textSection("Answer", `${leader.label} is the largest group, representing ${Math.round(leader.count / rows.length * 100)}% of the ${formatNumber(rows.length)} matched properties.`) + contextSection("Distribution", [], list)
        };
      }

      function insightRepeatSalesAnswer(rows, query) {
        if (!repeatSalesRequested(query)) return null;
        const seen = new Set();
        const repeats = rows.map(property => {
          const key = propertyRecordKey(property);
          if (seen.has(key)) return null;
          seen.add(key);
          const history = salesHistoryForTransaction(property)
            .filter(sale => Number(sale.price) > 0 && parseIso(String(sale.date || "").slice(0, 10)))
            .sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
          if (history.length < 2) return null;
          const pricesByDate = new Map();
          let conflictingSaleDate = false;
          history.forEach(sale => {
            const date = String(sale.date || "").slice(0, 10);
            const price = Number(sale.price || 0);
            if (pricesByDate.has(date) && pricesByDate.get(date) !== price) conflictingSaleDate = true;
            pricesByDate.set(date, price);
          });
          if (conflictingSaleDate) return null;
          const last = history[0];
          const prior = history[1];
          if (String(last.category || "").toUpperCase() === "B" || String(prior.category || "").toUpperCase() === "B") return null;
          if (normalise(last.propertyType) && normalise(prior.propertyType) && normalise(last.propertyType) !== normalise(prior.propertyType)) return null;
          const holdingYears = Math.max(0, monthsBetween(
            parseIso(String(prior.date).slice(0, 10)), parseIso(String(last.date).slice(0, 10))
          ) / 12);
          if (holdingYears < 1) return null;
          const priorPrice = inflationAdjustedPrice(prior);
          const change = priorPrice > 0 ? inflationAdjustedPrice(last) / priorPrice - 1 : 0;
          const annualised = holdingYears >= 1 ? Math.pow(1 + change, 1 / holdingYears) - 1 : null;
          return { key, history, prior, last, change, annualised, holdingYears };
        }).filter(Boolean).sort((left, right) => right.history.length - left.history.length || String(right.last.date).localeCompare(String(left.last.date)));
        if (!repeats.length) return {
          title: "Ask INSIGHT",
          subtitle: "No repeat sales",
          rows: [],
          html: textSection("Answer", "No matched properties have more than one loaded Land Registry transaction in the available history.")
        };
        const list = repeats.slice(0, topCountFromQuery(query, 10)).map(item => contextItem(
          propertyDisplayName(item.last),
          `${item.history.length} sales · ${formatDate(item.prior.date)} ${compactPrice(item.prior.price)} → ${formatDate(item.last.date)} ${compactPrice(item.last.price)} · ${preciseSignedPercent(item.change)} real${item.annualised !== null ? ` · ${preciseSignedPercent(item.annualised)} p.a.` : ""}`
        ));
        return {
          title: "Ask INSIGHT",
          subtitle: `${formatNumber(repeats.length)} repeat-sale properties`,
          layout: "report",
          rows: repeats.map(item => item.last),
          html: textSection("Answer", `${formatNumber(repeats.length)} matched properties have multiple loaded sales. Changes compare the latest two sales, are CPIH-adjusted and are annualised where the holding period is at least one year. They can still reflect refurbishment, extension or tenure changes.`) + contextSection("Repeat-sale evidence", [], list)
        };
      }

      function insightSampleConfidence(count) {
        const value = Number(count) || 0;
        if (value >= 30) return "High";
        if (value >= 15) return "Medium";
        if (value >= 5) return "Low";
        return "Indicative";
      }

      function realPriceForSale(item) {
        return inflationAdjustedPrice(item);
      }

      function realPpsfForSale(item) {
        const ppsf = Number(item?.pricePerSqft || 0);
        const sourceIndex = cpihIndexForDate(item?.date);
        return ppsf > 0 && sourceIndex > 0 ? ppsf * cpihAnnualIndex[2026] / sourceIndex : 0;
      }

      function insightPropertyTarget(query) {
        const selected = state.selectedType === "property"
          ? transactions.find(item => propertyId(item.id) === propertyId(state.selectedId))
          : null;
        const qn = normalise(query);
        if (selected && ["THIS PROPERTY", "SELECTED PROPERTY", "THIS HOUSE", "IT WORTH", "COMPS", "COMPARABLE"].some(term => qn.includes(term))) return selected;
        const postcode = (String(query || "").match(/\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})\b/i) || [])[0];
        const postcodeRows = postcode ? transactions.filter(item => normalisePostcode(item.postcode) === normalisePostcode(postcode)) : [];
        const fuzzy = fuzzyPropertyRows(transactions, query);
        const selectedReference = selected && !resolvedInsightLocations(query).length && ["THIS", "SELECTED", "IT", "PROPERTY", "HOUSE", "HOME", "COMPS", "COMPARABLE"].some(term => queryContainsTerm(query, term));
        return fuzzy[0] || (postcodeRows.length === 1 ? postcodeRows[0] : null) || (selectedReference ? selected : null);
      }

      function comparableSimilarity(target, candidate) {
        if (propertyRecordKey(target) === propertyRecordKey(candidate)) return null;
        const targetPoint = transactionGeoPoint(target);
        const candidatePoint = transactionGeoPoint(candidate);
        const distance = distanceKm(targetPoint, candidatePoint);
        const targetArea = Number(target.floorAreaSqft || 0);
        const candidateArea = Number(candidate.floorAreaSqft || 0);
        const areaSimilarity = targetArea && candidateArea ? Math.exp(-Math.abs(Math.log(candidateArea / targetArea)) * 1.8) : .35;
        const targetDate = parseIso(String(target.date || "").slice(0, 10));
        const candidateDate = parseIso(String(candidate.date || "").slice(0, 10));
        const yearGap = targetDate && candidateDate ? Math.abs(targetDate - candidateDate) / (365.25 * 24 * 60 * 60 * 1000) : 8;
        const typeMatch = normalise(target.propertyType) === normalise(candidate.propertyType) ? 1 : .25;
        const estateMatch = estateForTransaction(target)?.key && estateForTransaction(target)?.key === estateForTransaction(candidate)?.key ? 1 : 0;
        const marketMatch = target.market === candidate.market ? 1 : 0;
        const distanceScore = Math.exp(-Math.min(30, distance) / 7);
        const recencyScore = Math.exp(-yearGap / 6);
        const coordinateQuality = [targetPoint?.[3], candidatePoint?.[3]].every(value => value === "exact" || value === "address") ? 1 : .72;
        const score = (.28 * areaSimilarity + .2 * typeMatch + .18 * distanceScore + .12 * recencyScore + .1 * marketMatch + .08 * estateMatch + .04 * coordinateQuality) * 100;
        return { candidate, score, distance, areaSimilarity, coordinateQuality };
      }

      function insightComparableAnswer(rows, query) {
        if (!comparableRequested(query)) return null;
        const target = insightPropertyTarget(query);
        if (!target) return {
          title: "Comparable sales",
          subtitle: "Property required",
          layout: "compact",
          showLedger: false,
          rows: [],
          html: insightLead("Name a property or select it on the map, then ask for comparable sales or an evidence range.") + insightCaveat(insightUniverseBoundary())
        };
        const comparisons = transactions.map(candidate => comparableSimilarity(target, candidate)).filter(Boolean)
          .filter(item => item.score >= 32)
          .sort((left, right) => right.score - left.score)
          .slice(0, topCountFromQuery(query, 8));
        if (comparisons.length < 3) return {
          title: "Comparable sales",
          subtitle: propertyDisplayName(target),
          layout: "analysis",
          showLedger: false,
          rows: comparisons.map(item => item.candidate),
          html: insightLead(`Only ${formatNumber(comparisons.length)} defensible comparable sales were found for ${propertyDisplayName(target)}. That is too thin for a useful evidence range.`) + insightCaveat(insightUniverseBoundary())
        };
        const realPpsf = comparisons.map(item => realPpsfForSale(item.candidate)).filter(value => value > 0);
        const targetArea = Number(target.floorAreaSqft || 0);
        const adjustedPrices = comparisons.map(item => realPriceForSale(item.candidate)).filter(value => value > 0);
        const central = targetArea && realPpsf.length >= 3 ? median(realPpsf) * targetArea : median(adjustedPrices);
        const low = targetArea && realPpsf.length >= 3 ? quantileInclusive(realPpsf, .25) * targetArea : quantileInclusive(adjustedPrices, .25);
        const high = targetArea && realPpsf.length >= 3 ? quantileInclusive(realPpsf, .75) * targetArea : quantileInclusive(adjustedPrices, .75);
        const exactCount = comparisons.filter(item => item.coordinateQuality === 1).length;
        const table = insightTable(
          ["Comparable", "Sold", "Date", "Distance", "Area", "£/sq ft", "Match"],
          comparisons.map(item => [
            propertyDisplayName(item.candidate),
            compactPrice(item.candidate.price),
            formatDate(item.candidate.date),
            formatDistanceKm(item.distance),
            compactSqft(item.candidate.floorAreaSqft) || "—",
            compactPpsf(item.candidate.pricePerSqft) || "—",
            `${Math.round(item.score)}%`
          ])
        );
        return {
          title: "Comparable sales",
          subtitle: propertyDisplayName(target),
          layout: "report",
          showLedger: false,
          rows: comparisons.map(item => item.candidate),
          mapRows: [target, ...comparisons.map(item => item.candidate)],
          html: insightLead([
            `${propertyDisplayName(target)} has an indicative CPIH-adjusted evidence range of ${compactPrice(low)} to ${compactPrice(high)}, centred around ${compactPrice(central)} from ${formatNumber(comparisons.length)} scored comparable sales.`,
            "The selection weights floor-area similarity, property type, distance, sale recency, market and private-estate match. It is an evidence range, not a formal valuation."
          ]) + insightMetricGrid([
            { label: "Evidence centre", value: compactPrice(central), detail: targetArea && realPpsf.length >= 3 ? "Peer real £/sq ft × EPC area" : "Median real comparable price" },
            { label: "Middle range", value: `${compactPrice(low)}–${compactPrice(high)}`, detail: "Interquartile comparable evidence" },
            { label: "Comparables", value: formatNumber(comparisons.length), detail: `${insightSampleConfidence(comparisons.length)} sample strength` },
            { label: "Coordinate quality", value: `${formatNumber(exactCount)}/${formatNumber(comparisons.length)}`, detail: "Address-level pairs" }
          ]) + table + insightCaveat(`${insightUniverseBoundary("CPIH adjustment uses INSIGHT's internal annual index through 2026.")} Distances based on postcode-centroid coordinates are approximate.`)
        };
      }

      function insightRelativeValueAnswer(rows, query) {
        if (!outlierRequested(query)) return null;
        const recentStart = addMonths(analysisEnd, -60);
        const recentRows = rows.filter(item => {
          const date = parseIso(String(item.date || "").slice(0, 10));
          return date && date >= recentStart && realPpsfForSale(item) > 0;
        });
        const cohorts = new Map();
        recentRows.forEach(item => {
          const key = `${item.market}|${normalise(item.propertyType)}`;
          if (!cohorts.has(key)) cohorts.set(key, []);
          cohorts.get(key).push(realPpsfForSale(item));
        });
        const candidates = recentRows.map(item => {
          const cohort = cohorts.get(`${item.market}|${normalise(item.propertyType)}`) || [];
          if (cohort.length < 8) return null;
          const benchmark = median(cohort);
          const value = realPpsfForSale(item);
          return { item, benchmark, value, gap: benchmark ? value / benchmark - 1 : 0, cohortCount: cohort.length };
        }).filter(Boolean);
        const wantsHigh = normalise(query).includes("OVERVALUED") || normalise(query).includes("HIGH OUTLIER") || normalise(query).includes("PREMIUM");
        candidates.sort((left, right) => wantsHigh ? right.gap - left.gap : left.gap - right.gap);
        const ranked = candidates.slice(0, topCountFromQuery(query, 10));
        if (!ranked.length) return null;
        const strongest = ranked[0];
        return {
          title: wantsHigh ? "High relative-value signals" : "Low relative-value signals",
          subtitle: "Five-year prime-sale evidence",
          layout: "report",
          showLedger: false,
          rows: ranked.map(item => item.item),
          mapRows: ranked.map(item => item.item),
          html: insightLead(`${propertyDisplayName(strongest.item)} is the strongest ${wantsHigh ? "premium" : "discount"} signal in the matched cohort: its CPIH-adjusted ${compactPpsf(strongest.value)} is ${Math.abs(strongest.gap * 100).toFixed(1)}% ${strongest.gap < 0 ? "below" : "above"} the median for the same property type and authority.`) + insightMetricGrid([
            { label: "Signals shown", value: formatNumber(ranked.length), detail: "Minimum eight peer records" },
            { label: "Analysis window", value: "5 years", detail: "CPIH-adjusted sale evidence" },
            { label: "Strongest gap", value: preciseSignedPercent(strongest.gap), detail: "Versus matched peer median" },
            { label: "Peer sample", value: formatNumber(strongest.cohortCount), detail: insightSampleConfidence(strongest.cohortCount) + " strength" }
          ]) + insightTable(
            ["Property", "Sale", "Real £/sq ft", "Peer median", "Gap", "Peers"],
            ranked.map(item => [propertyDisplayName(item.item), compactPrice(item.item.price), compactPpsf(item.value), compactPpsf(item.benchmark), preciseSignedPercent(item.gap), formatNumber(item.cohortCount)])
          ) + insightCaveat(`${insightUniverseBoundary("These are historical relative-value signals, not properties currently for sale.")} A low £/sq ft can reflect condition, tenure, plot, design or data mismatch rather than mispricing.`)
        };
      }

      function pearsonCorrelation(pairs) {
        if (pairs.length < 5) return null;
        const meanX = average(pairs.map(pair => pair[0]));
        const meanY = average(pairs.map(pair => pair[1]));
        const numerator = pairs.reduce((sum, pair) => sum + (pair[0] - meanX) * (pair[1] - meanY), 0);
        const denominatorX = Math.sqrt(pairs.reduce((sum, pair) => sum + (pair[0] - meanX) ** 2, 0));
        const denominatorY = Math.sqrt(pairs.reduce((sum, pair) => sum + (pair[1] - meanY) ** 2, 0));
        return denominatorX && denominatorY ? numerator / (denominatorX * denominatorY) : null;
      }

      function insightRelationshipAnswer(rows, query) {
        if (!relationshipRequested(query)) return null;
        const qn = normalise(query);
        let title = "Evidence relationship";
        let groups = [];
        let correlation = null;
        let caveat = "Observed differences are associations in the loaded sale evidence and do not establish causation.";
        if (qn.includes("STATION") || qn.includes("TRAIN") || qn.includes("COMMUTE")) {
          title = "Station proximity and value";
          const records = rows.map(item => {
            const station = nearestStations(transactionGeoPoint(item), 1)[0];
            return station && realPpsfForSale(item) ? { item, value: realPpsfForSale(item), distance: station.distanceKm } : null;
          }).filter(Boolean);
          const definitions = [["Within 1.5km", 0, 1.5], ["1.5–3km", 1.5, 3], ["Over 3km", 3, Infinity]];
          groups = definitions.map(([label, minimum, maximum]) => {
            const matched = records.filter(record => record.distance >= minimum && record.distance < maximum);
            return { label, count: matched.length, value: median(matched.map(record => record.value)) };
          }).filter(group => group.count);
          correlation = pearsonCorrelation(records.map(record => [record.distance, record.value]));
          caveat += " Property coordinates are frequently postcode centroids, so short distances are approximate.";
        } else if (qn.includes("EPC") || qn.includes("ENERGY")) {
          title = "EPC and value";
          const definitions = [["A–B", ["A", "B"]], ["C–D", ["C", "D"]], ["E–G", ["E", "F", "G"]]];
          groups = definitions.map(([label, ratings]) => {
            const matched = rows.filter(item => ratings.includes(String(item.epcRating || "").slice(0, 1).toUpperCase()) && realPpsfForSale(item));
            return { label, count: matched.length, value: median(matched.map(realPpsfForSale)) };
          }).filter(group => group.count);
        } else if (qn.includes("PLANNING")) {
          title = "Planning history and value";
          const definitions = [["Planning history", item => planningApplicationCount(item) > 0], ["No loaded history", item => planningApplicationCount(item) === 0]];
          groups = definitions.map(([label, test]) => {
            const matched = rows.filter(item => test(item) && realPpsfForSale(item));
            return { label, count: matched.length, value: median(matched.map(realPpsfForSale)) };
          }).filter(group => group.count);
          caveat += " No loaded planning history means unknown/no match, not proof of no applications.";
        } else if (qn.includes("SCHOOL") || qn.includes("EDUCATION")) {
          title = "School proximity and value";
          const records = rows.map(item => {
            const nearest = item.ofsted?.nearestSchools?.[0];
            const metres = Number(nearest?.metres || 0);
            return metres > 0 && realPpsfForSale(item) ? { item, value: realPpsfForSale(item), distance: metres / 1000 } : null;
          }).filter(Boolean);
          const definitions = [["Within 1km", 0, 1], ["1–2km", 1, 2], ["Over 2km", 2, Infinity]];
          groups = definitions.map(([label, minimum, maximum]) => {
            const matched = records.filter(record => record.distance >= minimum && record.distance < maximum);
            return { label, count: matched.length, value: median(matched.map(record => record.value)) };
          }).filter(group => group.count);
          correlation = pearsonCorrelation(records.map(record => [record.distance, record.value]));
          caveat += " School evidence is proximity/context only, not catchment, quality or performance.";
        } else if (qn.includes("FLOOR AREA") || qn.includes("SIZE") || qn.includes("SQFT") || qn.includes("SQ FT")) {
          title = "Floor area and sale value";
          const records = rows.map(item => {
            const area = Number(item.floorAreaSqft || 0);
            const value = realPriceForSale(item);
            return area > 0 && value > 0 ? { item, area, value } : null;
          }).filter(Boolean);
          const areas = records.map(record => record.area);
          const lower = quantileInclusive(areas, 1 / 3);
          const upper = quantileInclusive(areas, 2 / 3);
          const definitions = [[`Under ${formatNumber(Math.round(lower))} sq ft`, 0, lower], [`${formatNumber(Math.round(lower))}–${formatNumber(Math.round(upper))} sq ft`, lower, upper], [`Over ${formatNumber(Math.round(upper))} sq ft`, upper, Infinity]];
          groups = definitions.map(([label, minimum, maximum]) => {
            const matched = records.filter(record => record.area >= minimum && record.area < maximum);
            return { label, count: matched.length, value: median(matched.map(record => record.value)), priceMetric: true };
          }).filter(group => group.count);
          correlation = pearsonCorrelation(records.map(record => [Math.log(record.area), Math.log(record.value)]));
          caveat += " Floor area is EPC-derived and the relationship also reflects location, condition, plot, tenure and specification.";
        } else if (qn.includes("PRIVATE ESTATE") || qn.includes("GATED") || qn.includes("ESTATE PREMIUM")) {
          title = "Private-estate premium";
          const definitions = [["Tracked private estate", item => Boolean(estateForTransaction(item))], ["Other prime records", item => !estateForTransaction(item)]];
          groups = definitions.map(([label, test]) => {
            const matched = rows.filter(item => test(item) && realPpsfForSale(item));
            return { label, count: matched.length, value: median(matched.map(realPpsfForSale)) };
          }).filter(group => group.count);
        } else {
          return {
            title: "Evidence relationship",
            subtitle: "Dimension required",
            layout: "compact",
            showLedger: false,
            preserveMap: true,
            rows: [],
            html: insightLead("Name the relationship you want tested—for example station proximity, school proximity, EPC, planning history, floor area or private-estate status. INSIGHT will not substitute a different dimension silently.") + insightCaveat(insightUniverseBoundary())
          };
        }
        groups = groups.filter(group => group.count >= 5 && Number.isFinite(group.value) && group.value > 0);
        if (groups.length < 2) return {
          title,
          subtitle: "Insufficient comparable groups",
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: insightLead("The loaded cohort does not contain at least two comparison groups with five usable records each, so INSIGHT is not asserting a relationship.") + insightCaveat(`${caveat} ${insightUniverseBoundary()}`)
        };
        const strongest = groups.slice().sort((left, right) => right.value - left.value)[0];
        const weakest = groups.slice().sort((left, right) => left.value - right.value)[0];
        const spread = weakest.value ? strongest.value / weakest.value - 1 : 0;
        const relationshipText = correlation === null ? "" : ` The linear association is ${correlation.toFixed(2)}, which is ${Math.abs(correlation) < .2 ? "weak" : Math.abs(correlation) < .5 ? "moderate" : "strong"} in this cohort.`;
        const formatRelationshipValue = group => group.priceMetric ? compactPrice(group.value) : compactPpsf(group.value);
        return {
          title,
          subtitle: `${formatNumber(groups.reduce((sum, group) => sum + group.count, 0))} usable records`,
          layout: "analysis",
          showLedger: false,
          rows,
          html: insightLead(`${strongest.label} has the highest median CPIH-adjusted value at ${formatRelationshipValue(strongest)}, ${Math.abs(spread * 100).toFixed(1)}% above ${weakest.label.toLowerCase()}, the lowest comparison group.${relationshipText}`) + insightBarList(groups.map(group => ({ label: group.label, value: group.value, formatted: `${formatRelationshipValue(group)} · n=${formatNumber(group.count)}` }))) + insightCaveat(`${caveat} ${insightUniverseBoundary("CPIH adjustment uses INSIGHT's internal annual index through 2026.")}`)
        };
      }

      function insightRequestedModuleHtml(rows, topics) {
        const modules = [];
        const topicIds = new Set(topics.map(topic => topic.id));
        if (topicIds.has("epc")) {
          const groups = [["A–B", ["A", "B"]], ["C", ["C"]], ["D", ["D"]], ["E–G", ["E", "F", "G"]], ["Unknown", []]];
          modules.push(insightTable(["EPC band", "Properties", "Share"], groups.map(([label, ratings]) => {
            const count = ratings.length
              ? rows.filter(item => ratings.includes(String(item.epcRating || "").slice(0, 1).toUpperCase())).length
              : rows.filter(item => !String(item.epcRating || "").trim()).length;
            return [label, formatNumber(count), rows.length ? `${Math.round(count / rows.length * 100)}%` : "—"];
          }), "EPC breakdown"));
        }
        if (topicIds.has("planning")) {
          const planning = planningMetricsForRows(rows);
          modules.push(contextSection("Planning evidence", [
            ["Unique authority/reference cases", formatNumber(planning.uniqueCases)],
            ["Property-application links", formatNumber(planning.propertyLinks)],
            ["Matched properties", `${formatNumber(planning.matchedProperties)} of ${formatNumber(new Set(rows.map(propertyRecordKey)).size)}`],
            ["High-confidence cases", formatNumber(planning.highConfidenceCases)],
            ["Low-confidence cases", formatNumber(planning.lowConfidenceCases)]
          ]));
        }
        if (topicIds.has("flood")) {
          const checked = rows.filter(item => item.environmentAgency?.floodStatus).length;
          const alerts = rows.filter(item => Number(item.environmentAgency?.currentFloodAlertCount || 0) > 0).length;
          modules.push(contextSection("Current flood evidence", [
            ["Properties with current alerts", formatNumber(alerts)],
            ["Loaded status checks", `${formatNumber(checked)} of ${formatNumber(rows.length)}`],
            ["Unknown / unmatched", formatNumber(Math.max(0, rows.length - checked))],
            ["Interpretation", "Current-alert context only"]
          ]));
        }
        if (topicIds.has("transport")) {
          const stationDistances = rows.map(item => nearestStations(transactionGeoPoint(item), 1)[0]?.distanceKm).filter(Number.isFinite);
          const airportTimes = rows.map(item => nearestAirports(transactionGeoPoint(item), 1)[0]?.driveMins).filter(Number.isFinite);
          modules.push(contextSection("Transport context", [
            ["Median nearest station", stationDistances.length ? formatDistanceKm(median(stationDistances)) : "Unavailable"],
            ["Within 1.5km of defined station", formatNumber(rows.filter(item => (nearestStations(transactionGeoPoint(item), 1)[0]?.distanceKm ?? Infinity) <= 1.5).length)],
            ["Median nearest airport drive", airportTimes.length ? formatMinutes(median(airportTimes)) : "Unavailable"],
            ["Distance basis", "Mapped / postcode-centroid coordinates"]
          ]));
        }
        if (topicIds.has("schools")) {
          const nearestDistances = rows.map(item => Number(item.ofsted?.nearestSchools?.[0]?.metres || 0)).filter(value => value > 0);
          modules.push(contextSection("School proximity context", [
            ["Properties with linked schools", `${formatNumber(nearestDistances.length)} of ${formatNumber(rows.length)}`],
            ["Median nearest supplied school", nearestDistances.length ? formatDistanceKm(median(nearestDistances) / 1000) : "Unavailable"],
            ["Within 1km", formatNumber(nearestDistances.filter(value => value <= 1000).length)],
            ["Interpretation", "Proximity only; not catchment or quality"]
          ]));
        }
        if (!modules.length) return "";
        return `<div class="insight-module-grid">${modules.join("")}</div>`;
      }

      function insightExecutiveBriefAnswer(rows, query, locations, dateRange, typeFilter) {
        if (!briefingRequested(query) && !compositeAnalysisRequested(query)) return null;
        if (!rows.length) return null;
        const stats = statsForRows(rows);
        const historicalSlice = isTransactionGrain(rows);
        const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
        const ppsfRows = rows.filter(item => realPpsfForSale(item) > 0);
        const ppsf = ppsfRows.map(realPpsfForSale);
        const planning = planningMetricsForRows(rows);
        const epcCovered = rows.filter(item => item.epcRating || Number(item.floorAreaSqft || 0) > 0).length;
        const floodCovered = rows.filter(item => item.environmentAgency?.floodStatus).length;
        const currentAlerts = rows.filter(item => Number(item.environmentAgency?.currentFloodAlertCount || 0) > 0).length;
        const exactCoordinates = rows.filter(item => ["exact", "address"].includes(transactionGeoPoint(item)?.[3])).length;
        const nearestDistances = rows.map(item => nearestStations(transactionGeoPoint(item), 1)[0]?.distanceKm).filter(Number.isFinite);
        const scope = [insightLocationScopeLabel(locations), typeFilter?.label, dateRange?.label].filter(Boolean).join(" · ") || "Surrey prime evidence";
        const skew = average(prices) > median(prices) * 1.12 ? "The mean sits materially above the median, indicating a top-heavy price distribution." : "The mean and median are relatively close, suggesting a less skewed matched price distribution.";
        const activity = historicalSlice
          ? `${formatNumber(rows.length)} recorded transactions fall within the requested historical period. Current velocity and momentum scores are deliberately not projected backwards into that slice.`
          : `Activity is ${velocityLabel(stats).toLowerCase()} with ${momentumLabel(stats).toLowerCase()} momentum; ${formatNumber(stats.recent)} recorded transactions fall in the latest 12-month window. Velocity measures transaction pace, not time-on-market.`;
        const movement = historicalSlice
          ? "Same-property movement is not calculated inside a pre-filtered historical transaction slice."
          : stats.priceConfidence > 0
          ? `Same-property evidence indicates ${priceMovementLabel(stats)}, based on ${priceMovementEvidenceLabel(stats).toLowerCase()}.`
          : "There is insufficient qualifying same-property evidence for a defensible real annualised price-movement estimate.";
        const coverage = `EPC evidence covers ${Math.round(epcCovered / rows.length * 100)}% of matched records; planning is linked to ${formatNumber(planning.matchedProperties)} properties and ${formatNumber(planning.uniqueCases || planning.propertyLinks)} unique or property-linked cases.`;
        const topics = explicitAnalysisTopics(query);
        return {
          title: compositeAnalysisRequested(query) ? "Multi-part analysis" : "INSIGHT briefing",
          subtitle: scope,
          layout: "report",
          showLedger: false,
          rows,
          mapRows: rows,
          html: insightLead([
            `${scope} contains ${formatNumber(rows.length)} matched ${dateRange ? "transaction" : "property"} records. The median recorded sale is ${compactPrice(median(prices))}, the average is ${compactPrice(average(prices))}, and the upper quartile begins around ${compactPrice(quantileInclusive(prices, .75))}.`,
            `${skew} ${activity}`,
            `${movement} ${coverage}`
          ]) + insightMetricGrid([
            { label: "Median sale", value: compactPrice(median(prices)), detail: `${insightSampleConfidence(rows.length)} sample strength` },
            { label: "Real median £/sq ft", value: compactPpsf(median(ppsf)) || "Unavailable", detail: `${formatNumber(ppsfRows.length)} EPC-priced records` },
            { label: historicalSlice ? "Transactions" : "Velocity", value: historicalSlice ? formatNumber(rows.length) : velocityLabel(stats), detail: historicalSlice ? dateRange?.label || "Requested period" : `${stats.velocity.toFixed(2)}× normal · ${accelerationLabel(stats)}` },
            { label: historicalSlice ? "Period coverage" : "Momentum", value: historicalSlice ? (dateRange?.label || "Historical slice") : momentumLabel(stats), detail: historicalSlice ? "No present-day score leakage" : priceMovementLabel(stats) },
            { label: "Planning cases", value: formatNumber(planning.uniqueCases || planning.propertyLinks), detail: `${formatNumber(planning.propertyLinks)} property links` },
            { label: "EPC coverage", value: `${Math.round(epcCovered / rows.length * 100)}%`, detail: `${formatNumber(epcCovered)} of ${formatNumber(rows.length)}` },
            { label: "Flood alerts", value: formatNumber(currentAlerts), detail: `${formatNumber(floodCovered)} loaded current-alert checks` },
            { label: "Station proximity", value: nearestDistances.length ? formatDistanceKm(median(nearestDistances)) : "Unavailable", detail: "Median nearest defined station" }
          ]) + `<div class="insight-columns">${contextSection("Market reading", [
            ["Activity", velocityLabel(stats)],
            ["90-day signal", accelerationLabel(stats)],
            ["Real movement", priceMovementLabel(stats)],
            ["Repeat-sale evidence", priceMovementEvidenceLabel(stats)]
          ])}${contextSection("Evidence quality", [
            ["Matched records", formatNumber(rows.length)],
            ["EPC-priced records", formatNumber(ppsfRows.length)],
            ["Address-level coordinates", `${formatNumber(exactCoordinates)} of ${formatNumber(rows.length)}`],
            ["Requested modules", topics.length ? topics.map(topic => topic.label).join(", ") : "Full briefing"]
          ])}</div>` + insightRequestedModuleHtml(rows, topics) + insightCaveat(`${insightUniverseBoundary("Full histories can include earlier sub-threshold sales only for properties that entered this prime universe.")} Flood evidence is current-alert context, not long-term flood risk; school evidence is proximity/context, not catchment or performance.`)
        };
      }

      function insightCapabilityAnswer() {
        const examples = [
          ["Full briefing", "Give me a full market assessment of Cobham"],
          ["Compare", "Compare Wentworth and St George's Hill by median price and velocity"],
          ["Momentum", "Which Surrey authorities have the strongest momentum?"],
          ["Trends", "Show Cobham's price trend by year since 2020"],
          ["Rankings", "Top 5 private estates by £ per sq ft"],
          ["Comparables", "Find the strongest comparable sales for Cartref, Esher"],
          ["Relative value", "Which large homes look inexpensive relative to their peers?"],
          ["Relationships", "Is station proximity associated with a £ per sq ft premium?"],
          ["Property search", "Most expensive detached sale near Oxshott station"],
          ["Evidence layers", "Show the EPC breakdown and planning activity in Esher"],
          ["Data audit", "How complete is the planning and EPC data?"],
          ["Repeat sales", "Which properties in Weybridge sold more than once?"],
          ["Follow-ups", "Then ask: What about Wentworth? or Detached only?"]
        ];
        return {
          title: "Ask INSIGHT",
          subtitle: "Offline property intelligence",
          layout: "analysis",
          showLedger: false,
          preserveMap: true,
          rows: transactions,
          html: insightLead("I analyse the loaded INSIGHT property database locally. I can build full briefings, compare exact cohorts, calculate market statistics, trace monthly/quarterly/yearly evidence, select scored comparables, find relative-value outliers, test relationships and explain where evidence is incomplete.") + contextSection("Try asking", examples)
        };
      }

      function saleAnswer(item, query, label = "Matched sale") {
        if (!item) return "";
        const point = transactionGeoPoint(item);
        const station = nearestStations(point, 1)[0];
        const airport = nearestAirports(point, 1)[0];
        const estate = estateForTransaction(item);
        const rows = [
          ["Property", propertyDisplayName(item)],
          ["Address", propertyAddressLabel(item)],
          ["Sold price", item.priceText || compactPrice(item.price)],
          ["Sale date", formatDate(item.date)],
          ["Type", item.propertyType],
          ["Market", marketById(item.market)?.short || item.district],
          ...(estate ? [["Private estate", estate.name]] : []),
          ["£/sq ft", compactPpsf(item.pricePerSqft) || "Awaiting EPC"],
          ["EPC area", compactSqft(item.floorAreaSqft)],
          ["EPC rating", item.epcRating],
          ["Planning history", formatNumber(planningApplicationCount(item))],
          ["Flood status", item.environmentAgency?.floodStatus],
          ["Nearest station", station ? `${station.name} · ${formatDistanceKm(station.distanceKm)} · ${formatMinutes(station.fastestMins)} to ${station.london}` : ""],
          ["Nearest airport", airport ? `${airport.name} · drive c. ${formatMinutes(airport.driveMins)}` : ""]
        ];
        const nameWanted = normalise(query).includes("NAME");
        const answer = nameWanted
          ? `The property name shown in the loaded Land Registry address is ${propertyDisplayName(item)}.`
          : `${label}: ${propertyDisplayName(item)} sold for ${item.priceText || compactPrice(item.price)} on ${formatDate(item.date)}.`;
        return textSection("Answer", answer) + dataRows(rows);
      }

      function fuzzyPropertyRows(rows, query) {
        const generic = new Set(normalise("ABOUT ANALYSE ANALYSIS AVERAGE COMPARE DATA DETACHED EPC ESTATE FIND FLOOD GROWTH HIGHEST INSIGHT LATEST MARKET MEDIAN MOMENTUM PLANNING PRICE PROPERTY SALE SALES SHOW TREND VELOCITY").split(" "));
        const tokens = insightQueryTokens(query).filter(token => token.length > 2 && !generic.has(token));
        if (tokens.length < 2) return [];
        return rows.map(item => {
          const textTokens = rowInsightText(item).split(" ");
          const matched = tokens.filter(token => textTokens.some(candidate => candidate === token || (token.length > 5 && editDistance(token, candidate) === 1)));
          return { item, score: matched.length / tokens.length, matched: matched.length };
        }).filter(result => result.matched >= Math.min(2, tokens.length) && result.score >= .55)
          .sort((a, b) => b.score - a.score || Number(b.item.price || 0) - Number(a.item.price || 0))
          .map(result => result.item);
      }

      function insightNarrativeAnswer(rows, query, locations, dateRange, typeFilter) {
        const qn = normalise(query);
        const stats = statsForRows(rows);
        const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
        const floorAreas = rows.map(item => Number(item.floorAreaSqft || 0)).filter(value => value > 0);
        const ppsf = rows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0);
        const scope = [insightLocationScopeLabel(locations), typeFilter?.label, dateRange?.label].filter(Boolean).join(" · ") || "loaded INSIGHT market";
        let answer;
        if (insightIntent(query) === "velocity") {
          answer = stats.transactionGrain
            ? `${scope} contains ${formatNumber(rows.length)} recorded transactions. The current 12-month velocity score is intentionally not applied to a historical transaction slice; ask for a trend or compare period volumes for historical pace.`
            : `${scope} is rated ${velocityLabel(stats)}. There were ${formatNumber(stats.recent)} sales in the latest 12 months, running at ${stats.velocity.toFixed(2)}x normal. The 90-day signal is ${accelerationLabel(stats).toLowerCase()} with ${velocityConfidenceLabel(stats).toLowerCase()}; ${formatNumber(stats.context24)} sales in 24 months are shown as context only.`;
        } else if (insightIntent(query) === "momentum") {
          answer = `${scope} has ${momentumLabel(stats).toLowerCase()} momentum, combining pure transaction velocity, the 90-day activity signal and confidence-weighted real annualised price movement. Velocity is ${velocityLabel(stats)} and real price movement is ${priceMovementLabel(stats)}.`;
        } else if (insightIntent(query) === "growth") {
          answer = stats.priceConfidence > 0
            ? `${scope} records ${priceMovementLabel(stats)}, based on ${priceMovementEvidenceLabel(stats).toLowerCase()}. Prices are CPIH-adjusted, annualised over each holding period and aggregated from repeat sales of the same property.`
            : `There is insufficient repeat-sale evidence to estimate real annualised price movement for ${scope}. At least three qualifying same-property pairs are required, so INSIGHT is not inferring movement from a changing mix of homes.`;
        } else if (insightIntent(query) === "planning") {
          const planning = planningMetricsForRows(rows);
          const total = planning.uniqueCases || planningApplicationVolumeForRows(rows);
          answer = `${formatNumber(total)} unique or property-linked planning cases are attached to ${formatNumber(planning.matchedProperties)} of the ${formatNumber(rows.length)} matched properties in ${scope}. There are ${formatNumber(planning.propertyLinks)} property-application links; duplicate authority/reference cases are counted once in the area total.`;
        } else if (insightIntent(query) === "flood") {
          const alerts = rows.filter(item => Number(item.environmentAgency?.currentFloodAlertCount || 0) > 0).length;
          const covered = rows.filter(item => item.environmentAgency?.floodStatus).length;
          answer = `${formatNumber(alerts)} of ${formatNumber(rows.length)} matched properties currently carry a loaded flood alert, and ${formatNumber(covered)} have a recorded flood-status assessment. A missing status is treated as unknown, not low risk.`;
        } else if (insightIntent(query) === "epc") {
          const covered = rows.filter(item => item.epcRating || Number(item.floorAreaSqft || 0) > 0).length;
          answer = `EPC evidence is available for ${formatNumber(covered)} of ${formatNumber(rows.length)} matched properties in ${scope}. Where floor area is present, the average is ${compactSqft(average(floorAreas)) || "unavailable"} and the average sale price per square foot is ${compactPpsf(average(ppsf)) || "unavailable"}.`;
        } else if (insightIntent(query) === "ppsf") {
          const useMedian = qn.includes("MEDIAN");
          const value = useMedian ? median(ppsf) : average(ppsf);
          answer = `The ${useMedian ? "median" : "average"} recorded sale price per square foot is ${compactPpsf(value) || "unavailable"} across ${formatNumber(ppsf.length)} EPC-priced records in ${scope}. ${formatNumber(Math.max(0, rows.length - ppsf.length))} matched records do not have usable floor-area evidence.`;
        } else if (insightIntent(query) === "size") {
          const useMedian = qn.includes("MEDIAN");
          const value = useMedian ? median(floorAreas) : average(floorAreas);
          answer = `The ${useMedian ? "median" : "average"} EPC floor area is ${compactSqft(value) || "unavailable"} across ${formatNumber(floorAreas.length)} usable records in ${scope}. EPC area is an evidence field, not a measured survey area.`;
        } else if (qn.includes("MEDIAN")) {
          answer = `The median matched sale price is ${compactPrice(median(prices))} across ${formatNumber(rows.length)} properties in ${scope}. The average is ${compactPrice(average(prices))}, so the ${average(prices) > median(prices) ? "upper end is pulling the mean above the typical transaction" : "mean and midpoint are relatively close"}.`;
        } else if (insightIntent(query) === "count") {
          answer = `${formatNumber(rows.length)} ${stats.transactionGrain ? "transactions" : "properties"} match ${scope}. Their average sale price is ${compactPrice(stats.avg)}, the median is ${compactPrice(median(prices))}, and the highest recorded sale is ${compactPrice(stats.max)}.`;
        } else {
          answer = `${formatNumber(rows.length)} matched properties in ${scope} have an average recorded sale price of ${compactPrice(stats.avg)} and a median of ${compactPrice(median(prices))}. The highest loaded sale is ${compactPrice(stats.max)}; ${formatNumber(stats.recent)} sales fall within the latest ${stats.velocityWindowMonths}-month velocity window.`;
        }
        const list = sortRowsForQuery(rows, query).slice(0, topCountFromQuery(query, 6)).map(item => contextItem(propertyDisplayName(item), `${item.priceText || compactPrice(item.price)} · ${formatDate(item.date)} · ${item.propertyType || "Property"} · ${marketById(item.market)?.short || item.district || ""}`));
        return {
          title: "Ask INSIGHT",
          subtitle: `${formatNumber(rows.length)} matched ${stats.transactionGrain ? "transactions" : "properties"}`,
          layout: "analysis",
          rows: sortRowsForQuery(rows, query),
          html: insightLead(answer) + insightMetricGrid([
            { label: "Median sale", value: compactPrice(median(prices)), detail: `${formatNumber(rows.length)} matched records` },
            { label: "Average sale", value: compactPrice(stats.avg), detail: average(prices) > median(prices) * 1.12 ? "Top-heavy distribution" : "Close to median" },
            { label: qn.includes("MEDIAN") && insightIntent(query) === "ppsf" ? "Median £/sq ft" : "Average £/sq ft", value: compactPpsf(qn.includes("MEDIAN") && insightIntent(query) === "ppsf" ? median(ppsf) : stats.ppsfAvg) || "Unavailable", detail: `${formatNumber(ppsf.length)} EPC-priced records` },
            { label: stats.transactionGrain ? "Period transactions" : "Velocity", value: stats.transactionGrain ? formatNumber(rows.length) : velocityLabel(stats), detail: stats.transactionGrain ? dateRange?.label || "Requested period" : `${formatNumber(stats.recent)} sales in 12 months` },
            { label: stats.transactionGrain ? "Period evidence" : "Momentum", value: stats.transactionGrain ? insightSampleConfidence(rows.length) : momentumLabel(stats), detail: stats.transactionGrain ? "No present-day score leakage" : priceMovementLabel(stats) },
            { label: "Planning cases", value: formatNumber(stats.planningApplications), detail: "Deduplicated where references are loaded" }
          ]) + insightEvidenceDetails("Show supporting records", `<div class="context-list">${list.join("")}</div>`) + insightCaveat(`${insightUniverseBoundary()} Missing evidence is unknown, not a negative result. Velocity is transaction activity pace, not selling speed.`)
        };
      }

      function insightAnswer(query, baseRows = state.selectedRows, options = {}) {
        const rawQuery = String(query || "").trim();
        if (capabilityRequested(rawQuery)) return insightCapabilityAnswer();
        const rawBoundary = guardrailResponse(rawQuery, options.useContext !== false) || unavailableDataResponse(rawQuery);
        if (rawBoundary) return rawBoundary;
        const effectiveQuery = options.useContext === false ? rawQuery : effectiveInsightQuery(query);
        if (capabilityRequested(effectiveQuery)) return insightCapabilityAnswer();
        const guarded = unavailableDataResponse(effectiveQuery);
        if (guarded) return guarded;
        const comparableAnswer = insightComparableAnswer(transactions, effectiveQuery);
        if (comparableAnswer) return comparableAnswer;
        const qn = normalise(effectiveQuery);
        const locations = resolvedInsightLocations(effectiveQuery);
        const isComparison = comparisonRequested(effectiveQuery, locations);
        const contextualBase = state.selectedType !== "overview" && !locations.length ? baseRows : transactions;
        let rows = contextualBase.slice();
        if (locations.length) rows = filterRowsByInsightLocations(rows, locations, isComparison);

        const dateRange = dateRangeFromQuery(effectiveQuery);
        const isTrend = trendRequested(effectiveQuery);
        const usesTransactionGrain = Boolean(dateRange) || isTrend;
        if (usesTransactionGrain) rows = activityRowsForProperties(rows);
        const typeFilter = propertyTypeFromQuery(effectiveQuery);
        const densityQuestion = typeFilter && (qn.includes("DENSITY") || qn.includes("SHARE") || qn.includes("CONCENTRATION"));
        if (typeFilter && !densityQuestion) rows = rows.filter(typeFilter.test);

        const ppsfRange = rangeFromValues(effectiveQuery, ppsfValuesFromQuery(effectiveQuery));
        if (ppsfRange) {
          rows = rows.filter(item => {
            const value = Number(item.pricePerSqft || 0);
            if (!value) return false;
            if (ppsfRange.min && value < ppsfRange.min) return false;
            if (ppsfRange.max && value > ppsfRange.max) return false;
            if (ppsfRange.exact && Math.abs(value - ppsfRange.exact) > Math.max(10, ppsfRange.exact * .02)) return false;
            return true;
          });
        }

        const sqftRange = rangeFromValues(effectiveQuery, sqftValuesFromQuery(effectiveQuery));
        if (sqftRange && !ppsfRange) {
          rows = rows.filter(item => {
            const value = Number(item.floorAreaSqft || 0);
            if (!value) return false;
            if (sqftRange.min && value < sqftRange.min) return false;
            if (sqftRange.max && value > sqftRange.max) return false;
            if (sqftRange.exact && Math.abs(value - sqftRange.exact) > Math.max(100, sqftRange.exact * .03)) return false;
            return true;
          });
        }

        const priceRange = rangeFromValues(effectiveQuery, moneyValuesFromQuery(effectiveQuery, true));
        if (priceRange && !ppsfRange && !sqftRange) {
          rows = rows.filter(item => {
            const value = Number(item.price || 0);
            if (priceRange.min && value < priceRange.min) return false;
            if (priceRange.max && value > priceRange.max) return false;
            if (priceRange.exact && Math.abs(value - priceRange.exact) > priceRange.exact * .04) return false;
            return true;
          });
        }

        const trendAnswer = insightTrendAnswer(rows, effectiveQuery, dateRange);
        if (trendAnswer) return trendAnswer;

        if (dateRange) {
          rows = rows.filter(item => {
            const date = parseIso(item.date);
            return date && (!dateRange.from || date >= dateRange.from) && (!dateRange.to || date <= dateRange.to);
          });
        }

        const comparisonAnswer = insightComparisonAnswer(rows, effectiveQuery, locations);
        if (comparisonAnswer) return comparisonAnswer;
        const relativeValueAnswer = insightRelativeValueAnswer(rows, effectiveQuery);
        if (relativeValueAnswer) return relativeValueAnswer;
        const relationshipAnswer = insightRelationshipAnswer(rows, effectiveQuery);
        if (relationshipAnswer) return relationshipAnswer;
        const briefingAnswer = insightExecutiveBriefAnswer(rows, effectiveQuery, locations, dateRange, typeFilter);
        if (briefingAnswer) return briefingAnswer;
        const repeatAnswer = insightRepeatSalesAnswer(rows, effectiveQuery);
        if (repeatAnswer) return repeatAnswer;
        const coverageAnswer = insightCoverageAnswer(rows, effectiveQuery);
        if (coverageAnswer) return coverageAnswer;
        const distributionAnswer = insightDistributionAnswer(rows, effectiveQuery);
        if (distributionAnswer) return distributionAnswer;

        const groupAnswer = insightGroupAnswer(rows, effectiveQuery, typeFilter);
        if (groupAnswer) return groupAnswer;

        if (!locations.length && !dateRange && !typeFilter && !priceRange && !ppsfRange && !sqftRange) {
          const textRows = rows.filter(item => rowInsightText(item).includes(qn));
          const fuzzyRows = textRows.length ? [] : fuzzyPropertyRows(rows, effectiveQuery);
          if (textRows.length || fuzzyRows.length) rows = textRows.length ? textRows : fuzzyRows;
        }

        const sorted = sortRowsForQuery(rows, effectiveQuery);
        const asksSingle = qn.includes("MOST EXPENSIVE") || qn.includes("HIGHEST SALE") || qn.includes("CHEAPEST") || qn.includes("LATEST") || qn.includes("OLDEST") || qn.includes("LARGEST") || qn.includes("BIGGEST") || qn.includes("NAME");

        if (!sorted.length) {
          return {
            title: "Ask INSIGHT",
            subtitle: "No loaded matches",
            rows: [],
            html: textSection("Answer", "No matching records were found in the loaded INSIGHT dataset. Try a broader location, date, price band or property type.")
          };
        }

        if (asksSingle) {
          const label = qn.includes("CHEAPEST") ? "Cheapest matched sale"
            : qn.includes("LATEST") ? "Latest matched sale"
            : qn.includes("OLDEST") ? "Oldest matched sale"
            : qn.includes("LARGEST") || qn.includes("BIGGEST") ? "Largest matched EPC area"
            : "Highest matched sale";
          return {
            title: "Ask INSIGHT",
            subtitle: `${formatNumber(sorted.length)} loaded matches`,
            rows: sorted,
            html: saleAnswer(sorted[0], effectiveQuery, label)
          };
        }
        return insightNarrativeAnswer(sorted, effectiveQuery, locations, dateRange, typeFilter);
      }

      function currentInsightAnswer() {
        const query = insightQuestion();
        if (!query) return null;
        const cacheKey = [normalise(query), state.selectedType, propertyId(state.selectedId), state.selectedRows.length, landRegMeta.to || ""].join("|");
        if (state.insightAnswerCache?.key === cacheKey) return state.insightAnswerCache.answer;
        const raw = insightAnswer(query, state.selectedRows);
        const answer = raw ? {
          layout: raw.layout || (raw.showLedger === false ? "analysis" : "compact"),
          evidenceRows: Array.isArray(raw.evidenceRows) ? raw.evidenceRows : raw.rows,
          ...raw
        } : null;
        state.insightAnswerCache = { key: cacheKey, answer };
        return answer;
      }

      // Stable local analyst seam for future INSIGHT sections. Consumers ask
      // for an evidence-bound answer; they do not reimplement parsing or gain
      // direct write access to the underlying datasets.
      window.INSIGHT_ANALYST = Object.freeze({
        version: "2.0-local",
        analyse(question) {
          const answer = insightAnswer(String(question || ""), transactions, { useContext: false });
          return answer ? {
            ...answer,
            matchedCount: Array.isArray(answer.rows) ? answer.rows.length : 0,
            universe: insightUniverseBoundary()
          } : null;
        },
        capabilities: Object.freeze(["briefing", "comparison", "trend", "ranking", "comparables", "relative-value", "relationship", "repeat-sales", "distribution", "coverage"])
      });
      window.INSIGHT_BOOT_STAGE = "interface";

      function rememberInsightQuery(query) {
        const clean = String(query || "").trim();
        if (clean.length < 4 || capabilityRequested(clean)) return;
        state.insightContext = { query: clean, rememberedAt: Date.now() };
      }

      function rowsMatchingSearch(rows) {
        const question = insightQuestion();
        if (question) {
          const answer = rows === state.selectedRows ? currentInsightAnswer() : insightAnswer(question, rows);
          return Array.isArray(answer?.evidenceRows) ? answer.evidenceRows : Array.isArray(answer?.rows) ? answer.rows : [];
        }
        const query = normalise(state.search);
        if (!query) return rows;
        return rows.filter(item => {
          const text = normalise([item.address, item.postcode, item.town, item.district, item.propertyType, item.priceText].join(" "));
          return text.includes(query);
        });
      }

      function selectOverview() {
        state.selectedType = "overview";
        state.selectedId = null;
        state.selectedRows = transactions;
        recordSelectionHistory();
        renderAll();
      }

      function resetMap() {
        clearHoveredMapFeature();
        hideMapTooltip();
        selectOverview();
        if (map) map.easeTo({ center: [-0.43, 51.29], zoom: mapZoomFromDisplay(defaultZoomLevel), padding: overviewMapPadding, duration: 650 });
      }

      function selectMarket(id) {
        const market = marketById(id);
        state.selectedType = "market";
        state.selectedId = id;
        state.selectedRows = rowsForMarket(id);
        recordSelectionHistory();
        if (map && market && districtGeoPoints[market.district]) {
          map.easeTo({ center: districtGeoPoints[market.district], zoom: Math.max(map.getZoom(), 10.4), padding: selectionMapPadding, duration: 650 });
        }
        renderAll();
      }

      function selectEstate(key) {
        const estate = estatePins.find(pin => pin.key === key);
        if (!estate) return;
        state.selectedType = "estate";
        state.selectedId = key;
        state.selectedRows = estateTransactions(key);
        recordSelectionHistory();
        const navigationAnchor = estateNavigationAnchors.find(pin => pin.key === key);
        const center = estateCenter(navigationAnchor);
        if (map && center) map.jumpTo({ center, zoom: 12.8, padding: selectionMapPadding });
        renderAll();
      }

      function selectTown(key) {
        const point = townGeoPoints[key];
        state.selectedType = "town";
        state.selectedId = key;
        state.selectedRows = rowsForTownKey(key);
        recordSelectionHistory();
        if (map && point) map.easeTo({ center: point, zoom: Math.max(map.getZoom(), 12.8), padding: selectionMapPadding, duration: 650 });
        renderAll();
      }

      function selectProperty(id) {
        const idText = propertyId(id);
        const item = transactions.find(row => propertyId(row.id) === idText);
        if (!item) return;
        state.selectedType = "property";
        state.selectedId = idText;
        state.selectedRows = [item];
        recordSelectionHistory();
        const point = transactionGeoPoint(item);
        const targetZoom = point[3] === "exact" || point[3] === "address" ? 14.8 : 14.4;
        if (map) map.easeTo({ center: [point[0], point[1]], zoom: Math.max(map.getZoom(), targetZoom), padding: selectionMapPadding, duration: 650 });
        renderAll();
        if (window.requestAnimationFrame) window.requestAnimationFrame(applyMapStateToMap);
      }

      function selectSchool(id) {
        const school = schoolById(id);
        if (!school) return;
        const point = schoolCoordinate(school);
        state.selectedType = "school";
        state.selectedId = schoolId(school);
        state.selectedRows = nearbyTransactionsForPoint(point, 2.5);
        recordSelectionHistory();
        if (map && point) map.easeTo({ center: point, zoom: Math.max(map.getZoom(), 14.2), padding: selectionMapPadding, duration: 650 });
        renderAll();
      }

      function selectStation(id) {
        const station = stationById(id);
        if (!station) return;
        const point = stationCoordinate(station);
        state.selectedType = "station";
        state.selectedId = station.id;
        state.selectedRows = nearbyTransactionsForPoint(point, 3);
        recordSelectionHistory();
        if (map && point) map.easeTo({ center: point, zoom: Math.max(map.getZoom(), 13.8), padding: selectionMapPadding, duration: 650 });
        renderAll();
      }

      function selectAirport(id) {
        const airport = airportById(id);
        if (!airport) return;
        const point = airportCoordinate(airport);
        state.selectedType = "airport";
        state.selectedId = airport.id;
        state.selectedRows = nearbyTransactionsForPoint(point, 18);
        recordSelectionHistory();
        if (map && point) map.easeTo({ center: point, zoom: Math.max(map.getZoom(), 11.6), padding: selectionMapPadding, duration: 650 });
        renderAll();
      }

      function recordSelectionHistory() {
        if (restoringSelectionHistory) return;
        const snapshot = { type: state.selectedType, id: state.selectedId == null ? null : String(state.selectedId) };
        const current = selectionHistory[selectionHistoryIndex];
        if (current && current.type === snapshot.type && current.id === snapshot.id) return;
        selectionHistory.splice(selectionHistoryIndex + 1);
        selectionHistory.push(snapshot);
        selectionHistoryIndex = selectionHistory.length - 1;
      }

      function navigateSelectionHistory(direction) {
        const nextIndex = clamp(0, selectionHistory.length - 1, selectionHistoryIndex + Number(direction || 0));
        if (nextIndex === selectionHistoryIndex) return false;
        selectionHistoryIndex = nextIndex;
        const snapshot = selectionHistory[selectionHistoryIndex];
        restoringSelectionHistory = true;
        try {
          if (snapshot.type === "overview") resetMap();
          else if (snapshot.type === "market") selectMarket(snapshot.id);
          else if (snapshot.type === "estate") selectEstate(snapshot.id);
          else if (snapshot.type === "town") selectTown(snapshot.id);
          else if (snapshot.type === "property") selectProperty(snapshot.id);
          else if (snapshot.type === "school") selectSchool(snapshot.id);
          else if (snapshot.type === "station") selectStation(snapshot.id);
          else if (snapshot.type === "airport") selectAirport(snapshot.id);
        } finally {
          restoringSelectionHistory = false;
        }
        return true;
      }

      window.INSIGHT_NAVIGATE_HISTORY = navigateSelectionHistory;

      function newsTimestamp(value) {
        const timestamp = Date.parse(String(value || ""));
        return Number.isFinite(timestamp) ? timestamp : 0;
      }

      function newsRelativeTime(value) {
        const timestamp = newsTimestamp(value);
        if (!timestamp) return "Recently";
        const seconds = Math.max(0, Math.round((Date.now() - timestamp) / 1000));
        if (seconds < 90) return "Just now";
        const minutes = Math.round(seconds / 60);
        if (minutes < 60) return `${minutes} min ago`;
        const hours = Math.round(minutes / 60);
        if (hours < 24) return `${hours} hr ago`;
        const days = Math.round(hours / 24);
        return days === 1 ? "Yesterday" : `${days} days ago`;
      }

      function leadingNewsItems(items) {
        if (items.length <= 3) return items;
        const selected = [items[0]];
        for (const item of items.slice(1)) {
          if (!selected.some(existing => existing.sourceId === item.sourceId)) selected.push(item);
          if (selected.length === 3) return selected;
        }
        for (const item of items.slice(1)) {
          if (!selected.includes(item)) selected.push(item);
          if (selected.length === 3) break;
        }
        return selected;
      }

      function renderNews() {
        if (!els.newsList) return;
        const valid = newsItems
          .filter(item => item && safeHttpsUrl(item.url) && item.title && Number(item.score) >= 0)
          .sort((left, right) => String(right.publishedAt || "").localeCompare(String(left.publishedAt || "")) || Number(right.score || 0) - Number(left.score || 0));
        const visible = newsExpanded ? valid.slice(0, 7) : leadingNewsItems(valid);
        const previousTimestamp = newsTimestamp(newsPreviousVisit);
        const newCount = valid.filter(item => newsTimestamp(item.publishedAt) > previousTimestamp).length;

        if (els.newsNewCount) {
          els.newsNewCount.hidden = newCount === 0;
          els.newsNewCount.textContent = newCount ? `${Math.min(newCount, 99)} new` : "";
        }
        if (els.newsMoreButton) {
          els.newsMoreButton.hidden = valid.length <= 3;
          els.newsMoreButton.textContent = newsExpanded ? "Show less" : `View all ${Math.min(valid.length, 7)}`;
          els.newsMoreButton.setAttribute("aria-expanded", newsExpanded ? "true" : "false");
        }
        els.newsList.classList.toggle("expanded", newsExpanded);

        if (!visible.length) {
          els.newsList.innerHTML = '<p class="news-empty">No relevant new stories. INSIGHT will keep checking.</p>';
        } else {
          els.newsList.innerHTML = visible.map(item => {
            const url = safeHttpsUrl(item.url);
            const isNew = newsTimestamp(item.publishedAt) > previousTimestamp;
            const topic = Array.isArray(item.topics) && item.topics.length ? item.topics[0] : "Property";
            const meta = [item.source, item.location, topic, newsRelativeTime(item.publishedAt)].filter(Boolean).join(" · ");
            return `
              <a class="news-item${isNew ? "" : " seen"}" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(item.title)}. ${escapeHtml(item.reason || meta)}">
                <span class="news-unread-dot" aria-hidden="true"></span>
                <span>
                  <span class="news-item-title">${escapeHtml(item.title)}</span>
                  <span class="news-item-meta">${escapeHtml(meta)}</span>
                </span>
              </a>`;
          }).join("");
        }

        if (els.newsFeedStatus && newsMeta.generatedAt) {
          const errors = Array.isArray(newsMeta.sourceErrors) ? newsMeta.sourceErrors.length : 0;
          els.newsFeedStatus.textContent = errors
            ? `Updated ${newsRelativeTime(newsMeta.generatedAt)} · ${errors} source delayed`
            : `Updated ${newsRelativeTime(newsMeta.generatedAt)}`;
        }
      }

      function renderAll() {
        renderLayers();
        renderNews();
        renderSummary();
        renderMarkets();
        renderEstates();
        renderTowns();
        renderInspector();
        renderLedger();
        renderLegend();
        updateZoomUi();
        applyMapStateToMap();
      }

      function mapStyleReady() {
        return Boolean(map && map.getStyle && map.getStyle() && map.getLayer("property-points"));
      }

      function applyMapStateToMap() {
        if (!mapStyleReady()) return;
        updatePropertyMapSource();
        applyLayerVisibility();
        applyRenderMode();
        updateSelectedPropertyHighlight();
        applyEstatePointSelection();
      }

      function applyEstatePointSelection() {
        if (!map) return;
        if (map.getSource("estates")) {
          if (selectedEstatePointId) {
            map.setFeatureState({ source: "estates", id: selectedEstatePointId }, { selected: false });
          }
          const nextPointId = state.selectedType === "estate" ? String(state.selectedId || "") : "";
          selectedEstatePointId = estateNavigationAnchors.some(anchor => anchor.key === nextPointId) ? nextPointId : null;
          if (selectedEstatePointId) {
            map.setFeatureState({ source: "estates", id: selectedEstatePointId }, { selected: true });
          }
        }
      }

      function renderLayers() {
        els.layerList.innerHTML = layerRegistry.map(layer => `
          <div class="layer-row">
            <div>
              <strong>${escapeHtml(layer.label)}</strong>
              <small>${escapeHtml(layer.detail)}</small>
            </div>
            <button class="switch" type="button" aria-pressed="${state.layers[layer.id] ? "true" : "false"}" data-layer="${escapeHtml(layer.id)}"></button>
          </div>
        `).join("");
        els.layerList.querySelectorAll("[data-layer]").forEach(button => {
          button.addEventListener("click", () => {
            state.layers[button.dataset.layer] = !state.layers[button.dataset.layer];
            renderLayers();
            applyLayerVisibility();
          });
        });
      }

      function selectedPropertyItem() {
        return state.selectedType === "property" ? transactions.find(row => propertyId(row.id) === propertyId(state.selectedId)) : null;
      }

      function propertyMarketContext(item = selectedPropertyItem()) {
        if (!item) return null;
        const estate = estateForTransaction(item);
        if (estate) {
          return {
            kind: "estate",
            id: estate.key,
            rows: estateTransactions(estate.key)
          };
        }
        const marketId = item.market || marketDefinitions.find(market => market.district === item.district)?.id;
        return {
          kind: "market",
          id: marketId,
          rows: marketId ? rowsForMarket(marketId) : [item]
        };
      }

      function selectedSummaryRows() {
        return propertyMarketContext()?.rows || state.selectedRows;
      }

      function selectedContextStats(rows = state.selectedRows) {
        if (state.selectedType === "overview") return overallStats;
        if (state.selectedType === "market") return marketStats[state.selectedId] || statsForRows(rows);
        if (state.selectedType === "town") return townStats[state.selectedId] || statsForRows(rows);
        if (state.selectedType === "estate") {
          const estate = estatePins.find(pin => pin.key === state.selectedId);
          return estate ? statsForEstate(estate) : statsForRows(rows);
        }
        if (state.selectedType === "property") {
          const context = propertyMarketContext();
          if (context?.kind === "estate") {
            const estate = estatePins.find(pin => pin.key === context.id);
            if (estate) return statsForEstate(estate);
          }
          if (context?.kind === "market" && marketStats[context.id]) return marketStats[context.id];
        }
        return statsForRows(rows);
      }

      function activeMarketId() {
        if (state.selectedType === "market") return state.selectedId;
        const context = propertyMarketContext();
        return context?.kind === "market" ? context.id : null;
      }

      function activeEstateKey() {
        if (state.selectedType === "estate") return state.selectedId;
        const context = propertyMarketContext();
        return context?.kind === "estate" ? context.id : null;
      }

      function visibleRankedWithActive(ranked, activeId, getId, expanded, limit = 5) {
        if (expanded || !activeId) return expanded ? ranked : ranked.slice(0, limit);
        const visible = ranked.slice(0, limit);
        if (visible.some(item => getId(item) === activeId)) return visible;
        const active = ranked.find(item => getId(item) === activeId);
        return active ? [active, ...visible.filter(item => getId(item) !== activeId).slice(0, limit - 1)] : visible;
      }

      function renderSummary() {
        if (!els.summaryGrid || !els.summaryNote) return;
        const stats = selectedContextStats(selectedSummaryRows());
        const rows = [
          ["Velocity", velocityLabel(stats)],
          ["12m pace", stats.velocity.toFixed(2) + "x"],
          ["Last 12m", formatNumber(stats.recent)],
          ["Last 24m", formatNumber(stats.context24)]
        ];
        els.summaryGrid.innerHTML = rows.map(row => `<div class="metric"><span>${row[0]}</span><strong>${row[1]}</strong></div>`).join("");
        els.summaryNote.textContent = state.selectedType === "overview" ? "Surrey" : `${formatNumber(stats.count)} sales`;
      }

      function renderMarkets() {
        const ranked = marketDefinitions.slice().sort((a, b) => {
          const aStats = marketStats[a.id];
          const bStats = marketStats[b.id];
          return bStats.velocityScore - aStats.velocityScore ||
            bStats.accelerationScore - aStats.accelerationScore ||
            bStats.velocityConfidence - aStats.velocityConfidence ||
            bStats.velocity - aStats.velocity ||
            bStats.recent - aStats.recent ||
            bStats.count - aStats.count;
        });
        const marketActiveId = activeMarketId();
        const visibleMarkets = visibleRankedWithActive(ranked, marketActiveId, market => market.id, state.marketListExpanded);
        els.marketTitle.textContent = "Local Authorities";
        els.marketRankNote.textContent = state.marketListExpanded ? "All 12m pace + 90d signal" : "Top 5 · 12m pace + 90d signal";
        els.marketList.innerHTML = visibleMarkets.map(market => {
          const stats = marketStats[market.id];
          return `
            <article class="market-card${marketActiveId === market.id ? " active" : ""}" data-market="${escapeHtml(market.id)}">
              <h3>${escapeHtml(market.short)}</h3>
              <p>${velocityLabel(stats)} · ${stats.velocity.toFixed(2)}x normal · ${formatNumber(stats.recent)} in 12m · ${accelerationLabel(stats)} · ${velocityConfidenceLabel(stats)}</p>
              <div class="heat-bar" style="--w:${stats.velocityScore}%"><span></span></div>
            </article>`;
        }).join("") + (ranked.length > 5 ? `<button class="more-button" type="button" data-market-more aria-expanded="${state.marketListExpanded}">More (${ranked.length - 5})</button>` : "");
        els.marketList.querySelectorAll("[data-market]").forEach(card => {
          card.addEventListener("click", () => selectMarket(card.dataset.market));
        });
        const more = els.marketList.querySelector("[data-market-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.marketListExpanded = !state.marketListExpanded;
            renderMarkets();
          });
        }
      }

      function renderEstates() {
        const ranked = estatePins.map(pin => {
          const rows = estateTransactions(pin);
          return { pin, stats: statsForEstate(pin) };
        }).sort((a, b) => {
          return b.stats.velocityScore - a.stats.velocityScore ||
            b.stats.accelerationScore - a.stats.accelerationScore ||
            b.stats.velocityConfidence - a.stats.velocityConfidence ||
            b.stats.velocity - a.stats.velocity ||
            b.stats.recent - a.stats.recent ||
            b.stats.count - a.stats.count;
        });
        const estateActiveKey = activeEstateKey();
        const visibleEstates = visibleRankedWithActive(ranked, estateActiveKey, item => item.pin.key, state.estateListExpanded);
        els.estateTitle.textContent = "Private Estates";
        els.estateRankNote.textContent = state.estateListExpanded ? "All 12m pace + 90d signal" : "Top 5 · 12m pace + 90d signal";
        els.estateList.innerHTML = visibleEstates.map(({ pin, stats }) => `
          <article class="estate-card${estateActiveKey === pin.key ? " active" : ""}" data-estate="${escapeHtml(pin.key)}">
            <h3>${escapeHtml(pin.name)}</h3>
            <p>${stats.count
              ? `${velocityLabel(stats)} · ${stats.velocity.toFixed(2)}x normal · ${formatNumber(stats.recent)} in 12m · ${accelerationLabel(stats)} · ${velocityConfidenceLabel(stats)}`
              : `No qualifying £3m+ sales since ${coverageYear}`}</p>
            <div class="heat-bar" style="--w:${stats.velocityScore}%"><span></span></div>
          </article>
        `).join("") + (ranked.length > 5 ? `<button class="more-button" type="button" data-estate-more aria-expanded="${state.estateListExpanded}">More (${ranked.length - 5})</button>` : "");
        els.estateList.querySelectorAll("[data-estate]").forEach(card => {
          card.addEventListener("click", () => selectEstate(card.dataset.estate));
        });
        const more = els.estateList.querySelector("[data-estate-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.estateListExpanded = !state.estateListExpanded;
            renderEstates();
          });
        }
      }

      function renderTowns() {
        const ranked = Object.keys(townStats)
          .map(key => ({ key, stats: townStats[key] }))
          .filter(item => item.stats.count > 0)
          .sort((a, b) => {
            return b.stats.velocityScore - a.stats.velocityScore ||
              b.stats.accelerationScore - a.stats.accelerationScore ||
              b.stats.velocityConfidence - a.stats.velocityConfidence ||
              b.stats.velocity - a.stats.velocity ||
              b.stats.recent - a.stats.recent ||
              b.stats.count - a.stats.count;
          });
        const visibleTowns = state.townListExpanded ? ranked : ranked.slice(0, 5);
        els.townTitle.textContent = "Towns";
        els.townRankNote.textContent = state.townListExpanded ? "All 12m pace + 90d signal" : "Top 5 · 12m pace + 90d signal";
        els.townList.innerHTML = visibleTowns.map(({ key, stats }) => `
          <article class="town-card${state.selectedType === "town" && state.selectedId === key ? " active" : ""}" data-town="${escapeHtml(key)}">
            <h3>${escapeHtml(townDisplayName(key))}</h3>
            <p>${velocityLabel(stats)} · ${stats.velocity.toFixed(2)}x normal · ${formatNumber(stats.recent)} in 12m · ${accelerationLabel(stats)} · ${velocityConfidenceLabel(stats)}</p>
            <div class="heat-bar" style="--w:${stats.velocityScore}%"><span></span></div>
          </article>
        `).join("") + (ranked.length > 5 ? `<button class="more-button" type="button" data-town-more aria-expanded="${state.townListExpanded}">More (${ranked.length - 5})</button>` : "");
        els.townList.querySelectorAll("[data-town]").forEach(card => {
          card.addEventListener("click", () => selectTown(card.dataset.town));
        });
        const more = els.townList.querySelector("[data-town-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.townListExpanded = !state.townListExpanded;
            renderTowns();
          });
        }
      }

      function contextSection(title, rows, listItems = []) {
        const rowHtml = rows && rows.length ? dataRows(rows) : "";
        const listHtml = listItems.length ? `<div class="context-list">${listItems.join("")}</div>` : "";
        if (!rowHtml && !listHtml) return "";
        return `<section class="context-section"><h3>${escapeHtml(title)}</h3>${rowHtml}${listHtml}</section>`;
      }

      function contextItem(title, meta) {
        return `<div class="context-item"><strong>${escapeHtml(title)}</strong>${meta ? `<span>${escapeHtml(meta)}</span>` : ""}</div>`;
      }

      function linkedContextItem(title, meta, link) {
        const safeLink = safeHttpsUrl(link);
        const content = `<strong>${escapeHtml(title)}</strong>${meta ? `<span>${escapeHtml(meta)}</span>` : ""}`;
        return safeLink
          ? `<a class="context-item context-item-link" href="${escapeHtml(safeLink)}" target="_blank" rel="noopener">${content}<em>Open</em></a>`
          : `<div class="context-item">${content}</div>`;
      }

      function textSection(title, body, link, marker = "") {
        if (!body) return "";
        const safeLink = safeHttpsUrl(link);
        const linkHtml = safeLink ? ` <a href="${escapeHtml(safeLink)}" target="_blank" rel="noopener">Open source</a>` : "";
        const markerAttr = marker ? ` ${marker}` : "";
        return `<section class="context-section"${markerAttr}><h3>${escapeHtml(title)}</h3><p class="context-copy">${escapeHtml(body)}${linkHtml}</p></section>`;
      }

      function insightLead(paragraphs) {
        return (Array.isArray(paragraphs) ? paragraphs : [paragraphs])
          .filter(Boolean)
          .map(paragraph => `<p class="insight-lead">${escapeHtml(paragraph)}</p>`)
          .join("");
      }

      function insightMetricGrid(metrics) {
        const cards = metrics.filter(metric => metric && metric.value !== undefined && metric.value !== null && metric.value !== "").map(metric => `
          <div class="insight-kpi">
            <span>${escapeHtml(metric.label)}</span>
            <strong>${escapeHtml(metric.value)}</strong>
            ${metric.detail ? `<small>${escapeHtml(metric.detail)}</small>` : ""}
          </div>
        `).join("");
        return cards ? `<div class="insight-metric-grid">${cards}</div>` : "";
      }

      function insightTable(headers, rows, caption = "") {
        if (!rows.length) return "";
        return `<div class="insight-table-wrap"><table class="insight-table">${caption ? `<caption>${escapeHtml(caption)}</caption>` : ""}<thead><tr>${headers.map(header => `<th scope="col">${escapeHtml(header)}</th>`).join("")}</tr></thead><tbody>${rows.map(row => `<tr>${row.map(cell => `<td>${escapeHtml(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
      }

      function insightBarList(items) {
        const maximum = Math.max(1, ...items.map(item => Math.abs(Number(item.value) || 0)));
        return `<div class="insight-bar-list">${items.map(item => `
          <div class="insight-bar-row">
            <span>${escapeHtml(item.label)}</span>
            <span class="insight-bar-track"><span style="--w:${clamp(2, 100, Math.abs(Number(item.value) || 0) / maximum * 100).toFixed(1)}%"></span></span>
            <strong>${escapeHtml(item.formatted)}</strong>
          </div>
        `).join("")}</div>`;
      }

      function insightCaveat(text) {
        return text ? `<p class="insight-caveat">${escapeHtml(text)}</p>` : "";
      }

      function insightEvidenceDetails(summary, content) {
        return content ? `<details class="insight-evidence"><summary>${escapeHtml(summary)}</summary>${content}</details>` : "";
      }

      function insightUniverseBoundary(extra = "") {
        const through = formatDate(landRegMeta.to || transactions[0]?.date || "");
        return `Universe: recorded Surrey residential transactions at or above ${compactPrice(landRegMeta.priceFloor || 3000000)}, through ${through || "the loaded feed date"}; this is not the whole property market.${extra ? ` ${extra}` : ""}`;
      }

      function estateRoadsSection(estate) {
        const roads = Array.from(new Set(
          privateEstateRules
            .filter(rule => rule.estateId === estate?.key)
            .map(rule => rule.canonicalStreet)
            .filter(Boolean)
        )).sort((left, right) => left.localeCompare(right));
        return roads.length ? contextSection("Estate roads", [], roads.map(road => contextItem(road, ""))) : "";
      }

      function humaniseKey(key) {
        return String(key || "")
          .replace(/([a-z])([A-Z])/g, "$1 $2")
          .replace(/[_-]+/g, " ")
          .replace(/\b[a-z]/g, letter => letter.toUpperCase());
      }

      function planningApplicationDate(application) {
        if (!application || typeof application !== "object") return "";
        return application.decisionDate || application.validatedDate || application.receivedDate ||
          application.submittedDate || application.registeredDate || application.startDate ||
          application.date || application.dateText || application.year ||
          application["decision-date"] || application["validated-date"] || application["received-date"] || "";
      }

      function formatPlanningDate(value) {
        const text = String(value || "").trim();
        if (!text) return "";
        if (/^(?:19|20)\d{2}$/.test(text)) return text;
        const date = new Date(/^\d{4}-\d{2}-\d{2}$/.test(text) ? `${text}T00:00:00Z` : text);
        if (Number.isNaN(date.getTime())) return text;
        return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(date);
      }

      function salesHistoryForTransaction(item) {
        if (!item) return [];
        const recordKey = propertyRecordKey(item);
        if (salesHistoryRowsCache.has(recordKey)) return salesHistoryRowsCache.get(recordKey).slice();
        const titleHistory = window.SURREY_SALES_HISTORY || {};
        const relatedRows = transactionRowsByProperty.get(recordKey) || [item];
        const complete = titleHistory[propertyId(item.id)] ||
          titleHistory[planningPropertyKey(item)] ||
          relatedRows.map(transaction => titleHistory[propertyId(transaction.id)] || titleHistory[planningPropertyKey(transaction)]).find(Boolean) || {};
        if (Array.isArray(complete.transactions) && complete.transactions.length) {
          const uniqueRows = new Map();
          [...complete.transactions, ...relatedRows].forEach(transaction => {
            const signature = `${String(transaction.date || "").slice(0, 10)}|${Number(transaction.price || 0)}`;
            if (!uniqueRows.has(signature) || String(transaction.source || "").includes("Price Paid Data")) {
              uniqueRows.set(signature, transaction);
            }
          });
          const completeRows = Array.from(uniqueRows.values()).sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
          salesHistoryRowsCache.set(recordKey, completeRows);
          return completeRows.slice();
        }
        const fallbackRows = relatedRows.slice().sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
        salesHistoryRowsCache.set(recordKey, fallbackRows);
        return fallbackRows.slice();
      }

      function salesHistoryContextHtml(item) {
        const sales = salesHistoryForTransaction(item);
        const latest = sales[0] || item;
        const titleHistory = window.SURREY_SALES_HISTORY || {};
        const relatedRows = transactionRowsByProperty.get(propertyRecordKey(item)) || [item];
        const complete = titleHistory[propertyId(item.id)] ||
          titleHistory[planningPropertyKey(item)] ||
          relatedRows.map(transaction => titleHistory[propertyId(transaction.id)] || titleHistory[planningPropertyKey(transaction)]).find(Boolean) || {};
        const coverage = complete.transactions ? "All Price Paid records · 1995 onwards" : [
          Number(landRegMeta.priceFloor) > 0 ? `${compactPrice(landRegMeta.priceFloor)}+` : "",
          landRegMeta.from ? `${String(landRegMeta.from).slice(0, 4)} onwards` : ""
        ].filter(Boolean).join(" · ");
        const saleItem = sale => contextItem(
          sale.priceText || compactPrice(sale.price),
          [formatDate(sale.date), sale.propertyType, sale.category].filter(Boolean).join(" · ")
        );
        const rows = [
          ["Registered sales", formatNumber(sales.length)],
          ["Latest sale", formatDate(latest.date)],
          ["Latest price", latest.priceText || compactPrice(latest.price)],
          ["Source", latest.source || "HM Land Registry Price Paid Data"],
          ["Coverage", coverage],
          ["Record type", "Price Paid transactions"]
        ];
        const historyList = sales.length
          ? `<div class="context-list sales-history-list">${sales.map(saleItem).join("")}</div>`
          : "";
        return `<section class="context-section sales-history-card"><h3>Transaction History</h3>${dataRows(rows)}${historyList}</section>`;
      }

      function planningContextHtml(item) {
        const planning = item.planning || {};
        const constraints = item.planningConstraints || {};
        const history = planningHistoryForTransaction(item);
        const historyApps = Array.isArray(history.applications) ? history.applications : [];
        const nearbyApps = Array.isArray(planning.recentApplications) ? planning.recentApplications : [];
        const apps = (historyApps.length ? historyApps : nearbyApps).filter(app => app && typeof app === "object");
        const total = Number(history.totalApplications ?? planning.recentApplicationCount ?? apps.length);
        const latest = history.latestApplication && typeof history.latestApplication === "object" ? history.latestApplication : apps[0] || null;
        const rows = [["Total applications", Number.isFinite(total) ? formatNumber(total) : ""]];
        if (history.authority) rows.push(["Planning authority", history.authority]);
        if (history.updatedAt) rows.push(["Last checked", formatPlanningDate(history.updatedAt)]);
        Object.entries(constraints).forEach(([key, value]) => {
          if (["source", "updatedAt", "constraintCount"].includes(key) || !value) return;
          rows.push([humaniseKey(key), value]);
        });
        const applicationItem = app => {
          const title = app.proposal || app.description || app.title || app.application || app.reference || "Planning application";
          const applicationDate = planningApplicationDate(app);
          const meta = [
            applicationDate ? formatPlanningDate(applicationDate) : "Date not supplied",
            app.reference,
            app.decision || app.status
          ].filter(Boolean).join(" · ");
          return linkedContextItem(title, meta, app.portalUrl || app.url);
        };
        if (latest) rows.push(["Latest application", planningApplicationDate(latest) ? formatPlanningDate(planningApplicationDate(latest)) : "Date not supplied"]);
        const latestHtml = latest ? `<div class="planning-latest"><span>Most recent</span>${applicationItem(latest)}</div>` : "";
        const remaining = latest
          ? apps.filter((app, index) => !(index === 0 && (app === latest || app.reference === latest.reference)))
          : apps;
        const moreHtml = remaining.length
          ? `<details class="planning-history-more"><summary>More (${remaining.length})</summary><div class="context-list">${remaining.map(applicationItem).join("")}</div></details>`
          : "";
        const emptyHtml = !latest && !total ? `<p class="context-copy">No matched property applications are loaded.</p>` : "";
        return `<section class="context-section planning-history-card"><h3>Planning History</h3>${dataRows(rows)}${latestHtml}${moreHtml}${emptyHtml}</section>`;
      }

      function schoolsContextHtml(item) {
        const ofsted = item.ofsted || {};
        const nearest = Array.isArray(ofsted.nearestSchools) ? ofsted.nearestSchools.slice(0, 5) : [];
        const rows = [
          ["Search radius", ofsted.searchRadius],
          ["Best nearby rating", ofsted.bestNearbyRating]
        ];
        const list = nearest.map(school => {
          const meta = [
            school.phase,
            school.distance,
            school.walkTime,
            school.postcode
          ].filter(Boolean).join(" · ");
          return contextItem(school.name || "School", meta);
        });
        return contextSection("Nearby Schools", rows, list);
      }

      function transportContextHtml(item) {
        const point = transactionGeoPoint(item);
        const nearest = nearestStations(point, 3);
        if (!nearest.length) return "";
        const primary = nearest[0];
        const list = nearest.map(station => {
          const meta = [
            `${formatDistanceKm(station.distanceKm)} away`,
            `${station.london} c. ${formatMinutes(station.fastestMins)} fastest`,
            station.crs
          ].filter(Boolean).join(" · ");
          return contextItem(station.name, meta);
        });
        return contextSection("Rail Access", [
          ["Nearest station", `${primary.name} · ${formatDistanceKm(primary.distanceKm)}`],
          ["London terminal", primary.london],
          ["Fastest London", `c. ${formatMinutes(primary.fastestMins)}`],
          ["Typical London", `c. ${formatMinutes(primary.typicalMins)}`]
        ], list);
      }

      function airportContextHtml(item) {
        const point = transactionGeoPoint(item);
        const nearest = nearestAirports(point, 3);
        if (!nearest.length) return "";
        const list = nearest.map(airport => {
          const meta = [
            `${formatDistanceKm(airport.distanceKm)} direct`,
            `drive c. ${formatMinutes(airport.driveMins)}`,
            airport.type
          ].filter(Boolean).join(" · ");
          return contextItem(airport.name, meta);
        });
        return contextSection("Airport Access", [], list);
      }

      function nationalRailLiveUrl(station) {
        return `https://www.nationalrail.co.uk/live-trains/departures/${encodeURIComponent(station.crs)}/`;
      }

      function stationLiveSection(station) {
        const link = nationalRailLiveUrl(station);
        return `<section class="context-section" data-live-station="${escapeHtml(station.id)}">
          <h3>Live Train Times</h3>
          <p class="context-copy">Live in-app departures need a Rail Data Marketplace / Darwin feed connected. <a href="${escapeHtml(link)}" target="_blank" rel="noopener">Open live station board</a></p>
        </section>`;
      }

      function refreshLiveStationTimes(station) {
        const template = window.INSIGHT_RAIL_LIVE_ENDPOINT;
        if (!station || !template || !window.fetch) return;
        const wrapper = Array.from(document.querySelectorAll("[data-live-station]")).find(element => element.dataset.liveStation === station.id);
        const target = wrapper?.querySelector(".context-copy");
        if (!target) return;
        const endpoint = String(template).replace("{crs}", encodeURIComponent(station.crs));
        fetch(endpoint)
          .then(response => response.ok ? response.json() : null)
          .then(payload => {
            const services = payload?.trainServices || payload?.services || payload?.departures || [];
            if (!Array.isArray(services) || !services.length) return;
            const rows = services.slice(0, 5).map(service => {
              const due = service.std || service.time || service.scheduled || "";
              const destination = service.destination?.[0]?.locationName || service.destination || service.to || "";
              const status = service.etd || service.status || service.expected || "";
              return [due, destination, status].filter(Boolean).join(" · ");
            }).filter(Boolean);
            if (!rows.length) return;
            target.innerHTML = rows.map(row => `<span>${escapeHtml(row)}</span>`).join("");
          })
          .catch(() => {});
      }

      function stationProfileHtml(station, nearbyRows) {
        const stats = statsForRows(nearbyRows || []);
        const nearby = nearbyRows.slice(0, 5).map(item => {
          const meta = [
            item.priceText,
            formatDate(item.date),
            item.distanceFromSelection ? formatDistanceKm(item.distanceFromSelection) : ""
          ].filter(Boolean).join(" · ");
          return contextItem(propertyDisplayName(item), meta);
        });
        return dataRows([
          ["Station", station.name],
          ["CRS", station.crs],
          ["London terminal", station.london],
          ["Fastest London", `c. ${formatMinutes(station.fastestMins)}`],
          ["Typical London", `c. ${formatMinutes(station.typicalMins)}`],
          ["Operator", station.operator]
        ]) + stationLiveSection(station) + contextSection("Nearby Prime Sales", [
          ["Within", "3km"],
          ["Sales", formatNumber(stats.count)],
          ["Average", compactPrice(stats.avg)]
        ], nearby);
      }

      function airportProfileHtml(airport, nearbyRows) {
        const stats = statsForRows(nearbyRows || []);
        const nearby = nearbyRows.slice(0, 5).map(item => {
          const meta = [
            item.priceText,
            formatDate(item.date),
            item.distanceFromSelection ? formatDistanceKm(item.distanceFromSelection) : ""
          ].filter(Boolean).join(" · ");
          return contextItem(propertyDisplayName(item), meta);
        });
        return dataRows([
          ["Airport", airport.name],
          ["Type", airport.type],
          ["Base access", `drive c. ${formatMinutes(airport.driveBaseMins)} plus distance`]
        ]) + contextSection("Nearby Prime Sales", [
          ["Within", "18km"],
          ["Sales", formatNumber(stats.count)],
          ["Average", compactPrice(stats.avg)]
        ], nearby);
      }

      function formatSchoolDate(value) {
        if (!value) return "";
        const text = String(value);
        const match = text.match(/^(\d{2})-(\d{2})-(\d{4})$/);
        if (match) return `${match[1]} ${new Date(`${match[3]}-${match[2]}-${match[1]}T00:00:00Z`).toLocaleString("en-GB", { month: "short" })} ${match[3]}`;
        return text;
      }

      function schoolProfileHtml(school, nearbyRows) {
        const stats = statsForRows(nearbyRows || []);
        const rows = [
          ["School", school.name],
          ["Sector", schoolSector(school)],
          ["Type", school.type],
          ["Ages", schoolAgeRange(school)],
          ["Phase", school.phase],
          ["Gender", school.gender],
          ["Admissions", school.admissions],
          ["Status", school.status],
          ["Pupils", school.pupils ? formatNumber(school.pupils) : ""],
          ["Capacity", school.capacity ? formatNumber(school.capacity) : ""],
          ["Inspectorate", school.inspectorate],
          ["Ofsted rating", school.ofstedRating || "Not supplied in current feed"],
          ["Last inspection", formatSchoolDate(school.lastInspection)],
          ["Postcode", school.postcode],
          ["Website", school.website]
        ];
        const nearby = nearbyRows.slice(0, 5).map(item => {
          const meta = [
            item.priceText,
            formatDate(item.date),
            item.distanceFromSelection ? formatDistanceKm(item.distanceFromSelection) : ""
          ].filter(Boolean).join(" · ");
          return contextItem(propertyDisplayName(item), meta);
        });
        return dataRows(rows) + contextSection("Nearby Prime Sales", [
          ["Within", "2.5km"],
          ["Sales", formatNumber(stats.count)],
          ["Average", compactPrice(stats.avg)]
        ], nearby);
      }

      function applyInsightAnswerLayout(answer) {
        const layout = answer?.layout || "compact";
        if (els.app) {
          if (answer) els.app.dataset.answerLayout = layout;
          else delete els.app.dataset.answerLayout;
        }
        [els.mapKey, els.mapTopbar].filter(Boolean).forEach(element => {
          if (layout === "report" && answer) {
            element.setAttribute("inert", "");
            element.setAttribute("aria-hidden", "true");
          } else {
            element.removeAttribute("inert");
            element.removeAttribute("aria-hidden");
          }
        });
        if (els.askStatus) els.askStatus.textContent = answer ? `${answer.title || "Ask INSIGHT"} ready` : "";
        if (!map || !window.requestAnimationFrame) return;
        window.requestAnimationFrame(() => {
          map.resize();
          const panelWidth = Math.round(els.answerWorkspace?.getBoundingClientRect().width || 0);
          const mapWidth = Math.round(document.getElementById("map")?.getBoundingClientRect().width || 0);
          const desired = answer ? panelWidth + 28 : 306;
          const right = mapWidth ? Math.min(desired, Math.max(0, mapWidth - 120)) : desired;
          if (typeof map.setPadding === "function") map.setPadding({ top: 0, right, bottom: 0, left: 0 });
        });
      }

      function renderInspector() {
        const ask = currentInsightAnswer();
        if (ask) {
          applyInsightAnswerLayout(ask);
          if (els.inspectorTitle) els.inspectorTitle.textContent = ask.title;
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = ask.subtitle || "Loaded data only";
          els.profileHeading.textContent = ask.title;
          els.profileType.textContent = ask.subtitle || "Loaded data only";
          els.profilePanel.className = "";
          els.profilePanel.innerHTML = ask.html;
          return;
        }
        applyInsightAnswerLayout(null);
        els.profilePanel.className = "";
        const stats = selectedContextStats(state.selectedRows);
        if (state.selectedType === "property") {
          const item = transactions.find(row => propertyId(row.id) === propertyId(state.selectedId));
          if (!item) {
            els.profileHeading.textContent = "Property";
            els.profileType.textContent = "";
            els.profilePanel.innerHTML = '<div class="empty">Property not found.</div>';
            return;
          }
          const estate = estateForTransaction(item);
          const point = transactionGeoPoint(item);
          const station = nearestStations(point, 1)[0];
          const airport = nearestAirports(point, 1)[0];
          if (els.inspectorTitle) els.inspectorTitle.textContent = propertyDisplayName(item);
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = `${item.address}${item.postcode ? " · " + item.postcode : ""}`;
          els.profileHeading.textContent = propertyDisplayName(item);
          els.profileType.textContent = propertyAddressLabel(item);
          const propertyRows = [
            ["Sold price", item.priceText || compactPrice(item.price)],
            ["Sale date", formatDate(item.date)],
            ["Type", item.propertyType],
            ["Market", marketById(item.market)?.short || item.district],
            ...(estate ? [["Private estate", estate.name]] : []),
            ["£/sq ft", compactPpsf(item.pricePerSqft) || "Awaiting EPC"],
            ["EPC area", compactSqft(item.floorAreaSqft)],
            ["EPC rating", item.epcRating],
            ["Planning history", formatNumber(planningApplicationCount(item))],
            ["Flood status", item.environmentAgency?.floodStatus],
            ["Nearest station", station ? `${station.name} · ${formatDistanceKm(station.distanceKm)} · ${formatMinutes(station.fastestMins)} to ${station.london}` : ""],
            ["Nearest airport", airport ? `${airport.name} · drive c. ${formatMinutes(airport.driveMins)}` : ""]
          ];
          els.profilePanel.innerHTML = dataRows(propertyRows) + salesHistoryContextHtml(item) + planningContextHtml(item) + schoolsContextHtml(item) + transportContextHtml(item) + airportContextHtml(item);
          return;
        }
        if (state.selectedType === "market") {
          const market = marketById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = market?.name || "Market";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Local authority profile";
          els.profileHeading.textContent = market?.name || "Local Authority";
          els.profileType.textContent = "Local authority";
        } else if (state.selectedType === "estate") {
          const estate = estatePins.find(pin => pin.key === state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = estate?.name || "Estate";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Private estate";
          els.profileHeading.textContent = estate?.name || "Estate";
          els.profileType.textContent = "Private estate";
        } else if (state.selectedType === "town") {
          if (els.inspectorTitle) els.inspectorTitle.textContent = townDisplayName(state.selectedId);
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Town profile";
          els.profileHeading.textContent = townDisplayName(state.selectedId);
          els.profileType.textContent = "Town";
        } else if (state.selectedType === "school") {
          const school = schoolById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = school?.name || "School";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = [schoolSector(school), schoolAgeRange(school), school?.postcode].filter(Boolean).join(" · ");
          els.profileHeading.textContent = school?.name || "School";
          els.profileType.textContent = "School";
          els.profilePanel.innerHTML = school ? schoolProfileHtml(school, state.selectedRows) : '<div class="empty">School not found.</div>';
          return;
        } else if (state.selectedType === "station") {
          const station = stationById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = station?.name || "Station";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = station ? `${station.london} · ${station.crs}` : "";
          els.profileHeading.textContent = station?.name || "Station";
          els.profileType.textContent = "Station";
          els.profilePanel.innerHTML = station ? stationProfileHtml(station, state.selectedRows) : '<div class="empty">Station not found.</div>';
          refreshLiveStationTimes(station);
          return;
        } else if (state.selectedType === "airport") {
          const airport = airportById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = airport?.name || "Airport";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = airport?.type || "";
          els.profileHeading.textContent = airport?.name || "Airport";
          els.profileType.textContent = "Airport";
          els.profilePanel.innerHTML = airport ? airportProfileHtml(airport, state.selectedRows) : '<div class="empty">Airport not found.</div>';
          return;
        } else {
          if (els.inspectorTitle) els.inspectorTitle.textContent = "Overview";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Click a market, estate, property, or ledger item.";
          els.profileHeading.textContent = "Overview";
          els.profileType.textContent = "";
        }
        const baseRows = [
          ["Velocity rating", velocityLabel(stats)],
          ["12m pace vs normal", stats.velocity.toFixed(2) + "x"],
          ["Last 12m sales", formatNumber(stats.recent)],
          ["90d signal", `${formatNumber(stats.recent90)} sales · ${accelerationLabel(stats)}`],
          ["Velocity confidence", velocityConfidenceLabel(stats)],
          ["Last 24m context", formatNumber(stats.context24)],
          ["Momentum", momentumLabel(stats)],
          [`Sales since ${coverageYear}`, formatNumber(stats.count)],
          ["Average value", compactPrice(stats.avg)],
          ["Highest sale", compactPrice(stats.max)],
          ["Real price movement (p.a.)", priceMovementLabel(stats)],
          ["Repeat-sale evidence", `${priceMovementEvidenceLabel(stats)} · ${priceMovementConfidenceLabel(stats)}`],
          ["Median holding period", stats.priceMedianHoldYears ? `${stats.priceMedianHoldYears.toFixed(1)} years` : ""],
          ["Avg £/sq ft", compactPpsf(stats.ppsfAvg) || "Awaiting EPC"]
        ];
        if (state.selectedType === "estate") {
          const estate = estatePins.find(pin => pin.key === state.selectedId);
          const market = estate ? marketById(estate.market) : null;
          els.profilePanel.innerHTML = dataRows([
            ["Market", market?.short || ""],
            ["Latest recorded sale", stats.latest ? `${stats.latest.priceText || compactPrice(stats.latest.price)} · ${formatDate(stats.latest.date)}` : "No qualifying £3m+ sales"],
            ["Velocity", velocityLabel(stats)],
            ["12m pace vs normal", stats.count ? stats.velocity.toFixed(2) + "x" : "Insufficient evidence"],
            ["Last 12m sales", formatNumber(stats.recent)],
            ["90d activity", stats.count ? `${formatNumber(stats.recent90)} sales · ${accelerationLabel(stats)}` : "Insufficient evidence"],
            ["Velocity confidence", velocityConfidenceLabel(stats)],
            ["Momentum", momentumLabel(stats)],
            [`Sales since ${coverageYear}`, formatNumber(stats.count)],
            ["Average sale · last 24m", stats.context24Avg ? compactPrice(stats.context24Avg) : "No qualifying sales"],
            ["Average £/sq ft · last 24m", stats.context24PpsfAvg ? compactPpsf(stats.context24PpsfAvg) : "Insufficient evidence"],
            ["Highest recorded sale", compactPrice(stats.max)],
            ["Real price movement (p.a.)", priceMovementLabel(stats)],
            ["Repeat-sale evidence", `${priceMovementEvidenceLabel(stats)} · ${priceMovementConfidenceLabel(stats)}`],
            ["Median holding period", stats.priceMedianHoldYears ? `${stats.priceMedianHoldYears.toFixed(1)} years` : "Insufficient evidence"]
          ]) + estateRoadsSection(estate);
          return;
        }
        els.profilePanel.innerHTML = dataRows(baseRows);
      }

      function renderLedger() {
        const hasQuestion = Boolean(insightQuestion());
        const ask = hasQuestion ? currentInsightAnswer() : null;
        const hideForAnswer = ask?.showLedger === false;
        if (els.ledgerSection) els.ledgerSection.hidden = hideForAnswer || (state.selectedType === "property" && !hasQuestion);
        if (hideForAnswer || (state.selectedType === "property" && !hasQuestion)) return;
        const allRows = rowsMatchingSearch(state.selectedRows).slice();
        if (!hasQuestion) allRows.sort((a, b) => b.date.localeCompare(a.date));
        const limit = state.ledgerExpanded ? 50 : 10;
        const rows = allRows.slice(0, limit);
        els.ledgerCount.textContent = state.search
          ? `${formatNumber(rows.length)} of ${formatNumber(allRows.length)} results`
          : state.ledgerExpanded
            ? `Latest ${formatNumber(rows.length)} sales`
            : "Most recent sales";
        if (!rows.length) {
          els.ledgerList.innerHTML = '<div class="empty">No matching transactions.</div>';
          return;
        }
        els.ledgerList.innerHTML = rows.map(item => `
          <button class="ledger-card${propertyId(state.selectedId) === propertyId(item.id) ? " active" : ""}" type="button" data-property="${escapeHtml(propertyId(item.id))}">
            <span class="ledger-price">${escapeHtml(item.priceText)}</span>
            <span class="ledger-address">${escapeHtml(item.address)}</span>
            <span class="ledger-meta">${formatDate(item.date)} · ${escapeHtml(item.propertyType || "Property")} · ${escapeHtml(marketById(item.market)?.short || item.district || "")}</span>
          </button>
        `).join("") + (allRows.length > 10 ? `<button class="more-button" type="button" data-ledger-more>${state.ledgerExpanded ? "Show latest 10" : "More (50)"}</button>` : "");
        els.ledgerList.querySelectorAll("[data-property]").forEach(card => {
          card.addEventListener("click", () => selectProperty(card.dataset.property));
        });
        const more = els.ledgerList.querySelector("[data-ledger-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.ledgerExpanded = !state.ledgerExpanded;
            renderLedger();
          });
        }
      }

      function renderLegend() {
        const breaks = breaksFor(state.renderMode);
        const labels = {
          velocity: ["Cold / Slow", "Steady", "Active", "Hot"],
          momentum: ["Cooling", "Balanced", "Building", "Strong"],
          value: ["Lower value", `${compactPrice(breaks[0])}+`, `${compactPrice(breaks[1])}+`, `${compactPrice(breaks[2])}+`],
          ppsf: ["Awaiting EPC", `£${formatNumber(breaks[0])}+`, `£${formatNumber(breaks[1])}+`, `£${formatNumber(breaks[2])}+`],
          growth: ["Insufficient evidence", "Declining (<−3%)", "Stable (−3% to +3%)", "Growth (+3% to +8%)", "Strong growth (+8%+)"],
          planning: ["None", `${formatNumber(breaks[0])}+`, `${formatNumber(breaks[1])}+`, `${formatNumber(breaks[2])}+`]
        }[state.renderMode];
        const colours = state.renderMode === "growth"
          ? ["#64748b", ...heatColours]
          : state.renderMode === "planning"
          ? ["#64748b", "#6f967b", "#c19a58", "#7c3f72"]
          : state.renderMode === "velocity" || state.renderMode === "momentum" ? velocityColours : heatColours;
        els.legendMode.textContent = "Map Mode";
        els.keyModeOptions?.querySelectorAll("[data-render-mode]").forEach(button => {
          button.setAttribute("aria-pressed", button.dataset.renderMode === state.renderMode ? "true" : "false");
        });
        els.legend.innerHTML = labels.map((label, index) => `
          <div class="legend-row"><span class="swatch" style="background:${colours[index]}"></span><span>${escapeHtml(label)}</span></div>
        `).join("");
        const propertyLegends = {
          price: {
            labels: ["£3m-£5m", "£5m-£10m", "£10m+"],
            colours: ["#006ab6", "#3f8f68", "#b63d42"]
          },
          ppsf: {
            labels: ["Unavailable", "Under £750", "£750-£999", "£1,000-£1,499", "£1,500+"],
            colours: ["#64748b", "#006ab6", "#3f8f68", "#d5a53a", "#b63d42"]
          },
          planning: {
            labels: ["No matched applications", "1 application", "2-3 applications", "4+ applications"],
            colours: ["#64748b", "#6f967b", "#c19a58", "#b63d42"]
          },
          epc: {
            labels: ["Unavailable", "A-B", "C", "D", "E-G"],
            colours: ["#64748b", "#3f8f68", "#d5a53a", "#db7f35", "#b63d42"]
          },
          recency: {
            labels: ["Over 2 years", "1-2 years", "Within 12 months", "Within 90 days"],
            colours: ["#006ab6", "#3f8f68", "#d5a53a", "#b63d42"]
          },
          uplift: {
            labels: ["No prior sale", "Below prior sale", "0-9%", "10-24%", "25%+"],
            colours: ["#64748b", "#006ab6", "#3f8f68", "#d5a53a", "#b63d42"]
          }
        };
        const propertyLegend = propertyLegends[state.propertyRenderMode] || propertyLegends.price;
        const propertyLabels = propertyLegend.labels;
        const propertyColours = propertyLegend.colours;
        els.propertyModeOptions?.querySelectorAll("[data-property-mode]").forEach(button => {
          button.setAttribute("aria-pressed", button.dataset.propertyMode === state.propertyRenderMode ? "true" : "false");
        });
        if (els.propertyLegendTitle) els.propertyLegendTitle.textContent = "Property Mode";
        if (els.propertyLegend) {
          els.propertyLegend.innerHTML = propertyLabels.map((label, index) => `
            <div class="legend-row"><span class="swatch" style="background:${propertyColours[index]}"></span><span>${escapeHtml(label)}</span></div>
          `).join("");
        }
      }

      function updateZoomUi() {
        if (!map) return;
        const zoom = map.getZoom();
        const displayZoom = displayZoomFromMap(zoom);
        const percent = displayZoom;
        if (els.zoomSlider && document.activeElement !== els.zoomSlider) {
          els.zoomSlider.value = String(displayZoom);
        }
        if (els.zoomSlider) els.zoomSlider.style.setProperty("--w", percent.toFixed(1) + "%");
        if (els.zoomReadout) els.zoomReadout.textContent = String(displayZoom);
      }

      function dataRows(rows) {
        return rows.filter(row => row[1] !== undefined && row[1] !== null && row[1] !== "").map(row => `
          <div class="data-row"><span>${escapeHtml(row[0])}</span><span>${escapeHtml(row[1])}</span></div>
        `).join("");
      }

      function propertyDisplayName(item) {
        return String(item.address || "").split(",")[0].trim() || item.postcode || "Property";
      }

      function propertyAddressLabel(item) {
        return [item.address, item.postcode].filter(Boolean).join(" · ");
      }

      function escapeHtml(value) {
        return String(value ?? "")
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
      }

      function safeHttpsUrl(value) {
        if (!value) return "";
        try {
          const url = new URL(String(value));
          return url.protocol === "https:" ? url.href : "";
        } catch (_error) {
          return "";
        }
      }

      els.newsMoreButton?.addEventListener("click", () => {
        newsExpanded = !newsExpanded;
        renderNews();
      });

      window.addEventListener("pagehide", () => {
        try {
          localStorage.setItem(newsVisitKey, new Date().toISOString());
        } catch (_error) {
          // A disabled local-storage policy should not affect the feed.
        }
      });

      els.keyModeOptions?.querySelectorAll("[data-render-mode]").forEach(button => {
        button.addEventListener("click", () => {
          state.renderMode = button.dataset.renderMode;
          els.keyModePicker?.removeAttribute("open");
          els.propertyModePicker?.removeAttribute("open");
          renderLegend();
          applyRenderMode();
        });
      });

      els.propertyModeOptions?.querySelectorAll("[data-property-mode]").forEach(button => {
        button.addEventListener("click", () => {
          state.propertyRenderMode = button.dataset.propertyMode;
          els.propertyModePicker?.removeAttribute("open");
          renderLegend();
          applyRenderMode();
        });
      });

      [els.keyModePicker, els.propertyModePicker].filter(Boolean).forEach(picker => {
        picker.addEventListener("toggle", () => {
          if (!picker.open) return;
          [els.keyModePicker, els.propertyModePicker].filter(other => other && other !== picker)
            .forEach(other => other.removeAttribute("open"));
        });
      });

      if (themeMedia.addEventListener) {
        themeMedia.addEventListener("change", () => {
          applyTheme();
          renderLegend();
        });
      }

      function clearInsightQuestion(resetContext = false) {
        if (els.searchBox) {
          els.searchBox.value = "";
          els.searchBox.blur();
        }
        state.search = "";
        state.insightAnswerCache = null;
        state.ledgerExpanded = false;
        if (resetContext) state.insightContext = null;
        if (els.askSubmit) els.askSubmit.disabled = true;
        if (els.askStatus) els.askStatus.textContent = "";
      }

      function submitInsightQuestion() {
        const next = String(els.searchBox.value || "").trim();
        if (!next) return;
        if (state.search && normalise(state.search) !== normalise(next) && !state.insightAnswerCache?.answer?.preserveMap) rememberInsightQuery(effectiveInsightQuery(state.search));
        state.search = next;
        state.insightAnswerCache = null;
        state.ledgerExpanded = false;
        renderInspector();
        renderLedger();
        updatePropertyMapSource();
        if (!state.insightAnswerCache?.answer?.preserveMap) rememberInsightQuery(effectiveInsightQuery(next));
      }

      els.askForm?.addEventListener("submit", event => {
        event.preventDefault();
        submitInsightQuestion();
      });

      els.searchBox.addEventListener("input", () => {
        const next = String(els.searchBox.value || "").trim();
        if (els.askSubmit) els.askSubmit.disabled = !next;
        if (next || !state.search) return;
        if (!state.insightAnswerCache?.answer?.preserveMap) rememberInsightQuery(effectiveInsightQuery(state.search));
        state.search = "";
        state.insightAnswerCache = null;
        state.ledgerExpanded = false;
        renderInspector();
        renderLedger();
        updatePropertyMapSource();
      });

      if (els.askSubmit) els.askSubmit.disabled = !String(els.searchBox.value || "").trim();

      if (els.zoomSlider) {
        els.zoomSlider.addEventListener("input", () => {
          const percent = clamp(0, 100, Number(els.zoomSlider.value));
          const zoom = mapZoomFromDisplay(percent);
          els.zoomSlider.style.setProperty("--w", percent.toFixed(1) + "%");
          if (els.zoomReadout) els.zoomReadout.textContent = String(Math.round(percent));
          if (map) map.easeTo({ zoom, duration: 80 });
        });
      }

      if (els.brandTitle) {
        els.brandTitle.addEventListener("click", () => {
          resetMap();
        });
      }

      document.addEventListener("keydown", event => {
        if (event.key !== "Escape") return;
        event.preventDefault();
        els.mapDropdowns.forEach(dropdown => dropdown.removeAttribute("open"));
        els.keyModePicker?.removeAttribute("open");
        els.propertyModePicker?.removeAttribute("open");
        clearInsightQuestion(true);
        resetMap();
      });

      els.mapDropdowns.forEach(dropdown => {
        dropdown.addEventListener("toggle", () => {
          if (!dropdown.open) return;
          els.mapDropdowns.forEach(other => {
            if (other !== dropdown) other.removeAttribute("open");
          });
        });
      });

      document.addEventListener("click", event => {
        if (!event.target.closest("[data-map-dropdown]")) {
          els.mapDropdowns.forEach(dropdown => dropdown.removeAttribute("open"));
        }
        if (!event.target.closest("[data-map-key]")) {
          els.keyModePicker?.removeAttribute("open");
          els.propertyModePicker?.removeAttribute("open");
        }
      });

      // The analyst and data panels remain fully operational without the map
      // runtime. Mapping is supporting evidence, never a dependency of Ask.
      if (!map) renderAll();
      window.INSIGHT_BOOT_STAGE = "ready";
    })();
