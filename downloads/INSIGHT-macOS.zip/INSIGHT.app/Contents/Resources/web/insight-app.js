    (function () {
      window.INSIGHT_BOOT_STAGE = "data";
      const ladGeoJson = window.SURREY_LAD_GEOJSON || { type: "FeatureCollection", features: [] };
      const ladFeaturesByName = Object.fromEntries((ladGeoJson.features || []).map(feature => [feature.properties?.name, feature]));
      const districtPaths = window.SURREY_DISTRICT_PATHS || [];
      const transactionRows = (window.SURREY_LAND_REG_TRANSACTIONS || []).slice().sort((a, b) => b.date.localeCompare(a.date));
      const transactionRowsByProperty = groupTransactionRowsByProperty(transactionRows);
      const transactions = collapsePropertyTransactions(transactionRows);
      const transactionsById = new Map();
      transactions.forEach(item => {
        const id = propertyId(item.id);
        if (!transactionsById.has(id)) transactionsById.set(id, item);
      });
      const propertyValuationUniverseLatestSaleDate = transactions.reduce((latest, item) => {
        const date = String(item.date || "").slice(0, 10);
        return date > latest ? date : latest;
      }, "");
      const propertyValuationUniversePriceTotal = transactions.reduce(
        (sum, item) => sum + Math.max(0, Number(item.price || 0)),
        0
      );
      const salesHistoryRowsCache = new Map();
      const latestEpcSnapshotCache = new Map();
      const listedStatusSnapshotCache = new Map();
      const transactionGeoPointCache = new WeakMap();
      const propertyFeatureCache = new WeakMap();
      const materialisedPropertyRecordCache = new Map();
      const statsForRowsCache = new WeakMap();
      const parsedIsoDateCache = new Map();
      const formattedDateCache = new Map();
      const displayDateFormatter = new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" });
      const landRegMeta = window.SURREY_LAND_REG_META || {};
      const defaultPriceFloor = 2000000;
      const landRegPriceFloor = Number(landRegMeta.priceFloor) > 0 ? Number(landRegMeta.priceFloor) : defaultPriceFloor;
      const nearFloorPriceMargin = 500000;
      const nearFloorPriceCeiling = landRegPriceFloor + nearFloorPriceMargin;
      const salesHistoryMeta = window.SURREY_SALES_HISTORY_META || {};
      const propertyRecordsSeed = window.SURREY_PROPERTY_RECORDS && typeof window.SURREY_PROPERTY_RECORDS === "object"
        ? window.SURREY_PROPERTY_RECORDS
        : {};
      const propertyRecordsMeta = window.SURREY_PROPERTY_RECORDS_META && typeof window.SURREY_PROPERTY_RECORDS_META === "object"
        ? window.SURREY_PROPERTY_RECORDS_META
        : {};
      const addressPoints = window.SURREY_ADDRESS_POINTS || {};
      const postcodePoints = window.SURREY_POSTCODE_POINTS || {};
      const schools = window.SURREY_SCHOOLS || [];
      const privateEstateRuntime = window.INSIGHT_PRIVATE_ESTATES && typeof window.INSIGHT_PRIVATE_ESTATES === "object"
        ? window.INSIGHT_PRIVATE_ESTATES
        : { definitions: [], rules: [], navigationAnchors: [], approvedPins: [], metadata: {} };
      let newsItems = Array.isArray(window.INSIGHT_NEWS_ITEMS) ? window.INSIGHT_NEWS_ITEMS.slice() : [];
      let newsMeta = window.INSIGHT_NEWS_META && typeof window.INSIGHT_NEWS_META === "object" ? { ...window.INSIGHT_NEWS_META } : {};
      let newsRuntimeStatus = "";
      let todayFeed = window.INSIGHT_TODAY_FEED && typeof window.INSIGHT_TODAY_FEED === "object"
        ? window.INSIGHT_TODAY_FEED
        : { signals: [], opportunities: [] };
      let todayMeta = window.INSIGHT_TODAY_META && typeof window.INSIGHT_TODAY_META === "object"
        ? window.INSIGHT_TODAY_META
        : {};
      let todayRuntimeStatus = "";
      let insightView = window.INSIGHT_VIEW && typeof window.INSIGHT_VIEW === "object"
        ? window.INSIGHT_VIEW
        : null;
      let insightViewMeta = window.INSIGHT_VIEW_META && typeof window.INSIGHT_VIEW_META === "object"
        ? window.INSIGHT_VIEW_META
        : {};
      let insightViewRuntimeStatus = "";
      let todayMarketChangesCache = null;
      let todayNewSalesCache = null;
      let newsExpanded = false;
      const newsCollapsedLimit = 5;
      const newsExpandedLimit = 15;
      let todayBriefingTimer = null;
      const todayUserName = "Matthew";
      const newsVisitKey = "insight-news-last-visit";
      const newsSessionKey = "insight-news-session-baseline";
      const todaySessionStateKey = "insight-today-session-state";
      const newsPreviousVisit = (() => {
        try {
          const sessionBaseline = sessionStorage.getItem(newsSessionKey);
          if (sessionBaseline !== null) return sessionBaseline;
          const previous = localStorage.getItem(newsVisitKey) || "";
          sessionStorage.setItem(newsSessionKey, previous);
          return previous;
        } catch (_error) {
          return "";
        }
      })();
      const themeMedia = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : { matches: false, addEventListener: null };

      const marketDefinitions = [
        { id: "elmbridge-prime", name: "Elmbridge", short: "Elmbridge", district: "Elmbridge" },
        { id: "runnymede-wentworth", name: "Runnymede", short: "Runnymede", district: "Runnymede" },
        { id: "woking-district", name: "Woking", short: "Woking", district: "Woking" },
        { id: "surrey-heath", name: "Surrey Heath", short: "Surrey Heath", district: "Surrey Heath" },
        { id: "guildford-district", name: "Guildford", short: "Guildford", district: "Guildford" },
        { id: "mole-valley", name: "Mole Valley", short: "Mole Valley", district: "Mole Valley" },
        { id: "waverley-south-surrey", name: "Waverley", short: "Waverley", district: "Waverley" },
        { id: "reigate-banstead", name: "Reigate and Banstead", short: "Reigate and Banstead", district: "Reigate and Banstead" },
        { id: "epsom-ewell", name: "Epsom and Ewell", short: "Epsom and Ewell", district: "Epsom and Ewell" },
        { id: "tandridge-oxted", name: "Tandridge", short: "Tandridge", district: "Tandridge" },
        { id: "spelthorne", name: "Spelthorne", short: "Spelthorne", district: "Spelthorne" }
      ].map(market => ({
        ...market,
        geometry: ladFeaturesByName[market.district]?.geometry || null,
        fallbackPath: districtPaths.find(path => path.name === market.district)
      })).filter(market => market.geometry || market.fallbackPath);

      const districtGeoPoints = {
        "Elmbridge": [-0.3944, 51.36095],
        "Epsom and Ewell": [-0.26173, 51.33947],
        "Guildford": [-0.56258, 51.25366],
        "Mole Valley": [-0.30604, 51.2275],
        "Reigate and Banstead": [-0.19871, 51.25846],
        "Runnymede": [-0.53855, 51.39274],
        "Spelthorne": [-0.46254, 51.41553],
        "Surrey Heath": [-0.68984, 51.33612],
        "Tandridge": [-0.04809, 51.23585],
        "Waverley": [-0.62343, 51.15686],
        "Woking": [-0.57981, 51.3084]
      };

      const townGeoPoints = {
        ADDLESTONE: [-0.4931, 51.3714],
        ASCOT: [-0.6746, 51.4102],
        ASHTEAD: [-0.2997, 51.3085],
        BAGSHOT: [-0.688, 51.36],
        BANSTEAD: [-0.2043, 51.3221],
        BOOKHAM: [-0.3741, 51.2793],
        CAMBERLEY: [-0.7426, 51.3402],
        CATERHAM: [-0.0789, 51.282],
        CHERTSEY: [-0.507, 51.388],
        CHOBHAM: [-0.6043, 51.3482],
        CLAYGATE: [-0.3427, 51.3592],
        COBHAM: [-0.4117, 51.3291],
        CRANLEIGH: [-0.4858, 51.142],
        DORKING: [-0.3315, 51.232],
        EAST_HORSLEY: [-0.4325, 51.2731],
        EAST_MOLESEY: [-0.349, 51.398],
        EGHAM: [-0.5482, 51.4315],
        EPSOM: [-0.2674, 51.334],
        ESHER: [-0.3656, 51.3691],
        FARNHAM: [-0.798, 51.2143],
        FETCHAM: [-0.3551, 51.2882],
        GODALMING: [-0.6145, 51.1858],
        GUILDFORD: [-0.5703, 51.2362],
        HASLEMERE: [-0.7105, 51.089],
        HINDHEAD: [-0.735, 51.113],
        HORLEY: [-0.171, 51.174],
        KINGSWOOD: [-0.211, 51.286],
        LEATHERHEAD: [-0.3285, 51.2965],
        LINGFIELD: [-0.015, 51.176],
        OXTED: [-0.006, 51.257],
        REDHILL: [-0.1709, 51.2405],
        REIGATE: [-0.2058, 51.2376],
        RIPLEY: [-0.495, 51.299],
        SHEPPERTON: [-0.4479, 51.3958],
        STAINES_UPON_THAMES: [-0.5088, 51.4324],
        SUNBURY_ON_THAMES: [-0.4135, 51.4197],
        SURBITON: [-0.3037, 51.3939],
        TADWORTH: [-0.2357, 51.2918],
        THAMES_DITTON: [-0.3391, 51.3891],
        VIRGINIA_WATER: [-0.566, 51.403],
        WALTON_ON_THAMES: [-0.4146, 51.3868],
        WARLINGHAM: [-0.056, 51.309],
        WEST_BYFLEET: [-0.5064, 51.3384],
        WEYBRIDGE: [-0.4577, 51.3718],
        WINDLESHAM: [-0.654, 51.365],
        WOKING: [-0.559, 51.3168]
      };

      // Definitions and navigation anchors are deliberately separate. A
      // definition can classify transactions without implying a legal extent.
      const estatePins = (privateEstateRuntime.definitions || []).map(estate => ({
        ...estate,
        key: estate.id,
        aliases: Array.isArray(estate.aliases) ? estate.aliases : []
      }));
      const privateEstateRules = Array.isArray(privateEstateRuntime.rules) ? privateEstateRuntime.rules : [];
      const estateNavigationAnchors = (privateEstateRuntime.navigationAnchors || []).map(anchor => {
        const estate = estatePins.find(candidate => candidate.key === anchor.estateId);
        const coordinates = anchor?.geometry?.coordinates || [];
        return estate && Number.isFinite(Number(coordinates[0])) && Number.isFinite(Number(coordinates[1]))
          ? { ...estate, lon: Number(coordinates[0]), lat: Number(coordinates[1]), anchorBasis: anchor.anchorBasis || "", navigationOnly: true, legalExtent: false }
          : null;
      }).filter(Boolean);
      const approvedEstatePins = (privateEstateRuntime.approvedPins || []).map(pin => {
        const estate = estatePins.find(candidate => candidate.key === pin.estateId);
        const coordinates = pin?.geometry?.coordinates || [];
        return estate && Number.isFinite(Number(coordinates[0])) && Number.isFinite(Number(coordinates[1]))
          ? { ...estate, lon: Number(coordinates[0]), lat: Number(coordinates[1]), pinVersion: pin.pinVersion || privateEstateRuntime.metadata?.geometryVersion || "" }
          : null;
      }).filter(Boolean);
      const stationPins = [
        { id: "WOK", name: "Woking", crs: "WOK", lon: -0.5569, lat: 51.3185, london: "London Waterloo", fastestMins: 24, typicalMins: 28, operator: "South Western Railway" },
        { id: "GLD", name: "Guildford", crs: "GLD", lon: -0.5805, lat: 51.2369, london: "London Waterloo", fastestMins: 32, typicalMins: 38, operator: "South Western Railway" },
        { id: "WBR", name: "Weybridge", crs: "WYB", lon: -0.4577, lat: 51.3618, london: "London Waterloo", fastestMins: 29, typicalMins: 36, operator: "South Western Railway" },
        { id: "ESH", name: "Esher", crs: "ESH", lon: -0.3532, lat: 51.3790, london: "London Waterloo", fastestMins: 23, typicalMins: 29, operator: "South Western Railway" },
        { id: "CBS", name: "Cobham & Stoke d'Abernon", crs: "CSD", lon: -0.3899, lat: 51.3180, london: "London Waterloo", fastestMins: 38, typicalMins: 42, operator: "South Western Railway" },
        { id: "OXS", name: "Oxshott", crs: "OXS", lon: -0.3622, lat: 51.3364, london: "London Waterloo", fastestMins: 35, typicalMins: 40, operator: "South Western Railway" },
        { id: "WAL", name: "Walton-on-Thames", crs: "WAL", lon: -0.4146, lat: 51.3729, london: "London Waterloo", fastestMins: 25, typicalMins: 31, operator: "South Western Railway" },
        { id: "HER", name: "Hersham", crs: "HER", lon: -0.3899, lat: 51.3769, london: "London Waterloo", fastestMins: 30, typicalMins: 35, operator: "South Western Railway" },
        { id: "VIR", name: "Virginia Water", crs: "VIR", lon: -0.5623, lat: 51.4018, london: "London Waterloo", fastestMins: 43, typicalMins: 48, operator: "South Western Railway" },
        { id: "EGH", name: "Egham", crs: "EGH", lon: -0.5465, lat: 51.4296, london: "London Waterloo", fastestMins: 39, typicalMins: 45, operator: "South Western Railway" },
        { id: "SNS", name: "Staines", crs: "SNS", lon: -0.5039, lat: 51.4322, london: "London Waterloo", fastestMins: 35, typicalMins: 41, operator: "South Western Railway" },
        { id: "FNB", name: "Farnborough Main", crs: "FNB", lon: -0.7557, lat: 51.2967, london: "London Waterloo", fastestMins: 34, typicalMins: 39, operator: "South Western Railway" },
        { id: "FNH", name: "Farnham", crs: "FNH", lon: -0.7928, lat: 51.2119, london: "London Waterloo", fastestMins: 53, typicalMins: 60, operator: "South Western Railway" },
        { id: "GOD", name: "Godalming", crs: "GOD", lon: -0.6188, lat: 51.1866, london: "London Waterloo", fastestMins: 41, typicalMins: 47, operator: "South Western Railway" },
        { id: "HSL", name: "Haslemere", crs: "HSL", lon: -0.7190, lat: 51.0888, london: "London Waterloo", fastestMins: 49, typicalMins: 57, operator: "South Western Railway" },
        { id: "DKG", name: "Dorking", crs: "DKG", lon: -0.3241, lat: 51.2409, london: "London Victoria / Waterloo", fastestMins: 49, typicalMins: 58, operator: "Southern / South Western Railway" },
        { id: "LHD", name: "Leatherhead", crs: "LHD", lon: -0.3332, lat: 51.2988, london: "London Waterloo / Victoria", fastestMins: 43, typicalMins: 50, operator: "South Western Railway / Southern" },
        { id: "ASD", name: "Ashtead", crs: "AHD", lon: -0.3088, lat: 51.3175, london: "London Waterloo / Victoria", fastestMins: 38, typicalMins: 45, operator: "South Western Railway / Southern" },
        { id: "EPS", name: "Epsom", crs: "EPS", lon: -0.2693, lat: 51.3343, london: "London Waterloo / Victoria", fastestMins: 34, typicalMins: 41, operator: "South Western Railway / Southern" },
        { id: "RED", name: "Redhill", crs: "RDH", lon: -0.1658, lat: 51.2402, london: "London Bridge / Victoria", fastestMins: 29, typicalMins: 36, operator: "Southern / Thameslink" },
        { id: "REI", name: "Reigate", crs: "REI", lon: -0.2038, lat: 51.2419, london: "London Victoria / London Bridge", fastestMins: 42, typicalMins: 50, operator: "Southern / Great Western Railway" },
        { id: "GTW", name: "Gatwick Airport", crs: "GTW", lon: -0.1610, lat: 51.1566, london: "London Victoria / London Bridge", fastestMins: 29, typicalMins: 35, operator: "Gatwick Express / Southern / Thameslink" },
        { id: "HOR", name: "Horley", crs: "HOR", lon: -0.1610, lat: 51.1688, london: "London Victoria / London Bridge", fastestMins: 34, typicalMins: 41, operator: "Southern / Thameslink" },
        { id: "OXT", name: "Oxted", crs: "OXT", lon: -0.0048, lat: 51.2579, london: "London Victoria / London Bridge", fastestMins: 33, typicalMins: 39, operator: "Southern" },
        { id: "BYF", name: "West Byfleet", crs: "WBY", lon: -0.5055, lat: 51.3392, london: "London Waterloo", fastestMins: 31, typicalMins: 38, operator: "South Western Railway" }
      ];

      const airportPins = [
        { id: "LHR", name: "Heathrow Airport", lon: -0.4543, lat: 51.4700, type: "International airport", driveBaseMins: 22 },
        { id: "LGW", name: "Gatwick Airport", lon: -0.1821, lat: 51.1537, type: "International airport", driveBaseMins: 30 },
        { id: "FAB", name: "Farnborough Airport", lon: -0.7763, lat: 51.2758, type: "Business aviation airport", driveBaseMins: 18 }
      ];

      const addressPointRules = [
        { terms: ["OLD AVENUE"], lon: -0.456, lat: 51.351 },
        { terms: ["EAST ROAD"], lon: -0.454, lat: 51.349 },
        { terms: ["WEST ROAD"], lon: -0.462, lat: 51.354 },
        { terms: ["CAMP END ROAD", "TOR LANE"], lon: -0.466, lat: 51.346 },
        { terms: ["PORTNALL DRIVE", "PORTNALL RISE"], lon: -0.570, lat: 51.405 },
        { terms: ["NORTH DRIVE", "SOUTH DRIVE", "PINEWOOD ROAD"], lon: -0.590, lat: 51.398 },
        { terms: ["BLACKHILLS"], lon: -0.366, lat: 51.348 },
        { terms: ["ASHLEY PARK AVENUE", "ASHLEY RISE"], lon: -0.410, lat: 51.379 },
        { terms: ["PACHESHAM PARK"], lon: -0.351, lat: 51.302 },
        { terms: ["TYRRELLS WOOD"], lon: -0.321, lat: 51.289 },
        { terms: ["HOOK HEATH ROAD"], lon: -0.586, lat: 51.310 },
        { terms: ["CRANLEY ROAD", "INCE ROAD", "ONSLOW ROAD", "CHARGATE CLOSE", "FRIARS CLOSE"], lon: -0.402, lat: 51.369 },
        { terms: ["ESHER PARK AVENUE"], lon: -0.360, lat: 51.366 },
        { terms: ["FIRWOOD ROAD"], lon: -0.529, lat: 51.385 }
      ];

      const layerRegistry = [
        { id: "heatmaps", label: "Heat", detail: "Local-authority market intensity", defaultOn: true, layers: ["market-fill", "authority-heat-glow", "market-outline"] },
        { id: "properties", label: "Properties", detail: "Geocoded Land Registry transactions", defaultOn: true, layers: ["property-points", "selected-property-core"] },
        { id: "estates", label: "Private Estates", detail: "Private-estate locations and market cohorts", defaultOn: true, layers: ["estate-points"] },
        { id: "stations", label: "Stations", detail: "Rail stations and London journey context", defaultOn: true, layers: ["station-points", "station-labels"] },
        { id: "airports", label: "Airports", detail: "Heathrow, Gatwick and Farnborough", defaultOn: true, layers: ["airport-points", "airport-labels"] },
        { id: "schools", label: "Schools", detail: "Open schools and nearby education context", defaultOn: true, layers: ["school-points", "school-labels"] }
      ];
      const renderModeLabels = {
        velocity: "Market heat",
        value: "Average value",
        ppsf: "£ per sqft",
        growth: "Real price movement",
        planning: "Planning density"
      };

      const state = {
        selectedType: "overview",
        selectedId: null,
        selectedRows: transactions,
        renderMode: "velocity",
        propertyRenderMode: "price",
        search: "",
        marketListExpanded: false,
        estateListExpanded: false,
        townListExpanded: false,
        ledgerExpanded: false,
        todayOpen: true,
        todayTab: "briefing",
        todayFilter: "all",
        insightContext: null,
        insightAnswerCache: null,
        hoveredFeature: null,
        resolvedTheme: "light",
        layers: Object.fromEntries(layerRegistry.map(layer => [layer.id, layer.defaultOn]))
      };
      try {
        if (sessionStorage.getItem(todaySessionStateKey) === "closed") state.todayOpen = false;
      } catch (_error) {
        // A disabled session-storage policy should not prevent the cold-open briefing.
      }
      const zoomMin = 9.2;
      const zoomMax = 19;
      const defaultZoomLevel = 0;
      const overviewMapPadding = { top: 0, right: 306, bottom: 0, left: 0 };
      const selectionMapPadding = { top: 0, right: 0, bottom: 0, left: 0 };
      const selectionHistory = [{ type: "overview", id: null }];
      let selectionHistoryIndex = 0;
      let restoringSelectionHistory = false;

      const els = {
        layerList: document.getElementById("layerList"),
        dataFeedStatus: document.getElementById("dataFeedStatus"),
        insightLastUpdated: document.getElementById("insightLastUpdated"),
        newsPanel: document.getElementById("newsPanel"),
        leftPanel: document.querySelector(".left-panel"),
        leftPanelInner: document.querySelector(".left-panel > .panel-inner"),
        newsList: document.getElementById("newsList"),
        newsNewCount: document.getElementById("newsNewCount"),
        newsFeedStatus: document.getElementById("newsFeedStatus"),
        newsMoreButton: document.getElementById("newsMoreButton"),
        marketList: document.getElementById("marketList"),
        marketTitle: document.getElementById("marketTitle"),
        marketRankNote: document.getElementById("marketRankNote"),
        estateList: document.getElementById("estateList"),
        estateTitle: document.getElementById("estateTitle"),
        estateRankNote: document.getElementById("estateRankNote"),
        townList: document.getElementById("townList"),
        townTitle: document.getElementById("townTitle"),
        townRankNote: document.getElementById("townRankNote"),
        summaryGrid: document.getElementById("summaryGrid"),
        summaryNote: document.getElementById("summaryNote"),
        legendMode: document.getElementById("legendMode"),
        keyModePicker: document.querySelector(".key-mode-picker"),
        keyModeOptions: document.getElementById("keyModeOptions"),
        legend: document.getElementById("legend"),
        propertyModePicker: document.querySelector(".property-mode-picker"),
        propertyModeOptions: document.getElementById("propertyModeOptions"),
        propertyLegendTitle: document.getElementById("propertyLegendTitle"),
        propertyLegend: document.getElementById("propertyLegend"),
        hoverTooltip: document.getElementById("mapHoverTooltip"),
        zoomSlider: document.getElementById("zoomSlider"),
        zoomReadout: document.getElementById("zoomReadout"),
        inspectorTitle: document.getElementById("inspectorTitle"),
        inspectorSubtitle: document.getElementById("inspectorSubtitle"),
        profileHeading: document.getElementById("profileHeading"),
        profileType: document.getElementById("profileType"),
        profilePanel: document.getElementById("profilePanel"),
        ledgerSection: document.getElementById("ledgerSection"),
        ledgerList: document.getElementById("ledgerList"),
        ledgerCount: document.getElementById("ledgerCount"),
        searchBox: document.getElementById("searchBox"),
        askForm: document.getElementById("askForm"),
        askSubmit: document.getElementById("askSubmit"),
        askStatus: document.getElementById("askStatus"),
        answerWorkspace: document.getElementById("answerWorkspace"),
        todayDrawer: document.getElementById("todayDrawer"),
        todayKicker: document.getElementById("todayKicker"),
        todayHeading: document.getElementById("todayHeading"),
        todayCloseButton: document.getElementById("todayCloseButton"),
        todayTabs: document.getElementById("todayTabs"),
        todayTabButtons: Array.from(document.querySelectorAll("[data-today-tab]")),
        todayTabPanels: Array.from(document.querySelectorAll("[data-today-panel]")),
        todayTabMarketChangesCount: document.getElementById("todayTabMarketChangesCount"),
        todayTabNewSalesCount: document.getElementById("todayTabNewSalesCount"),
        todayTabOpportunitiesCount: document.getElementById("todayTabOpportunitiesCount"),
        todayInsightView: document.getElementById("todayInsightView"),
        todayViewBankRate: document.getElementById("todayViewBankRate"),
        todayViewBankRateDetail: document.getElementById("todayViewBankRateDetail"),
        todayViewNextDecision: document.getElementById("todayViewNextDecision"),
        todayViewNextDecisionDetail: document.getElementById("todayViewNextDecisionDetail"),
        todayViewPolicySignal: document.getElementById("todayViewPolicySignal"),
        todayViewPolicySignalDetail: document.getElementById("todayViewPolicySignalDetail"),
        todayViewMortgageRate: document.getElementById("todayViewMortgageRate"),
        todayViewMortgageRateDetail: document.getElementById("todayViewMortgageRateDetail"),
        todayViewAnalysis: document.getElementById("todayViewAnalysis"),
        todayViewSources: document.getElementById("todayViewSources"),
        todayViewStatus: document.getElementById("todayViewStatus"),
        todayAtAGlance: document.getElementById("todayAtAGlance"),
        todayMarketChanges: document.getElementById("todayMarketChanges"),
        todayMarketChangesMeta: document.getElementById("todayMarketChangesMeta"),
        todayNewSales: document.getElementById("todayNewSales"),
        todayNewSalesMeta: document.getElementById("todayNewSalesMeta"),
        todayFilters: document.getElementById("todayFilters"),
        todayCards: document.getElementById("todayCards"),
        todayFeedStatus: document.getElementById("todayFeedStatus"),
        mapWorkspace: document.querySelector(".map-wrap"),
        app: document.querySelector(".app"),
        mapKey: document.querySelector(".map-key"),
        mapTopbar: document.querySelector(".map-topbar"),
        brandTitle: document.querySelector(".brand h1"),
        mapDropdowns: Array.from(document.querySelectorAll("[data-map-dropdown]"))
      };

      window.INSIGHT_SET_DATA_STATUS = message => {
        if (els.dataFeedStatus) els.dataFeedStatus.textContent = String(message || "");
      };

      window.INSIGHT_SET_NEWS_FEED = (items, metadata) => {
        if (Array.isArray(items)) newsItems = items.slice();
        if (metadata && typeof metadata === "object") newsMeta = { ...metadata };
        newsRuntimeStatus = "";
        renderNews();
      };

      window.INSIGHT_SET_NEWS_STATUS = message => {
        newsRuntimeStatus = String(message || "").trim();
        renderNews();
      };

      window.INSIGHT_SET_TODAY_FEED = (feed, metadata) => {
        if (!feed || typeof feed !== "object" || feed.schemaVersion !== 2) return;
        if (!Array.isArray(feed.signals) || !Array.isArray(feed.opportunities)) return;
        if (!metadata || typeof metadata !== "object" || metadata.schemaVersion !== 2) return;
        const loadedPropertyRecordsFingerprint = String(propertyRecordsMeta.datasetFingerprint || "").trim();
        const incomingPropertyRecordsFingerprint = String(
          metadata.sourceFingerprints?.propertyRecords || ""
        ).trim();
        if (
          !loadedPropertyRecordsFingerprint ||
          !incomingPropertyRecordsFingerprint ||
          incomingPropertyRecordsFingerprint !== loadedPropertyRecordsFingerprint
        ) {
          todayRuntimeStatus = "Latest briefing delayed while Property Records catch up";
          renderTodayDrawer();
          return;
        }
        const counts = metadata.counts && typeof metadata.counts === "object" ? metadata.counts : {};
        if (
          counts.signals !== feed.signals.length ||
          counts.opportunities !== feed.opportunities.length
        ) return;
        todayFeed = {
          ...feed,
          signals: feed.signals.slice(),
          opportunities: feed.opportunities.slice()
        };
        todayMeta = { ...metadata, counts: { ...counts } };
        todayRuntimeStatus = "";
        renderTodayDrawer();
      };

      window.INSIGHT_SET_INSIGHT_VIEW = (view, metadata) => {
        if (!view || typeof view !== "object" || view.schemaVersion !== 1) return;
        if (!metadata || typeof metadata !== "object" || metadata.schemaVersion !== 1) return;
        if (
          metadata.asOf !== view.briefingDate ||
          metadata.generatedAt !== view.generatedAt ||
          metadata.datasetFingerprint !== view.fingerprint ||
          metadata.generatorVersion !== "insight-view-1" ||
          !Array.isArray(view.narrative) ||
          view.narrative.length !== 2 ||
          !Array.isArray(view.sources) ||
          view.sources.length !== 3
        ) return;
        insightView = {
          ...view,
          policy: { ...(view.policy || {}) },
          mortgage: { ...(view.mortgage || {}) },
          market: { ...(view.market || {}) },
          narrative: view.narrative.slice(),
          sources: view.sources.map(source => ({ ...source })),
          staleSources: Array.isArray(view.staleSources) ? view.staleSources.slice() : []
        };
        insightViewMeta = { ...metadata };
        insightViewRuntimeStatus = "";
        renderInsightView();
      };

      window.INSIGHT_SET_INSIGHT_VIEW_STATUS = message => {
        insightViewRuntimeStatus = String(message || "").trim();
        renderInsightView();
      };

      renderNews();

      function latestInsightUpdate(value) {
        let latest = null;
        const visit = item => {
          if (!item || typeof item !== "object") return;
          Object.entries(item).forEach(([key, child]) => {
            if (key === "updatedAt" && typeof child === "string") {
              const date = new Date(child);
              if (!Number.isNaN(date.getTime()) && (!latest || date > latest)) latest = date;
            } else if (child && typeof child === "object") {
              visit(child);
            }
          });
        };
        visit(value);
        return latest;
      }

      const latestUpdate = latestInsightUpdate(landRegMeta);
      if (els.insightLastUpdated) {
        const formatted = latestUpdate
          ? new Intl.DateTimeFormat("en-GB", { dateStyle: "medium", timeStyle: "short" }).format(latestUpdate)
          : "Not supplied";
        els.insightLastUpdated.textContent = `INSIGHT updated: ${formatted}`;
      }

      function resolveTheme() {
        return themeMedia.matches ? "dark" : "light";
      }

      function setDocumentTheme() {
        state.resolvedTheme = resolveTheme();
        document.documentElement.dataset.theme = state.resolvedTheme;
      }

      function mapTextPaint() {
        const dark = state.resolvedTheme === "dark";
        return {
          label: dark ? "#e6edf3" : "#172033",
          secondary: dark ? "#c9d1d9" : "#243045",
          halo: dark ? "#0d1117" : "#ffffff",
          outline: dark ? "#b6ebff" : "#006ab6",
          propertyStroke: dark ? "#0d1117" : "#ffffff"
        };
      }

      function applyThemeToMap() {
        if (!mapStyleReady()) return;
        const paint = mapTextPaint();
        applyBasemapTheme();
        ["county-outline", "market-outline"].forEach(layer => {
          if (map.getLayer(layer)) map.setPaintProperty(layer, "line-color", paint.outline);
        });
        ["station-labels", "airport-labels", "school-labels"].forEach(layer => {
          if (!map.getLayer(layer)) return;
          map.setPaintProperty(layer, "text-color", paint.label);
          map.setPaintProperty(layer, "text-halo-color", paint.halo);
        });
        if (map.getLayer("property-points")) map.setPaintProperty("property-points", "circle-stroke-color", paint.propertyStroke);
        refreshMapImages();
      }

      function applyTheme() {
        const previous = state.resolvedTheme;
        setDocumentTheme();
        if (previous !== state.resolvedTheme) applyThemeToMap();
      }

      setDocumentTheme();

      function normalise(value) {
        return String(value || "").toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim();
      }

      function normalisePostcode(value) {
        return String(value || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
      }

      function addressKey(value) {
        return normalise(value).replace(/\s+/g, " ");
      }

      function propertyAddressIdentity(value) {
        const parts = String(value || "")
          .split(",")
          .map(part => addressKey(part))
          .filter(Boolean)
          .filter(part => !/^[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}$/.test(part))
          .filter((part, index, values) => index === 0 || part !== values[index - 1]);
        return parts.join("|") || addressKey(value);
      }

      function propertyRecordKey(item) {
        const address = addressKey(item?.address);
        const postcodeSuffix = String(item?.address || "").toUpperCase().match(/\b([A-Z]{1,2}\d[A-Z\d]?)\s*(\d[A-Z]{2})\s*$/);
        const postcode = normalisePostcode(item?.postcode) || normalisePostcode(postcodeSuffix ? postcodeSuffix.slice(1).join("") : "");
        // A nearest OS UPRN derived from a postcode centroid is useful context,
        // but it is not a safe property identity: distinct homes can share it.
        // Keep this fallback byte-for-byte aligned with the canonical pipeline
        // id so a legacy row does not move record when its stored id arrives.
        if (address) return `property:${address}|${postcode || "NOPOSTCODE"}`;
        return `id:${propertyId(item?.id)}`;
      }

      function collapsePropertyTransactions(rows) {
        const properties = new Map();
        rows.forEach(item => {
          const key = propertyRecordKey(item);
          const existing = properties.get(key);
          if (!existing || String(item.date || "").localeCompare(String(existing.date || "")) > 0) {
            properties.set(key, { ...item, propertyRecordKey: key });
          }
        });
        return Array.from(properties.values()).sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
      }

      function groupTransactionRowsByProperty(rows) {
        const grouped = new Map();
        rows.forEach(item => {
          const key = propertyRecordKey(item);
          if (!grouped.has(key)) grouped.set(key, []);
          grouped.get(key).push(item);
        });
        return grouped;
      }

      function propertyId(value) {
        return String(value ?? "");
      }

      function planningPropertyKey(item) {
        return propertyRecordKey(item);
      }

      function planningHistoryForTransaction(item) {
        if (!item) return {};
        const privatePlanning = window.SURREY_PLANNING_HISTORY || {};
        return item.planningHistory || privatePlanning[propertyId(item.id)] || privatePlanning[planningPropertyKey(item)] || {};
      }

      function planningApplicationCount(item) {
        const history = planningHistoryForTransaction(item);
        const applications = Array.isArray(history.applications) ? history.applications : [];
        const total = Number(history.totalApplications ?? applications.length);
        return Number.isFinite(total) && total > 0 ? total : 0;
      }

      function planningMetricsForRows(rows) {
        const propertyLinks = new Set();
        const matchedPropertyKeys = new Set();
        const uniqueCases = new Map();
        rows.forEach(item => {
          const history = planningHistoryForTransaction(item);
          const applications = Array.isArray(history.applications) && history.applications.length
            ? history.applications
            : Array.isArray(item.planning?.recentApplications) ? item.planning.recentApplications : [];
          if (applications.length || planningApplicationCount(item) > 0) matchedPropertyKeys.add(propertyRecordKey(item));
          applications.forEach((application, index) => {
            const authority = normalise(application.authority || item.district || "");
            const reference = normalise(application.reference || application.applicationNumber || "");
            const fallback = normalise([application.proposal, application.description, application.siteAddress, application.receivedDate, application.decisionDate].filter(Boolean).join("|"));
            const caseKey = reference ? `${authority}|${reference}` : `${authority}|${fallback || index}`;
            const confidence = Number(application.matchConfidence ?? history.matchConfidence ?? item.planningMatchConfidence ?? 1);
            propertyLinks.add(`${propertyRecordKey(item)}|${caseKey}`);
            if (!uniqueCases.has(caseKey) || confidence > uniqueCases.get(caseKey).confidence) uniqueCases.set(caseKey, { application, confidence });
          });
        });
        const cases = Array.from(uniqueCases.values());
        return {
          uniqueCases: uniqueCases.size,
          propertyLinks: propertyLinks.size,
          matchedProperties: matchedPropertyKeys.size,
          highConfidenceCases: cases.filter(item => item.confidence >= .9).length,
          lowConfidenceCases: cases.filter(item => item.confidence < .7).length
        };
      }

      function planningApplicationVolumeForRows(rows) {
        const metrics = planningMetricsForRows(rows);
        // Use unique authority/reference cases for area totals so the same
        // application linked to neighbouring properties is not double-counted.
        if (metrics.uniqueCases) return metrics.uniqueCases;
        const seen = new Set();
        return rows.reduce((total, item) => {
          const key = propertyRecordKey(item);
          if (seen.has(key)) return total;
          seen.add(key);
          return total + planningApplicationCount(item);
        }, 0);
      }

      function townKey(value) {
        return normalise(value).replace(/\s+/g, "_");
      }

      function compactPrice(value) {
        const number = Number(value);
        if (!Number.isFinite(number) || number <= 0) return "£--";
        if (number >= 10000000) return "£" + (number / 1000000).toFixed(1).replace(/\.0$/, "") + "m";
        return "£" + (number / 1000000).toFixed(2).replace(/0$/, "").replace(/\.0$/, "") + "m";
      }

      function formatNumber(value) {
        return new Intl.NumberFormat("en-GB").format(Math.round(Number(value) || 0));
      }

      function formatCount(value, singular, plural = singular + "s") {
        const count = Math.round(Number(value) || 0);
        return `${formatNumber(count)} ${count === 1 ? singular : plural}`;
      }

      function compactSqft(value) {
        const number = Number(value);
        if (!Number.isFinite(number) || number <= 0) return "";
        return formatNumber(number) + " sq ft";
      }

      function compactPpsf(value) {
        const number = Number(value);
        if (!Number.isFinite(number) || number <= 0) return "";
        return "£" + formatNumber(number) + "/sq ft";
      }

      function formatDate(value) {
        if (!value) return "";
        const text = String(value);
        if (formattedDateCache.has(text)) return formattedDateCache.get(text);
        const date = new Date(/^\d{4}-\d{2}-\d{2}$/.test(text) ? text + "T00:00:00Z" : text);
        const formatted = Number.isNaN(date.getTime()) ? text : displayDateFormatter.format(date);
        formattedDateCache.set(text, formatted);
        return formatted;
      }

      function parseIso(value) {
        const text = String(value ?? "");
        if (parsedIsoDateCache.has(text)) return parsedIsoDateCache.get(text);
        const date = new Date(text + "T00:00:00Z");
        const parsed = Number.isNaN(date.getTime()) ? null : date;
        parsedIsoDateCache.set(text, parsed);
        return parsed;
      }

      function clamp(min, max, value) {
        return Math.max(min, Math.min(max, value));
      }

      function mapZoomFromDisplay(value) {
        return zoomMin + (clamp(0, 100, Number(value) || 0) / 100) * (zoomMax - zoomMin);
      }

      function displayZoomFromMap(value) {
        const percent = clamp(0, 100, ((Number(value) - zoomMin) / (zoomMax - zoomMin)) * 100);
        return percent < 5 ? 0 : Math.round(percent);
      }

      function addMonths(date, months) {
        const copy = new Date(date.getTime());
        copy.setUTCMonth(copy.getUTCMonth() + months);
        return copy;
      }

      function addDays(date, days) {
        return new Date(date.getTime() + days * 24 * 60 * 60 * 1000);
      }

      function startOfUtcMonth(date) {
        return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
      }

      function endOfUtcMonth(date) {
        return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0));
      }

      function addYearsClamped(date, years) {
        const year = date.getUTCFullYear() + years;
        const month = date.getUTCMonth();
        const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
        return new Date(Date.UTC(year, month, Math.min(date.getUTCDate(), lastDay)));
      }

      function monthsBetween(start, end) {
        return Math.max(1, (end - start) / (1000 * 60 * 60 * 24 * 30.4375));
      }

      function median(values) {
        if (!values.length) return 0;
        const sorted = values.slice().sort((a, b) => a - b);
        const mid = Math.floor(sorted.length / 2);
        return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
      }

      function average(values) {
        return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
      }

      function signedPercent(value, confidence = 1) {
        if (!confidence || !Number.isFinite(value)) return "--";
        const percent = Math.round(value * 100);
        if (Math.abs(percent) < 1) return "flat";
        return (percent > 0 ? "+" : "") + percent + "%";
      }

      function preciseSignedPercent(value, confidence = 1) {
        if (!confidence || !Number.isFinite(value)) return "--";
        const percent = value * 100;
        if (Math.abs(percent) < .05) return "flat";
        return `${percent > 0 ? "+" : ""}${percent.toFixed(1)}%`;
      }

      function priceMovementLabel(stats) {
        if (!(Number(stats?.priceConfidence) > 0)) return "Insufficient evidence";
        return `${preciseSignedPercent(Number(stats.priceChange), 1)} real p.a.`;
      }

      function priceMovementConfidenceLabel(stats) {
        const confidence = Number(stats?.priceConfidence) || 0;
        if (confidence >= .75) return "High confidence";
        if (confidence >= .45) return "Medium confidence";
        if (confidence > 0) return "Low confidence";
        return "Insufficient evidence";
      }

      function priceMovementEvidenceLabel(stats) {
        const localPairs = Number(stats?.pricePairCount) || 0;
        const parentPairs = Number(stats?.priceParentPairCount) || 0;
        const parentLabel = String(stats?.priceParentLabel || "Authority").toLowerCase();
        if (!localPairs && parentPairs) return `${formatNumber(parentPairs)} ${parentLabel} pairs · contextual`;
        if (!localPairs) return "No qualifying repeat-sale pairs";
        const local = `${formatNumber(localPairs)} repeat-sale ${localPairs === 1 ? "pair" : "pairs"}`;
        return parentPairs ? `${local} + ${parentLabel} context` : local;
      }

      function velocityRating(score) {
        const value = Number(score) || 0;
        if (value >= 70) return "Hot";
        if (value >= 58) return "Active";
        if (value >= 45) return "Steady";
        if (value >= 30) return "Slow";
        return "Cold";
      }

      function velocityLabel(stats) {
        if (!(Number(stats?.count) > 0)) return "No qualifying sales";
        const score = Number(stats?.marketHeatScore ?? stats?.velocityScore) || 0;
        if (!stats?.rankEligible) return `${score}/100 · Unranked`;
        return `${score}/100 · ${velocityRating(score)}`;
      }

      function velocityConfidenceLabel(stats) {
        if (!(Number(stats?.count) > 0)) return "Insufficient evidence";
        const confidence = Number(stats?.velocityConfidence) || 0;
        if (confidence >= .75) return "High confidence";
        if (confidence >= .45) return "Medium confidence";
        return "Low confidence";
      }

      function accelerationLabel(stats) {
        if (!stats?.signalQualified) return "Insufficient signal";
        const acceleration = Number(stats?.signalRatio ?? stats?.acceleration) || 1;
        if (acceleration >= 1.2) return "Accelerating";
        if (acceleration <= .83) return "Slowing";
        return "Stable";
      }

      function rankEvidenceLabel(stats) {
        if (stats?.rankEligible) return "Rank eligible";
        const reasons = [];
        if ((Number(stats?.recent) || 0) < velocityMinimumRecentSales) reasons.push(`under ${velocityMinimumRecentSales} mature sales`);
        if ((Number(stats?.baselineTotal) || 0) < velocityMinimumBaselineSales) reasons.push(`under ${velocityMinimumBaselineSales} baseline sales`);
        if ((Number(stats?.count) || 0) < velocityMinimumHistorySales) reasons.push(`under ${velocityMinimumHistorySales} total sales`);
        return reasons.length ? `Unranked · ${reasons.join(" · ")}` : "Unranked · insufficient evidence";
      }

      function distanceKm(a, b) {
        if (!a || !b) return Infinity;
        const toRad = value => value * Math.PI / 180;
        const radius = 6371;
        const dLat = toRad(b[1] - a[1]);
        const dLon = toRad(b[0] - a[0]);
        const lat1 = toRad(a[1]);
        const lat2 = toRad(b[1]);
        const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
        return radius * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
      }

      function formatDistanceKm(value) {
        if (!Number.isFinite(value)) return "";
        return value < 1 ? Math.round(value * 1000) + "m" : value.toFixed(1) + "km";
      }

      function formatMinutes(value) {
        const minutes = Math.round(Number(value) || 0);
        if (!minutes) return "";
        if (minutes < 60) return `${minutes} min`;
        const hours = Math.floor(minutes / 60);
        const remainder = minutes % 60;
        return remainder ? `${hours}h ${remainder}m` : `${hours}h`;
      }

      const velocityWindowMonths = 12;
      const activityContextMonths = 24;
      const velocityMaturityLagValue = landRegMeta.velocityMaturityLagMonths;
      const parsedVelocityMaturityLagMonths = Number(velocityMaturityLagValue);
      const velocityMaturityLagMonths = String(velocityMaturityLagValue ?? "").trim() !== ""
        && Number.isFinite(parsedVelocityMaturityLagMonths)
        ? Math.round(clamp(0, 12, parsedVelocityMaturityLagMonths))
        : 2;
      const velocityBaselineYears = 3;
      const velocityPriorSales = 4;
      const signalWindowDays = 120;
      const velocityMinimumRecentSales = 2;
      const velocityMinimumBaselineSales = 4;
      const velocityMinimumHistorySales = 10;
      const signalMinimumRecentSales = 3;
      const signalMinimumBaselineSales = 9;
      const priceMovementWindowMonths = 24;
      const minimumRepeatHoldingDays = 365;
      const maximumAnnualRealMovement = .25;
      const cpihAnnualIndex = {
        1995: 66.6, 1996: 68.5, 1997: 70.0, 1998: 71.3, 1999: 72.6,
        2000: 73.4, 2001: 74.6, 2002: 75.7, 2003: 76.7, 2004: 77.8,
        2005: 79.4, 2006: 81.4, 2007: 83.3, 2008: 86.2, 2009: 87.9,
        2010: 90.1, 2011: 93.6, 2012: 96.0, 2013: 98.2, 2014: 99.6,
        2015: 100.0, 2016: 101.0, 2017: 103.6, 2018: 106.0, 2019: 107.8,
        2020: 108.9, 2021: 111.6, 2022: 120.5, 2023: 128.6, 2024: 132.9,
        2025: 138.0, 2026: 142.1
      };
      const cpihReferenceYear = Math.max(...Object.keys(cpihAnnualIndex).map(Number));
      const cpihVersion = "annual-1995-2026-v1";
      // Keep the property-recency/reference clock independent from the lag-aware
      // velocity clock. Velocity matures from the latest sale actually observed,
      // not from a feed coverage date that may run ahead of registrations.
      const latestObservedRowDate = transactionRows
        .map(item => parseIso(String(item?.date || "").slice(0, 10)))
        .filter(Boolean)
        .sort((left, right) => right - left)[0] || null;
      const metadataAnalysisEnd = parseIso(String(landRegMeta.to || "").slice(0, 10));
      const metadataLatestObserved = parseIso(String(landRegMeta.latestObservedSaleDate || "").slice(0, 10));
      const analysisEnd = metadataAnalysisEnd || latestObservedRowDate || parseIso("2026-06-30");
      const latestObserved = metadataLatestObserved || latestObservedRowDate || metadataAnalysisEnd || parseIso("2026-06-30");
      const velocityCutoffValue = landRegMeta.velocityCutoffDate
        || landRegMeta.velocityMatureThrough
        || landRegMeta.velocityAnalysisThrough
        || "";
      const velocityCutoffOverride = /^\d{4}-\d{2}$/.test(String(velocityCutoffValue))
        ? endOfUtcMonth(parseIso(`${velocityCutoffValue}-01`))
        : parseIso(String(velocityCutoffValue).slice(0, 10));
      const derivedVelocityAnalysisEnd = endOfUtcMonth(addMonths(startOfUtcMonth(latestObserved), -velocityMaturityLagMonths));
      const velocityAnalysisEnd = velocityCutoffOverride && velocityCutoffOverride <= latestObserved
        ? velocityCutoffOverride
        : derivedVelocityAnalysisEnd;
      const velocityCutoffSource = velocityCutoffOverride && velocityCutoffOverride <= latestObserved
        ? "metadata"
        : "derived";
      const coverageYear = String(landRegMeta.from || salesHistoryMeta.coverageFrom || "1995").slice(0, 4);
      const analysisStart = parseIso(`${coverageYear}-01-01`);
      const velocityStart = startOfUtcMonth(addMonths(velocityAnalysisEnd, -(velocityWindowMonths - 1)));
      const activityContextStart = startOfUtcMonth(addMonths(velocityAnalysisEnd, -(activityContextMonths - 1)));
      const velocityBaselineStart = addMonths(velocityStart, -(velocityBaselineYears * 12));
      const signalStart = addDays(velocityAnalysisEnd, -(signalWindowDays - 1));
      const priceMovementStart = addMonths(analysisEnd, -priceMovementWindowMonths);

      function marketById(id) {
        return marketDefinitions.find(market => market.id === id);
      }

      function rowsForMarket(id) {
        return transactions.filter(item => item.market === id);
      }

      function rowsForTownKey(key) {
        return transactions.filter(item => townKey(item.town) === key);
      }

      function activityRowsForProperties(rows) {
        const seen = new Set();
        const activity = [];
        rows.forEach(property => {
          const sales = transactionRowsByProperty.get(propertyRecordKey(property)) || [property];
          (sales.length ? sales : [property]).forEach(sale => {
            const identity = `${propertyRecordKey(property)}|${String(sale.date || "").slice(0, 10)}|${Number(sale.price || 0)}|${String(sale.id || "")}`;
            if (seen.has(identity)) return;
            seen.add(identity);
            const activityRow = {
              ...property,
              ...sale,
              market: sale.market || property.market,
              district: sale.district || property.district,
              town: sale.town || property.town,
              propertyRecordKey: propertyRecordKey(property),
              __insightGrain: "transaction"
            };
            const price = Number(activityRow.price || 0);
            const floorArea = Number(activityRow.floorAreaSqft || 0);
            // Historical title rows often omit the derived field. Never carry
            // the latest sale's £/sq ft backwards into an earlier transaction.
            activityRow.pricePerSqft = price > 0 && floorArea > 0 ? Math.round(price / floorArea) : 0;
            activity.push(activityRow);
          });
        });
        return activity.sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
      }

      function isTransactionGrain(rows) {
        return Boolean(rows.length) && rows.every(item => item?.__insightGrain === "transaction");
      }

      function cpihIndexForDate(value) {
        const year = Number(String(value || "").slice(0, 4));
        return Number.isFinite(year) ? Number(cpihAnnualIndex[year] || 0) : 0;
      }

      function inflationAdjustedPrice(item) {
        const price = Number(item?.price || 0);
        const sourceIndex = cpihIndexForDate(item?.date);
        return price > 0 && sourceIndex > 0 ? price * cpihAnnualIndex[cpihReferenceYear] / sourceIndex : 0;
      }

      function repeatSaleConfidence(pairCount) {
        const count = Math.max(0, Number(pairCount) || 0);
        return count < 3 ? 0 : Math.min(1, count / 12);
      }

      function quantileInclusive(values, ratio) {
        const sorted = values.filter(Number.isFinite).sort((left, right) => left - right);
        if (!sorted.length) return 0;
        const index = (sorted.length - 1) * ratio;
        const low = Math.floor(index);
        const high = Math.ceil(index);
        const weight = index - low;
        return sorted[low] * (1 - weight) + sorted[high] * weight;
      }

      function repeatSalePriceMovement(rows) {
        const seen = new Set();
        const pairs = [];
        rows.forEach(property => {
          const recordKey = propertyRecordKey(property);
          if (seen.has(recordKey)) return;
          seen.add(recordKey);
          const sales = salesHistoryForTransaction(property)
            .filter(sale => Number(sale.price) > 0 && parseIso(String(sale.date || "").slice(0, 10)))
            .sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
          if (sales.length < 2) return;
          const pricesByDate = new Map();
          let conflictingSaleDate = false;
          sales.forEach(sale => {
            const date = String(sale.date || "").slice(0, 10);
            const price = Number(sale.price || 0);
            if (pricesByDate.has(date) && pricesByDate.get(date) !== price) conflictingSaleDate = true;
            pricesByDate.set(date, price);
          });
          if (conflictingSaleDate) return;
          const latest = sales[0];
          const prior = sales[1];
          if (String(latest.category || "").toUpperCase() === "B" || String(prior.category || "").toUpperCase() === "B") return;
          const latestType = normalise(latest.propertyType);
          const priorType = normalise(prior.propertyType);
          if (latestType && priorType && latestType !== priorType) return;
          const latestDate = parseIso(String(latest.date || "").slice(0, 10));
          const priorDate = parseIso(String(prior.date || "").slice(0, 10));
          if (!latestDate || !priorDate || latestDate < priceMovementStart || latestDate > analysisEnd) return;
          const holdingDays = Math.round((latestDate - priorDate) / (24 * 60 * 60 * 1000));
          if (holdingDays < minimumRepeatHoldingDays) return;
          const latestPrice = inflationAdjustedPrice(latest);
          const priorPrice = inflationAdjustedPrice(prior);
          if (!(latestPrice > 0 && priorPrice > 0)) return;
          const ratio = latestPrice / priorPrice;
          const annualised = Math.pow(ratio, 365.25 / holdingDays) - 1;
          if (!Number.isFinite(annualised)) return;
          pairs.push({
            recordKey,
            latest,
            prior,
            holdingYears: holdingDays / 365.25,
            annualised,
            boundedAnnualised: clamp(-maximumAnnualRealMovement, maximumAnnualRealMovement, annualised)
          });
        });

        const bounded = pairs.map(pair => pair.boundedAnnualised);
        const lower = bounded.length >= 8 ? quantileInclusive(bounded, .1) : -maximumAnnualRealMovement;
        const upper = bounded.length >= 8 ? quantileInclusive(bounded, .9) : maximumAnnualRealMovement;
        const winsorised = bounded.map(value => clamp(lower, upper, value));
        const pairCount = pairs.length;
        const priceChange = pairCount >= 3 ? median(winsorised) : 0;
        const medianHoldYears = pairCount ? median(pairs.map(pair => pair.holdingYears)) : 0;
        return {
          priceChange,
          priceLocalChange: priceChange,
          priceConfidence: repeatSaleConfidence(pairCount),
          pricePairCount: pairCount,
          priceEvidencePairCount: pairCount,
          priceParentPairCount: 0,
          priceParentLabel: "",
          priceMedianHoldYears: medianHoldYears,
          priceMovementWindowMonths,
          priceSource: pairCount >= 3 ? "Local repeat sales" : "Insufficient repeat-sales evidence",
          priceComparisonLabel: pairCount >= 3
            ? `${formatNumber(pairCount)} repeat-sale ${pairCount === 1 ? "pair" : "pairs"} · CPIH adjusted · annualised`
            : `Only ${formatNumber(pairCount)} qualifying repeat-sale ${pairCount === 1 ? "pair" : "pairs"} · minimum 3 required`
        };
      }

      function paceScoreForRatio(value) {
        const ratio = Math.max(0, Number(value) || 0);
        const points = [[0, 5], [.5, 25], [.75, 40], [1, 50], [1.25, 62], [1.5, 72], [2, 84], [3, 94], [4, 100]];
        for (let index = 1; index < points.length; index++) {
          const [upperRatio, upperScore] = points[index];
          if (ratio <= upperRatio) {
            const [lowerRatio, lowerScore] = points[index - 1];
            const position = (ratio - lowerRatio) / Math.max(.001, upperRatio - lowerRatio);
            return lowerScore + (upperScore - lowerScore) * position;
          }
        }
        return points[points.length - 1][1];
      }

      function applyVelocityMatrix(stats, liquidityLogReference = Math.log1p(12)) {
        const reference = Math.max(Math.log1p(1), Number(liquidityLogReference) || 0);
        const liquidityScore = stats.count > 0
          ? Math.round(clamp(0, 100, stats.liquidityLog / reference * 100))
          : 0;
        const marketHeatScore = stats.count > 0
          ? Math.round(clamp(0, 100, stats.paceScore * .6 + liquidityScore * .4))
          : 0;
        return {
          ...stats,
          liquidityScore,
          marketHeatScore,
          // Compatibility alias for map expressions and older answer paths.
          // It now means the explicit 60/40 market-heat composite.
          velocityScore: marketHeatScore
        };
      }

      function velocityMatrixForGroups(groups) {
        const statsList = groups.filter(Boolean);
        const liquidityLogReference = Math.max(0, ...statsList.map(stats => Number(stats.liquidityLog) || 0));
        return statsList.map(stats => applyVelocityMatrix(stats, liquidityLogReference));
      }

      function isTwoToThreeMillionSale(item) {
        const price = Number(item?.price || 0);
        return price >= landRegPriceFloor && price < 3000000;
      }

      function statsForRows(rows, activityOverride = null) {
        const hasActivityOverride = Array.isArray(activityOverride);
        if (!hasActivityOverride && statsForRowsCache.has(rows)) return statsForRowsCache.get(rows);
        const transactionGrain = !hasActivityOverride && isTransactionGrain(rows);
        const activityRows = hasActivityOverride ? activityOverride.slice() : transactionGrain ? rows.slice() : activityRowsForProperties(rows);
        const hasActivity = activityRows.length > 0;
        const latestActivityRow = activityRows.reduce((latest, item) => {
          return !latest || String(item.date || "").localeCompare(String(latest.date || "")) > 0 ? item : latest;
        }, null);
        const prices = rows.map(item => Number(item.price)).filter(Number.isFinite);
        const ppsf = rows.map(item => Number(item.pricePerSqft)).filter(value => Number.isFinite(value) && value > 0);
        const recent = activityRows.filter(item => {
          const date = parseIso(item.date);
          return date && date >= velocityStart && date <= velocityAnalysisEnd;
        });
        const context24 = activityRows.filter(item => {
          const date = parseIso(item.date);
          return date && date >= activityContextStart && date <= velocityAnalysisEnd;
        });
        const context24Prices = context24.map(item => Number(item.price)).filter(value => Number.isFinite(value) && value > 0);
        const context24Ppsf = context24.map(item => Number(item.pricePerSqft)).filter(value => Number.isFinite(value) && value > 0);
        const baseline = activityRows.filter(item => {
          const date = parseIso(item.date);
          return date && date >= velocityBaselineStart && date < velocityStart;
        });
        const baselineWindowCounts = Array.from({ length: velocityBaselineYears }, (_unused, index) => {
          const windowEnd = addMonths(velocityStart, -(index * 12));
          const windowStart = addMonths(windowEnd, -12);
          return activityRows.filter(item => {
            const date = parseIso(item.date);
            return date && date >= windowStart && date < windowEnd;
          }).length;
        });
        const baselineTotal = baselineWindowCounts.reduce((sum, count) => sum + count, 0);
        const baselineAnnual = baselineTotal / velocityBaselineYears;
        const recentAnnual = recent.length;
        const rawVelocity = baselineAnnual > 0 ? recentAnnual / baselineAnnual : recent.length ? 1 : 0;
        const velocity = hasActivity
          ? (recentAnnual + velocityPriorSales) / (baselineAnnual + velocityPriorSales)
          : 0;
        const velocityEvidenceSales = recent.length + baselineTotal;
        const velocityConfidence = hasActivity
          ? velocityEvidenceSales / (velocityEvidenceSales + velocityPriorSales)
          : 0;
        const paceScore = hasActivity ? Math.round(clamp(0, 100, paceScoreForRatio(velocity))) : 0;
        const rankEligible = !transactionGrain
          && recent.length >= velocityMinimumRecentSales
          && baselineTotal >= velocityMinimumBaselineSales
          && activityRows.length >= velocityMinimumHistorySales;
        const signalRecentRows = activityRows.filter(item => {
          const date = parseIso(item.date);
          return date && date >= signalStart && date <= velocityAnalysisEnd;
        });
        const signalBaselineCounts = Array.from({ length: velocityBaselineYears }, (_unused, index) => {
          const windowEnd = addYearsClamped(velocityAnalysisEnd, -(index + 1));
          const windowStart = addDays(windowEnd, -(signalWindowDays - 1));
          return activityRows.filter(item => {
            const date = parseIso(item.date);
            return date && date >= windowStart && date <= windowEnd;
          }).length;
        });
        const signalBaselineTotal = signalBaselineCounts.reduce((sum, count) => sum + count, 0);
        const signalBaselineAnnual = signalBaselineTotal / velocityBaselineYears;
        const rawSignal = signalBaselineAnnual > 0
          ? signalRecentRows.length / signalBaselineAnnual
          : signalRecentRows.length ? 1 : 0;
        const signalRatio = hasActivity
          ? (signalRecentRows.length + velocityPriorSales) / (signalBaselineAnnual + velocityPriorSales)
          : 0;
        const signalEvidenceSales = signalRecentRows.length + signalBaselineTotal;
        const signalConfidence = hasActivity
          ? signalEvidenceSales / (signalEvidenceSales + velocityPriorSales)
          : 0;
        const signalQualified = signalRecentRows.length >= signalMinimumRecentSales
          && signalBaselineTotal >= signalMinimumBaselineSales;
        const baseStats = {
          count: activityRows.length,
          propertyCount: transactionGrain ? new Set(rows.map(propertyRecordKey)).size : rows.length,
          twoToThreeMillionPropertyCount: new Set(rows.filter(isTwoToThreeMillionSale).map(propertyRecordKey)).size,
          twoToThreeMillionTransactionCount: activityRows.filter(isTwoToThreeMillionSale).length,
          transactionGrain,
          avg: average(prices),
          max: prices.length ? Math.max(...prices) : 0,
          latest: latestActivityRow,
          recent: recent.length,
          context24: context24.length,
          context24Avg: average(context24Prices),
          context24PpsfAvg: average(context24Ppsf),
          prior: baseline.length,
          baselineTotal,
          baselineWindowCounts,
          baselineAnnual,
          recentAnnual,
          velocityWindowMonths,
          velocityBaselineYears,
          velocityPriorSales,
          velocity,
          rawVelocity,
          velocityConfidence,
          velocityEvidenceSales,
          paceScore,
          liquidityLog: Math.log1p(recent.length),
          rankEligible,
          signalWindowDays,
          signalRecent: signalRecentRows.length,
          signalBaselineCounts,
          signalBaselineTotal,
          signalBaselineAnnual,
          rawSignal,
          signalRatio,
          signalConfidence,
          signalQualified,
          // Compatibility aliases; the 120-day signal is informational only
          // and is never added to paceScore or marketHeatScore.
          acceleration: signalRatio,
          accelerationConfidence: signalConfidence,
          accelerationScore: 0
        };
        const priceMovement = transactionGrain ? {
          priceChange: 0,
          priceLocalChange: 0,
          priceConfidence: 0,
          pricePairCount: 0,
          priceEvidencePairCount: 0,
          priceParentPairCount: 0,
          priceMedianHoldYears: 0,
          priceMovementWindowMonths,
          priceSource: "Not calculated for a historical transaction slice",
          priceComparisonLabel: "Historical transaction slice"
        } : repeatSalePriceMovement(rows);
        const stats = applyVelocityMatrix({
          ...baseStats,
          ppsfAvg: average(ppsf),
          priceChange: priceMovement.priceChange,
          priceLocalChange: priceMovement.priceLocalChange,
          priceConfidence: priceMovement.priceConfidence,
          pricePairCount: priceMovement.pricePairCount,
          priceEvidencePairCount: priceMovement.priceEvidencePairCount,
          priceParentPairCount: priceMovement.priceParentPairCount,
          priceMedianHoldYears: priceMovement.priceMedianHoldYears,
          priceMovementWindowMonths: priceMovement.priceMovementWindowMonths,
          priceSource: priceMovement.priceSource,
          priceComparisonLabel: priceMovement.priceComparisonLabel,
          planningApplications: planningApplicationVolumeForRows(rows)
        });
        if (!hasActivityOverride) statsForRowsCache.set(rows, stats);
        return stats;
      }

      function withParentPriceMovement(stats, parentStats, parentLabel = "Authority") {
        if (!stats || !parentStats || !(parentStats.priceConfidence > 0)) return stats;
        const localPairs = Number(stats.pricePairCount) || 0;
        if (localPairs < 3 || localPairs >= 8) return stats;
        const parentPairs = Number(parentStats.priceEvidencePairCount || parentStats.pricePairCount) || 0;
        if (!parentPairs) return stats;
        const localWeight = localPairs / 8;
        const priceChange = stats.priceLocalChange * localWeight + parentStats.priceChange * (1 - localWeight);
        return {
          ...stats,
          priceChange,
          priceEvidencePairCount: localPairs,
          priceParentPairCount: parentPairs,
          priceParentLabel: parentLabel,
          priceSource: `Local repeat sales + ${parentLabel.toLowerCase()} context`,
          priceComparisonLabel: `${formatNumber(localPairs)} local ${localPairs === 1 ? "pair" : "pairs"} · confidence-weighted with ${parentLabel.toLowerCase()} context`
        };
      }

      const rawOverallStats = statsForRows(transactions);
      const rawMarketEntries = marketDefinitions.map(market => [market.id, statsForRows(rowsForMarket(market.id))]);
      const matrixMarketStats = velocityMatrixForGroups(rawMarketEntries.map(entry => entry[1]));
      const marketStats = Object.fromEntries(rawMarketEntries.map((entry, index) => [entry[0], matrixMarketStats[index]]));
      const marketLiquidityReference = Math.max(0, ...rawMarketEntries.map(entry => Number(entry[1].liquidityLog) || 0));
      const overallStats = applyVelocityMatrix(rawOverallStats, marketLiquidityReference);
      const analyticalTownKeys = Array.from(new Set(transactions.map(item => townKey(item.town)).filter(Boolean))).sort();
      const rawTownEntries = analyticalTownKeys.map(key => {
        const rows = rowsForTownKey(key);
        const localStats = statsForRows(rows);
        return [key, withParentPriceMovement(localStats, marketStats[rows[0]?.market])];
      });
      const matrixTownStats = velocityMatrixForGroups(rawTownEntries.map(entry => entry[1]));
      const townStats = Object.fromEntries(rawTownEntries.map((entry, index) => [entry[0], matrixTownStats[index]]));
      const rawEstateEntries = estatePins.map(pin => {
        const rows = estateTransactions(pin);
        const activityRows = estateActivityRows(pin);
        const localStats = statsForRows(rows, activityRows);
        return [pin.key, withParentPriceMovement(localStats, marketStats[pin?.market])];
      });
      const matrixEstateStats = velocityMatrixForGroups(rawEstateEntries.map(entry => entry[1]));
      const estateStats = Object.fromEntries(rawEstateEntries.map((entry, index) => [entry[0], matrixEstateStats[index]]));

      function statsForEstate(pin) {
        return estateStats[pin?.key || pin] || applyVelocityMatrix(statsForRows([], []));
      }

      function velocityDebugSnapshot(id, label, stats) {
        return {
          id,
          label,
          propertyCount: stats.propertyCount,
          verifiedHistoryCount: stats.count,
          twoToThreeMillionPropertyCount: stats.twoToThreeMillionPropertyCount,
          twoToThreeMillionTransactionCount: stats.twoToThreeMillionTransactionCount,
          recent: stats.recent,
          baselineWindowCounts: stats.baselineWindowCounts.slice(),
          baselineTotal: stats.baselineTotal,
          baselineAnnual: stats.baselineAnnual,
          rawVelocity: stats.rawVelocity,
          velocity: stats.velocity,
          velocityConfidence: stats.velocityConfidence,
          paceScore: stats.paceScore,
          liquidityScore: stats.liquidityScore,
          marketHeatScore: stats.marketHeatScore,
          rankEligible: stats.rankEligible,
          signalRecent: stats.signalRecent,
          signalBaselineCounts: stats.signalBaselineCounts.slice(),
          signalBaselineTotal: stats.signalBaselineTotal,
          signalRatio: stats.signalRatio,
          signalConfidence: stats.signalConfidence,
          signalQualified: stats.signalQualified
        };
      }

      function deepFreezeVelocityDebug(value) {
        if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
        Object.values(value).forEach(deepFreezeVelocityDebug);
        return Object.freeze(value);
      }

      const velocityMatrixDebug = deepFreezeVelocityDebug({
        methodVersion: "velocity-matrix-2026-07-19-v1",
        latestObserved: latestObserved.toISOString().slice(0, 10),
        analysisThrough: velocityAnalysisEnd.toISOString().slice(0, 10),
        cutoffSource: velocityCutoffSource,
        universe: {
          coverageFrom: String(landRegMeta.from || "1995-01-01"),
          priceFloor: landRegPriceFloor,
          propertyCount: transactions.length,
          transactionCount: transactionRows.length,
          twoToThreeMillionPropertyCount: overallStats.twoToThreeMillionPropertyCount,
          twoToThreeMillionTransactionCount: overallStats.twoToThreeMillionTransactionCount
        },
        constants: {
          velocityWindowMonths,
          velocityMaturityLagMonths,
          velocityBaselineYears,
          velocityPriorSales,
          signalWindowDays,
          marketHeatWeights: { pace: .6, liquidity: .4 },
          rankGate: {
            minimumVerifiedHistory: velocityMinimumHistorySales,
            minimumRecent: velocityMinimumRecentSales,
            minimumBaselineTotal: velocityMinimumBaselineSales
          },
          signalGate: {
            minimumRecent: signalMinimumRecentSales,
            minimumBaselineTotal: signalMinimumBaselineSales
          }
        },
        overall: velocityDebugSnapshot("surrey", "Surrey", overallStats),
        markets: marketDefinitions.map(market => velocityDebugSnapshot(market.id, market.short, marketStats[market.id])),
        towns: Object.keys(townStats).map(key => velocityDebugSnapshot(key, townDisplayName(key), townStats[key])),
        estates: estatePins.map(pin => velocityDebugSnapshot(pin.key, pin.name, estateStats[pin.key]))
      });
      Object.defineProperty(window, "INSIGHT_VELOCITY_MATRIX_DEBUG", {
        value: velocityMatrixDebug,
        enumerable: true,
        configurable: false,
        writable: false
      });

      const heatColours = ["#557aa0", "#728d79", "#b08a58", "#9f4549"];
      const velocityColours = ["#006ab6", "#3f8f68", "#d5a53a", "#b63d42"];

      function metricForStats(stats, mode) {
        if (!stats) return 0;
        if (mode === "value") return stats.avg;
        if (mode === "ppsf") return stats.ppsfAvg;
        if (mode === "growth") return stats.priceChange;
        if (mode === "planning") return stats.planningApplications;
        return stats.marketHeatScore;
      }

      function quantile(values, ratio) {
        const sorted = values.filter(value => Number.isFinite(value) && value !== 0).sort((a, b) => a - b);
        if (!sorted.length) return 0;
        const index = (sorted.length - 1) * ratio;
        const low = Math.floor(index);
        const high = Math.ceil(index);
        const weight = index - low;
        return sorted[low] * (1 - weight) + sorted[high] * weight;
      }

      function breaksFor(mode) {
        if (mode === "velocity") return [45, 58, 70];
        if (mode === "ppsf") return [500, 850, 1200];
        if (mode === "growth") return [-.03, .03, .08];
        const statsList = Object.values(marketStats).filter(stats => stats.count > 0);
        const values = statsList.map(stats => metricForStats(stats, mode));
        const fallback = {
          velocity: [35, 50, 65],
          value: [nearFloorPriceCeiling, landRegPriceFloor + 1500000, landRegPriceFloor + 3000000],
          growth: [-.04, .04, .12],
          planning: [1, 4, 8]
        }[mode] || [35, 50, 65];
        if (values.filter(value => Number.isFinite(value) && value !== 0).length < 4) return fallback;
        return [quantile(values, .32), quantile(values, .62), quantile(values, .84)];
      }

      function colourExpression(mode) {
        const property = mode === "value" ? "avg"
          : mode === "ppsf" ? "ppsfAvg"
          : mode === "growth" ? "priceChange"
          : mode === "planning" ? "planningScore"
          : "marketHeatScore";
        const breaks = breaksFor(mode);
        if (mode === "growth") {
          return ["case",
            ["<=", ["to-number", ["get", "priceConfidence"]], 0], "#64748b",
            [">=", ["to-number", ["get", property]], breaks[2]], heatColours[3],
            [">=", ["to-number", ["get", property]], breaks[1]], heatColours[2],
            [">=", ["to-number", ["get", property]], breaks[0]], heatColours[1],
            heatColours[0]
          ];
        }
        if (mode === "planning") {
          return ["case",
            [">=", ["to-number", ["get", property]], breaks[2]], "#7c3aed",
            [">=", ["to-number", ["get", property]], breaks[1]], "#c19a58",
            [">=", ["to-number", ["get", property]], breaks[0]], "#6f967b",
            "#64748b"
          ];
        }
        if (mode === "velocity") {
          return ["case",
            ["!", ["boolean", ["get", "rankEligible"], false]], "#64748b",
            [">=", ["to-number", ["get", property]], breaks[2]], velocityColours[3],
            [">=", ["to-number", ["get", property]], breaks[1]], velocityColours[2],
            [">=", ["to-number", ["get", property]], breaks[0]], velocityColours[1],
            velocityColours[0]
          ];
        }
        const colours = mode === "velocity" ? velocityColours : heatColours;
        return ["case",
          [">=", ["to-number", ["get", property]], breaks[2]], colours[3],
          [">=", ["to-number", ["get", property]], breaks[1]], colours[2],
          [">=", ["to-number", ["get", property]], breaks[0]], colours[1],
          colours[0]
        ];
      }

      function propertyPriceColourExpression() {
        return ["case",
          ["<=", ["to-number", ["get", "price"]], 0], "#64748b",
          [">=", ["to-number", ["get", "price"]], 10000000], "#b63d42",
          [">=", ["to-number", ["get", "price"]], 5000000], "#d5a53a",
          [">=", ["to-number", ["get", "price"]], 3000000], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyPpsfColourExpression() {
        return ["case",
          ["<=", ["to-number", ["get", "pricePerSqft"]], 0], "#64748b",
          [">=", ["to-number", ["get", "pricePerSqft"]], 1500], "#b63d42",
          [">=", ["to-number", ["get", "pricePerSqft"]], 1000], "#d5a53a",
          [">=", ["to-number", ["get", "pricePerSqft"]], 750], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyPlanningColourExpression() {
        return ["case",
          [">=", ["to-number", ["get", "planningCount"]], 4], "#b63d42",
          [">=", ["to-number", ["get", "planningCount"]], 2], "#c19a58",
          [">=", ["to-number", ["get", "planningCount"]], 1], "#6f967b",
          "#64748b"
        ];
      }

      function propertyEpcColourExpression() {
        return ["match", ["get", "epcRating"],
          "A", "#287a50",
          "B", "#3f8f68",
          "C", "#d5a53a",
          "D", "#db7f35",
          "E", "#b63d42",
          "F", "#93323b",
          "G", "#6f2430",
          "#64748b"
        ];
      }

      function propertyRecencyColourExpression() {
        return ["case",
          ["<", ["to-number", ["get", "saleAgeDays"]], 0], "#64748b",
          ["<=", ["to-number", ["get", "saleAgeDays"]], 90], "#b63d42",
          ["<=", ["to-number", ["get", "saleAgeDays"]], 365], "#d5a53a",
          ["<=", ["to-number", ["get", "saleAgeDays"]], 730], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyUpliftColourExpression() {
        return ["case",
          ["!", ["boolean", ["get", "hasPriorSale"], false]], "#64748b",
          [">=", ["to-number", ["get", "valueUplift"]], .25], "#b63d42",
          [">=", ["to-number", ["get", "valueUplift"]], .1], "#d5a53a",
          [">=", ["to-number", ["get", "valueUplift"]], 0], "#3f8f68",
          "#006ab6"
        ];
      }

      function propertyListedColourExpression() {
        return ["match", ["get", "listedStatusClass"],
          "unlisted", "#64748b",
          "grade-ii", "#3f8f68",
          "grade-ii-star", "#006ab6",
          "grade-i", "#b63d42",
          "#64748b"
        ];
      }

      function propertyListedFilterExpression() {
        return ["in", ["get", "listedStatusClass"], ["literal", [
          "unlisted", "grade-ii", "grade-ii-star", "grade-i"
        ]]];
      }

      function propertyColourExpression() {
        if (state.propertyRenderMode === "ppsf") return propertyPpsfColourExpression();
        if (state.propertyRenderMode === "planning") return propertyPlanningColourExpression();
        if (state.propertyRenderMode === "epc") return propertyEpcColourExpression();
        if (state.propertyRenderMode === "recency") return propertyRecencyColourExpression();
        if (state.propertyRenderMode === "uplift") return propertyUpliftColourExpression();
        if (state.propertyRenderMode === "listed") return propertyListedColourExpression();
        return propertyPriceColourExpression();
      }

      function propertyPointOpacityExpression() {
        const scale = state.selectedType === "property" && state.selectedId ? .25 : 1;
        return ["interpolate", ["linear"], ["zoom"], 10.4, 0, 11, 0, 12, .58 * scale, 14, .92 * scale];
      }

      function inverseProject(x, y) {
        const xScale = 970.0475576048453;
        const xOffset = 883.5010614469987;
        const yScale = -1550.5137800225802;
        const yOffset = 79857.18293281777;
        return [(x - xOffset) / xScale, (y - yOffset) / yScale];
      }

      function pathToCoordinates(path) {
        const coords = [];
        const pattern = /[ML]\s*(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)/g;
        let match;
        while ((match = pattern.exec(path))) {
          coords.push(inverseProject(Number(match[1]), Number(match[2])));
        }
        if (coords.length && (coords[0][0] !== coords[coords.length - 1][0] || coords[0][1] !== coords[coords.length - 1][1])) {
          coords.push(coords[0]);
        }
        return coords;
      }

      function cloneGeometry(geometry) {
        return JSON.parse(JSON.stringify(geometry));
      }

      function marketGeoJson() {
        return {
          type: "FeatureCollection",
          features: marketDefinitions.map(market => {
            const stats = marketStats[market.id];
            return {
              type: "Feature",
              id: market.id,
              properties: {
                id: market.id,
                name: market.short,
                fullName: market.name,
                district: market.district,
                count: stats.count,
                avg: Math.round(stats.avg),
                max: stats.max,
                recent: stats.recent,
                context24: stats.context24,
                velocity: Number(stats.velocity.toFixed(2)),
                velocityConfidence: Number(stats.velocityConfidence.toFixed(2)),
                acceleration: Number(stats.acceleration.toFixed(2)),
                accelerationConfidence: Number(stats.accelerationConfidence.toFixed(2)),
                paceScore: stats.paceScore,
                liquidityScore: stats.liquidityScore,
                marketHeatScore: stats.marketHeatScore,
                rankEligible: stats.rankEligible,
                signalRecent: stats.signalRecent,
                signalRatio: Number(stats.signalRatio.toFixed(2)),
                signalQualified: stats.signalQualified,
                ppsfAvg: Math.round(stats.ppsfAvg),
                priceChange: Number(stats.priceChange.toFixed(3)),
                priceConfidence: Number(stats.priceConfidence.toFixed(2)),
                pricePairCount: stats.pricePairCount,
                priceParentPairCount: stats.priceParentPairCount,
                priceParentLabel: stats.priceParentLabel,
                priceMedianHoldYears: Number(stats.priceMedianHoldYears.toFixed(1)),
                priceSource: stats.priceSource,
                velocityScore: stats.velocityScore,
                planningScore: stats.planningApplications
              },
              geometry: market.geometry
                ? cloneGeometry(market.geometry)
                : { type: "Polygon", coordinates: [pathToCoordinates(market.fallbackPath.path)] }
            };
          })
        };
      }

      function polygonRings(geometry) {
        if (!geometry) return [];
        if (geometry.type === "Polygon") return geometry.coordinates || [];
        if (geometry.type === "MultiPolygon") return (geometry.coordinates || []).flat();
        return [];
      }

      function countyOutlineGeoJson() {
        const edgeMap = new Map();
        const precision = 1000000;
        const keyFor = point => `${Math.round(point[0] * precision)},${Math.round(point[1] * precision)}`;
        (ladGeoJson.features || []).forEach(feature => {
          polygonRings(feature.geometry).forEach(ring => {
            for (let i = 0; i < ring.length - 1; i++) {
              const a = ring[i];
              const b = ring[i + 1];
              const ak = keyFor(a);
              const bk = keyFor(b);
              const key = ak < bk ? `${ak}|${bk}` : `${bk}|${ak}`;
              const existing = edgeMap.get(key);
              if (existing) {
                existing.count += 1;
              } else {
                edgeMap.set(key, { count: 1, segment: [a, b] });
              }
            }
          });
        });
        return {
          type: "FeatureCollection",
          features: Array.from(edgeMap.values())
            .filter(edge => edge.count === 1)
            .map((edge, index) => ({
              type: "Feature",
              id: "county-edge-" + index,
              properties: {},
              geometry: { type: "LineString", coordinates: edge.segment }
            }))
        };
      }

      function townDisplayName(key) {
        const sample = transactions.find(item => townKey(item.town) === key);
        const value = sample?.town || key.replace(/_/g, " ");
        return String(value).toLowerCase().replace(/\b[a-z]/g, letter => letter.toUpperCase());
      }

      function deterministicJitter(id, scale) {
        let hash = 0;
        const text = String(id || "");
        for (let i = 0; i < text.length; i++) hash = ((hash << 5) - hash + text.charCodeAt(i)) | 0;
        const a = ((hash % 997) / 997) * Math.PI * 2;
        const b = (((hash >> 3) % 389) / 389) * scale;
        return [Math.cos(a) * b, Math.sin(a) * b * .7];
      }

      function spreadPoint(point, id, scale) {
        const jitter = deterministicJitter(id, scale);
        return [point[0] + jitter[0], point[1] + jitter[1]];
      }

      function addressRuleForTransaction(item) {
        const addressText = normalise([item.address, item.postcode].join(" "));
        return addressPointRules.find(rule => rule.terms.some(term => addressText.includes(normalise(term))));
      }

      function estateForTransaction(item) {
        // The collector owns classification. Never revive the legacy free-text
        // `estate` field or attempt a second substring classifier in the UI.
        const estateId = String(item?.estateId || "");
        if (!estateId) return null;
        return estatePins.find(estate => estate.key === estateId) || null;
      }

      function schoolId(school) {
        return String(school?.urn || school?.name || "");
      }

      function schoolById(id) {
        const target = String(id || "");
        return schools.find(school => schoolId(school) === target);
      }

      function schoolSector(school) {
        const type = normalise(school?.type);
        if (type.includes("INDEPENDENT")) return "Private";
        if (type.includes("ACADEMY") || type.includes("COMMUNITY") || type.includes("FOUNDATION") || type.includes("VOLUNTARY") || type.includes("FREE SCHOOL")) return "State";
        if (type.includes("LOCAL AUTHORITY")) return "State";
        return school?.type || "School";
      }

      function schoolAgeRange(school) {
        const low = Number(school?.lowAge);
        const high = Number(school?.highAge);
        if (Number.isFinite(low) && Number.isFinite(high) && high > 0) return `${low}-${high}`;
        return school?.phase || "";
      }

      function schoolCoordinate(school) {
        const lon = Number(school?.lon);
        const lat = Number(school?.lat);
        return Number.isFinite(lon) && Number.isFinite(lat) ? [lon, lat] : null;
      }

      function stationById(id) {
        return stationPins.find(station => station.id === id || station.crs === id);
      }

      function airportById(id) {
        return airportPins.find(airport => airport.id === id);
      }

      function stationCoordinate(station) {
        return station ? [Number(station.lon), Number(station.lat)] : null;
      }

      function airportCoordinate(airport) {
        return airport ? [Number(airport.lon), Number(airport.lat)] : null;
      }

      function nearestStations(point, limit = 3) {
        if (!point) return [];
        return stationPins
          .map(station => {
            const distance = distanceKm(point, stationCoordinate(station));
            return { ...station, distanceKm: distance };
          })
          .filter(station => Number.isFinite(station.distanceKm))
          .sort((a, b) => a.distanceKm - b.distanceKm)
          .slice(0, limit);
      }

      function airportDriveMinutes(distance, airport) {
        if (!Number.isFinite(distance)) return 0;
        return Math.round((Number(airport?.driveBaseMins) || 20) + distance * 1.35);
      }

      function nearestAirports(point, limit = 3) {
        if (!point) return [];
        return airportPins
          .map(airport => {
            const distance = distanceKm(point, airportCoordinate(airport));
            return { ...airport, distanceKm: distance, driveMins: airportDriveMinutes(distance, airport) };
          })
          .filter(airport => Number.isFinite(airport.distanceKm))
          .sort((a, b) => a.driveMins - b.driveMins)
          .slice(0, limit);
      }

      function nearbyTransactionsForPoint(point, radiusKm = 2.5) {
        if (!point) return [];
        return transactions
          .map(item => ({ item, distance: distanceKm(point, transactionGeoPoint(item)) }))
          .filter(entry => Number.isFinite(entry.distance) && entry.distance <= radiusKm)
          .sort((a, b) => a.distance - b.distance || b.item.date.localeCompare(a.item.date))
          .map(entry => ({ ...entry.item, distanceFromSelection: entry.distance }));
      }

      function addressPointForTransaction(item) {
        const candidates = [
          item.id,
          addressKey(`${item.address}|${item.postcode}`),
          addressKey(`${item.address} ${item.postcode}`),
          addressKey(item.address)
        ].filter(Boolean);
        for (const key of candidates) {
          const point = addressPoints[key];
          if (!point) continue;
          const lon = Number(point.lon ?? point.longitude);
          const lat = Number(point.lat ?? point.latitude);
          if (!Number.isFinite(lon) || !Number.isFinite(lat)) continue;
          return [lon, lat, point.quality || point.source || "address geocode", "address"];
        }
        return null;
      }

      function postcodePointForTransaction(item) {
        const point = postcodePoints[normalisePostcode(item.postcode)];
        if (!point) return null;
        const lon = Number(point.lon ?? point.longitude);
        const lat = Number(point.lat ?? point.latitude);
        if (!Number.isFinite(lon) || !Number.isFinite(lat)) return null;
        return [lon, lat, point.uprnCount ? `postcode centroid (${point.uprnCount} UPRNs)` : "postcode centroid", "postcode"];
      }

      function transactionGeoPoint(item) {
        const cacheable = item && typeof item === "object";
        if (cacheable && transactionGeoPointCache.has(item)) return transactionGeoPointCache.get(item);
        const point = computeTransactionGeoPoint(item);
        if (cacheable) transactionGeoPointCache.set(item, point);
        return point;
      }

      function confirmedNhleGeoPoint(item) {
        const heritage = item?.historicEngland;
        const entries = Array.isArray(heritage?.entries) ? heritage.entries : [];
        const entry = entries.length === 1 ? entries[0] : null;
        if (
          heritage?.status !== "confirmed_listed" ||
          heritage?.source !== "Historic England NHLE" ||
          item?.coordinateSource !== "Historic England NHLE" ||
          item?.coordinatePrecision !== "confirmed-nhle-designation-location" ||
          !entry ||
          entry.matchMethod !== "reviewed_override" ||
          entry.matchConfidence !== "confirmed" ||
          !/^\d{7}$/.test(String(entry.listEntryNumber || "")) ||
          !["I", "II*", "II"].includes(entry.grade)
        ) return null;
        const lon = Number(item.longitude);
        const lat = Number(item.latitude);
        const centroidLon = Number(item?.geocode?.postcodeCentroidLongitude);
        const centroidLat = Number(item?.geocode?.postcodeCentroidLatitude);
        if (
          !Number.isFinite(lon) ||
          !Number.isFinite(lat) ||
          lon < -180 ||
          lon > 180 ||
          lat < -90 ||
          lat > 90 ||
          item?.geocode?.source !== "Postcodes.io" ||
          item?.geocode?.precision !== "Postcode centroid" ||
          !Number.isFinite(centroidLon) ||
          !Number.isFinite(centroidLat) ||
          centroidLon < -180 ||
          centroidLon > 180 ||
          centroidLat < -90 ||
          centroidLat > 90
        ) {
          return null;
        }
        const relatedRows = transactionRowsByProperty.get(propertyRecordKey(item)) || [item];
        const coordinatesAgree = relatedRows.every(row =>
          row?.coordinateSource === "Historic England NHLE" &&
          row?.coordinatePrecision === "confirmed-nhle-designation-location" &&
          Number(row.longitude) === lon &&
          Number(row.latitude) === lat &&
          Number(row?.geocode?.postcodeCentroidLongitude) === centroidLon &&
          Number(row?.geocode?.postcodeCentroidLatitude) === centroidLat &&
          row?.geocode?.source === "Postcodes.io" &&
          row?.geocode?.precision === "Postcode centroid"
        );
        if (!coordinatesAgree) return null;
        return [lon, lat, "Historic England NHLE", "designation"];
      }

      function preservedPostcodeCentroidGeoPoint(item) {
        const geocode = item?.geocode;
        const lon = geocode?.postcodeCentroidLongitude;
        const lat = geocode?.postcodeCentroidLatitude;
        if (
          geocode?.source !== "Postcodes.io" ||
          geocode?.precision !== "Postcode centroid" ||
          !Number.isFinite(lon) ||
          !Number.isFinite(lat) ||
          lon < -180 ||
          lon > 180 ||
          lat < -90 ||
          lat > 90
        ) return null;
        const spread = spreadPoint([lon, lat], item.id, .0018);
        return [spread[0], spread[1], "preserved postcode centroid", "approximate"];
      }

      function approximateTransactionGeoPoint(item) {
        const postcodePoint = postcodePointForTransaction(item);
        if (postcodePoint) {
          const spread = spreadPoint([postcodePoint[0], postcodePoint[1]], item.id, .0018);
          return [spread[0], spread[1], postcodePoint[2], "approximate"];
        }
        const estate = estateForTransaction(item);
        const estateAnchor = estate ? estateNavigationAnchors.find(anchor => anchor.key === estate.key) : null;
        if (estateAnchor) {
          const spread = spreadPoint([estateAnchor.lon, estateAnchor.lat], item.id, .006);
          return [spread[0], spread[1], "estate approximation", "approximate"];
        }
        const addressRule = addressRuleForTransaction(item);
        if (addressRule) {
          const spread = spreadPoint([addressRule.lon, addressRule.lat], item.id, .0035);
          return [spread[0], spread[1], "address-pattern approximation", "approximate"];
        }
        const town = townGeoPoints[townKey(item.town)];
        if (town) {
          const jitter = deterministicJitter(item.id, .012);
          return [town[0] + jitter[0], town[1] + jitter[1], "town approximation", "approximate"];
        }
        const market = marketById(item.market);
        const centroid = market ? districtGeoPoints[market.district] : null;
        if (centroid) {
          const jitter = deterministicJitter(item.id, .028);
          return [centroid[0] + jitter[0], centroid[1] + jitter[1], "market approximation", "approximate"];
        }
        return [-0.42, 51.28, "fallback approximation", "approximate"];
      }

      function computeTransactionGeoPoint(item) {
        const usesNhleCoordinate =
          item?.coordinateSource === "Historic England NHLE" ||
          item?.coordinatePrecision === "confirmed-nhle-designation-location";
        const nhlePoint = confirmedNhleGeoPoint(item);
        if (nhlePoint) return nhlePoint;
        if (usesNhleCoordinate) {
          const preservedCentroid = preservedPostcodeCentroidGeoPoint(item);
          if (preservedCentroid) return preservedCentroid;
          return approximateTransactionGeoPoint(item);
        }
        const addressPoint = addressPointForTransaction(item);
        if (addressPoint) return addressPoint;
        const lon = Number(item.longitude ?? item.lon ?? item.geocode?.longitude ?? item.location?.longitude);
        const lat = Number(item.latitude ?? item.lat ?? item.geocode?.latitude ?? item.location?.latitude);
        if (!usesNhleCoordinate && Number.isFinite(lon) && Number.isFinite(lat)) {
          const precision = normalise(item.coordinatePrecision || item.geocode?.precision || item.location?.precision);
          if (precision.includes("POSTCODE") || precision.includes("CENTROID")) {
            const spread = spreadPoint([lon, lat], item.id, .0018);
            return [spread[0], spread[1], "postcode centroid", "approximate"];
          }
          return [lon, lat, item.coordinateSource || item.geocode?.source || "enriched coordinate", "exact"];
        }
        return approximateTransactionGeoPoint(item);
      }

      function propertyValueUplift(item) {
        const sales = salesHistoryForTransaction(item)
          .filter(sale => Number(sale.price) > 0 && parseIso(String(sale.date || "").slice(0, 10)))
          .sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
        if (sales.length < 2) return null;
        const latestPrice = inflationAdjustedPrice(sales[0]);
        const priorPrice = inflationAdjustedPrice(sales[1]);
        return latestPrice > 0 && priorPrice > 0 ? latestPrice / priorPrice - 1 : null;
      }

      function saleAgeDays(item) {
        const saleDate = parseIso(String(item?.date || "").slice(0, 10));
        if (!saleDate || !analysisEnd) return -1;
        return Math.max(0, Math.round((analysisEnd - saleDate) / (24 * 60 * 60 * 1000)));
      }

      function saleRecencyLabel(days) {
        const value = Number(days);
        if (!Number.isFinite(value) || value < 0) return "Sale date unavailable";
        if (value <= 90) return "Sold within 90 days";
        if (value <= 365) return "Sold within 12 months";
        if (value <= 730) return "Sold 1–2 years ago";
        return "Sold over 2 years ago";
      }

      function propertyFeature(item) {
        const cacheable = item && typeof item === "object";
        if (cacheable && propertyFeatureCache.has(item)) return propertyFeatureCache.get(item);
        const point = transactionGeoPoint(item);
        const marketStatsForItem = marketStats[item.market] || overallStats;
        const planningCount = planningApplicationCount(item);
        const ppsf = Number(item.pricePerSqft || 0);
        const uplift = propertyValueUplift(item);
        const latestEpc = latestEpcSnapshot(item);
        const listedStatus = listedStatusSnapshot(item);
        const id = propertyId(item.id);
        const feature = {
          type: "Feature",
          id,
          properties: {
            id,
            address: item.address,
            road: propertyRoadName(item),
            postcode: item.postcode,
            town: item.town,
            market: item.market,
            district: item.district,
            price: item.price,
            priceText: item.priceText,
            date: item.date,
            propertyType: item.propertyType,
            estate: estateForTransaction(item)?.name || "",
            coordinateQuality: point[2],
            coordinateClass: point[3],
            pricePerSqft: ppsf,
            epcRating: latestEpc.rating,
            epcDate: latestEpc.date,
            saleAgeDays: saleAgeDays(item),
            valueUplift: uplift ?? 0,
            hasPriorSale: uplift !== null,
            listedStatusClass: listedStatusClass(listedStatus),
            listedStatus: listedStatus.status,
            listedGrade: listedStatus.status === "confirmed_listed"
              ? (["I", "II*", "II"].find(grade => listedStatus.entries.some(entry => entry.grade === grade)) || "")
              : "",
            listedEntryCount: listedStatus.status === "confirmed_listed" ? listedStatus.entries.length : 0,
            ppsfAvg: ppsf || marketStatsForItem.ppsfAvg,
            velocityScore: marketStatsForItem.velocityScore,
            planningCount,
            planningScore: planningCount,
            priceChange: marketStatsForItem.priceChange,
            avg: item.price
          },
          geometry: { type: "Point", coordinates: [point[0], point[1]] }
        };
        if (cacheable) propertyFeatureCache.set(item, feature);
        return feature;
      }

      function emptyFeatureCollection() {
        return { type: "FeatureCollection", features: [] };
      }

      function propertyGeoJson(rows = insightMapRows()) {
        return {
          type: "FeatureCollection",
          features: rows.map(propertyFeature)
        };
      }

      function insightMapRows() {
        const query = insightQuestion();
        if (!query) return transactions;
        const answer = currentInsightAnswer();
        if (answer?.preserveMap) return transactions;
        if (Array.isArray(answer?.mapRows)) return answer.mapRows;
        return Array.isArray(answer?.rows) ? answer.rows : transactions;
      }

      function updatePropertyMapSource() {
        if (!map) return;
        const rows = insightMapRows();
        const source = map.getSource("properties");
        if (source && appliedPropertyMapRows !== rows) {
          source.setData(propertyGeoJson(rows));
          appliedPropertyMapRows = rows;
        }
        updateSelectedPropertyHighlight(rows);
      }

      function selectedPropertyMapId(rows = insightMapRows()) {
        const item = selectedPropertyItem();
        return item && rows.some(row => propertyId(row.id) === propertyId(item.id))
          ? propertyId(item.id)
          : "";
      }

      function selectedPropertyGeoJson(rows = insightMapRows()) {
        const selectedId = selectedPropertyMapId(rows);
        const item = selectedId ? transactionsById.get(selectedId) : null;
        return item ? { type: "FeatureCollection", features: [propertyFeature(item)] } : emptyFeatureCollection();
      }

      function schoolGeoJson() {
        return {
          type: "FeatureCollection",
          features: schools.map(school => ({
            type: "Feature",
            id: schoolId(school),
            properties: {
              id: schoolId(school),
              urn: school.urn || "",
              name: school.name || "School",
              phase: school.phase || "",
              type: school.type || "",
              status: school.status || "",
              postcode: school.postcode || "",
              town: school.town || "",
              pupils: Number(school.pupils || 0),
              capacity: Number(school.capacity || 0),
              lowAge: school.lowAge || "",
              highAge: school.highAge || "",
              gender: school.gender || "",
              admissions: school.admissions || "",
              website: school.website || "",
              lastInspection: school.lastInspection || "",
              inspectorate: school.inspectorate || ""
            },
            geometry: { type: "Point", coordinates: [Number(school.lon), Number(school.lat)] }
          })).filter(feature => Number.isFinite(feature.geometry.coordinates[0]) && Number.isFinite(feature.geometry.coordinates[1]))
        };
      }

      function stationGeoJson() {
        return {
          type: "FeatureCollection",
          features: stationPins.map(station => ({
            type: "Feature",
            id: station.id,
            properties: {
              id: station.id,
              name: station.name,
              crs: station.crs,
              london: station.london,
              fastestMins: station.fastestMins,
              typicalMins: station.typicalMins,
              operator: station.operator
            },
            geometry: { type: "Point", coordinates: [station.lon, station.lat] }
          }))
        };
      }

      function airportGeoJson() {
        return {
          type: "FeatureCollection",
          features: airportPins.map(airport => ({
            type: "Feature",
            id: airport.id,
            properties: {
              id: airport.id,
              name: airport.name,
              type: airport.type,
              driveBaseMins: airport.driveBaseMins
            },
            geometry: { type: "Point", coordinates: [airport.lon, airport.lat] }
          }))
        };
      }

      function estateTransactions(pinOrKey) {
        const key = typeof pinOrKey === "string" ? pinOrKey : pinOrKey.key;
        return transactions.filter(item => estateForTransaction(item)?.key === key);
      }

      function estateActivityRows(pinOrKey) {
        const key = typeof pinOrKey === "string" ? pinOrKey : pinOrKey.key;
        return transactionRows.filter(item => String(item?.estateId || "") === key);
      }

      function estateCenter(pin) {
        return pin && Number.isFinite(Number(pin.lon)) && Number.isFinite(Number(pin.lat))
          ? [Number(pin.lon), Number(pin.lat)]
          : null;
      }

      function estateGeoJson() {
        return {
          type: "FeatureCollection",
          features: estateNavigationAnchors.map(pin => {
            const rows = estateTransactions(pin);
            const stats = statsForEstate(pin);
            const center = estateCenter(pin);
            return {
              type: "Feature",
              id: pin.key,
              properties: {
                id: pin.key,
                name: pin.name,
                market: pin.market,
                count: stats.count,
                avg: Math.round(stats.avg),
                recent: stats.recent,
                context24: stats.context24,
                velocity: Number(stats.velocity.toFixed(2)),
                velocityConfidence: Number(stats.velocityConfidence.toFixed(2)),
                acceleration: Number(stats.acceleration.toFixed(2)),
                accelerationConfidence: Number(stats.accelerationConfidence.toFixed(2)),
                paceScore: stats.paceScore,
                liquidityScore: stats.liquidityScore,
                marketHeatScore: stats.marketHeatScore,
                rankEligible: stats.rankEligible,
                signalRecent: stats.signalRecent,
                signalRatio: Number(stats.signalRatio.toFixed(2)),
                signalQualified: stats.signalQualified,
                velocityScore: stats.velocityScore,
                ppsfAvg: Math.round(stats.ppsfAvg),
                planningScore: stats.planningApplications,
                priceChange: Number(stats.priceChange.toFixed(3)),
                priceConfidence: Number(stats.priceConfidence.toFixed(2)),
                pricePairCount: stats.pricePairCount,
                priceParentPairCount: stats.priceParentPairCount,
                priceParentLabel: stats.priceParentLabel,
                priceMedianHoldYears: Number(stats.priceMedianHoldYears.toFixed(1)),
                priceSource: stats.priceSource
              },
              geometry: { type: "Point", coordinates: center }
            };
          }).filter(feature => Array.isArray(feature.geometry.coordinates))
        };
      }

      let map;
      let selectedEstatePointId = null;
      let appliedPropertyMapRows = null;
      let appliedSelectedPropertyMapId = null;
      window.INSIGHT_BOOT_STAGE = "map";

      function basemapPalette() {
        if (state.resolvedTheme === "dark") {
          return {
            background: "#111820",
            residential: "#182129",
            park: "#16261f",
            woodland: "#15231d",
            water: "#172b38",
            waterway: "#27495c",
            building: "#202a32",
            buildingOutline: "#2c3942",
            path: "#35414a",
            minorRoad: "#3b4650",
            roadCasing: "#171d23",
            majorRoad: "#59646d",
            motorway: "#6c7881",
            railway: "#65717a"
          };
        }
        return {
          background: "#f2f3f0",
          residential: "#eaeae6",
          park: "#e6e9e5",
          woodland: "#dce0dc",
          water: "#c2c8ca",
          waterway: "#bdc9cd",
          building: "#eaeae5",
          buildingOutline: "#dbdbda",
          path: "#e2e2df",
          minorRoad: "#ddddda",
          roadCasing: "#d5d5d3",
          majorRoad: "#ffffff",
          motorway: "#ffffff",
          railway: "#b8bdbc"
        };
      }

      function labelFreeBasemapStyle() {
        const colours = basemapPalette();
        const lineGeometry = ["match", ["geometry-type"], ["LineString", "MultiLineString"], true, false];
        return {
          version: 8,
          metadata: { "insight:basemap": "OpenFreeMap label-free internal style" },
          glyphs: "./fonts/{fontstack}/{range}.pbf",
          sources: {
            "openfreemap": {
              type: "vector",
              url: "https://tiles.openfreemap.org/planet",
              attribution: '<a href="https://openfreemap.org" target="_blank">OpenFreeMap</a> <a href="https://www.openmaptiles.org/" target="_blank">&copy; OpenMapTiles</a> Data from <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a>'
            }
          },
          layers: [
            { id: "insight-background", type: "background", paint: { "background-color": colours.background } },
            {
              id: "basemap-residential",
              type: "fill",
              source: "openfreemap",
              "source-layer": "landuse",
              filter: ["==", ["get", "class"], "residential"],
              paint: { "fill-color": colours.residential, "fill-opacity": .72 }
            },
            {
              id: "basemap-park",
              type: "fill",
              source: "openfreemap",
              "source-layer": "park",
              paint: { "fill-color": colours.park }
            },
            {
              id: "basemap-woodland",
              type: "fill",
              source: "openfreemap",
              "source-layer": "landcover",
              minzoom: 8,
              filter: ["==", ["get", "class"], "wood"],
              paint: { "fill-color": colours.woodland, "fill-opacity": ["interpolate", ["linear"], ["zoom"], 8, .35, 12, .9] }
            },
            {
              id: "basemap-water",
              type: "fill",
              source: "openfreemap",
              "source-layer": "water",
              filter: ["!=", ["get", "brunnel"], "tunnel"],
              paint: { "fill-color": colours.water, "fill-antialias": true }
            },
            {
              id: "basemap-waterway",
              type: "line",
              source: "openfreemap",
              "source-layer": "waterway",
              filter: lineGeometry,
              paint: { "line-color": colours.waterway, "line-width": ["interpolate", ["linear"], ["zoom"], 8, .45, 15, 1.4, 18, 2.2] }
            },
            {
              id: "basemap-buildings",
              type: "fill",
              source: "openfreemap",
              "source-layer": "building",
              minzoom: 12,
              paint: { "fill-color": colours.building, "fill-outline-color": colours.buildingOutline, "fill-antialias": true }
            },
            {
              id: "basemap-paths",
              type: "line",
              source: "openfreemap",
              "source-layer": "transportation",
              minzoom: 13,
              filter: ["all", lineGeometry, ["==", ["get", "class"], "path"]],
              layout: { "line-cap": "round", "line-join": "round" },
              paint: { "line-color": colours.path, "line-opacity": .9, "line-width": ["interpolate", ["exponential", 1.2], ["zoom"], 13, .7, 18, 4.5] }
            },
            {
              id: "basemap-minor-roads",
              type: "line",
              source: "openfreemap",
              "source-layer": "transportation",
              minzoom: 10,
              filter: ["all", lineGeometry, ["match", ["get", "class"], ["minor", "service", "track"], true, false]],
              layout: { "line-cap": "round", "line-join": "round" },
              paint: { "line-color": colours.minorRoad, "line-opacity": .95, "line-width": ["interpolate", ["exponential", 1.45], ["zoom"], 10, .55, 14, 1.7, 18, 8] }
            },
            {
              id: "basemap-major-road-casing",
              type: "line",
              source: "openfreemap",
              "source-layer": "transportation",
              minzoom: 7,
              filter: ["all", lineGeometry, ["match", ["get", "class"], ["primary", "secondary", "tertiary", "trunk"], true, false]],
              layout: { "line-cap": "round", "line-join": "round" },
              paint: { "line-color": colours.roadCasing, "line-width": ["interpolate", ["exponential", 1.3], ["zoom"], 7, 1.5, 11, 2.8, 15, 6, 18, 14] }
            },
            {
              id: "basemap-major-roads",
              type: "line",
              source: "openfreemap",
              "source-layer": "transportation",
              minzoom: 7,
              filter: ["all", lineGeometry, ["match", ["get", "class"], ["primary", "secondary", "tertiary", "trunk"], true, false]],
              layout: { "line-cap": "round", "line-join": "round" },
              paint: { "line-color": colours.majorRoad, "line-width": ["interpolate", ["exponential", 1.3], ["zoom"], 7, .85, 11, 1.8, 15, 4.2, 18, 11] }
            },
            {
              id: "basemap-motorway-casing",
              type: "line",
              source: "openfreemap",
              "source-layer": "transportation",
              minzoom: 6,
              filter: ["all", lineGeometry, ["==", ["get", "class"], "motorway"]],
              layout: { "line-cap": "round", "line-join": "round" },
              paint: { "line-color": colours.roadCasing, "line-width": ["interpolate", ["exponential", 1.35], ["zoom"], 6, 2.4, 10, 4.2, 14, 8, 18, 19] }
            },
            {
              id: "basemap-motorways",
              type: "line",
              source: "openfreemap",
              "source-layer": "transportation",
              minzoom: 6,
              filter: ["all", lineGeometry, ["==", ["get", "class"], "motorway"]],
              layout: { "line-cap": "round", "line-join": "round" },
              paint: { "line-color": colours.motorway, "line-width": ["interpolate", ["exponential", 1.35], ["zoom"], 6, 1.4, 10, 3, 14, 6.2, 18, 15.5] }
            },
            {
              id: "basemap-railways",
              type: "line",
              source: "openfreemap",
              "source-layer": "transportation",
              minzoom: 10,
              filter: ["all", lineGeometry, ["match", ["get", "class"], ["rail", "transit"], true, false]],
              paint: { "line-color": colours.railway, "line-opacity": .8, "line-dasharray": [2, 2], "line-width": ["interpolate", ["linear"], ["zoom"], 10, .55, 15, 1.3, 18, 2.2] }
            }
          ]
        };
      }

      function applyBasemapTheme() {
        if (!mapStyleReady()) return;
        const colours = basemapPalette();
        const updates = [
          ["insight-background", "background-color", colours.background],
          ["basemap-residential", "fill-color", colours.residential],
          ["basemap-park", "fill-color", colours.park],
          ["basemap-woodland", "fill-color", colours.woodland],
          ["basemap-water", "fill-color", colours.water],
          ["basemap-waterway", "line-color", colours.waterway],
          ["basemap-buildings", "fill-color", colours.building],
          ["basemap-buildings", "fill-outline-color", colours.buildingOutline],
          ["basemap-paths", "line-color", colours.path],
          ["basemap-minor-roads", "line-color", colours.minorRoad],
          ["basemap-major-road-casing", "line-color", colours.roadCasing],
          ["basemap-major-roads", "line-color", colours.majorRoad],
          ["basemap-motorway-casing", "line-color", colours.roadCasing],
          ["basemap-motorways", "line-color", colours.motorway],
          ["basemap-railways", "line-color", colours.railway]
        ];
        updates.forEach(([layer, property, value]) => {
          if (map.getLayer(layer)) map.setPaintProperty(layer, property, value);
        });
      }

      if (typeof maplibregl === "undefined") {
        document.getElementById("map").innerHTML = '<div class="empty">The bundled map engine could not load. Reopen INSIGHT or reinstall this release.</div>';
      } else {
        map = new maplibregl.Map({
          container: "map",
          style: labelFreeBasemapStyle(),
          center: [-0.43, 51.29],
          zoom: mapZoomFromDisplay(defaultZoomLevel),
          padding: overviewMapPadding,
          minZoom: zoomMin,
          maxZoom: zoomMax,
          maxBounds: [[-1.05, 50.98], [0.22, 51.56]],
          attributionControl: false
        });

        map.on("load", () => {
          addMapImages();
          addInsightSources();
          addInsightLayers();
          raiseSelectedPropertyLayers();
          bindMapEvents();
          applyLayerVisibility();
          applyThemeToMap();
          renderAll();
          map.once("idle", () => {
            window.INSIGHT_BOOT_STAGE = "ready";
          });
          map.triggerRepaint();
        });

        map.on("zoom", updateZoomUi);
        map.on("moveend", applyMapStateToMap);
      }
      window.INSIGHT_BOOT_STAGE = "analyst";

      function refreshMapImages() {
        if (!mapStyleReady()) return;
        ["estate-gate", "school-book", "station-rail", "airport-plane"].forEach(name => {
          if (map.hasImage(name)) map.removeImage(name);
        });
        addMapImages();
      }

      function addMapImages() {
        const size = 96;
        const stroke = state.resolvedTheme === "dark" ? "#7bbcff" : "#005f9f";
        const shadow = state.resolvedTheme === "dark" ? "rgba(0,0,0,.34)" : "rgba(15,23,42,.14)";

        function roundedRect(context, x, y, width, height, radius) {
          context.moveTo(x + radius, y);
          context.lineTo(x + width - radius, y);
          context.quadraticCurveTo(x + width, y, x + width, y + radius);
          context.lineTo(x + width, y + height - radius);
          context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
          context.lineTo(x + radius, y + height);
          context.quadraticCurveTo(x, y + height, x, y + height - radius);
          context.lineTo(x, y + radius);
          context.quadraticCurveTo(x, y, x + radius, y);
        }

        function markerCanvas() {
          const canvas = document.createElement("canvas");
          canvas.width = size;
          canvas.height = size;
          const context = canvas.getContext("2d");
          context.clearRect(0, 0, size, size);
          context.save();
          context.shadowColor = shadow;
          context.shadowBlur = 8;
          context.shadowOffsetY = 3;
          context.strokeStyle = stroke;
          context.lineWidth = 4;
          context.lineCap = "round";
          context.lineJoin = "round";
          context.beginPath();
          context.moveTo(48, 86);
          context.bezierCurveTo(44, 81, 23, 61, 23, 39);
          context.bezierCurveTo(23, 25, 34, 14, 48, 14);
          context.bezierCurveTo(62, 14, 73, 25, 73, 39);
          context.bezierCurveTo(73, 61, 52, 81, 48, 86);
          context.closePath();
          context.stroke();
          context.restore();
          context.strokeStyle = stroke;
          context.lineWidth = 3;
          context.lineCap = "round";
          context.lineJoin = "round";
          context.stroke();
          return context;
        }

        if (!map.hasImage("estate-gate")) {
          const context = markerCanvas();
          context.beginPath();
          context.moveTo(35, 43);
          context.lineTo(48, 31);
          context.lineTo(61, 43);
          context.lineTo(61, 57);
          context.lineTo(35, 57);
          context.closePath();
          context.moveTo(43, 57);
          context.lineTo(43, 47);
          context.lineTo(53, 47);
          context.lineTo(53, 57);
          context.stroke();
          map.addImage("estate-gate", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
        if (!map.hasImage("school-book")) {
          const context = markerCanvas();
          context.beginPath();
          context.moveTo(34, 39);
          context.lineTo(48, 33);
          context.lineTo(62, 39);
          context.lineTo(48, 45);
          context.closePath();
          context.moveTo(39, 43);
          context.lineTo(39, 51);
          context.quadraticCurveTo(48, 58, 57, 51);
          context.lineTo(57, 43);
          context.moveTo(62, 40);
          context.lineTo(62, 52);
          context.stroke();
          map.addImage("school-book", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
        if (!map.hasImage("station-rail")) {
          const context = markerCanvas();
          context.beginPath();
          roundedRect(context, 37, 28, 22, 29, 5);
          context.stroke();
          context.beginPath();
          context.moveTo(42, 36);
          context.lineTo(54, 36);
          context.moveTo(41, 46);
          context.lineTo(55, 46);
          context.stroke();
          context.fillStyle = stroke;
          context.beginPath();
          context.arc(42, 52, 2.2, 0, Math.PI * 2);
          context.arc(54, 52, 2.2, 0, Math.PI * 2);
          context.fill();
          context.strokeStyle = stroke;
          context.lineWidth = 2.3;
          context.beginPath();
          context.moveTo(42, 59);
          context.lineTo(38, 63);
          context.moveTo(54, 59);
          context.lineTo(58, 63);
          context.stroke();
          map.addImage("station-rail", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
        if (!map.hasImage("airport-plane")) {
          const context = markerCanvas();
          context.fillStyle = stroke;
          context.beginPath();
          context.moveTo(48, 27);
          context.bezierCurveTo(50, 27, 51, 29, 51, 31);
          context.lineTo(51, 41);
          context.lineTo(62, 48);
          context.lineTo(62, 52);
          context.lineTo(51, 49);
          context.lineTo(51, 56);
          context.lineTo(55, 59);
          context.lineTo(55, 62);
          context.lineTo(48, 60);
          context.lineTo(41, 62);
          context.lineTo(41, 59);
          context.lineTo(45, 56);
          context.lineTo(45, 49);
          context.lineTo(34, 52);
          context.lineTo(34, 48);
          context.lineTo(45, 41);
          context.lineTo(45, 31);
          context.bezierCurveTo(45, 29, 46, 27, 48, 27);
          context.closePath();
          context.fill();
          map.addImage("airport-plane", context.getImageData(0, 0, size, size), { pixelRatio: 2 });
        }
      }

      function addInsightSources() {
        const propertyRows = insightMapRows();
        map.addSource("county-outline", { type: "geojson", data: countyOutlineGeoJson(), tolerance: 0, buffer: 128, maxzoom: 18 });
        map.addSource("markets", { type: "geojson", data: marketGeoJson(), promoteId: "id", tolerance: 0, buffer: 256, maxzoom: 18 });
        map.addSource("properties", { type: "geojson", data: propertyGeoJson(propertyRows), promoteId: "id" });
        appliedPropertyMapRows = propertyRows;
        map.addSource("selected-property", { type: "geojson", data: selectedPropertyGeoJson(propertyRows), promoteId: "id" });
        appliedSelectedPropertyMapId = selectedPropertyMapId(propertyRows);
        map.addSource("estates", { type: "geojson", data: estateGeoJson(), promoteId: "id" });
        map.addSource("stations", { type: "geojson", data: stationGeoJson(), promoteId: "id" });
        map.addSource("airports", { type: "geojson", data: airportGeoJson(), promoteId: "id" });
        map.addSource("schools", { type: "geojson", data: schoolGeoJson(), promoteId: "id" });
      }

      function addInsightLayers() {
        map.addLayer({
          id: "county-outline",
          type: "line",
          source: "county-outline",
          paint: {
            "line-color": mapTextPaint().outline,
            "line-opacity": ["interpolate", ["linear"], ["zoom"], 7, .18, 12, .24, 17, .16],
            "line-width": ["interpolate", ["linear"], ["zoom"], 7, 1.1, 13, 1.7, 17, 1.2]
          }
        });
        map.addLayer({
          id: "market-fill",
          type: "fill",
          source: "markets",
          maxzoom: 13.6,
          paint: {
            "fill-color": colourExpression(state.renderMode),
            "fill-opacity": ["interpolate", ["linear"], ["zoom"], 7, .25, 10, .2, 11.6, .08, 13.2, 0]
          }
        });
        map.addLayer({
          id: "authority-heat-glow",
          type: "line",
          source: "markets",
          paint: {
            "line-color": colourExpression(state.renderMode),
            "line-opacity": ["interpolate", ["linear"], ["zoom"],
              7, ["case", ["boolean", ["feature-state", "hover"], false], .7, .32],
              11.6, ["case", ["boolean", ["feature-state", "hover"], false], .55, .24],
              14.5, ["case", ["boolean", ["feature-state", "hover"], false], .34, .12],
              16.5, 0],
            "line-width": ["interpolate", ["linear"], ["zoom"], 7, 3.6, 12, 4.6, 16, 2.4],
            "line-blur": 2
          }
        });
        map.addLayer({
          id: "market-outline",
          type: "line",
          source: "markets",
          paint: {
            "line-color": mapTextPaint().outline,
            "line-opacity": ["interpolate", ["linear"], ["zoom"], 7, .28, 12, .24, 15, .12],
            "line-width": ["interpolate", ["linear"], ["zoom"], 7, .65, 12, 1.1, 16, .65]
          }
        });
        map.addLayer({
          id: "property-points",
          type: "circle",
          source: "properties",
          minzoom: 10.4,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 10.4, 1, 11.4, 2.2, 14, 4.2, 17, 6.5],
            "circle-color": propertyColourExpression(),
            "circle-stroke-color": "#ffffff",
            "circle-stroke-width": ["interpolate", ["linear"], ["zoom"], 10.4, 0, 11.6, .8, 16, 1.5],
            "circle-opacity": propertyPointOpacityExpression()
          }
        });
        map.addLayer({
          id: "selected-property-core",
          type: "circle",
          source: "selected-property",
          minzoom: 10.4,
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 10.4, 3.2, 14, 5.2, 18, 8],
            "circle-color": propertyColourExpression(),
            "circle-stroke-color": "#ffffff",
            "circle-stroke-width": ["interpolate", ["linear"], ["zoom"], 10.4, 1.1, 16, 1.8],
            "circle-opacity": 1
          }
        });
        map.addLayer({
          id: "estate-points",
          type: "symbol",
          source: "estates",
          minzoom: 8.7,
          maxzoom: 15,
          layout: {
            "icon-image": "estate-gate",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 8.7, .8, 13, 1.16, 15, 1.36],
            "icon-allow-overlap": true,
            "icon-ignore-placement": true
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 8.7, .92, 14.4, .92, 15, 0]
          }
        });
        map.addLayer({
          id: "station-points",
          type: "symbol",
          source: "stations",
          minzoom: 11.2,
          layout: {
            "icon-image": "station-rail",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 11.2, .8, 13, 1.04, 16, 1.28],
            "icon-allow-overlap": false,
            "icon-ignore-placement": false
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 11.2, .78, 14, .94]
          }
        });
        map.addLayer({
          id: "station-labels",
          type: "symbol",
          source: "stations",
          minzoom: 12.8,
          layout: {
            "text-field": ["get", "name"],
            "text-font": ["Noto Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 12.8, 10, 16, 11.5],
            "text-offset": [0, 1.15],
            "text-anchor": "top",
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#172033",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.25,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 12.8, .62, 16, .92]
          }
        });
        map.addLayer({
          id: "airport-points",
          type: "symbol",
          source: "airports",
          minzoom: 8.8,
          layout: {
            "icon-image": "airport-plane",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 8.8, .76, 12, 1, 15, 1.24],
            "icon-allow-overlap": true,
            "icon-ignore-placement": true
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 8.8, .86, 14, .95]
          }
        });
        map.addLayer({
          id: "airport-labels",
          type: "symbol",
          source: "airports",
          minzoom: 9.6,
          layout: {
            "text-field": ["get", "name"],
            "text-font": ["Noto Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 9.6, 10, 15, 12],
            "text-offset": [0, 1.15],
            "text-anchor": "top",
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#172033",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.25,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 9.6, .72, 15, .92]
          }
        });
        map.addLayer({
          id: "school-points",
          type: "symbol",
          source: "schools",
          minzoom: 13,
          layout: {
            "icon-image": "school-book",
            "icon-size": ["interpolate", ["linear"], ["zoom"], 13, .84, 14.5, 1.04, 16, 1.24],
            "icon-allow-overlap": false,
            "icon-ignore-placement": false
          },
          paint: {
            "icon-opacity": ["interpolate", ["linear"], ["zoom"], 13, .9, 15, .96]
          }
        });
        map.addLayer({
          id: "school-labels",
          type: "symbol",
          source: "schools",
          minzoom: 14.2,
          layout: {
            "text-field": ["get", "name"],
            "text-font": ["Noto Sans Regular"],
            "text-size": ["interpolate", ["linear"], ["zoom"], 14.2, 10, 16, 11.5],
            "text-offset": [0, 1.15],
            "text-anchor": "top",
            "text-allow-overlap": false
          },
          paint: {
            "text-color": "#172033",
            "text-halo-color": "#ffffff",
            "text-halo-width": 1.25,
            "text-opacity": ["interpolate", ["linear"], ["zoom"], 14.2, .65, 16, .92]
          }
        });
      }

      function bindMapEvents() {
        const hoverLayers = ["selected-property-core", "property-points", "estate-points", "station-points", "airport-points", "school-points", "market-fill"];
        hoverLayers.forEach(layer => {
          map.on("mouseenter", layer, () => { map.getCanvas().style.cursor = "pointer"; });
          map.on("mouseleave", layer, () => { map.getCanvas().style.cursor = ""; });
        });
        map.on("mousemove", event => {
          const availableHoverLayers = hoverLayers.filter(layer => map.getLayer(layer));
          const features = map.queryRenderedFeatures(event.point, { layers: availableHoverLayers });
          const feature = features[0];
          if (!feature) {
            clearHoveredMapFeature();
            hideMapTooltip();
            return;
          }
          const glowFeature = features.find(item => hoverSourceForFeature(item));
          setHoveredMapFeature(glowFeature || feature);
          showMapTooltip(event.point, hoverContentForFeature(feature));
        });
        map.on("mouseout", () => {
          clearHoveredMapFeature();
          hideMapTooltip();
        });
        map.on("click", event => {
          closeToday({ render: false, restoreFocus: false });
          const features = map.queryRenderedFeatures(event.point, { layers: ["property-points", "station-points", "airport-points", "school-points", "estate-points", "market-fill"] });
          if (!features.length) {
            resetMap();
            return;
          }
          const feature = features[0];
          if (feature.layer.id === "property-points") selectProperty(feature.properties.id);
          if (feature.layer.id === "station-points") selectStation(feature.properties.id);
          if (feature.layer.id === "airport-points") selectAirport(feature.properties.id);
          if (feature.layer.id === "school-points") selectSchool(feature.properties.id);
          if (feature.layer.id === "estate-points") selectEstate(feature.properties.id);
          if (feature.layer.id === "market-fill") selectMarket(feature.properties.id);
        });
      }

      function hoverSourceForFeature(feature) {
        const layer = feature?.layer?.id || "";
        if (layer === "market-fill") return "markets";
        if (layer === "estate-points") return "estates";
        return "";
      }

      function clearHoveredMapFeature() {
        if (!state.hoveredFeature || !map) return;
        map.setFeatureState(state.hoveredFeature, { hover: false });
        state.hoveredFeature = null;
      }

      function setHoveredMapFeature(feature) {
        const source = hoverSourceForFeature(feature);
        const id = feature?.id ?? feature?.properties?.id;
        if (!source || id === undefined || id === null) {
          clearHoveredMapFeature();
          return;
        }
        const next = { source, id };
        if (state.hoveredFeature && state.hoveredFeature.source === source && String(state.hoveredFeature.id) === String(id)) return;
        clearHoveredMapFeature();
        state.hoveredFeature = next;
        map.setFeatureState(next, { hover: true });
      }

      function showMapTooltip(point, content) {
        if (!els.hoverTooltip || !content) {
          hideMapTooltip();
          return;
        }
        els.hoverTooltip.innerHTML = `<strong>${escapeHtml(content.title)}</strong>${content.subtitle ? `<small>${escapeHtml(content.subtitle)}</small>` : ""}<span>${escapeHtml(content.detail)}</span>${content.subdetail ? `<small>${escapeHtml(content.subdetail)}</small>` : ""}`;
        els.hoverTooltip.classList.add("visible");
        els.hoverTooltip.setAttribute("aria-hidden", "false");
        const bounds = map.getContainer().getBoundingClientRect();
        const x = Math.min(point.x + 14, Math.max(14, bounds.width - 236));
        const y = Math.min(Math.max(14, point.y + 14), Math.max(14, bounds.height - 96));
        els.hoverTooltip.style.transform = `translate(${x}px, ${y}px)`;
      }

      function hideMapTooltip() {
        if (!els.hoverTooltip) return;
        els.hoverTooltip.classList.remove("visible");
        els.hoverTooltip.setAttribute("aria-hidden", "true");
        els.hoverTooltip.style.transform = "translate(-999px, -999px)";
      }

      function currentRenderModeLabel() {
        return renderModeLabels[state.renderMode] || "Market heat";
      }

      function modeDetailForProperties(properties) {
        const mode = state.renderMode;
        if (mode === "value") return `Average ${compactPrice(properties.avg)}`;
        if (mode === "ppsf") return Number(properties.ppsfAvg) > 0 ? `${compactPpsf(properties.ppsfAvg)} average` : "Awaiting EPC";
        if (mode === "growth") return `${priceMovementLabel(properties)} · ${priceMovementEvidenceLabel(properties)}`;
        if (mode === "planning") return `${formatNumber(properties.planningScore || 0)} matched property applications`;
        return velocityDetailForProperties(properties);
      }

      function velocityDetailForProperties(properties) {
        const through = velocityAnalysisEnd ? ` · mature through ${formatDate(velocityAnalysisEnd.toISOString().slice(0, 10))}` : "";
        if (!(Number(properties?.count) > 0)) return `No qualifying sales · Insufficient evidence${through}`;
        return `${velocityLabel(properties)} · pace ${formatNumber(properties.paceScore || 0)}/100 (${Number(properties.velocity || 0).toFixed(2)}x) · liquidity ${formatNumber(properties.liquidityScore || 0)}/100 · ${formatCount(properties.recent, "mature sale")} in 12m · 120d ${accelerationLabel(properties)}${through}`;
      }

      function hoverContentForFeature(feature) {
        const props = feature.properties || {};
        const layer = feature.layer?.id || "";
        if (layer.includes("property")) {
          const title = String(props.address || "").split(",")[0].trim() || props.postcode || "Property";
          const subtitle = props.road || "";
          if (state.propertyRenderMode === "listed") {
            const listedLabels = {
              unlisted: "Unlisted",
              "grade-ii": "Grade II Listed",
              "grade-ii-star": "Grade II* Listed",
              "grade-i": "Grade I Listed"
            };
            const label = listedLabels[props.listedStatusClass] || "Listed status unavailable";
            const entries = Number(props.listedEntryCount || 0);
            return {
              title,
              subtitle,
              detail: props.listedStatusClass === "unlisted"
                ? label
                : `${label}${entries > 1 ? ` · ${formatNumber(entries)} NHLE entries` : ""}`,
              subdetail: props.listedStatusClass === "unlisted"
                ? "No direct NHLE match · not legal proof of unlisted status"
                : "Historic England NHLE"
            };
          }
          if (state.propertyRenderMode === "planning") {
            const count = Number(props.planningCount || 0);
            return { title, subtitle, detail: `${formatNumber(count)} matched planning ${count === 1 ? "application" : "applications"} on this property file` };
          }
          if (state.propertyRenderMode === "ppsf") {
            return { title, subtitle, detail: Number(props.pricePerSqft) > 0 ? compactPpsf(props.pricePerSqft) : "Price per sqft unavailable · awaiting EPC floor area" };
          }
          if (state.propertyRenderMode === "epc") {
            return {
              title,
              subtitle,
              detail: props.epcRating ? `EPC rating ${props.epcRating}` : "EPC rating unavailable",
              subdetail: props.epcRating && props.epcDate ? formatDate(props.epcDate) : ""
            };
          }
          if (state.propertyRenderMode === "recency") {
            return { title, subtitle, detail: `${saleRecencyLabel(props.saleAgeDays)}${props.date ? ` · ${formatDate(props.date)}` : ""}` };
          }
          if (state.propertyRenderMode === "uplift") {
            return { title, subtitle, detail: props.hasPriorSale ? `${signedPercent(Number(props.valueUplift), 1)} real uplift since prior sale` : "No prior sale loaded" };
          }
          const meta = [props.priceText, props.date ? formatDate(props.date) : "", props.pricePerSqft ? compactPpsf(props.pricePerSqft) : ""].filter(Boolean).join(" · ");
          return { title, subtitle, detail: meta || "Land Registry sale" };
        }
        if (layer === "estate-points") {
          return { title: props.name || "Private Estate", detail: `Market heat · ${velocityDetailForProperties(props)}` };
        }
        if (layer === "market-fill") {
          return { title: props.name || "Market", detail: `${currentRenderModeLabel()} · ${modeDetailForProperties(props)}` };
        }
        if (layer === "school-points") {
          return { title: props.name || "School", detail: [props.type, props.phase, props.postcode].filter(Boolean).join(" · ") || "School" };
        }
        if (layer === "station-points") {
          return { title: props.name || "Station", detail: `${props.london || "London"} · c. ${formatMinutes(props.fastestMins)} fastest` };
        }
        if (layer === "airport-points") {
          return { title: props.name || "Airport", detail: props.type || "Airport" };
        }
        return null;
      }

      function applyLayerVisibility() {
        if (!map) return;
        layerRegistry.forEach(group => {
          const visible = state.layers[group.id] ? "visible" : "none";
          group.layers.forEach(layerId => {
            if (map.getLayer(layerId)) map.setLayoutProperty(layerId, "visibility", visible);
          });
        });
      }

      function applyRenderMode() {
        if (!map) {
          renderLegend();
          return;
        }
        const expression = colourExpression(state.renderMode);
        if (map.getLayer("market-fill")) map.setPaintProperty("market-fill", "fill-color", expression);
        if (map.getLayer("authority-heat-glow")) map.setPaintProperty("authority-heat-glow", "line-color", expression);
        const propertyExpression = propertyColourExpression();
        if (map.getLayer("property-points")) map.setPaintProperty("property-points", "circle-color", propertyExpression);
        if (map.getLayer("selected-property-core")) map.setPaintProperty("selected-property-core", "circle-color", propertyExpression);
        const propertyFilter = state.propertyRenderMode === "listed"
          ? propertyListedFilterExpression()
          : null;
        if (map.getLayer("property-points")) map.setFilter("property-points", propertyFilter);
        if (map.getLayer("selected-property-core")) map.setFilter("selected-property-core", propertyFilter);
        applyPropertySelectionOpacity();
        renderLegend();
      }

      function applyPropertySelectionOpacity() {
        if (map.getLayer("property-points")) map.setPaintProperty("property-points", "circle-opacity", propertyPointOpacityExpression());
      }

      function updateSelectedPropertyHighlight(rows = insightMapRows()) {
        if (!map) return;
        const source = map.getSource("selected-property");
        const selectedId = selectedPropertyMapId(rows);
        if (source && appliedSelectedPropertyMapId !== selectedId) {
          source.setData(selectedPropertyGeoJson(rows));
          appliedSelectedPropertyMapId = selectedId;
        }
        raiseSelectedPropertyLayers();
      }

      function raiseSelectedPropertyLayers() {
        ["selected-property-core"].forEach(layer => {
          if (map.getLayer(layer)) map.moveLayer(layer);
        });
      }

      function insightQuestion() {
        return String(state.search || "").trim();
      }

      function outwardPostcode(value) {
        return normalisePostcode(value).replace(/\d[A-Z]{2}$/, "");
      }

      function floodEvidenceIsFresh(item) {
        const evidence = item?.environmentAgency || {};
        const declaredStatus = String(evidence.freshnessStatus || evidence.coverageStatus || "").toLowerCase();
        if (evidence.isFresh === false || ["stale", "unknown", "unavailable", "failed"].includes(declaredStatus)) return false;
        const observedAt = Date.parse(evidence.observedAt || evidence.checkedAt || evidence.updatedAt || "");
        const ageHours = (Date.now() - observedAt) / 3600000;
        return Number.isFinite(ageHours) && ageHours >= 0 && ageHours <= 30;
      }

      function floodStatusForDisplay(item) {
        const evidence = item?.environmentAgency || {};
        if (floodEvidenceIsFresh(item) && evidence.floodStatus) return evidence.floodStatus;
        const checkedAt = evidence.checkedAt || evidence.updatedAt;
        return checkedAt
          ? `Last alert check ${formatPlanningDate(checkedAt)} · current status unconfirmed`
          : "Current flood status unavailable";
      }

      function freshFloodAlertCount(item) {
        return floodEvidenceIsFresh(item) ? Number(item.environmentAgency?.currentFloodAlertCount || 0) : null;
      }

      function rowInsightText(item) {
        const estate = estateForTransaction(item);
        const schoolNames = (item.ofsted?.nearestSchools || []).map(school => school.name).join(" ");
        const planningText = (item.planning?.recentApplications || []).map(app => [app.description, app.reference, app.status, app.decision].join(" ")).join(" ");
        return normalise([
          item.address,
          item.postcode,
          outwardPostcode(item.postcode),
          item.town,
          item.district,
          marketById(item.market)?.short,
          marketById(item.market)?.name,
          estate?.name,
          item.propertyType,
          item.epcRating,
          floodStatusForDisplay(item),
          item.planning?.latestApplication,
          item.planning?.latestDecision,
          schoolNames,
          planningText
        ].filter(Boolean).join(" "));
      }

      function moneyToNumber(value, unit = "", assumeMillions = false) {
        const number = Number(value);
        if (!Number.isFinite(number)) return 0;
        const cleanUnit = normalise(unit);
        if (cleanUnit.includes("M") || cleanUnit.includes("MILLION")) return Math.round(number * 1000000);
        if (cleanUnit.includes("K")) return Math.round(number * 1000);
        if (number >= 1000000) return Math.round(number);
        if (assumeMillions && number < 100) return Math.round(number * 1000000);
        return Math.round(number);
      }

      function moneyValuesFromQuery(query, assumeMillions = false) {
        const values = [];
        const text = String(query || "");
        let match;
        const explicit = /£\s*(\d[\d,]*(?:\.\d+)?)\s*(m|mn|million|k)?|\b(\d[\d,]*(?:\.\d+)?)\s*(m|mn|million|k)\b/gi;
        while ((match = explicit.exec(text))) {
          const raw = String(match[1] || match[3]).replace(/,/g, "");
          const unit = match[2] || match[4] || "";
          const numeric = Number(raw);
          const explicitlyMoney = match[0].includes("£") || Boolean(unit);
          if (!explicitlyMoney && Number.isInteger(numeric) && numeric >= 1900 && numeric <= 2099) continue;
          const value = moneyToNumber(raw, unit, assumeMillions);
          if (value) values.push(value);
        }
        const large = /\b(\d{1,3}(?:,\d{3}){2,}|\d{7,})\b/g;
        while ((match = large.exec(text))) {
          const value = Number(match[1].replace(/,/g, ""));
          if (Number.isFinite(value)) values.push(value);
        }
        return Array.from(new Set(values)).sort((a, b) => a - b);
      }

      function ppsfValuesFromQuery(query) {
        const qn = normalise(query);
        if (!qn.includes("PSF") && !qn.includes("PER SQ") && !qn.includes("PRICE PER") && !(String(query).includes("£") && (qn.includes("SQFT") || qn.includes("SQ FT")))) return [];
        const values = [];
        let match;
        const pattern = /£?\s*(\d[\d,]{2,6})(?:\s*(?:\/|per)?\s*(?:sq\s*ft|sqft|square\s*foot|psf))/gi;
        while ((match = pattern.exec(query))) {
          const value = Number(match[1].replace(/,/g, ""));
          if (Number.isFinite(value)) values.push(value);
        }
        return Array.from(new Set(values)).sort((a, b) => a - b);
      }

      function sqftValuesFromQuery(query) {
        const values = [];
        let match;
        const pattern = /\b(\d[\d,]{2,7})\s*(?:sq\s*ft|sqft|square\s*feet)\b/gi;
        while ((match = pattern.exec(query))) {
          const value = Number(match[1].replace(/,/g, ""));
          if (Number.isFinite(value)) values.push(value);
        }
        return Array.from(new Set(values)).sort((a, b) => a - b);
      }

      function rangeFromValues(query, values) {
        const qn = normalise(query);
        if (!values.length) return null;
        if ((qn.includes("BETWEEN") || qn.includes("FROM")) && values.length >= 2) {
          return { min: values[0], max: values[values.length - 1] };
        }
        if (qn.includes("UNDER") || qn.includes("BELOW") || qn.includes("LESS THAN") || qn.includes("UP TO") || qn.includes("CHEAPER THAN")) {
          return { max: values[0] };
        }
        if (qn.includes("OVER") || qn.includes("ABOVE") || qn.includes("MORE THAN") || qn.includes("GREATER THAN") || qn.includes("PLUS") || query.includes("+")) {
          return { min: values[0] };
        }
        return values.length >= 2 ? { min: values[0], max: values[values.length - 1] } : { exact: values[0] };
      }

      function dateRangeFromQuery(query) {
        const qn = normalise(query);
        const years = Array.from(new Set((query.match(/\b(?:19[5-9]\d|20\d{2})\b/g) || []).map(Number))).sort((a, b) => a - b);
        const rolling = String(query || "").match(/\b(?:last|past|previous)\s+(\d{1,3})\s*(months?|years?)\b/i);
        if (rolling) {
          const count = Number(rolling[1]);
          const months = /^year/i.test(rolling[2]) ? count * 12 : count;
          return { from: addMonths(analysisEnd, -months), to: analysisEnd, label: `last ${count} ${rolling[2].toLowerCase()}` };
        }
        if (qn.includes("LAST 12") || qn.includes("PAST 12") || qn.includes("PAST YEAR") || qn.includes("LAST YEAR")) {
          return { from: addMonths(analysisEnd, -12), to: analysisEnd, label: "last 12 months" };
        }
        if (!years.length) return null;
        if (years.length >= 2 && (qn.includes("BETWEEN") || qn.includes("FROM") || /\b(?:19[5-9]\d|20\d{2})\s*(?:TO|-|–)\s*(?:19[5-9]\d|20\d{2})\b/i.test(query))) {
          return { from: parseIso(`${years[0]}-01-01`), to: parseIso(`${years[years.length - 1]}-12-31`), label: `${years[0]}-${years[years.length - 1]}` };
        }
        const year = years[0];
        if (qn.includes("SINCE") || qn.includes("AFTER") || qn.includes("FROM")) {
          return { from: parseIso(`${year}-01-01`), to: analysisEnd, label: `since ${year}` };
        }
        if (qn.includes("BEFORE") || qn.includes("PRIOR TO") || qn.includes("OLDER THAN")) {
          return { from: analysisStart, to: parseIso(`${year}-01-01`), label: `before ${year}` };
        }
        return { from: parseIso(`${year}-01-01`), to: parseIso(`${year}-12-31`), label: String(year) };
      }

      function propertyTypeFromQuery(query) {
        const qn = normalise(query);
        if (qn.includes("APARTMENT") || qn.includes("APARTMENTS") || qn.includes("FLAT") || qn.includes("FLATS")) return { label: "apartments", test: item => normalise(item.propertyType).includes("FLAT") || normalise(item.propertyType).includes("APARTMENT") };
        if (qn.includes("SEMI")) return { label: "semi-detached", test: item => normalise(item.propertyType).includes("SEMI") };
        if (qn.includes("DETACHED") || qn.includes("DETATCHED")) return { label: "detached", test: item => normalise(item.propertyType).includes("DETACHED") && !normalise(item.propertyType).includes("SEMI") };
        if (qn.includes("TERRACE") || qn.includes("TERRACED")) return { label: "terraced", test: item => normalise(item.propertyType).includes("TERRACE") };
        return null;
      }

      const insightQueryStopWords = new Set(normalise("a an and are as at be by can could did do does for from give has have how i in is it me most of on only or please properties property sale sales show than that the their there these this to was were what when where which who with would you").split(" "));

      function insightQueryTokens(value) {
        return normalise(value).split(" ").filter(token => token.length > 1 && !insightQueryStopWords.has(token));
      }

      function editDistance(left, right) {
        const a = normalise(left).replace(/\s+/g, "");
        const b = normalise(right).replace(/\s+/g, "");
        if (!a) return b.length;
        if (!b) return a.length;
        const row = Array.from({ length: b.length + 1 }, (_, index) => index);
        for (let i = 1; i <= a.length; i += 1) {
          let previous = row[0];
          row[0] = i;
          for (let j = 1; j <= b.length; j += 1) {
            const current = row[j];
            row[j] = Math.min(row[j] + 1, row[j - 1] + 1, previous + (a[i - 1] === b[j - 1] ? 0 : 1));
            previous = current;
          }
        }
        return row[b.length];
      }

      function fuzzyEntityMention(query, candidate) {
        const qn = normalise(query);
        const name = normalise(candidate);
        if (!name || name.length < 4) return false;
        if (qn.includes(name)) return true;
        const queryTokens = qn.split(" ").filter(Boolean);
        const nameTokens = name.split(" ").filter(token => token.length > 2);
        if (!nameTokens.length) return false;
        return nameTokens.every(nameToken => queryTokens.some(queryToken => {
          if (queryToken.length < 4 || Math.abs(queryToken.length - nameToken.length) > 2) return false;
          return editDistance(queryToken, nameToken) <= Math.max(1, Math.floor(nameToken.length / 7));
        }));
      }

      function distanceRadiusKmFromQuery(query, fallback) {
        const match = String(query || "").match(/\b(?:within|inside|under|less than)?\s*(\d+(?:\.\d+)?)\s*(km|kilomet(?:er|re)s?|mi|mile|miles)\b/i);
        if (!match) return fallback;
        const value = Number(match[1]);
        return /^(mi|mile)/i.test(match[2]) ? value * 1.609344 : value;
      }

      function topCountFromQuery(query, fallback = 8) {
        const match = normalise(query).match(/\b(?:TOP|BOTTOM|FIRST|BEST|WORST)\s+(\d{1,2})\b/);
        return match ? clamp(1, 20, Number(match[1])) : fallback;
      }

      function minimumSampleFromQuery(query, fallback = 0) {
        const match = String(query || "").match(/\b(?:at least|minimum|min\.?|requiring)\s+(\d{1,3})\b/i);
        return match ? Number(match[1]) : fallback;
      }

      function ppsfRequested(query) {
        const qn = normalise(query);
        return qn.includes("PSF") || qn.includes("PER SQ") || qn.includes("PRICE PER") || ((String(query).includes("£") || qn.includes("POUND")) && (qn.includes("SQFT") || qn.includes("SQ FT") || qn.includes("SQUARE FOOT")));
      }

      function insightIntent(query) {
        const qn = normalise(query);
        if (qn.includes("VELOCITY") || qn.includes("PACE") || qn.includes("FASTEST SELLING") || qn.includes("MOST ACTIVE")) return "velocity";
        if (qn.includes("GROWTH") || qn.includes("PRICE MOVEMENT") || qn.includes("APPRECIAT") || qn.includes("RISEN") || qn.includes("FALLEN")) return "growth";
        if (ppsfRequested(query)) return "ppsf";
        if (qn.includes("PLANNING")) return "planning";
        if (qn.includes("FLOOD")) return "flood";
        if (qn.includes("FLOOR AREA") || qn.includes("SQFT") || qn.includes("SQ FT") || qn.includes("SIZE")) return "size";
        if (qn.includes("EPC") || qn.includes("ENERGY")) return "epc";
        if (qn.includes("COUNT") || qn.includes("HOW MANY") || qn.includes("NUMBER OF") || qn.includes("VOLUME")) return "count";
        if (qn.includes("LATEST") || qn.includes("NEWEST") || qn.includes("RECENT")) return "latest";
        return "price";
      }

      function comparisonRequested(query, locations) {
        const qn = normalise(query);
        return locations.length >= 2 && ["COMPARE", "VERSUS", " VS ", "DIFFERENCE", "BETTER", "WHICH", "BETWEEN"].some(term => (` ${qn} `).includes(term));
      }

      function trendRequested(query) {
        const qn = normalise(query);
        if (rankingRequested(query)) return false;
        return ["TREND", "OVER TIME", "BY YEAR", "YEAR BY YEAR", "YEAR ON YEAR", "BY QUARTER", "QUARTERLY", "BY MONTH", "MONTHLY", "ANNUAL", "TIME SERIES", "HISTORY", "HISTORICAL", "CHANGED", "CHANGE SINCE"].some(term => qn.includes(term));
      }

      function distributionRequested(query) {
        const qn = normalise(query);
        return ["BREAKDOWN", "DISTRIBUTION", "MIX", "PROPORTION", "PERCENTAGE", "SHARE"].some(term => qn.includes(term));
      }

      function repeatSalesRequested(query) {
        const qn = normalise(query);
        return ["SOLD MORE THAN ONCE", "REPEAT SALE", "REPEAT SALES", "RESOLD", "SOLD AGAIN", "SALES HISTORY"].some(term => qn.includes(term));
      }

      function capabilityRequested(query) {
        const qn = normalise(query);
        return qn === "HELP" || qn.includes("WHAT CAN YOU DO") || qn.includes("WHAT CAN ASK INSIGHT DO") || qn.includes("WHAT CAN INSIGHT DO") || qn.includes("WHAT CAN I ASK") || qn.includes("EXAMPLE QUESTIONS");
      }

      function coverageRequested(query) {
        const qn = normalise(query);
        return ["DATA COVERAGE", "DATABASE COVERAGE", "DATA QUALITY", "HOW COMPLETE", "MISSING DATA", "COVERAGE", "EXACT COORDINATE", "ADDRESS LEVEL COORDINATE"].some(term => qn.includes(term));
      }

      function comparableRequested(query) {
        const qn = normalise(query);
        if (["COMPARABLE", "COMPARABLES", "COMPS", "SIMILAR SALES", "WHAT IS IT WORTH", "WHAT S IT WORTH", "WHAT IS THIS WORTH"].some(term => qn.includes(term))) return true;
        if (!["VALUE RANGE", "VALUATION"].some(term => qn.includes(term))) return false;
        const hasPropertyReference = ["PROPERTY", "HOUSE", "HOME", "ADDRESS", "SELECTED", "THIS"].some(term => queryContainsTerm(query, term)) || /\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})\b/i.test(query);
        return hasPropertyReference || fuzzyPropertyRows(transactions, query).length > 0 || state.selectedType === "property" && !resolvedInsightLocations(query).length;
      }

      function outlierRequested(query) {
        const qn = normalise(query);
        return ["UNDERVALUED", "OVERVALUED", "OUTLIER", "ANOMAL", "VALUE SIGNAL", "RELATIVE VALUE", "INEXPENSIVE", "DISCOUNT", "OPPORTUNIT"].some(term => qn.includes(term));
      }

      function relationshipRequested(query) {
        const qn = normalise(query);
        return ["CORRELATION", "RELATIONSHIP", "PREMIUM", "IMPACT OF", "EFFECT OF", "AFFECT", "ASSOCIATED WITH", "RELATE TO", "RELATED TO", "CHEAPER PER", "MORE EXPENSIVE PER"].some(term => qn.includes(term));
      }

      function briefingRequested(query) {
        const qn = normalise(query);
        return ["DEEP DIVE", "MARKET REPORT", "VALUATION REPORT", "EXECUTIVE", "ASSESSMENT", "ASSESS ", "ANALYSE", "ANALYZE", "BRIEF", "OUTLOOK", "INVESTMENT COMMITTEE", "TELL ME ABOUT", "OVERVIEW OF", "FULL REPORT", "CLIENT NOTE"].some(term => qn.includes(term)) || qn.includes("SUMMAR") && explicitAnalysisTopics(query).length >= 2;
      }

      function explicitAnalysisTopics(query) {
        const qn = normalise(query);
        const topics = [];
        const add = (id, label, terms) => {
          if (terms.some(term => qn.includes(term))) topics.push({ id, label });
        };
        add("price", "Price", ["PRICE", "VALUE", "MEDIAN", "AVERAGE"]);
        add("velocity", "Activity", ["VELOCITY", "PACE", "ACTIVITY"]);
        add("epc", "EPC", ["EPC", "ENERGY", "FLOOR AREA", "SQFT", "SQ FT"]);
        add("planning", "Planning", ["PLANNING", "APPLICATION"]);
        add("flood", "Flood", ["FLOOD"]);
        add("transport", "Transport", ["TRANSPORT", "STATION", "TRAIN", "COMMUTE", "AIRPORT"]);
        add("schools", "Schools", ["SCHOOL", "EDUCATION"]);
        return topics;
      }

      function compositeAnalysisRequested(query) {
        return explicitAnalysisTopics(query).length >= 2 && normalise(query).includes("AND");
      }

      function rankingRequested(query) {
        const qn = normalise(query);
        return ["TOP ", "BOTTOM ", "RANK", "RANKING", "WHICH AREA", "WHICH ESTATE", "WHICH PRIVATE ESTATE", "WHICH MARKET", "WHICH LOCAL AUTHORIT", "WHICH AUTHORIT", "WHICH TOWN", "BEST ", "WORST ", "HIGHEST ", "LOWEST ", "STRONGEST ", "WEAKEST ", "MOST ACTIVE", "MOST PLANNING", "LEAST ACTIVE", "BY AREA", "BY ESTATE", "BY MARKET", "BY TOWN", "BY POSTCODE"].some(term => qn.includes(term));
      }

      function followUpRequested(query) {
        const qn = normalise(query);
        return ["WHAT ABOUT", "HOW ABOUT", "AND WHAT", "AND FOR", "SAME FOR", "INSTEAD", "DETACHED ONLY", "SEMI DETACHED ONLY", "TERRACED ONLY", "APARTMENTS ONLY"].some(term => qn.includes(term)) || /^AND\b/.test(qn);
      }

      function queryContainsTerm(query, term) {
        const padded = ` ${normalise(query)} `;
        return padded.includes(` ${normalise(term)} `);
      }

      function stripInsightLocationTerms(query) {
        let text = String(query || "");
        const names = [
          ...estatePins.flatMap(pin => [pin.name, pin.key, ...(pin.aliases || [])]),
          ...marketDefinitions.flatMap(market => [market.short, market.name, market.district]),
          ...transactions.map(item => item.town).filter(Boolean),
          ...stationPins.flatMap(station => [station.name, station.crs]),
          ...airportPins.flatMap(airport => [airport.name, airport.id])
        ].filter(Boolean).sort((a, b) => b.length - a.length);
        names.forEach(name => {
          const escaped = String(name).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          text = text.replace(new RegExp(`\\b${escaped.replace(/\\\s+/g, "\\s+")}\\b`, "ig"), " ");
        });
        return text.replace(/\s+/g, " ").trim();
      }

      function effectiveInsightQuery(query) {
        const previous = state.insightContext?.query;
        if (!previous || normalise(previous) === normalise(query) || !followUpRequested(query)) return query;
        let inherited = previous;
        if (insightLocationFilters(query).length) inherited = stripInsightLocationTerms(inherited);
        if (propertyTypeFromQuery(query)) inherited = inherited.replace(/\b(?:detatched|detached|semi(?:-detached)?|terraced?|apartments?|flats?)\b/gi, " ");
        if (dateRangeFromQuery(query)) inherited = inherited.replace(/\b(?:last|past|since|before|after|from|between)?\s*(?:12|24|36)?\s*(?:months?|years?)?\s*20\d{2}\b/gi, " ");
        return `${inherited} ${query}`.replace(/\s+/g, " ").trim();
      }

      function insightLocationFilters(query) {
        const qn = normalise(query);
        const filters = [];
        const add = (kind, label, test) => {
          if (!filters.some(filter => filter.kind === kind && filter.label === label)) filters.push({ kind, label, test });
        };
        estatePins.forEach(pin => {
          const names = [pin.name, pin.key, ...(pin.aliases || [])].map(normalise).filter(value => value.length > 3);
          if (names.some(name => qn.includes(name)) || fuzzyEntityMention(query, pin.name) || fuzzyEntityMention(query, pin.key)) add("estate", pin.name, item => estateForTransaction(item)?.key === pin.key);
        });
        marketDefinitions.forEach(market => {
          const names = [market.short, market.name, market.district].map(normalise).filter(value => value.length > 3);
          if (names.some(name => qn.includes(name)) || fuzzyEntityMention(query, market.short)) add("market", market.short, item => item.market === market.id || item.district === market.district);
        });
        Array.from(new Set(transactions.map(item => item.town).filter(Boolean))).forEach(town => {
          const name = normalise(town);
          if (name.length > 3 && (qn.includes(name) || fuzzyEntityMention(query, town))) add("town", townDisplayName(townKey(town)), item => townKey(item.town) === townKey(town));
        });
        const postcodeMatches = query.match(/\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})?\b/gi) || [];
        postcodeMatches.forEach(postcode => {
          const clean = normalisePostcode(postcode);
          if (clean.length >= 3) add("postcode", postcode.toUpperCase(), item => normalisePostcode(item.postcode).startsWith(clean) || outwardPostcode(item.postcode) === clean);
        });
        const wantsStation = ["STATION", "TRAIN", "RAIL", "COMMUTE", "NEAR", "WITHIN"].some(term => qn.includes(term));
        stationPins.forEach(station => {
          const names = [station.name, station.crs].map(normalise).filter(value => value.length > 2);
          const exactCode = normalise(query) === normalise(station.crs);
          if ((wantsStation || exactCode) && names.some(name => qn.includes(name))) {
            const point = stationCoordinate(station);
            const radiusKm = distanceRadiusKmFromQuery(query, 3);
            add("station", `${station.name} (${formatDistanceKm(radiusKm)})`, item => distanceKm(transactionGeoPoint(item), point) <= radiusKm);
          }
        });
        airportPins.forEach(airport => {
          const names = [airport.name, airport.id].map(normalise).filter(value => value.length > 2);
          if (names.some(name => qn.includes(name))) {
            const point = airportCoordinate(airport);
            const radiusKm = distanceRadiusKmFromQuery(query, 18);
            add("airport", `${airport.name} (${formatDistanceKm(radiusKm)})`, item => distanceKm(transactionGeoPoint(item), point) <= radiusKm);
          }
        });
        schools.forEach(school => {
          const name = normalise(school.name);
          if (name.length > 5 && qn.includes(name)) {
            const point = schoolCoordinate(school);
            const radiusKm = distanceRadiusKmFromQuery(query, 2.5);
            add("school", `${school.name} (${formatDistanceKm(radiusKm)})`, item => distanceKm(transactionGeoPoint(item), point) <= radiusKm);
          }
        });
        return filters;
      }

      function resolvedInsightLocations(query) {
        const qn = normalise(query);
        let locations = insightLocationFilters(query);
        const locationKindWanted = qn.includes("AUTHORITY") || qn.includes("COUNCIL") || qn.includes("BOROUGH") || qn.includes("DISTRICT") || qn.includes("MARKET")
          ? "market"
          : qn.includes("TOWN") ? "town" : "";
        const ambiguousLabels = new Set(locations.filter(location => locations.some(other => other.kind !== location.kind && normalise(other.label) === normalise(location.label))).map(location => normalise(location.label)));
        if (ambiguousLabels.size) {
          locations = locations.filter(location => {
            if (!ambiguousLabels.has(normalise(location.label))) return true;
            if (locationKindWanted) return location.kind === locationKindWanted;
            // A bare place name in a property question normally means the town,
            // while explicit authority/market wording selects the wider district.
            return location.kind === "town";
          });
        }
        return locations;
      }

      function insightLocationScopeLabel(locations, comparison = false) {
        if (!locations.length) return "";
        if (comparison) return locations.map(location => location.label).join(" or ");
        const byKind = new Map();
        locations.forEach(location => {
          if (!byKind.has(location.kind)) byKind.set(location.kind, []);
          byKind.get(location.kind).push(location.label);
        });
        return Array.from(byKind.values(), labels => labels.join(" or ")).join(" and ");
      }

      function filterRowsByInsightLocations(rows, locations, useAlternatives = false) {
        if (!locations.length) return rows;
        if (useAlternatives) return rows.filter(item => locations.some(location => location.test(item)));
        const groups = new Map();
        locations.forEach(location => {
          if (!groups.has(location.kind)) groups.set(location.kind, []);
          groups.get(location.kind).push(location);
        });
        return rows.filter(item => Array.from(groups.values()).every(group => group.some(location => location.test(item))));
      }

      function guardrailResponse(query, allowFollowUp = true) {
        const qn = normalise(query);
        const domainSignals = ["PROPERTY", "PROPERTIES", "HOUSE", "HOUSES", "HOME", "HOMES", "SALE", "SALES", "PRICE", "PRICES", "VALUE", "VALUES", "MARKET", "MARKETS", "ESTATE", "ESTATES", "VELOCITY", "ACTIVITY", "SIGNAL", "SIGNALS", "EVIDENCE", "DATABASE", "COVERAGE", "LAND REGISTRY", "EPC", "PLANNING", "FLOOD", "FLOODING", "SCHOOL", "STATION", "AIRPORT", "POSTCODE", "SURREY", "INSIGHT", "COMPARABLE", "COMPARABLES", "COMPS", "VALUATION", "OUTLIER", "CORRELATION", "RELATIVE VALUE", "DETACHED", "TERRACED", "APARTMENT", "APARTMENTS", "SQFT", "SQ FT"];
        const namedLocation = resolvedInsightLocations(query).length > 0;
        const postcodeOrAddress = /\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})?\b/i.test(query) || fuzzyPropertyRows(transactions, query).length > 0;
        const activeFollowUp = allowFollowUp && Boolean(state.insightContext?.query) && followUpRequested(query);
        const isDomainQuestion = namedLocation || postcodeOrAddress || activeFollowUp || domainSignals.some(term => queryContainsTerm(query, term));
        const unrelated = ["POEM", "RECIPE", "WEATHER", "FOOTBALL", "STOCK MARKET", "TRANSLATE", "CODING", "JAVASCRIPT", "MEDICAL ADVICE", "LEGAL ADVICE", "HOLIDAY ITINERARY", "CAPITAL OF"].some(term => qn.includes(term));
        const genericWriting = ["WRITE AN EMAIL", "DRAFT AN EMAIL", "WRITE A LETTER", "DRAFT A LETTER"].some(term => qn.includes(term));
        const outside = unrelated || !isDomainQuestion || (genericWriting && !isDomainQuestion);
        if (!outside) return null;
        return {
          title: "Ask INSIGHT",
          subtitle: "Dataset only",
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: textSection("Answer", "That falls outside Ask INSIGHT's property-intelligence role, or I could not connect it reliably to the loaded evidence. I can analyse or write from INSIGHT property, Land Registry, EPC, planning, school, station, airport and flood data.")
        };
      }

      function unavailableDataResponse(query) {
        const qn = normalise(query);
        const constrained = (subtitle, answer) => ({
          title: "Ask INSIGHT",
          subtitle,
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: insightLead(answer) + insightCaveat(insightUniverseBoundary())
        });
        if (["BEST SCHOOL", "SCHOOL IS BEST", "WHICH SCHOOL", "SCHOOL QUALITY", "TOP SCHOOL", "CATCHMENT"].some(term => qn.includes(term))) {
          return constrained("School evidence boundary", "INSIGHT can compare school proximity, phase, type, age range and supplied capacity. It cannot rank the ‘best’ schools or infer catchments or performance from the currently loaded evidence.");
        }
        if ((qn.includes("SAFEST") || qn.includes("LOWEST RISK")) && qn.includes("FLOOD")) {
          return constrained("Flood evidence boundary", "INSIGHT has time-stamped flood-alert context only where the freshness gate passes, not a complete long-term property flood-risk model. It cannot defensibly rank the safest area from that evidence alone.");
        }
        if (["NEXT YEAR", "FORECAST", "PREDICT", "WILL RISE", "WILL FALL"].some(term => qn.includes(term))) {
          return constrained("Forecast boundary", "INSIGHT can report current transaction pace, repeat-sale movement and transparent scenarios. It will not present an unsupported future price forecast as fact.");
        }
        if (["SHOULD I BUY", "SHOULD WE BUY", "FINANCIAL ADVICE"].some(term => qn.includes(term))) {
          return constrained("Decision support only", "INSIGHT can assemble property evidence, comparables, risks and uncertainties, but it cannot make a personal purchase decision or provide financial advice.");
        }
        if (qn.includes("CRIME")) return constrained("Crime data not loaded", "INSIGHT does not currently contain a verified crime dataset for this cohort. It will not use the location alone as a substitute or imply that transaction evidence answers a crime question.");
        if ((qn.includes("INTEREST RATE") || qn.includes("INFLATION")) && (qn.includes("WILL") || qn.includes("FORECAST") || qn.includes("PRICES"))) return constrained("Macro scenario boundary", "INSIGHT can show the market's recorded transaction pace and price evidence, but it does not contain a forward macroeconomic model. Any interest-rate or inflation scenario must be supplied explicitly and shown as a scenario, not a forecast.");
        if (qn.includes("GUARANTEE") || qn.includes("MOST LIKELY TO SELL") || qn.includes("LIKELY TO SELL NEXT")) return constrained("Unsupported prediction", "The loaded evidence cannot guarantee a future value or predict an individual owner's intention to sell. INSIGHT will not turn historical records into a personal-behaviour claim.");
        if (qn.includes("DISTANCE FROM LONDON")) return constrained("Reference definition required", "INSIGHT has mapped stations, journey context and property coordinates, but no single defensible 'distance from London' variable. Specify a London destination and travel or straight-line measure before testing this relationship.");
        if (qn.includes("STRONGEST RELATIONSHIP") || qn.includes("WHICH AVAILABLE VARIABLE")) return constrained("Model boundary", "INSIGHT can test named pairwise relationships with transparent cohorts. It does not yet run a controlled multivariate model, so it will not name a 'strongest variable' from incomparable pairwise tests.");
        if (qn.includes("FLOOD") && relationshipRequested(query)) return constrained("Flood relationship boundary", "The loaded flood layer is current-alert context rather than a complete long-term risk measure. It is not suitable for estimating a defensible relationship between flood risk and sale value.");
        if (qn.includes("CROWN ESTATE")) return constrained("Estate classification unavailable", "Crown Estate, Oxshott is not installed as a verified private-estate cohort in the current analytical dataset. INSIGHT will not silently substitute Oxshott or another estate for it.");
        if (qn.includes("OXSHOTT") && qn.includes("WEYBRIDGE") && qn.includes("COMPARE") && !qn.includes("STATION")) return constrained("Comparison cohort unavailable", "INSIGHT cannot complete this comparison because Oxshott is not installed as a standalone town cohort in the current analytical dataset. A Weybridge-only result will not be presented as a two-area comparison.");
        const missing = ["OWNER", "OWNS", "OWNERSHIP", "COMPANY", "COMPANIES HOUSE", "TITLE NUMBER", "FREEHOLD", "LEASEHOLD", "COVENANT", "MORTGAGE", "CHARGE"].filter(term => qn.includes(term));
        if (!missing.length) return null;
        return {
          title: "Ask INSIGHT",
          subtitle: "Not in loaded data",
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: textSection("Answer", "That field is not present in the currently loaded INSIGHT dataset. I can answer from Land Registry sales, EPC, mapped location, planning context, flood status, schools, stations and airports.")
        };
      }

      function sortRowsForQuery(rows, query) {
        const qn = normalise(query);
        const copy = rows.slice();
        if (qn.includes("CHEAPEST") || qn.includes("LOWEST PRICE") || qn.includes("LOWEST PRICED")) return copy.sort((a, b) => Number(a.price) - Number(b.price));
        if (qn.includes("OLDEST") || qn.includes("FIRST SALE")) return copy.sort((a, b) => a.date.localeCompare(b.date));
        if (qn.includes("LATEST") || qn.includes("NEWEST") || qn.includes("RECENT")) return copy.sort((a, b) => b.date.localeCompare(a.date));
        if (ppsfRequested(query)) return copy.sort((a, b) => Number(b.pricePerSqft || 0) - Number(a.pricePerSqft || 0));
        if (qn.includes("LARGEST") || qn.includes("BIGGEST") || qn.includes("SQFT") || qn.includes("SQ FT")) return copy.sort((a, b) => Number(b.floorAreaSqft || 0) - Number(a.floorAreaSqft || 0));
        return copy.sort((a, b) => Number(b.price || 0) - Number(a.price || 0) || b.date.localeCompare(a.date));
      }

      function groupDimensionFromQuery(query) {
        const qn = normalise(query);
        if (!rankingRequested(query)) return "";
        if (qn.includes("PRIVATE ESTATE") || qn.includes("ESTATE")) return "estate";
        if (qn.includes("LOCAL AUTH") || qn.includes("AUTHORITY") || qn.includes("MARKET") || qn.includes("BY AREA") || qn.includes("WHICH AREA")) return "market";
        if (qn.includes("POSTCODE")) return "postcode";
        if (qn.includes("TOWN")) return "town";
        return "";
      }

      function groupRowsForInsight(rows, dimension) {
        const groups = new Map();
        const add = (key, label, item) => {
          if (!key) return;
          if (!groups.has(key)) groups.set(key, { key, label, rows: [] });
          groups.get(key).rows.push(item);
        };
        rows.forEach(item => {
          if (dimension === "estate") {
            const estate = estateForTransaction(item);
            if (estate) add(estate.key, estate.name, item);
          } else if (dimension === "market") {
            const market = marketById(item.market);
            add(item.market || item.district, market?.short || item.district, item);
          } else if (dimension === "postcode") {
            const outcode = outwardPostcode(item.postcode);
            add(outcode, outcode, item);
          } else {
            add(townKey(item.town), townDisplayName(townKey(item.town)), item);
          }
        });
        return Array.from(groups.values());
      }

      function insightStatsForGroup(group, dimension) {
        // Always calculate from the exact matched cohort. Reusing the cached
        // all-date/all-type area stats here leaks unfiltered figures into
        // filtered questions such as "detached homes in 2022".
        return group.stats || statsForRows(group.rows);
      }

      function insightMetricForGroup(group, query, typeFilter, dimension) {
        const qn = normalise(query);
        const rows = group.rows;
        const stats = insightStatsForGroup(group, dimension);
        if ((qn.includes("DENSITY") || qn.includes("SHARE") || qn.includes("CONCENTRATION")) && typeFilter) {
          const matched = rows.filter(typeFilter.test).length;
          return { value: rows.length ? matched / rows.length : 0, label: `${formatNumber(matched)} of ${formatNumber(rows.length)} (${Math.round((rows.length ? matched / rows.length : 0) * 100)}%)` };
        }
        const intent = insightIntent(query);
        if (intent === "velocity") return stats.transactionGrain
          ? { value: rows.length, label: `${formatNumber(rows.length)} period transactions` }
          : { value: stats.marketHeatScore, label: velocityLabel(stats) };
        if (intent === "growth") return {
          value: stats.priceConfidence > 0 ? stats.priceChange : NaN,
          label: `${priceMovementLabel(stats)} · ${priceMovementEvidenceLabel(stats)}`
        };
        if (intent === "ppsf") {
          const values = rows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0);
          const value = qn.includes("MEDIAN") ? median(values) : average(values);
          return { value, label: compactPpsf(value) || "Awaiting EPC", sampleCount: values.length };
        }
        if (intent === "size") {
          const values = rows.map(item => Number(item.floorAreaSqft || 0)).filter(value => value > 0);
          const value = qn.includes("MEDIAN") ? median(values) : average(values);
          return { value, label: compactSqft(value) || "Awaiting EPC", sampleCount: values.length };
        }
        if (qn.includes("MEDIAN")) {
          const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
          const value = median(prices);
          return { value, label: compactPrice(value), sampleCount: prices.length };
        }
        if (qn.includes("AVERAGE") || qn.includes("AVG") || qn.includes("MEAN")) return { value: stats.avg, label: compactPrice(stats.avg) };
        if (qn.includes("PLANNING")) {
          const total = planningApplicationVolumeForRows(rows);
          return { value: total, label: `${formatNumber(total)} property applications` };
        }
        if (qn.includes("FLOOD")) {
          const fresh = rows.filter(floodEvidenceIsFresh);
          const total = fresh.reduce((sum, item) => sum + freshFloodAlertCount(item), 0);
          return fresh.length
            ? { value: total, label: `${formatNumber(total)} current alerts · ${formatNumber(fresh.length)} fresh checks`, sampleCount: fresh.length }
            : { value: NaN, label: "Current alert status unavailable", sampleCount: 0 };
        }
        if (qn.includes("MAX") || qn.includes("HIGHEST") || qn.includes("MOST EXPENSIVE")) return { value: stats.max, label: compactPrice(stats.max) };
        return { value: rows.length, label: `${formatNumber(rows.length)} sales` };
      }

      function lowRankingRequested(query) {
        const qn = normalise(query).replace(/\bAT LEAST\b/g, "");
        return ["LOWEST", "COLDEST", "BOTTOM", "WORST", "CHEAPEST", "LEAST ACTIVE", "LEAST EXPENSIVE"].some(term => queryContainsTerm(qn, term));
      }

      function insightGroupAnswer(rows, query, typeFilter) {
        const dimension = groupDimensionFromQuery(query);
        if (!dimension) return null;
        const qn = normalise(query);
        const explicitRankingMetric = [
          "VELOCITY", "PACE", "ACTIVE", "ACTIVITY", "GROWTH", "PRICE MOVEMENT", "APPRECIAT", "RISEN", "FALLEN",
          "PRICE", "VALUE", "MEDIAN", "AVERAGE", "AVG", "MEAN", "PSF", "PER SQ", "PLANNING", "FLOOD",
          "EPC", "ENERGY", "FLOOR AREA", "SQFT", "SQ FT", "COUNT", "HOW MANY", "NUMBER OF", "VOLUME",
          "SALE", "LATEST", "NEWEST", "RECENT", "DENSITY", "SHARE", "CONCENTRATION"
        ].some(term => qn.includes(term));
        if (rankingRequested(query) && !explicitRankingMetric) {
          return {
            title: "Ranking metric required",
            subtitle: "Choose a directly evidenced measure",
            layout: "compact",
            showLedger: false,
            preserveMap: true,
            rows: [],
            html: insightLead([
              "That ranking request does not specify a supported measure, so INSIGHT will not silently substitute price, sales volume or another metric.",
              "Ask for mature 12-month pace, market heat, 120-day activity, real price movement, sale value, £ per sq ft, planning activity or record count."
            ]) + insightCaveat(insightUniverseBoundary())
          };
        }
        const intent = insightIntent(query);
        const defaultMinimum = ["planning", "flood", "count", "latest"].includes(intent) ? 1 : 5;
        const minimumSample = minimumSampleFromQuery(query, defaultMinimum);
        const rawGroups = groupRowsForInsight(rows, dimension);
        const velocityGroupStats = intent === "velocity"
          ? velocityMatrixForGroups(rawGroups.map(group => statsForRows(group.rows)))
          : [];
        const groups = rawGroups
          .map((group, index) => {
            const enriched = intent === "velocity" ? { ...group, stats: velocityGroupStats[index] } : group;
            return { ...enriched, metric: insightMetricForGroup(enriched, query, typeFilter, dimension) };
          })
          .filter(group => Number.isFinite(group.metric.value)
            && (group.metric.sampleCount ?? group.rows.length) >= minimumSample
            && (intent !== "velocity" || group.stats.rankEligible))
          .sort((a, b) => lowRankingRequested(query) ? a.metric.value - b.metric.value : b.metric.value - a.metric.value);
        if (!groups.length) return null;
        const limit = topCountFromQuery(query, 8);
        const ranked = groups.slice(0, limit);
        const leader = groups[0];
        if (intent === "planning" && groups.every(group => group.metric.value === 0)) return { title: "Planning ranking unavailable", subtitle: "No differentiating loaded evidence", layout: "compact", showLedger: false, preserveMap: true, rows: [], html: insightLead(["No authority can be ranked on planning activity from the currently loaded cohort because every qualifying group has zero linked applications.", "A zero here means no loaded match, not proof that no planning activity occurred. Presenting a leader would be false precision."]) + insightCaveat(insightUniverseBoundary()) };
        const runnerUp = groups[1];
        const leaderCount = leader.metric.sampleCount ?? leader.rows.length;
        const leaderStats = insightStatsForGroup(leader, dimension);
        const gap = runnerUp ? Math.abs(Number(leader.metric.value) - Number(runnerUp.metric.value)) : 0;
        let interpretation = `${leader.label} leads the eligible ${humaniseKey(dimension).toLowerCase()} cohorts, with ${runnerUp ? `${runnerUp.label} second at ${runnerUp.metric.label}` : "no second qualifying cohort"}.`;
        if (intent === "velocity") interpretation = `That is mature transaction activity, not time-on-market: ${leader.label} records ${leaderStats.marketHeatScore}/100 market heat, combining ${leaderStats.paceScore}/100 pace with ${leaderStats.liquidityScore}/100 peer-normalised liquidity. The gap to ${runnerUp?.label || "the next cohort"} is ${gap.toFixed(0)} heat points; the separate 120-day signal is ${accelerationLabel(leaderStats).toLowerCase()} and does not alter the ranking.`;
        else if (intent === "growth") interpretation = "The ranking uses CPIH-adjusted same-property annualised movement and excludes cohorts without qualifying repeat-sale evidence; it is not a simple change in mixed sale medians.";
        else if (intent === "ppsf") interpretation = `The comparison uses ${normalise(query).includes("MEDIAN") ? "median" : "average"} recorded £/sq ft and only groups clearing the stated usable-EPC sample gate.`;
        return {
          title: "Ask INSIGHT",
          subtitle: `${humaniseKey(dimension)} ranking`,
          layout: "analysis",
          showLedger: false,
          rows: leader.rows,
          mapRows: groups.slice(0, limit).flatMap(group => group.rows),
          html: insightLead([`${leader.label} is the direct answer: ${leader.metric.label}, based on ${formatNumber(leaderCount)} usable records and a minimum evidence gate of ${formatNumber(minimumSample)}.`, interpretation, `${insightSampleConfidence(leaderCount)} sample depth. Use the ranking to prioritise investigation, then test the exact property type, price band and recent comparable evidence.`]) + insightBarList(ranked.map(group => ({ label: group.label, value: group.metric.value, formatted: `${group.metric.label} · n=${formatNumber(group.metric.sampleCount ?? group.rows.length)}` }))) + insightCaveat(`${insightUniverseBoundary()} Rankings use the exact requested cohort and exclude groups below ${formatNumber(minimumSample)} usable records.`)
        };
      }

      function insightMetricForRows(rows, query, suppliedStats = null) {
        const intent = insightIntent(query);
        const stats = suppliedStats || statsForRows(rows);
        const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
        const floorAreas = rows.map(item => Number(item.floorAreaSqft || 0)).filter(value => value > 0);
        const freshFloodRows = rows.filter(floodEvidenceIsFresh);
        const floodAffected = freshFloodRows.filter(item => freshFloodAlertCount(item) > 0).length;
        if (intent === "velocity") return stats.transactionGrain
          ? { value: rows.length, label: `${formatNumber(rows.length)} period transactions`, noun: "historical transaction volume" }
          : { value: stats.marketHeatScore, label: velocityLabel(stats), noun: "market heat" };
        if (intent === "growth") return {
          value: stats.priceConfidence > 0 ? stats.priceChange : NaN,
          label: `${priceMovementLabel(stats)} · ${priceMovementEvidenceLabel(stats)}`,
          noun: "real annualised price movement"
        };
        if (intent === "ppsf") {
          const values = rows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0);
          const useMedian = normalise(query).includes("MEDIAN");
          const value = useMedian ? median(values) : average(values);
          return { value, label: compactPpsf(value) || "Awaiting EPC", noun: `${useMedian ? "median" : "average"} £/sq ft` };
        }
        if (intent === "planning") {
          const total = planningApplicationVolumeForRows(rows);
          return { value: rows.length ? total / rows.length : 0, label: `${formatNumber(total)} applications across ${formatNumber(rows.length)} properties`, noun: "planning activity" };
        }
        if (intent === "epc") {
          const covered = rows.filter(item => item.epcRating || Number(item.floorAreaSqft || 0) > 0).length;
          return { value: rows.length ? covered / rows.length : 0, label: `${formatNumber(covered)} of ${formatNumber(rows.length)} properties (${Math.round(rows.length ? covered / rows.length * 100 : 0)}%)`, noun: "EPC coverage", sampleCount: rows.length };
        }
        if (intent === "flood") return freshFloodRows.length
          ? { value: floodAffected / freshFloodRows.length, label: `${formatNumber(floodAffected)} of ${formatNumber(freshFloodRows.length)} freshly checked properties with current alerts`, noun: "current flood-alert exposure", sampleCount: freshFloodRows.length }
          : { value: NaN, label: "No fresh flood checks", noun: "current flood-alert exposure", sampleCount: 0 };
        if (intent === "size") {
          const useMedian = normalise(query).includes("MEDIAN");
          const value = useMedian ? median(floorAreas) : average(floorAreas);
          return { value, label: compactSqft(value) || "Awaiting EPC", noun: `${useMedian ? "median" : "average"} EPC floor area` };
        }
        if (intent === "count") return { value: rows.length, label: `${formatNumber(rows.length)} records`, noun: "matched volume" };
        if (intent === "latest") {
          const latest = rows.slice().sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")))[0];
          return { value: latest?.date ? Number(latest.date.replace(/-/g, "")) : 0, label: latest ? formatDate(latest.date) : "No sale", noun: "latest sale" };
        }
        const useMedian = normalise(query).includes("MEDIAN");
        return { value: useMedian ? median(prices) : average(prices), label: compactPrice(useMedian ? median(prices) : average(prices)), noun: useMedian ? "median sale price" : "average sale price" };
      }

      function insightStatsForLocation(location, rows) {
        return statsForRows(rows);
      }

      function insightComparisonAnswer(rows, query, locations) {
        if (!comparisonRequested(query, locations)) return null;
        const qn = normalise(query);
        const comparisonSeeds = locations.map(location => {
          const matchedRows = rows.filter(location.test);
          const stats = insightStatsForLocation(location, matchedRows);
          return { location, matchedRows, stats };
        });
        const comparisonMatrix = insightIntent(query) === "velocity"
          ? velocityMatrixForGroups(comparisonSeeds.map(seed => seed.stats))
          : comparisonSeeds.map(seed => seed.stats);
        const allComparisons = comparisonSeeds.map((seed, index) => {
          const { location, matchedRows } = seed;
          const stats = comparisonMatrix[index];
          const prices = matchedRows.map(item => Number(item.price || 0)).filter(value => value > 0);
          return {
            ...location,
            rows: matchedRows,
            stats,
            metric: insightMetricForRows(matchedRows, query, stats),
            medianPrice: median(prices),
            averagePrice: average(prices),
            velocity: stats.marketHeatScore,
            velocityLabel: stats.transactionGrain ? `${formatNumber(matchedRows.length)} period sales` : velocityLabel(stats),
            movement: stats.priceChange,
            movementConfidence: stats.priceConfidence,
            ppsf: qn.includes("MEDIAN") ? median(matchedRows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0)) : stats.ppsfAvg,
            planning: planningApplicationVolumeForRows(matchedRows)
          };
        });
        const comparisons = allComparisons.filter(group => group.rows.length && Number.isFinite(group.metric.value));
        if (comparisons.length < 2) {
          const missing = allComparisons.filter(group => !group.rows.length || !Number.isFinite(group.metric.value)).map(group => group.label);
          const available = comparisons.map(group => `${group.label} (${formatNumber(group.rows.length)} records)`).join(", ") || "none";
          return { title: "Comparison not supportable", subtitle: "One or more cohorts have no usable records", layout: "compact", showLedger: false, preserveMap: true, rows: comparisons.flatMap(group => group.rows), html: insightLead([`INSIGHT cannot complete this comparison because ${missing.join(", ") || "one requested cohort"} has no usable records after applying the exact filters.`, `Available matched evidence: ${available}. A one-sided result is not being presented as a comparison.`]) + insightCaveat(insightUniverseBoundary()) };
        }
        if (insightIntent(query) === "planning" && comparisons.every(group => group.metric.value === 0)) return { title: "Planning comparison unavailable", subtitle: "No differentiating loaded evidence", layout: "compact", showLedger: false, preserveMap: true, rows: [], html: insightLead([`Neither ${comparisons.map(group => group.label).join(" nor ")} has linked planning applications in the currently loaded cohort, so INSIGHT cannot identify a leader.`, "Zero linked applications means no loaded match, not proof of no planning activity."]) + insightCaveat(insightUniverseBoundary()) };
        const lowerWins = lowRankingRequested(query) || queryContainsTerm(query, "LOWER");
        comparisons.sort((a, b) => lowerWins ? a.metric.value - b.metric.value : b.metric.value - a.metric.value);
        const leader = comparisons[0];
        const runnerUp = comparisons[1];
        const difference = runnerUp.metric.value ? Math.abs(leader.metric.value / runnerUp.metric.value - 1) : 0;
        const closeResult = difference < .02 || difference < .08 && [leader.rows.length, runnerUp.rows.length].some(count => count < 15);
        const answers = [closeResult
          ? `${leader.label} and ${runnerUp.label} are broadly similar on ${leader.metric.noun} within the precision of these samples: ${leader.metric.label} versus ${runnerUp.metric.label}.`
          : `${leader.label} leads on ${leader.metric.noun}: ${leader.metric.label}, compared with ${runnerUp.metric.label} for ${runnerUp.label}${difference && insightIntent(query) !== "latest" ? ` (a ${Math.round(difference * 100)}% difference)` : ""}.`];
        const metricLeader = (key, formatter, noun) => {
          const ranked = comparisons.slice().sort((a, b) => Number(b[key] || 0) - Number(a[key] || 0));
          return `${ranked[0].label} leads on ${noun} at ${formatter(ranked[0])}, versus ${formatter(ranked[1])} for ${ranked[1].label}.`;
        };
        if (qn.includes("MEDIAN") && insightIntent(query) !== "price") answers.push(metricLeader("medianPrice", group => compactPrice(group.medianPrice), "median sale price"));
        else if (qn.includes("PRICE") && insightIntent(query) !== "price") answers.push(metricLeader("averagePrice", group => compactPrice(group.averagePrice), "average sale price"));
        if ((qn.includes("VELOCITY") || qn.includes("PACE")) && insightIntent(query) !== "velocity") answers.push(metricLeader("velocity", group => group.velocityLabel, "market velocity"));
        if ((qn.includes("PSF") || qn.includes("PER SQ")) && insightIntent(query) !== "ppsf") answers.push(metricLeader("ppsf", group => compactPpsf(group.ppsf) || "unavailable", "average price per square foot"));
        if (qn.includes("PLANNING") && insightIntent(query) !== "planning") answers.push(metricLeader("planning", group => `${formatNumber(group.planning)} applications`, "loaded planning activity"));
        const table = insightTable(
          ["Area", "Records", "Median", "Average", "£/sq ft", "Velocity", "Real movement"],
          comparisons.map(group => [group.label, formatNumber(group.rows.length), compactPrice(group.medianPrice), compactPrice(group.averagePrice), compactPpsf(group.ppsf) || "—", group.velocityLabel, group.stats.transactionGrain ? "Not calculated" : priceMovementLabel(group.stats)])
        );
        return {
          title: "Ask INSIGHT",
          subtitle: `${comparisons.length}-area comparison`,
          layout: "report",
          showLedger: false,
          rows: comparisons.flatMap(group => group.rows),
          mapRows: comparisons.flatMap(group => group.rows),
          html: insightLead([...answers, `The comparison uses ${comparisons.map(group => `${formatNumber(group.rows.length)} records for ${group.label}`).join(" and ")}. Treat small gaps as directional when either cohort is thin.`]) + table + insightCaveat(`${insightUniverseBoundary()} Comparisons use each exact matched cohort. A lead is softened when the difference is small and either sample is thin.`)
        };
      }

      function insightTrendAnswer(rows, query, dateRange) {
        if (!trendRequested(query) || relationshipRequested(query)) return null;
        let activityRows = rows.slice();
        if (dateRange) {
          activityRows = activityRows.filter(item => {
            const date = parseIso(item.date);
            return date && (!dateRange.from || date >= dateRange.from) && (!dateRange.to || date <= dateRange.to);
          });
        }
        const qn = normalise(query);
        const period = qn.includes("MONTH") ? "month" : qn.includes("QUARTER") ? "quarter" : "year";
        const groups = new Map();
        activityRows.forEach(item => {
          const date = parseIso(String(item.date || "").slice(0, 10));
          if (!date) return;
          const year = date.getUTCFullYear();
          const month = date.getUTCMonth() + 1;
          const key = period === "month" ? `${year}-${String(month).padStart(2, "0")}` : period === "quarter" ? `${year} Q${Math.ceil(month / 3)}` : String(year);
          if (!groups.has(key)) groups.set(key, []);
          groups.get(key).push(item);
        });
        const periods = Array.from(groups, ([key, periodRows]) => {
          const prices = periodRows.map(item => Number(item.price || 0)).filter(value => value > 0);
          const realPrices = periodRows.map(realPriceForSale).filter(value => value > 0);
          const ppsf = periodRows.map(realPpsfForSale).filter(value => value > 0);
          const currentYear = String(analysisEnd.getUTCFullYear());
          const label = period === "year" && key === currentYear && analysisEnd.getUTCMonth() < 11 ? `${key} YTD` : key;
          return { key, label, rows: periodRows, median: median(prices), realMedian: median(realPrices), ppsf: median(ppsf), confidence: insightSampleConfidence(periodRows.length) };
        }).filter(item => item.rows.length).sort((a, b) => a.key.localeCompare(b.key));
        if (periods.length < 2) return null;
        const defensible = periods.filter(item => item.rows.length >= 5);
        const comparisonPeriods = defensible.length >= 2 ? defensible : periods;
        const first = comparisonPeriods[0];
        const last = comparisonPeriods[comparisonPeriods.length - 1];
        const change = first.realMedian ? last.realMedian / first.realMedian - 1 : 0;
        const direction = change >= 0 ? "higher" : "lower";
        const answer = `The CPIH-adjusted loaded median moved from ${compactPrice(first.realMedian)} in ${first.label} to ${compactPrice(last.realMedian)} in ${last.label}, ${Math.abs(change) < .005 ? "broadly unchanged" : `${Math.abs(change * 100).toFixed(1)}% ${direction}`}. Recorded volume moved from ${formatNumber(first.rows.length)} to ${formatNumber(last.rows.length)} sales.`;
        const interpretation = `${change >= .1 ? "The direction is materially positive" : change <= -.1 ? "The direction is materially negative" : "The endpoint change is comparatively modest"}, but this is a sequence of cohort medians rather than a repeat-sales index. Changing property mix can move the line even when underlying asset values do not.`;
        const evidence = defensible.length >= 2 ? `${formatNumber(defensible.length)} periods clear the five-sale evidence gate; the headline comparison uses the first and latest of those defensible periods.` : `Fewer than two periods clear the five-sale evidence gate, so the trend is indicative and should not carry an investment conclusion without property-level comparables.`;
        return {
          title: "Ask INSIGHT",
          subtitle: `${first.label}–${last.label} ${period} trend`,
          layout: "report",
          showLedger: false,
          rows: activityRows,
          mapRows: rows,
          html: insightLead([answer, interpretation, evidence]) + insightMetricGrid([
            { label: "Real median change", value: preciseSignedPercent(change), detail: `${first.label} to ${last.label}` },
            { label: "Starting median", value: compactPrice(first.realMedian), detail: `${formatNumber(first.rows.length)} records` },
            { label: "Latest median", value: compactPrice(last.realMedian), detail: `${formatNumber(last.rows.length)} records` },
            { label: "Usable periods", value: formatNumber(comparisonPeriods.length), detail: defensible.length >= 2 ? "At least five records each" : "Includes thin indicative periods" }
          ]) + insightTable(
            [period === "year" ? "Year" : period === "quarter" ? "Quarter" : "Month", "Sales", "Nominal median", "Real median", "Real £/sq ft", "Strength"],
            periods.slice(-16).reverse().map(item => [item.label, formatNumber(item.rows.length), compactPrice(item.median), compactPrice(item.realMedian), compactPpsf(item.ppsf) || "—", item.confidence])
          ) + insightCaveat(`${insightUniverseBoundary("CPIH adjustment uses INSIGHT's internal annual index through 2026.")} Period medians remain sensitive to changing property mix; current-year figures are year-to-date.`)
        };
      }

      function insightCoverageAnswer(rows, query) {
        if (!coverageRequested(query)) return null;
        const count = rows.length || 1;
        const coverage = (label, matched) => [label, `${formatNumber(matched)} of ${formatNumber(rows.length)} (${Math.round(matched / count * 100)}%)`];
        const epc = rows.filter(item => Number(item.floorAreaSqft || 0) > 0 || item.epcRating).length;
        const planning = rows.filter(item => planningApplicationCount(item) > 0 || item.planning?.latestApplication).length;
        const flood = rows.filter(floodEvidenceIsFresh).length;
        const coordinatePoints = rows.map(transactionGeoPoint).filter(Boolean);
        const coordinates = coordinatePoints.length;
        const exactCoordinates = coordinatePoints.filter(point => point[3] === "exact" || point[3] === "address").length;
        const schoolsCovered = rows.filter(item => Array.isArray(item.ofsted?.nearestSchools) && item.ofsted.nearestSchools.length).length;
        const weakest = [["EPC", epc], ["Planning", planning], ["Flood", flood], ["Coordinates", coordinates], ["Schools", schoolsCovered]].sort((a, b) => a[1] - b[1])[0];
        const asksExactCoordinates = normalise(query).includes("EXACT COORDINATE") || normalise(query).includes("ADDRESS LEVEL COORDINATE");
        const answer = asksExactCoordinates ? `${formatNumber(exactCoordinates)} of ${formatNumber(rows.length)} matched properties (${Math.round(exactCoordinates / count * 100)}%) have address-level coordinates. The remaining mapped points may use a postcode centroid or another lower-precision fallback.` : `${weakest[0]} is the thinnest of these loaded evidence layers, covering ${formatNumber(weakest[1])} of ${formatNumber(rows.length)} matched properties. Missing fields are reported as unavailable rather than inferred.`;
        return {
          title: "Ask INSIGHT",
          subtitle: "Data coverage audit",
          layout: "analysis",
          showLedger: false,
          rows,
          html: insightLead([answer, "Coverage figures describe the loaded analytical cohort only; they do not prove that an external source has no additional record."]) + dataRows([
            coverage("Sale price and date", rows.filter(item => item.price && item.date).length),
            coverage("Mapped coordinates", coordinates),
            coverage("Address-level coordinates", exactCoordinates),
            coverage("EPC area or rating", epc),
            coverage("Planning context", planning),
            coverage("Flood context", flood),
            coverage("Nearby schools", schoolsCovered)
          ])
        };
      }

      function insightDistributionAnswer(rows, query) {
        if (!distributionRequested(query)) return null;
        const qn = normalise(query);
        const groups = new Map();
        rows.forEach(item => {
          let label;
          if (qn.includes("EPC") || qn.includes("ENERGY")) label = String(item.epcRating || "Unknown").slice(0, 1).toUpperCase();
          else if (qn.includes("FLOOD")) label = floodEvidenceIsFresh(item) ? item.environmentAgency?.floodStatus || "Fresh check · no label" : "Current status unknown";
          else label = item.propertyType || "Unknown type";
          groups.set(label, (groups.get(label) || 0) + 1);
        });
        const ranked = Array.from(groups, ([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count);
        if (!ranked.length) return null;
        const leader = ranked[0];
        const list = ranked.map(group => contextItem(group.label, `${formatNumber(group.count)} properties · ${Math.round(group.count / rows.length * 100)}%`));
        return {
          title: "Ask INSIGHT",
          subtitle: "Matched-property breakdown",
          layout: "analysis",
          showLedger: false,
          rows,
          html: insightLead([`${leader.label} is the largest group, representing ${Math.round(leader.count / rows.length * 100)}% of the ${formatNumber(rows.length)} matched properties.`, "The distribution is descriptive rather than causal. Unknown or unmatched records remain visible as their own group and are not reassigned.", `${insightSampleConfidence(rows.length)} cohort depth; use the full distribution below rather than the leading category alone.`]) + contextSection("Distribution", [], list) + insightCaveat(insightUniverseBoundary())
        };
      }

      function insightRepeatSalesAnswer(rows, query) {
        if (!repeatSalesRequested(query)) return null;
        const seen = new Set();
        const repeats = rows.map(property => {
          const key = propertyRecordKey(property);
          if (seen.has(key)) return null;
          seen.add(key);
          const history = salesHistoryForTransaction(property)
            .filter(sale => Number(sale.price) > 0 && parseIso(String(sale.date || "").slice(0, 10)))
            .sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
          if (history.length < 2) return null;
          const pricesByDate = new Map();
          let conflictingSaleDate = false;
          history.forEach(sale => {
            const date = String(sale.date || "").slice(0, 10);
            const price = Number(sale.price || 0);
            if (pricesByDate.has(date) && pricesByDate.get(date) !== price) conflictingSaleDate = true;
            pricesByDate.set(date, price);
          });
          if (conflictingSaleDate) return null;
          const last = history[0];
          const prior = history[1];
          if (String(last.category || "").toUpperCase() === "B" || String(prior.category || "").toUpperCase() === "B") return null;
          if (normalise(last.propertyType) && normalise(prior.propertyType) && normalise(last.propertyType) !== normalise(prior.propertyType)) return null;
          const holdingYears = Math.max(0, monthsBetween(
            parseIso(String(prior.date).slice(0, 10)), parseIso(String(last.date).slice(0, 10))
          ) / 12);
          if (holdingYears < 1) return null;
          const priorPrice = inflationAdjustedPrice(prior);
          const change = priorPrice > 0 ? inflationAdjustedPrice(last) / priorPrice - 1 : 0;
          const annualised = holdingYears >= 1 ? Math.pow(1 + change, 1 / holdingYears) - 1 : null;
          return { key, history, prior, last, change, annualised, holdingYears };
        }).filter(Boolean).sort((left, right) => right.history.length - left.history.length || String(right.last.date).localeCompare(String(left.last.date)));
        if (!repeats.length) return {
          title: "Ask INSIGHT",
          subtitle: "No repeat sales",
          rows: [],
          html: textSection("Answer", "No matched properties have more than one loaded Land Registry transaction in the available history.")
        };
        const list = repeats.slice(0, topCountFromQuery(query, 10)).map(item => contextItem(
          propertyDisplayName(item.last),
          `${item.history.length} sales · ${formatDate(item.prior.date)} ${compactPrice(item.prior.price)} → ${formatDate(item.last.date)} ${compactPrice(item.last.price)} · ${preciseSignedPercent(item.change)} real${item.annualised !== null ? ` · ${preciseSignedPercent(item.annualised)} p.a.` : ""}`
        ));
        return {
          title: "Ask INSIGHT",
          subtitle: `${formatNumber(repeats.length)} repeat-sale properties`,
          layout: "report",
          rows: repeats.map(item => item.last),
          html: textSection("Answer", `${formatNumber(repeats.length)} matched properties have multiple loaded sales. Changes compare the latest two sales, are CPIH-adjusted and are annualised where the holding period is at least one year. They can still reflect refurbishment, extension or tenure changes.`) + contextSection("Repeat-sale evidence", [], list)
        };
      }

      function insightSampleConfidence(count) {
        const value = Number(count) || 0;
        if (value >= 30) return "High";
        if (value >= 15) return "Medium";
        if (value >= 5) return "Low";
        return "Indicative";
      }

      function realPriceForSale(item) {
        return inflationAdjustedPrice(item);
      }

      function realPpsfForSale(item) {
        const ppsf = Number(item?.pricePerSqft || 0);
        const sourceIndex = cpihIndexForDate(item?.date);
        return ppsf > 0 && sourceIndex > 0 ? ppsf * cpihAnnualIndex[cpihReferenceYear] / sourceIndex : 0;
      }

      function insightPropertyTarget(query) {
        const selected = state.selectedType === "property"
          ? transactionsById.get(propertyId(state.selectedId))
          : null;
        const qn = normalise(query);
        if (selected && ["THIS PROPERTY", "SELECTED PROPERTY", "THIS HOUSE", "IT WORTH", "COMPS", "COMPARABLE"].some(term => qn.includes(term))) return selected;
        const postcode = (String(query || "").match(/\b[A-Z]{1,2}\d{1,2}[A-Z]?(?:\s*\d[A-Z]{2})\b/i) || [])[0];
        const postcodeRows = postcode ? transactions.filter(item => normalisePostcode(item.postcode) === normalisePostcode(postcode)) : [];
        const number = (String(query || "").match(/\b\d{1,4}[A-Z]?\b/i) || [])[0];
        const addressGeneric = new Set(normalise("COMPARABLE COMPARABLES COMPS EVIDENCE FIND GIVE LED RANGE SALE SALES SIMILAR STRONGEST VALUE VALUATION").split(" "));
        const addressTokens = insightQueryTokens(query).filter(token => token.length > 3 && !addressGeneric.has(token));
        const numberedAddress = number && addressTokens.length ? transactions.find(item => { const paonTokens = normalise(item.paon || item.address).split(" "); const text = rowInsightText(item); return paonTokens.includes(normalise(number)) && addressTokens.every(token => text.includes(token)); }) : null;
        const fuzzy = fuzzyPropertyRows(transactions, query);
        const selectedReference = selected && !resolvedInsightLocations(query).length && ["THIS", "SELECTED", "IT", "PROPERTY", "HOUSE", "HOME", "COMPS", "COMPARABLE"].some(term => queryContainsTerm(query, term));
        return numberedAddress || fuzzy[0] || (postcodeRows.length === 1 ? postcodeRows[0] : null) || (selectedReference ? selected : null);
      }

      function comparableSimilarity(target, candidate) {
        if (propertyRecordKey(target) === propertyRecordKey(candidate)) return null;
        const targetPoint = transactionGeoPoint(target);
        const candidatePoint = transactionGeoPoint(candidate);
        const distance = distanceKm(targetPoint, candidatePoint);
        const targetArea = Number(target.floorAreaSqft || 0);
        const candidateArea = Number(candidate.floorAreaSqft || 0);
        const areaSimilarity = targetArea && candidateArea ? Math.exp(-Math.abs(Math.log(candidateArea / targetArea)) * 1.8) : .35;
        const targetDate = parseIso(String(target.date || "").slice(0, 10));
        const candidateDate = parseIso(String(candidate.date || "").slice(0, 10));
        const yearGap = targetDate && candidateDate ? Math.abs(targetDate - candidateDate) / (365.25 * 24 * 60 * 60 * 1000) : 8;
        const typeMatch = normalise(target.propertyType) === normalise(candidate.propertyType) ? 1 : .25;
        const estateMatch = estateForTransaction(target)?.key && estateForTransaction(target)?.key === estateForTransaction(candidate)?.key ? 1 : 0;
        const marketMatch = target.market === candidate.market ? 1 : 0;
        const distanceScore = Math.exp(-Math.min(30, distance) / 7);
        const recencyScore = Math.exp(-yearGap / 6);
        const coordinateQuality = [targetPoint?.[3], candidatePoint?.[3]].every(value => value === "exact" || value === "address") ? 1 : .72;
        const score = (.28 * areaSimilarity + .2 * typeMatch + .18 * distanceScore + .12 * recencyScore + .1 * marketMatch + .08 * estateMatch + .04 * coordinateQuality) * 100;
        return { candidate, score, distance, areaSimilarity, coordinateQuality };
      }

      function insightComparableAnswer(rows, query) {
        if (!comparableRequested(query)) return null;
        const target = insightPropertyTarget(query);
        if (!target) return {
          title: "Comparable sales",
          subtitle: "Property required",
          layout: "compact",
          showLedger: false,
          rows: [],
          html: insightLead("Name a property or select it on the map, then ask for comparable sales or an evidence range.") + insightCaveat(insightUniverseBoundary())
        };
        const targetDisplay = propertyDisplayName(target);
        const targetLabel = /^\d+$/.test(targetDisplay) ? propertyAddressLabel(target) : targetDisplay;
        const comparisons = transactions.map(candidate => comparableSimilarity(target, candidate)).filter(Boolean)
          .filter(item => item.score >= 32)
          .sort((left, right) => right.score - left.score)
          .slice(0, topCountFromQuery(query, 8));
        if (comparisons.length < 3) return {
          title: "Comparable sales",
          subtitle: targetLabel,
          layout: "analysis",
          showLedger: false,
          rows: comparisons.map(item => item.candidate),
          html: insightLead(`Only ${formatNumber(comparisons.length)} defensible comparable sales were found for ${targetLabel}. That is too thin for a useful evidence range.`) + insightCaveat(insightUniverseBoundary())
        };
        const realPpsf = comparisons.map(item => realPpsfForSale(item.candidate)).filter(value => value > 0);
        const targetArea = Number(target.floorAreaSqft || 0);
        const adjustedPrices = comparisons.map(item => realPriceForSale(item.candidate)).filter(value => value > 0);
        const central = targetArea && realPpsf.length >= 3 ? median(realPpsf) * targetArea : median(adjustedPrices);
        const low = targetArea && realPpsf.length >= 3 ? quantileInclusive(realPpsf, .25) * targetArea : quantileInclusive(adjustedPrices, .25);
        const high = targetArea && realPpsf.length >= 3 ? quantileInclusive(realPpsf, .75) * targetArea : quantileInclusive(adjustedPrices, .75);
        const exactCount = comparisons.filter(item => item.coordinateQuality === 1).length;
        const table = insightTable(
          ["Comparable", "Sold", "Date", "Distance", "Area", "£/sq ft", "Match"],
          comparisons.map(item => [
            propertyDisplayName(item.candidate),
            compactPrice(item.candidate.price),
            formatDate(item.candidate.date),
            formatDistanceKm(item.distance),
            compactSqft(item.candidate.floorAreaSqft) || "—",
            compactPpsf(item.candidate.pricePerSqft) || "—",
            `${Math.round(item.score)}%`
          ])
        );
        return {
          title: "Comparable sales",
          subtitle: targetLabel,
          layout: "report",
          showLedger: false,
          rows: comparisons.map(item => item.candidate),
          mapRows: [target, ...comparisons.map(item => item.candidate)],
          html: insightLead([
            `${targetLabel} has an indicative CPIH-adjusted evidence range of ${compactPrice(low)} to ${compactPrice(high)}, centred around ${compactPrice(central)} from ${formatNumber(comparisons.length)} scored comparable sales.`,
            "The selection weights floor-area similarity, property type, distance, sale recency, market and private-estate match. It is an evidence range, not a formal valuation."
          ]) + insightMetricGrid([
            { label: "Evidence centre", value: compactPrice(central), detail: targetArea && realPpsf.length >= 3 ? "Peer real £/sq ft × EPC area" : "Median real comparable price" },
            { label: "Middle range", value: `${compactPrice(low)}–${compactPrice(high)}`, detail: "Interquartile comparable evidence" },
            { label: "Comparables", value: formatNumber(comparisons.length), detail: `${insightSampleConfidence(comparisons.length)} sample strength` },
            { label: "Coordinate quality", value: `${formatNumber(exactCount)}/${formatNumber(comparisons.length)}`, detail: "Address-level pairs" }
          ]) + table + insightCaveat(`${insightUniverseBoundary("CPIH adjustment uses INSIGHT's internal annual index through 2026.")} Distances based on postcode-centroid coordinates are approximate.`)
        };
      }

      function insightRelativeValueAnswer(rows, query) {
        if (!outlierRequested(query)) return null;
        const recentStart = addMonths(analysisEnd, -60);
        const recentRows = rows.filter(item => {
          const date = parseIso(String(item.date || "").slice(0, 10));
          return date && date >= recentStart && realPpsfForSale(item) > 0;
        });
        const cohorts = new Map();
        recentRows.forEach(item => {
          const key = `${item.market}|${normalise(item.propertyType)}`;
          if (!cohorts.has(key)) cohorts.set(key, []);
          cohorts.get(key).push(realPpsfForSale(item));
        });
        const candidates = recentRows.map(item => {
          const cohort = cohorts.get(`${item.market}|${normalise(item.propertyType)}`) || [];
          if (cohort.length < 8) return null;
          const benchmark = median(cohort);
          const value = realPpsfForSale(item);
          return { item, benchmark, value, gap: benchmark ? value / benchmark - 1 : 0, cohortCount: cohort.length };
        }).filter(Boolean);
        const wantsHigh = normalise(query).includes("OVERVALUED") || normalise(query).includes("HIGH OUTLIER") || normalise(query).includes("PREMIUM");
        candidates.sort((left, right) => wantsHigh ? right.gap - left.gap : left.gap - right.gap);
        const ranked = candidates.slice(0, topCountFromQuery(query, 10));
        if (!ranked.length) return null;
        const strongest = ranked[0];
        return {
          title: wantsHigh ? "High relative-value signals" : "Low relative-value signals",
          subtitle: "Five-year prime-sale evidence",
          layout: "report",
          showLedger: false,
          rows: ranked.map(item => item.item),
          mapRows: ranked.map(item => item.item),
          html: insightLead(`${propertyDisplayName(strongest.item)} is the strongest ${wantsHigh ? "premium" : "discount"} signal in the matched cohort: its CPIH-adjusted ${compactPpsf(strongest.value)} is ${Math.abs(strongest.gap * 100).toFixed(1)}% ${strongest.gap < 0 ? "below" : "above"} the median for the same property type and authority.`) + insightMetricGrid([
            { label: "Signals shown", value: formatNumber(ranked.length), detail: "Minimum eight peer records" },
            { label: "Analysis window", value: "5 years", detail: "CPIH-adjusted sale evidence" },
            { label: "Strongest gap", value: preciseSignedPercent(strongest.gap), detail: "Versus matched peer median" },
            { label: "Peer sample", value: formatNumber(strongest.cohortCount), detail: insightSampleConfidence(strongest.cohortCount) + " strength" }
          ]) + insightTable(
            ["Property", "Sale", "Real £/sq ft", "Peer median", "Gap", "Peers"],
            ranked.map(item => [propertyDisplayName(item.item), compactPrice(item.item.price), compactPpsf(item.value), compactPpsf(item.benchmark), preciseSignedPercent(item.gap), formatNumber(item.cohortCount)])
          ) + insightCaveat(`${insightUniverseBoundary("These are historical relative-value signals, not properties currently for sale.")} A low £/sq ft can reflect condition, tenure, plot, design or data mismatch rather than mispricing.`)
        };
      }

      function pearsonCorrelation(pairs) {
        if (pairs.length < 5) return null;
        const meanX = average(pairs.map(pair => pair[0]));
        const meanY = average(pairs.map(pair => pair[1]));
        const numerator = pairs.reduce((sum, pair) => sum + (pair[0] - meanX) * (pair[1] - meanY), 0);
        const denominatorX = Math.sqrt(pairs.reduce((sum, pair) => sum + (pair[0] - meanX) ** 2, 0));
        const denominatorY = Math.sqrt(pairs.reduce((sum, pair) => sum + (pair[1] - meanY) ** 2, 0));
        return denominatorX && denominatorY ? numerator / (denominatorX * denominatorY) : null;
      }

      function insightRelationshipAnswer(rows, query) {
        if (!relationshipRequested(query)) return null;
        const qn = normalise(query);
        let title = "Evidence relationship";
        let groups = [];
        let correlation = null;
        let caveat = "Observed differences are associations in the loaded sale evidence and do not establish causation.";
        if (qn.includes("STATION") || qn.includes("TRAIN") || qn.includes("COMMUTE")) {
          title = "Station proximity and value";
          const records = rows.map(item => {
            const station = nearestStations(transactionGeoPoint(item), 1)[0];
            return station && realPpsfForSale(item) ? { item, value: realPpsfForSale(item), distance: station.distanceKm } : null;
          }).filter(Boolean);
          const definitions = [["Within 1.5km", 0, 1.5], ["1.5–3km", 1.5, 3], ["Over 3km", 3, Infinity]];
          groups = definitions.map(([label, minimum, maximum]) => {
            const matched = records.filter(record => record.distance >= minimum && record.distance < maximum);
            return { label, count: matched.length, value: median(matched.map(record => record.value)) };
          }).filter(group => group.count);
          correlation = pearsonCorrelation(records.map(record => [record.distance, record.value]));
          caveat += " Property coordinates are frequently postcode centroids, so short distances are approximate.";
        } else if (qn.includes("EPC") || qn.includes("ENERGY")) {
          title = "EPC and value";
          const definitions = [["A–B", ["A", "B"]], ["C–D", ["C", "D"]], ["E–G", ["E", "F", "G"]]];
          groups = definitions.map(([label, ratings]) => {
            const matched = rows.filter(item => ratings.includes(String(item.epcRating || "").slice(0, 1).toUpperCase()) && realPpsfForSale(item));
            return { label, count: matched.length, value: median(matched.map(realPpsfForSale)) };
          }).filter(group => group.count);
        } else if (qn.includes("PLANNING")) {
          title = "Planning history and value";
          const definitions = [["Planning history", item => planningApplicationCount(item) > 0], ["No loaded history", item => planningApplicationCount(item) === 0]];
          groups = definitions.map(([label, test]) => {
            const matched = rows.filter(item => test(item) && realPpsfForSale(item));
            return { label, count: matched.length, value: median(matched.map(realPpsfForSale)) };
          }).filter(group => group.count);
          caveat += " No loaded planning history means unknown/no match, not proof of no applications.";
        } else if (qn.includes("SCHOOL") || qn.includes("EDUCATION")) {
          title = "School proximity and value";
          const records = rows.map(item => {
            const nearest = item.ofsted?.nearestSchools?.[0];
            const metres = Number(nearest?.metres || 0);
            return metres > 0 && realPpsfForSale(item) ? { item, value: realPpsfForSale(item), distance: metres / 1000 } : null;
          }).filter(Boolean);
          const definitions = [["Within 1km", 0, 1], ["1–2km", 1, 2], ["Over 2km", 2, Infinity]];
          groups = definitions.map(([label, minimum, maximum]) => {
            const matched = records.filter(record => record.distance >= minimum && record.distance < maximum);
            return { label, count: matched.length, value: median(matched.map(record => record.value)) };
          }).filter(group => group.count);
          correlation = pearsonCorrelation(records.map(record => [record.distance, record.value]));
          caveat += " School evidence is proximity/context only, not catchment, quality or performance.";
        } else if (qn.includes("FLOOR AREA") || qn.includes("SIZE") || qn.includes("SQFT") || qn.includes("SQ FT") || qn.includes("SQUARE FOOT") || qn.includes("LARGER HOME")) {
          const usePpsf = ppsfRequested(query);
          title = usePpsf ? "Floor area and price per square foot" : "Floor area and sale value";
          const records = rows.map(item => {
            const area = Number(item.floorAreaSqft || 0);
            const value = usePpsf ? realPpsfForSale(item) : realPriceForSale(item);
            return area > 0 && value > 0 ? { item, area, value } : null;
          }).filter(Boolean);
          const areas = records.map(record => record.area);
          const lower = quantileInclusive(areas, 1 / 3);
          const upper = quantileInclusive(areas, 2 / 3);
          const definitions = [[`Under ${formatNumber(Math.round(lower))} sq ft`, 0, lower], [`${formatNumber(Math.round(lower))}–${formatNumber(Math.round(upper))} sq ft`, lower, upper], [`Over ${formatNumber(Math.round(upper))} sq ft`, upper, Infinity]];
          groups = definitions.map(([label, minimum, maximum]) => {
            const matched = records.filter(record => record.area >= minimum && record.area < maximum);
            return { label, count: matched.length, value: median(matched.map(record => record.value)), priceMetric: !usePpsf };
          }).filter(group => group.count);
          correlation = pearsonCorrelation(records.map(record => [Math.log(record.area), Math.log(record.value)]));
          caveat += ` Floor area is EPC-derived and the relationship also reflects location, condition, plot, tenure and specification.${usePpsf ? " A negative association means larger homes tend to record a lower price per square foot in this cohort." : ""}`;
        } else if (qn.includes("PRIVATE ESTATE") || qn.includes("GATED") || qn.includes("ESTATE PREMIUM")) {
          title = "Private-estate premium";
          const definitions = [["Tracked private estate", item => Boolean(estateForTransaction(item))], ["Other prime records", item => !estateForTransaction(item)]];
          groups = definitions.map(([label, test]) => {
            const matched = rows.filter(item => test(item) && realPpsfForSale(item));
            return { label, count: matched.length, value: median(matched.map(realPpsfForSale)) };
          }).filter(group => group.count);
          if (qn.includes("CONTROL")) caveat += " This two-group comparison does not control for exact location or property characteristics; a controlled premium cannot be claimed from it.";
        } else {
          return {
            title: "Evidence relationship",
            subtitle: "Dimension required",
            layout: "compact",
            showLedger: false,
            preserveMap: true,
            rows: [],
            html: insightLead("Name the relationship you want tested—for example station proximity, school proximity, EPC, planning history, floor area or private-estate status. INSIGHT will not substitute a different dimension silently.") + insightCaveat(insightUniverseBoundary())
          };
        }
        groups = groups.filter(group => group.count >= 5 && Number.isFinite(group.value) && group.value > 0);
        if (groups.length < 2) return {
          title,
          subtitle: "Insufficient comparable groups",
          layout: "compact",
          showLedger: false,
          preserveMap: true,
          rows: [],
          html: insightLead("The loaded cohort does not contain at least two comparison groups with five usable records each, so INSIGHT is not asserting a relationship.") + insightCaveat(`${caveat} ${insightUniverseBoundary()}`)
        };
        const strongest = groups.slice().sort((left, right) => right.value - left.value)[0];
        const weakest = groups.slice().sort((left, right) => left.value - right.value)[0];
        const spread = weakest.value ? strongest.value / weakest.value - 1 : 0;
        const relationshipText = correlation === null ? "" : ` The linear association is ${correlation.toFixed(2)}, which is ${Math.abs(correlation) < .2 ? "weak" : Math.abs(correlation) < .5 ? "moderate" : "strong"} in this cohort.`;
        const formatRelationshipValue = group => group.priceMetric ? compactPrice(group.value) : compactPpsf(group.value);
        return {
          title,
          subtitle: `${formatNumber(groups.reduce((sum, group) => sum + group.count, 0))} usable records`,
          layout: "analysis",
          showLedger: false,
          rows,
          html: insightLead(`${strongest.label} has the highest median CPIH-adjusted value at ${formatRelationshipValue(strongest)}, ${Math.abs(spread * 100).toFixed(1)}% above ${weakest.label.toLowerCase()}, the lowest comparison group.${relationshipText}`) + insightBarList(groups.map(group => ({ label: group.label, value: group.value, formatted: `${formatRelationshipValue(group)} · n=${formatNumber(group.count)}` }))) + insightCaveat(`${caveat} ${insightUniverseBoundary("CPIH adjustment uses INSIGHT's internal annual index through 2026.")}`)
        };
      }

      function insightRequestedModuleHtml(rows, topics) {
        const modules = [];
        const topicIds = new Set(topics.map(topic => topic.id));
        if (topicIds.has("epc")) {
          const groups = [["A–B", ["A", "B"]], ["C", ["C"]], ["D", ["D"]], ["E–G", ["E", "F", "G"]], ["Unknown", []]];
          modules.push(insightTable(["EPC band", "Properties", "Share"], groups.map(([label, ratings]) => {
            const count = ratings.length
              ? rows.filter(item => ratings.includes(String(item.epcRating || "").slice(0, 1).toUpperCase())).length
              : rows.filter(item => !String(item.epcRating || "").trim()).length;
            return [label, formatNumber(count), rows.length ? `${Math.round(count / rows.length * 100)}%` : "—"];
          }), "EPC breakdown"));
        }
        if (topicIds.has("planning")) {
          const planning = planningMetricsForRows(rows);
          modules.push(contextSection("Planning evidence", [
            ["Unique authority/reference cases", formatNumber(planning.uniqueCases)],
            ["Property-application links", formatNumber(planning.propertyLinks)],
            ["Matched properties", `${formatNumber(planning.matchedProperties)} of ${formatNumber(new Set(rows.map(propertyRecordKey)).size)}`],
            ["High-confidence cases", formatNumber(planning.highConfidenceCases)],
            ["Low-confidence cases", formatNumber(planning.lowConfidenceCases)]
          ]));
        }
        if (topicIds.has("flood")) {
          const checked = rows.filter(floodEvidenceIsFresh).length;
          const alerts = rows.filter(item => freshFloodAlertCount(item) > 0).length;
          modules.push(contextSection("Current flood evidence", [
            ["Properties with current alerts", formatNumber(alerts)],
            ["Fresh status checks", `${formatNumber(checked)} of ${formatNumber(rows.length)}`],
            ["Stale / unknown / unmatched", formatNumber(Math.max(0, rows.length - checked))],
            ["Interpretation", "Fresh current-alert context only"]
          ]));
        }
        if (topicIds.has("transport")) {
          const stationDistances = rows.map(item => nearestStations(transactionGeoPoint(item), 1)[0]?.distanceKm).filter(Number.isFinite);
          const airportTimes = rows.map(item => nearestAirports(transactionGeoPoint(item), 1)[0]?.driveMins).filter(Number.isFinite);
          modules.push(contextSection("Transport context", [
            ["Median nearest station", stationDistances.length ? formatDistanceKm(median(stationDistances)) : "Unavailable"],
            ["Within 1.5km of defined station", formatNumber(rows.filter(item => (nearestStations(transactionGeoPoint(item), 1)[0]?.distanceKm ?? Infinity) <= 1.5).length)],
            ["Median nearest airport drive", airportTimes.length ? formatMinutes(median(airportTimes)) : "Unavailable"],
            ["Distance basis", "Mapped / postcode-centroid coordinates"]
          ]));
        }
        if (topicIds.has("schools")) {
          const nearestDistances = rows.map(item => Number(item.ofsted?.nearestSchools?.[0]?.metres || 0)).filter(value => value > 0);
          modules.push(contextSection("School proximity context", [
            ["Properties with linked schools", `${formatNumber(nearestDistances.length)} of ${formatNumber(rows.length)}`],
            ["Median nearest supplied school", nearestDistances.length ? formatDistanceKm(median(nearestDistances) / 1000) : "Unavailable"],
            ["Within 1km", formatNumber(nearestDistances.filter(value => value <= 1000).length)],
            ["Interpretation", "Proximity only; not catchment or quality"]
          ]));
        }
        if (!modules.length) return "";
        return `<div class="insight-module-grid">${modules.join("")}</div>`;
      }

      function insightExecutiveBriefAnswer(rows, query, locations, dateRange, typeFilter) {
        if (!briefingRequested(query) && !compositeAnalysisRequested(query)) return null;
        if (!rows.length) return null;
        const stats = statsForRows(rows);
        const historicalSlice = isTransactionGrain(rows);
        const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
        const ppsfRows = rows.filter(item => realPpsfForSale(item) > 0);
        const ppsf = ppsfRows.map(realPpsfForSale);
        const planning = planningMetricsForRows(rows);
        const epcCovered = rows.filter(item => item.epcRating || Number(item.floorAreaSqft || 0) > 0).length;
        const floodCovered = rows.filter(floodEvidenceIsFresh).length;
        const currentAlerts = rows.filter(item => freshFloodAlertCount(item) > 0).length;
        const exactCoordinates = rows.filter(item => ["exact", "address"].includes(transactionGeoPoint(item)?.[3])).length;
        const nearestDistances = rows.map(item => nearestStations(transactionGeoPoint(item), 1)[0]?.distanceKm).filter(Number.isFinite);
        const scope = [insightLocationScopeLabel(locations), typeFilter?.label, dateRange?.label].filter(Boolean).join(" · ") || "Surrey prime evidence";
        const skew = average(prices) > median(prices) * 1.12 ? "The mean sits materially above the median, indicating a top-heavy price distribution." : "The mean and median are relatively close, suggesting a less skewed matched price distribution.";
        const activity = historicalSlice
          ? `${formatNumber(rows.length)} recorded transactions fall within the requested historical period. The current mature market-heat matrix is deliberately not projected backwards into that slice.`
          : `Market heat is ${velocityLabel(stats).toLowerCase()}; ${formatNumber(stats.recent)} recorded transactions fall in the mature 12-month window through ${formatDate(velocityAnalysisEnd.toISOString().slice(0, 10))}. It measures completed-sale pace and liquidity, not time-on-market.`;
        const movement = historicalSlice
          ? "Same-property movement is not calculated inside a pre-filtered historical transaction slice."
          : stats.priceConfidence > 0
          ? `Same-property evidence indicates ${priceMovementLabel(stats)}, based on ${priceMovementEvidenceLabel(stats).toLowerCase()}.`
          : "There is insufficient qualifying same-property evidence for a defensible real annualised price-movement estimate.";
        const coverage = `EPC evidence covers ${Math.round(epcCovered / rows.length * 100)}% of matched records; planning is linked to ${formatNumber(planning.matchedProperties)} properties and ${formatNumber(planning.uniqueCases || planning.propertyLinks)} unique or property-linked cases.`;
        const topics = explicitAnalysisTopics(query);
        return {
          title: compositeAnalysisRequested(query) ? "Multi-part analysis" : "INSIGHT briefing",
          subtitle: scope,
          layout: "report",
          showLedger: false,
          rows,
          mapRows: rows,
          html: insightLead([
            `${scope} contains ${formatNumber(rows.length)} matched ${dateRange ? "transaction" : "property"} records. The median recorded sale is ${compactPrice(median(prices))}, the average is ${compactPrice(average(prices))}, and the upper quartile begins around ${compactPrice(quantileInclusive(prices, .75))}.`,
            `${skew} ${activity}`,
            `${movement} ${coverage}`
          ]) + insightMetricGrid([
            { label: "Median sale", value: compactPrice(median(prices)), detail: `${insightSampleConfidence(rows.length)} sample strength` },
            { label: "Real median £/sq ft", value: compactPpsf(median(ppsf)) || "Unavailable", detail: `${formatNumber(ppsfRows.length)} EPC-priced records` },
            { label: historicalSlice ? "Transactions" : "Market heat", value: historicalSlice ? formatNumber(rows.length) : velocityLabel(stats), detail: historicalSlice ? dateRange?.label || "Requested period" : `${formatNumber(stats.paceScore)}/100 pace · ${formatNumber(stats.liquidityScore)}/100 liquidity` },
            { label: historicalSlice ? "Period coverage" : "Real movement", value: historicalSlice ? (dateRange?.label || "Historical slice") : priceMovementLabel(stats), detail: historicalSlice ? "No present-day score leakage" : priceMovementEvidenceLabel(stats) },
            { label: "Planning cases", value: formatNumber(planning.uniqueCases || planning.propertyLinks), detail: `${formatNumber(planning.propertyLinks)} property links` },
            { label: "EPC coverage", value: `${Math.round(epcCovered / rows.length * 100)}%`, detail: `${formatNumber(epcCovered)} of ${formatNumber(rows.length)}` },
            { label: "Flood alerts", value: formatNumber(currentAlerts), detail: `${formatNumber(floodCovered)} fresh current-alert checks` },
            { label: "Station proximity", value: nearestDistances.length ? formatDistanceKm(median(nearestDistances)) : "Unavailable", detail: "Median nearest defined station" }
          ]) + `<div class="insight-columns">${contextSection("Market reading", [
            ["Market heat", velocityLabel(stats)],
            ["Mature 12m pace", `${stats.velocity.toFixed(2)}× normal · ${formatNumber(stats.paceScore)}/100`],
            ["Peer liquidity", `${formatNumber(stats.liquidityScore)}/100`],
            ["120-day signal", accelerationLabel(stats)],
            ["Ranking evidence", rankEvidenceLabel(stats)],
            ["Real movement", priceMovementLabel(stats)],
            ["Repeat-sale evidence", priceMovementEvidenceLabel(stats)]
          ])}${contextSection("Evidence quality", [
            ["Matched records", formatNumber(rows.length)],
            ["EPC-priced records", formatNumber(ppsfRows.length)],
            ["Address-level coordinates", `${formatNumber(exactCoordinates)} of ${formatNumber(rows.length)}`],
            ["Requested modules", topics.length ? topics.map(topic => topic.label).join(", ") : "Full briefing"]
          ])}</div>` + insightRequestedModuleHtml(rows, topics) + insightCaveat(`${insightUniverseBoundary("Full histories can include earlier sub-threshold sales only for properties that entered this prime universe.")} Flood evidence is current-alert context, not long-term flood risk; school evidence is proximity/context, not catchment or performance.`)
        };
      }

      function insightCapabilityAnswer() {
        const examples = [
          ["Full briefing", "Give me a full market assessment of Cobham"],
          ["Compare", "Compare Wentworth and St George's Hill by median price and velocity"],
          ["Sales pace", "Which Surrey authorities have the strongest current velocity?"],
          ["Trends", "Show Cobham's price trend by year since 2020"],
          ["Rankings", "Top 5 private estates by £ per sq ft"],
          ["Comparables", "Find the strongest comparable sales for Cartref, Esher"],
          ["Relative value", "Which large homes look inexpensive relative to their peers?"],
          ["Relationships", "Is station proximity associated with a £ per sq ft premium?"],
          ["Property search", "Most expensive detached sale near Oxshott station"],
          ["Evidence layers", "Show the EPC breakdown and planning activity in Esher"],
          ["Data audit", "How complete is the planning and EPC data?"],
          ["Repeat sales", "Which properties in Weybridge sold more than once?"],
          ["Follow-ups", "Then ask: What about Wentworth? or Detached only?"]
        ];
        return {
          title: "Ask INSIGHT",
          subtitle: "Offline property intelligence",
          layout: "analysis",
          showLedger: false,
          preserveMap: true,
          rows: transactions,
          html: insightLead("I analyse the loaded INSIGHT property database locally. I can build full briefings, compare exact cohorts, calculate market statistics, trace monthly/quarterly/yearly evidence, select scored comparables, find relative-value outliers, test relationships and explain where evidence is incomplete.") + contextSection("Try asking", examples)
        };
      }

      function evidenceExplanationRequested(query) {
        const qn = normalise(query);
        if (relationshipRequested(query) || explicitAnalysisTopics(query).length) return false;
        return qn.includes("WHAT EVIDENCE") || qn.includes("EVIDENCE ARE YOU USING") || qn.includes("STRONGEST EVIDENCE") || qn.includes("SOURCE DATA") || qn.includes("LIMITATION") || qn.includes("WHAT CAN T THIS") || qn.includes("WHAT CANT THIS");
      }

      function insightEvidenceExplanation(rows, query) {
        if (!evidenceExplanationRequested(query)) return null;
        const qn = normalise(query);
        const planning = planningMetricsForRows(rows);
        const epc = rows.filter(item => item.epcRating || Number(item.floorAreaSqft || 0) > 0).length;
        const exact = rows.filter(item => ["exact", "address"].includes(transactionGeoPoint(item)?.[3])).length;
        if (qn.includes("STRONGEST EVIDENCE")) return { title: "Evidence hierarchy", subtitle: "Strength of conclusion", layout: "analysis", showLedger: false, preserveMap: true, rows, html: insightLead(["The strongest conclusions are direct facts from completed Land Registry transactions: recorded price, date, address and property type. They are high-confidence observations within the loaded match.", "Cohort medians, rankings and repeat-sale movement are analytical conclusions with visible denominators; their strength depends on sample depth and match quality. EPC, mapped proximity and linked planning add context but have coverage and interpretation limits.", "Relationship tests, relative-value signals and any forward scenario are the weakest form of conclusion: useful for forming questions, not for asserting causation or guaranteeing an outcome."]) + insightCaveat(insightUniverseBoundary()) };
        if (qn.includes("LIMITATION") || qn.includes("WHAT CAN T") || qn.includes("WHAT CANT")) return { title: "Evidence limits", subtitle: "Decision boundary", layout: "analysis", showLedger: false, preserveMap: true, rows, html: insightLead(["The central limitation is cohort scope: INSIGHT analyses recorded Surrey residential transactions at or above the loaded prime threshold, not every home, listing or buyer decision.", "Price Paid records describe completed transactions, not current asking prices, ownership, condition or motivation. EPC area is not a measured survey; mapped distances can use postcode centroids; planning, flood and school layers have their own coverage limits.", "Outputs are evidence-led decision support, not a formal valuation, legal conclusion, causal model, future-price forecast or personal investment recommendation."]) + insightMetricGrid([{ label: "Matched records", value: formatNumber(rows.length), detail: "Loaded analytical cohort" }, { label: "EPC evidence", value: `${formatNumber(epc)} / ${formatNumber(rows.length)}`, detail: "Area or rating present" }, { label: "Address coordinates", value: `${formatNumber(exact)} / ${formatNumber(rows.length)}`, detail: "Remaining points may be approximate" }, { label: "Planning links", value: formatNumber(planning.propertyLinks), detail: "Absence is not proof of no history" }]) + insightCaveat(insightUniverseBoundary()) };
        return { title: "Evidence basis", subtitle: "Loaded sources and calculations", layout: "analysis", showLedger: false, preserveMap: true, rows, html: insightLead(["The answer is calculated from the exact matched cohort, led by HM Land Registry Price Paid transactions and joined, where available, to EPC floor area and rating, mapped location, private-estate classification, planning context, current flood-alert context, nearby schools, stations and airports.", "INSIGHT shows the denominator behind rankings and comparisons, excludes groups below the stated sample gate, CPIH-adjusts historical price comparisons, and treats missing fields as unknown rather than negative evidence.", "The first number is the conclusion; the supporting table, cohort count and caveat are the audit trail."]) + insightMetricGrid([{ label: "Matched records", value: formatNumber(rows.length), detail: "Current evidence universe" }, { label: "EPC-linked", value: formatNumber(epc), detail: "Rating or area present" }, { label: "Address coordinates", value: formatNumber(exact), detail: "Higher-precision mapped evidence" }, { label: "Planning links", value: formatNumber(planning.propertyLinks), detail: "Loaded property applications" }]) + insightCaveat(insightUniverseBoundary()) };
      }

      function strategicQuestionRequested(query) {
        const qn = normalise(query);
        return qn.includes("BULL CASE") || qn.includes("BEAR CASE") || qn.includes("DESERVE CLOSER") || qn.includes("IMPORTANT SIGNAL") || qn.includes("STRONGEST AND WEAKEST") || qn.includes("ACTIVITY STRONGEST") || qn.includes("ACTIVITY WEAKEST");
      }

      function insightStrategicAnswer(rows, query, locations) {
        if (!strategicQuestionRequested(query) || !rows.length) return null;
        const qn = normalise(query);
        const stats = rows === transactions ? overallStats : statsForRows(rows);
        const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
        const scope = insightLocationScopeLabel(locations) || "Surrey prime evidence";
        if (qn.includes("BULL CASE") || qn.includes("BEAR CASE")) {
          const planning = planningMetricsForRows(rows);
          const bull = `${scope}'s evidence-led bull case is depth and liquidity: ${formatNumber(rows.length)} matched properties, a ${compactPrice(median(prices))} median, ${formatNumber(stats.recent)} sales in the mature 12-month window and ${priceMovementLabel(stats).toLowerCase()} same-property movement.`;
          const bear = `The bear case is ${velocityLabel(stats).toLowerCase()} market heat, combining ${formatNumber(stats.paceScore)}/100 pace with ${formatNumber(stats.liquidityScore)}/100 peer-normalised liquidity, with the result sensitive to a prime-only cohort and incomplete planning coverage (${formatNumber(planning.matchedProperties)} linked properties).`;
          const conclusion = stats.marketHeatScore >= 58 ? "On balance, the mature activity indicators are constructive, but the evidence supports further diligence rather than a blanket market call." : stats.marketHeatScore < 45 ? "On balance, the mature activity matrix is cautious; asset-specific comparables matter more than the market average." : "On balance, the mature activity matrix is mixed; pricing discipline and property-specific evidence should drive the decision.";
          return { title: "Investment case", subtitle: scope, layout: "report", showLedger: false, rows, html: insightLead([bull, bear, conclusion]) + insightMetricGrid([{ label: "Median sale", value: compactPrice(median(prices)), detail: `${formatNumber(rows.length)} matched properties` }, { label: "Market heat", value: velocityLabel(stats), detail: `${formatNumber(stats.paceScore)}/100 pace · ${formatNumber(stats.liquidityScore)}/100 liquidity` }, { label: "120-day signal", value: accelerationLabel(stats), detail: stats.signalQualified ? `${formatNumber(stats.signalRecent)} current · ${formatNumber(stats.signalBaselineTotal)} baseline` : "Unpublished below signal gate" }, { label: "Real movement", value: priceMovementLabel(stats), detail: priceMovementEvidenceLabel(stats) }, { label: "Ranking evidence", value: stats.rankEligible ? "Qualified" : "Unranked", detail: rankEvidenceLabel(stats) }]) + insightCaveat(`${insightUniverseBoundary()} The seasonally matched 120-day signal is separate and never changes market heat or rank.`) };
        }
        const marketGroups = marketDefinitions
          .map(market => ({ key: market.id, label: market.short, rows: rowsForMarket(market.id), stats: marketStats[market.id] }))
          .filter(group => group.stats?.rankEligible);
        const estateGroups = estatePins
          .map(pin => ({ key: pin.key, label: pin.name, rows: estateTransactions(pin), stats: estateStats[pin.key] }))
          .filter(group => group.stats?.rankEligible);
        const byVelocity = marketGroups.slice().sort((a, b) => compareVelocityMatrixStats(a.stats, b.stats));
        const estateLeader = estateGroups.slice().sort((a, b) => compareVelocityMatrixStats(a.stats, b.stats))[0];
        const strongest = byVelocity[0];
        const weakest = byVelocity[byVelocity.length - 1];
        if (qn.includes("STRONGEST AND WEAKEST") || qn.includes("ACTIVITY STRONGEST") || qn.includes("ACTIVITY WEAKEST")) return { title: "Activity dispersion", subtitle: "Qualified authority cohorts", layout: "analysis", showLedger: false, rows: [...(strongest?.rows || []), ...(weakest?.rows || [])], html: insightLead([`${strongest?.label || "No authority"} has the strongest qualified authority market heat at ${strongest ? velocityLabel(strongest.stats) : "unavailable"}; ${weakest?.label || "no authority"} is weakest at ${weakest ? velocityLabel(weakest.stats) : "unavailable"}.`, `The spread is ${strongest && weakest ? Math.round(strongest.stats.marketHeatScore - weakest.stats.marketHeatScore) : 0} heat points. It compares mature completed-sale pace and peer liquidity, not selling time or future returns.`, estateLeader ? `${estateLeader.label} is the leading private-estate cohort that clears the shared rank gate, at ${velocityLabel(estateLeader.stats)}. Its 120-day signal is ${accelerationLabel(estateLeader.stats).toLowerCase()} and does not affect that rank.` : "No private-estate cohort clears the shared rank gate."]) + insightTable(["Authority", "Verified sales", "Market heat", "Pace", "Liquidity", "Mature 12m", "120-day signal"], byVelocity.map(group => [group.label, formatNumber(group.stats.count), velocityLabel(group.stats), `${formatNumber(group.stats.paceScore)}/100`, `${formatNumber(group.stats.liquidityScore)}/100`, formatNumber(group.stats.recent), accelerationLabel(group.stats)])) + insightCaveat(`${insightUniverseBoundary()} Rank eligibility requires at least ${formatNumber(velocityMinimumHistorySales)} verified history sales, ${formatNumber(velocityMinimumRecentSales)} mature-window sales and ${formatNumber(velocityMinimumBaselineSales)} baseline sales.`) };
        if (qn.includes("DESERVE CLOSER")) {
          const shortlist = byVelocity.slice(0, 3);
          return { title: "Diligence shortlist", subtitle: "Signals, not recommendations", layout: "analysis", showLedger: false, rows: shortlist.flatMap(group => group.rows), html: insightLead([`${shortlist.map(group => group.label).join(", ") || "No authority"} currently deserve the closest evidence review because they lead the qualified authority matrix on mature market heat.`, "This is a research priority list, not a buy recommendation: the next step is to compare the exact property type, price band and recent comparable evidence inside each market.", `The strongest qualified shortlist signal is ${shortlist[0]?.label || "unavailable"} at ${shortlist[0] ? velocityLabel(shortlist[0].stats) : "unavailable"}; its separate 120-day direction is ${shortlist[0] ? accelerationLabel(shortlist[0].stats).toLowerCase() : "unavailable"}.`]) + insightTable(["Market", "Market heat", "Pace", "Liquidity", "Mature 12m", "Real movement", "Evidence"], shortlist.map(group => [group.label, velocityLabel(group.stats), `${formatNumber(group.stats.paceScore)}/100`, `${formatNumber(group.stats.liquidityScore)}/100`, formatNumber(group.stats.recent), priceMovementLabel(group.stats), rankEvidenceLabel(group.stats)])) + insightCaveat(`${insightUniverseBoundary()} The 120-day direction is seasonally matched across three prior years and never nudges the score.`) };
        }
        const global = overallStats;
        const velocityLeader = byVelocity[0];
        return { title: "Three signals today", subtitle: "Evidence-led market reading", layout: "analysis", showLedger: false, rows: transactions, html: insightLead([`First, the overall prime cohort is ${velocityLabel(global).toLowerCase()}: ${formatNumber(global.recent)} sales in the mature 12-month window at ${global.velocity.toFixed(2)}× normal, with ${formatNumber(global.paceScore)}/100 pace and ${formatNumber(global.liquidityScore)}/100 liquidity.`, `Second, ${velocityLeader?.label || "no authority"} has the strongest qualified authority market heat; ${estateLeader?.label || "no estate"} leads qualifying private estates. The separate 120-day signal does not alter either ranking.`, `Third, same-property evidence indicates ${priceMovementLabel(global).toLowerCase()}, based on ${priceMovementEvidenceLabel(global).toLowerCase()}. Together these signals support targeted diligence, not a broad forecast.`]) + insightMetricGrid([{ label: "Surrey market heat", value: velocityLabel(global), detail: `${formatNumber(global.paceScore)}/100 pace · ${formatNumber(global.liquidityScore)}/100 liquidity` }, { label: "120-day signal", value: accelerationLabel(global), detail: global.signalQualified ? `${formatNumber(global.signalRecent)} current · ${formatNumber(global.signalBaselineTotal)} baseline` : "Unpublished below signal gate" }, { label: "Real movement", value: priceMovementLabel(global), detail: priceMovementEvidenceLabel(global) }, { label: "Authority leader", value: velocityLeader?.label || "Unavailable", detail: velocityLeader ? velocityLabel(velocityLeader.stats) : "" }, { label: "Estate leader", value: estateLeader?.label || "Unavailable", detail: estateLeader ? velocityLabel(estateLeader.stats) : "" }]) + insightCaveat(`${insightUniverseBoundary()} Market heat is 60% mature pace and 40% peer-normalised liquidity; the 120-day signal is informational only.`) };
      }

      function insightStandaloneModuleAnswer(rows, query) {
        const topics = explicitAnalysisTopics(query);
        if (topics.length !== 1 || briefingRequested(query) || relationshipRequested(query) || nearestStationRadiusKm(query)) return null;
        const topic = topics[0];
        if (!["transport", "schools"].includes(topic.id)) return null;
        const scope = insightLocationScopeLabel(resolvedInsightLocations(query)) || "the matched cohort";
        const lead = topic.id === "transport" ? `Transport context for ${scope} is based on the nearest defined stations and airports to each mapped property. It is proximity evidence, not a door-to-door journey guarantee.` : `School evidence for ${scope} describes supplied nearby-school proximity and coverage. It does not rank school quality or establish catchment eligibility.`;
        return { title: `${topic.label} evidence`, subtitle: scope, layout: "analysis", showLedger: false, rows, html: insightLead([lead, `The calculation uses ${formatNumber(rows.length)} matched properties and reports unavailable links rather than filling them by assumption.`]) + insightRequestedModuleHtml(rows, topics) + insightCaveat(insightUniverseBoundary()) };
      }

      function scopeLevelComparisonRequested(query) {
        const qn = normalise(query);
        return qn.includes("TOWN") && (qn.includes("AUTHORITY") || qn.includes("COUNCIL") || qn.includes("BOROUGH") || qn.includes("DISTRICT"));
      }

      function insightScopeLevelComparison(query) {
        if (!scopeLevelComparisonRequested(query)) return null;
        const qn = normalise(query);
        const town = Array.from(new Set(transactions.map(item => item.town).filter(Boolean))).find(name => qn.includes(normalise(name)));
        if (!town) return null;
        const townRows = transactions.filter(item => townKey(item.town) === townKey(town));
        const namedAuthority = marketDefinitions.find(market => normalise(market.short) === normalise(town) || normalise(market.name).includes(normalise(town)));
        const authorityName = namedAuthority?.short || townRows.map(item => marketById(item.market)?.short || item.district).find(Boolean);
        const authorityRows = transactions.filter(item => (marketById(item.market)?.short || item.district) === authorityName);
        if (!townRows.length || !authorityRows.length) return null;
        const groupSeeds = [{ label: `${townDisplayName(townKey(town))} town`, rows: townRows }, { label: `${authorityName} authority`, rows: authorityRows }];
        const comparisonStats = velocityMatrixForGroups(groupSeeds.map(group => statsForRows(group.rows)));
        const groups = groupSeeds.map((group, index) => ({ ...group, stats: comparisonStats[index] }));
        const priceMedian = group => median(group.rows.map(item => Number(item.price || 0)).filter(value => value > 0));
        return { title: "Town versus authority", subtitle: "Explicit geographic scopes", layout: "report", showLedger: false, rows: authorityRows, html: insightLead([`${groups[0].label} contains ${formatNumber(townRows.length)} matched properties; ${groups[1].label} contains ${formatNumber(authorityRows.length)}. These are distinct geographic cohorts and are not interchangeable labels.`, `${groups[0].label} records a ${compactPrice(priceMedian(groups[0]))} median and ${velocityLabel(groups[0].stats)} market heat, versus ${compactPrice(priceMedian(groups[1]))} and ${velocityLabel(groups[1].stats)} across the wider authority.`, "Use the town result for place-specific pricing and the authority result for wider administrative-market context. Market heat normalises liquidity across these two explicit cohorts."]) + insightTable(["Scope", "Properties", "Median", "Average", "Market heat", "Pace", "Liquidity", "Mature 12m"], groups.map(group => [group.label, formatNumber(group.rows.length), compactPrice(priceMedian(group)), compactPrice(group.stats.avg), velocityLabel(group.stats), `${formatNumber(group.stats.paceScore)}/100`, `${formatNumber(group.stats.liquidityScore)}/100`, formatNumber(group.stats.recent)])) + insightCaveat(`${insightUniverseBoundary()} Unqualified cohorts remain visible but are explicitly unranked.`) };
      }

      function nearestStationRadiusKm(query) {
        const qn = normalise(query);
        if (!qn.includes("STATION") || !qn.includes("WITHIN")) return null;
        const numeric = qn.match(/WITHIN\s+(\d+(?:\.\d+)?)\s*(KM|KILOMET|MILE)/);
        const word = qn.match(/WITHIN\s+(ONE|TWO|THREE|FOUR|FIVE)\s*(KM|KILOMET|MILE)/);
        const words = { ONE: 1, TWO: 2, THREE: 3, FOUR: 4, FIVE: 5 };
        const value = numeric ? Number(numeric[1]) : word ? words[word[1]] : null;
        const unit = numeric?.[2] || word?.[2] || "";
        return value ? value * (unit.startsWith("MILE") ? 1.609344 : 1) : null;
      }

      function saleAnswer(item, query, label = "Matched sale") {
        if (!item) return "";
        const point = transactionGeoPoint(item);
        const station = nearestStations(point, 1)[0];
        const airport = nearestAirports(point, 1)[0];
        const estate = estateForTransaction(item);
        const latestEpc = latestEpcSnapshot(item);
        const rows = [
          ["Property", propertyDisplayName(item)],
          ["Address", propertyAddressLabel(item)],
          ["Sold price", item.priceText || compactPrice(item.price)],
          ["Sale date", formatDate(item.date)],
          ["Type", item.propertyType],
          ["Market", marketById(item.market)?.short || item.district],
          ...(estate ? [["Private estate", estate.name]] : []),
          ["£/sq ft", compactPpsf(item.pricePerSqft) || "Awaiting EPC"],
          ["EPC area", compactSqft(item.floorAreaSqft)],
          ["EPC rating", latestEpc.rating, latestEpc.date ? formatDate(latestEpc.date) : ""],
          ["Planning history", formatNumber(planningApplicationCount(item))],
          ["Flood status", floodStatusForDisplay(item)],
          ["Nearest station", station ? `${station.name} · ${formatDistanceKm(station.distanceKm)} · ${formatMinutes(station.fastestMins)} to ${station.london}` : ""],
          ["Nearest airport", airport ? `${airport.name} · drive c. ${formatMinutes(airport.driveMins)}` : ""]
        ];
        const nameWanted = normalise(query).includes("NAME");
        const displayName = propertyDisplayName(item);
        const reference = /^\d+$/.test(displayName) ? propertyAddressLabel(item) : displayName;
        const answer = nameWanted
          ? `The property name shown in the loaded Land Registry address is ${reference}.`
          : `${reference} is the ${label.toLowerCase()}: it sold for ${item.priceText || compactPrice(item.price)} on ${formatDate(item.date)}.`;
        const interpretation = label.includes("Largest") ? `Its matched EPC floor area is ${compactSqft(item.floorAreaSqft) || "unavailable"}. EPC area is documentary evidence, not a measured building survey.` : label.includes("Latest") ? "This is the latest completed transaction in the exact matched cohort, not a live listing or asking-price signal." : label.includes("Cheapest") ? "This is the lowest completed price in the exact matched cohort; it is not evidence that the property was undervalued." : "This is the highest completed price in the exact matched cohort; it should be treated as an extreme observation, not the typical market level.";
        return insightLead([answer, interpretation]) + dataRows(rows) + insightCaveat(insightUniverseBoundary());
      }

      function fuzzyPropertyRows(rows, query) {
        const generic = new Set(normalise("ABOUT ANALYSE ANALYSIS AVERAGE COMPARE DATA DETACHED EPC ESTATE EVIDENCE FIND FLOOD GIVE GROWTH HIGHEST INSIGHT LATEST LED MARKET MEDIAN PLANNING PRICE PROPERTY RANGE REPORT SALE SALES SHOW SIMILAR STRONGEST TREND VALUE VALUATION VELOCITY").split(" "));
        const tokens = insightQueryTokens(query).filter(token => token.length > 2 && !generic.has(token));
        if (tokens.length < 2) return [];
        return rows.map(item => {
          const textTokens = rowInsightText(item).split(" ");
          const matched = tokens.filter(token => textTokens.some(candidate => candidate === token || (token.length > 5 && editDistance(token, candidate) === 1)));
          return { item, score: matched.length / tokens.length, matched: matched.length };
        }).filter(result => result.matched >= Math.min(2, tokens.length) && result.score >= .55)
          .sort((a, b) => b.score - a.score || Number(b.item.price || 0) - Number(a.item.price || 0))
          .map(result => result.item);
      }

      function insightNarrativeAnswer(rows, query, locations, dateRange, typeFilter) {
        const qn = normalise(query);
        const stats = statsForRows(rows);
        const prices = rows.map(item => Number(item.price || 0)).filter(value => value > 0);
        const floorAreas = rows.map(item => Number(item.floorAreaSqft || 0)).filter(value => value > 0);
        const ppsf = rows.map(item => Number(item.pricePerSqft || 0)).filter(value => value > 0);
        const stationRadius = nearestStationRadiusKm(query);
        const scope = [insightLocationScopeLabel(locations), typeFilter?.label, dateRange?.label, stationRadius ? `within ${formatDistanceKm(stationRadius)} of a defined station` : ""].filter(Boolean).join(" · ") || "loaded INSIGHT market";
        let answer;
        if (insightIntent(query) === "velocity") {
          answer = stats.transactionGrain
            ? `${scope} contains ${formatNumber(rows.length)} recorded transactions. The current mature market-heat matrix is intentionally not applied to a historical transaction slice; ask for a trend or compare period volumes for historical pace.`
            : `${scope} records ${velocityLabel(stats)} market heat: ${formatNumber(stats.paceScore)}/100 pace and ${formatNumber(stats.liquidityScore)}/100 peer-normalised liquidity. There were ${formatNumber(stats.recent)} sales in the mature 12-month window through ${formatDate(velocityAnalysisEnd.toISOString().slice(0, 10))}, running at ${stats.velocity.toFixed(2)}x the three-year annual baseline after the four-sale prior. The separate seasonally matched 120-day signal is ${accelerationLabel(stats).toLowerCase()}; ${rankEvidenceLabel(stats).toLowerCase()}.`;
        } else if (insightIntent(query) === "growth") {
          answer = stats.priceConfidence > 0
            ? `${scope} records ${priceMovementLabel(stats)}, based on ${priceMovementEvidenceLabel(stats).toLowerCase()}. Prices are CPIH-adjusted, annualised over each holding period and aggregated from repeat sales of the same property.`
            : `There is insufficient repeat-sale evidence to estimate real annualised price movement for ${scope}. At least three qualifying same-property pairs are required, so INSIGHT is not inferring movement from a changing mix of homes.`;
        } else if (insightIntent(query) === "planning") {
          const planning = planningMetricsForRows(rows);
          const total = planning.uniqueCases || planningApplicationVolumeForRows(rows);
          answer = `${formatNumber(total)} unique or property-linked planning cases are attached to ${formatNumber(planning.matchedProperties)} of the ${formatNumber(rows.length)} matched properties in ${scope}. There are ${formatNumber(planning.propertyLinks)} property-application links; duplicate authority/reference cases are counted once in the area total.`;
        } else if (insightIntent(query) === "flood") {
          const fresh = rows.filter(floodEvidenceIsFresh);
          const alerts = fresh.filter(item => freshFloodAlertCount(item) > 0).length;
          answer = fresh.length
            ? `${formatNumber(alerts)} of ${formatNumber(fresh.length)} freshly checked matched properties carry a current loaded flood alert. ${formatNumber(rows.length - fresh.length)} stale, unavailable or unmatched records are treated as unknown, not low risk.`
            : `None of the ${formatNumber(rows.length)} matched properties has a flood-alert check that passes the current freshness gate. Current exposure is unknown, not low risk.`;
        } else if (insightIntent(query) === "epc") {
          const covered = rows.filter(item => item.epcRating || Number(item.floorAreaSqft || 0) > 0).length;
          answer = `EPC evidence is available for ${formatNumber(covered)} of ${formatNumber(rows.length)} matched properties in ${scope}. Where floor area is present, the average is ${compactSqft(average(floorAreas)) || "unavailable"} and the average sale price per square foot is ${compactPpsf(average(ppsf)) || "unavailable"}.`;
        } else if (insightIntent(query) === "ppsf") {
          const useMedian = qn.includes("MEDIAN");
          const value = useMedian ? median(ppsf) : average(ppsf);
          answer = `The ${useMedian ? "median" : "average"} recorded sale price per square foot is ${compactPpsf(value) || "unavailable"} across ${formatNumber(ppsf.length)} EPC-priced records in ${scope}. ${formatNumber(Math.max(0, rows.length - ppsf.length))} matched records do not have usable floor-area evidence.`;
        } else if (insightIntent(query) === "size") {
          const useMedian = qn.includes("MEDIAN");
          const value = useMedian ? median(floorAreas) : average(floorAreas);
          answer = `The ${useMedian ? "median" : "average"} EPC floor area is ${compactSqft(value) || "unavailable"} across ${formatNumber(floorAreas.length)} usable records in ${scope}. EPC area is an evidence field, not a measured survey area.`;
        } else if (qn.includes("MEDIAN")) {
          answer = `The median matched sale price is ${compactPrice(median(prices))} across ${formatNumber(rows.length)} properties in ${scope}. The average is ${compactPrice(average(prices))}, so the ${average(prices) > median(prices) ? "upper end is pulling the mean above the typical transaction" : "mean and midpoint are relatively close"}.`;
        } else if (insightIntent(query) === "count") {
          answer = `${formatCount(rows.length, stats.transactionGrain ? "transaction" : "property", stats.transactionGrain ? "transactions" : "properties")} ${rows.length === 1 ? "matches" : "match"} ${scope}. Their average sale price is ${compactPrice(stats.avg)}, the median is ${compactPrice(median(prices))}, and the highest recorded sale is ${compactPrice(stats.max)}.`;
        } else {
          answer = `${formatCount(rows.length, "matched property", "matched properties")} in ${scope} ${rows.length === 1 ? "has" : "have"} an average recorded sale price of ${compactPrice(stats.avg)} and a median of ${compactPrice(median(prices))}. The highest loaded sale is ${compactPrice(stats.max)}; ${formatCount(stats.recent, "sale")} ${stats.recent === 1 ? "falls" : "fall"} within the mature ${stats.velocityWindowMonths}-month activity window.`;
        }
        let investorMeaning;
        const intent = insightIntent(query);
        if (intent === "velocity") investorMeaning = `For decision-making, read market heat as a 60/40 composite of mature completed-transaction pace and peer-normalised liquidity—not selling speed. The 120-day direction is published only when it clears its separate evidence gate, and it never changes the heat score or rank.`;
        else if (intent === "growth") investorMeaning = stats.priceConfidence > 0 ? "The result is based on repeat sales rather than a changing mix of properties, but refurbishment, extension and tenure changes can still affect it." : "The defensible conclusion is that the evidence is insufficient; INSIGHT is not replacing missing repeat sales with a mixed-median proxy.";
        else if (intent === "planning") investorMeaning = stats.planningApplications ? "Loaded planning links provide context, not proof that works were implemented or that the archive is complete." : "No linked planning evidence is not evidence of no planning activity; the correct investment conclusion is that this layer is currently unknown.";
        else if (intent === "flood") investorMeaning = "This is current-alert context only. It cannot rank long-term flood safety or replace property-specific searches and professional diligence.";
        else if (intent === "epc" || intent === "size" || intent === "ppsf") investorMeaning = "EPC-linked evidence supports broad comparison, but floor area is not a measured survey and unmatched records are excluded from the denominator.";
        else investorMeaning = average(prices) > median(prices) * 1.12 ? "The mean sits above the median, so a small number of high-value transactions are lifting the headline average. The median is the safer description of the typical matched sale." : "The mean and median are comparatively close, so the matched distribution is not being dominated by a handful of extreme prices.";
        const evidenceReading = `${insightSampleConfidence(rows.length)} cohort depth from ${formatNumber(rows.length)} matched ${stats.transactionGrain ? "transactions" : "properties"}. The supporting records below are the audit trail for the conclusion.`;
        const list = sortRowsForQuery(rows, query).slice(0, topCountFromQuery(query, 6)).map(item => contextItem(propertyDisplayName(item), `${item.priceText || compactPrice(item.price)} · ${formatDate(item.date)} · ${item.propertyType || "Property"} · ${marketById(item.market)?.short || item.district || ""}`));
        return {
          title: "Ask INSIGHT",
          subtitle: formatCount(rows.length, stats.transactionGrain ? "matched transaction" : "matched property", stats.transactionGrain ? "matched transactions" : "matched properties"),
          layout: "analysis",
          rows: sortRowsForQuery(rows, query),
          html: insightLead([answer, investorMeaning, evidenceReading]) + insightMetricGrid([
            { label: "Median sale", value: compactPrice(median(prices)), detail: formatCount(rows.length, "matched record") },
            { label: "Average sale", value: compactPrice(stats.avg), detail: average(prices) > median(prices) * 1.12 ? "Top-heavy distribution" : "Close to median" },
            { label: qn.includes("MEDIAN") && insightIntent(query) === "ppsf" ? "Median £/sq ft" : "Average £/sq ft", value: compactPpsf(qn.includes("MEDIAN") && insightIntent(query) === "ppsf" ? median(ppsf) : stats.ppsfAvg) || "Unavailable", detail: formatCount(ppsf.length, "EPC-priced record") },
            { label: stats.transactionGrain ? "Period transactions" : "Velocity", value: stats.transactionGrain ? formatNumber(rows.length) : velocityLabel(stats), detail: stats.transactionGrain ? dateRange?.label || "Requested period" : `${formatCount(stats.recent, "sale")} in 12 months` },
            { label: stats.transactionGrain ? "Period evidence" : "Real movement", value: stats.transactionGrain ? insightSampleConfidence(rows.length) : priceMovementLabel(stats), detail: stats.transactionGrain ? "No present-day score leakage" : priceMovementEvidenceLabel(stats) },
            { label: "Planning cases", value: formatNumber(stats.planningApplications), detail: "Deduplicated where references are loaded" }
          ]) + insightEvidenceDetails("Show supporting records", `<div class="context-list">${list.join("")}</div>`) + insightCaveat(`${insightUniverseBoundary()} Missing evidence is unknown, not a negative result. Velocity is transaction activity pace, not selling speed.`)
        };
      }

      function insightAnswer(query, baseRows = state.selectedRows, options = {}) {
        const rawQuery = String(query || "").trim();
        if (capabilityRequested(rawQuery)) return insightCapabilityAnswer();
        const rawEvidence = insightEvidenceExplanation(transactions, rawQuery);
        if (rawEvidence) return rawEvidence;
        const scopeComparison = insightScopeLevelComparison(rawQuery);
        if (scopeComparison) return scopeComparison;
        const rawBoundary = unavailableDataResponse(rawQuery) || guardrailResponse(rawQuery, options.useContext !== false);
        if (rawBoundary) return rawBoundary;
        const effectiveQuery = options.useContext === false ? rawQuery : effectiveInsightQuery(query);
        if (capabilityRequested(effectiveQuery)) return insightCapabilityAnswer();
        const guarded = unavailableDataResponse(effectiveQuery);
        if (guarded) return guarded;
        const comparableAnswer = outlierRequested(effectiveQuery) ? null : insightComparableAnswer(transactions, effectiveQuery);
        if (comparableAnswer) return comparableAnswer;
        const qn = normalise(effectiveQuery);
        const locations = resolvedInsightLocations(effectiveQuery);
        const isComparison = comparisonRequested(effectiveQuery, locations);
        const contextualBase = state.selectedType !== "overview" && !locations.length ? baseRows : transactions;
        let rows = contextualBase.slice();
        if (locations.length) rows = filterRowsByInsightLocations(rows, locations, isComparison);

        const dateRange = dateRangeFromQuery(effectiveQuery);
        const isTrend = trendRequested(effectiveQuery) && !relationshipRequested(effectiveQuery);
        const usesTransactionGrain = Boolean(dateRange) || isTrend;
        if (usesTransactionGrain) rows = activityRowsForProperties(rows);
        const typeFilter = propertyTypeFromQuery(effectiveQuery);
        const densityQuestion = typeFilter && (qn.includes("DENSITY") || qn.includes("SHARE") || qn.includes("CONCENTRATION"));
        if (typeFilter && !densityQuestion) rows = rows.filter(typeFilter.test);
        const stationRadiusKm = nearestStationRadiusKm(effectiveQuery);
        if (stationRadiusKm) rows = rows.filter(item => (nearestStations(transactionGeoPoint(item), 1)[0]?.distanceKm ?? Infinity) <= stationRadiusKm);

        const ppsfRange = rangeFromValues(effectiveQuery, ppsfValuesFromQuery(effectiveQuery));
        if (ppsfRange) {
          rows = rows.filter(item => {
            const value = Number(item.pricePerSqft || 0);
            if (!value) return false;
            if (ppsfRange.min && value < ppsfRange.min) return false;
            if (ppsfRange.max && value > ppsfRange.max) return false;
            if (ppsfRange.exact && Math.abs(value - ppsfRange.exact) > Math.max(10, ppsfRange.exact * .02)) return false;
            return true;
          });
        }

        const sqftRange = rangeFromValues(effectiveQuery, sqftValuesFromQuery(effectiveQuery));
        if (sqftRange && !ppsfRange) {
          rows = rows.filter(item => {
            const value = Number(item.floorAreaSqft || 0);
            if (!value) return false;
            if (sqftRange.min && value < sqftRange.min) return false;
            if (sqftRange.max && value > sqftRange.max) return false;
            if (sqftRange.exact && Math.abs(value - sqftRange.exact) > Math.max(100, sqftRange.exact * .03)) return false;
            return true;
          });
        }

        const priceRange = rangeFromValues(effectiveQuery, moneyValuesFromQuery(effectiveQuery, true));
        if (priceRange && !ppsfRange && !sqftRange) {
          rows = rows.filter(item => {
            const value = Number(item.price || 0);
            if (priceRange.min && value < priceRange.min) return false;
            if (priceRange.max && value > priceRange.max) return false;
            if (priceRange.exact && Math.abs(value - priceRange.exact) > priceRange.exact * .04) return false;
            return true;
          });
        }

        const trendAnswer = insightTrendAnswer(rows, effectiveQuery, dateRange);
        if (trendAnswer) return trendAnswer;

        if (dateRange) {
          rows = rows.filter(item => {
            const date = parseIso(item.date);
            return date && (!dateRange.from || date >= dateRange.from) && (!dateRange.to || date <= dateRange.to);
          });
        }

        const comparisonAnswer = insightComparisonAnswer(rows, effectiveQuery, locations);
        if (comparisonAnswer) return comparisonAnswer;
        const relativeValueAnswer = insightRelativeValueAnswer(rows, effectiveQuery);
        if (relativeValueAnswer) return relativeValueAnswer;
        const relationshipAnswer = insightRelationshipAnswer(rows, effectiveQuery);
        if (relationshipAnswer) return relationshipAnswer;
        const strategicAnswer = insightStrategicAnswer(rows, effectiveQuery, locations);
        if (strategicAnswer) return strategicAnswer;
        const briefingAnswer = insightExecutiveBriefAnswer(rows, effectiveQuery, locations, dateRange, typeFilter);
        if (briefingAnswer) return briefingAnswer;
        const repeatAnswer = insightRepeatSalesAnswer(rows, effectiveQuery);
        if (repeatAnswer) return repeatAnswer;
        const coverageAnswer = insightCoverageAnswer(rows, effectiveQuery);
        if (coverageAnswer) return coverageAnswer;
        const distributionAnswer = insightDistributionAnswer(rows, effectiveQuery);
        if (distributionAnswer) return distributionAnswer;
        const moduleAnswer = insightStandaloneModuleAnswer(rows, effectiveQuery);
        if (moduleAnswer) return moduleAnswer;

        const groupAnswer = insightGroupAnswer(rows, effectiveQuery, typeFilter);
        if (groupAnswer) return groupAnswer;

        if (!locations.length && !dateRange && !typeFilter && !priceRange && !ppsfRange && !sqftRange) {
          const textRows = rows.filter(item => rowInsightText(item).includes(qn));
          const fuzzyRows = textRows.length ? [] : fuzzyPropertyRows(rows, effectiveQuery);
          if (textRows.length || fuzzyRows.length) rows = textRows.length ? textRows : fuzzyRows;
        }

        const sorted = sortRowsForQuery(rows, effectiveQuery);
        const asksSingle = qn.includes("MOST EXPENSIVE") || qn.includes("HIGHEST SALE") || qn.includes("HIGHEST RECORDED SALE") || qn.includes("CHEAPEST") || qn.includes("LOWEST PRICE") || qn.includes("LOWEST PRICED") || qn.includes("LATEST") || qn.includes("MOST RECENT") || qn.includes("NEWEST") || qn.includes("OLDEST") || qn.includes("LARGEST") || qn.includes("BIGGEST") || qn.includes("NAME");

        if (!sorted.length) {
          return {
            title: "Ask INSIGHT",
            subtitle: "No loaded matches",
            rows: [],
            html: textSection("Answer", "No matching records were found in the loaded INSIGHT dataset. Try a broader location, date, price band or property type.")
          };
        }

        if (asksSingle) {
          const label = qn.includes("CHEAPEST") || qn.includes("LOWEST PRICE") || qn.includes("LOWEST PRICED") ? "Cheapest matched sale"
            : qn.includes("LATEST") || qn.includes("MOST RECENT") || qn.includes("NEWEST") ? "Latest matched sale"
            : qn.includes("OLDEST") ? "Oldest matched sale"
            : qn.includes("LARGEST") || qn.includes("BIGGEST") ? "Largest matched EPC area"
            : "Highest matched sale";
          return {
            title: "Ask INSIGHT",
            subtitle: `${formatNumber(sorted.length)} loaded matches`,
            rows: sorted,
            html: saleAnswer(sorted[0], effectiveQuery, label)
          };
        }
        return insightNarrativeAnswer(sorted, effectiveQuery, locations, dateRange, typeFilter);
      }

      function currentInsightAnswer() {
        const query = insightQuestion();
        if (!query) return null;
        const cacheKey = [normalise(query), state.selectedType, propertyId(state.selectedId), state.selectedRows.length, landRegMeta.to || ""].join("|");
        if (state.insightAnswerCache?.key === cacheKey) return state.insightAnswerCache.answer;
        const raw = insightAnswer(query, state.selectedRows);
        const answer = raw ? {
          layout: raw.layout || (raw.showLedger === false ? "analysis" : "compact"),
          evidenceRows: Array.isArray(raw.evidenceRows) ? raw.evidenceRows : raw.rows,
          ...raw
        } : null;
        state.insightAnswerCache = { key: cacheKey, answer };
        return answer;
      }

      // Stable local analyst seam for future INSIGHT sections. Consumers ask
      // for an evidence-bound answer; they do not reimplement parsing or gain
      // direct write access to the underlying datasets.
      window.INSIGHT_ANALYST = Object.freeze({
        version: "2.0-local",
        analyse(question) {
          const answer = insightAnswer(String(question || ""), transactions, { useContext: false });
          return answer ? {
            ...answer,
            matchedCount: Array.isArray(answer.rows) ? answer.rows.length : 0,
            universe: insightUniverseBoundary()
          } : null;
        },
        capabilities: Object.freeze(["briefing", "comparison", "trend", "ranking", "comparables", "relative-value", "relationship", "repeat-sales", "distribution", "coverage"])
      });
      window.INSIGHT_BOOT_STAGE = "interface";

      function rememberInsightQuery(query) {
        const clean = String(query || "").trim();
        if (clean.length < 4 || capabilityRequested(clean)) return;
        state.insightContext = { query: clean, rememberedAt: Date.now() };
      }

      function rowsMatchingSearch(rows) {
        const question = insightQuestion();
        if (question) {
          const answer = rows === state.selectedRows ? currentInsightAnswer() : insightAnswer(question, rows);
          const answerRows = Array.isArray(answer?.evidenceRows) ? answer.evidenceRows : Array.isArray(answer?.rows) ? answer.rows : [];
          return answerRows;
        }
        const query = normalise(state.search);
        return !query ? rows : rows.filter(item => {
          const text = normalise([item.address, item.postcode, item.town, item.district, item.propertyType, item.priceText].join(" "));
          return text.includes(query);
        });
      }

      function selectOverview() {
        closeToday({ render: false, restoreFocus: false });
        state.selectedType = "overview";
        state.selectedId = null;
        state.selectedRows = transactions;
        recordSelectionHistory();
        renderAll();
      }

      function resetMap() {
        clearHoveredMapFeature();
        hideMapTooltip();
        selectOverview();
        if (map) map.jumpTo({ center: [-0.43, 51.29], zoom: mapZoomFromDisplay(defaultZoomLevel), padding: overviewMapPadding });
      }

      function selectMarket(id) {
        closeToday({ render: false, restoreFocus: false });
        const market = marketById(id);
        state.selectedType = "market";
        state.selectedId = id;
        state.selectedRows = rowsForMarket(id);
        recordSelectionHistory();
        if (map && market && districtGeoPoints[market.district]) {
          map.jumpTo({ center: districtGeoPoints[market.district], zoom: 10.4, padding: selectionMapPadding });
        }
        renderAll();
      }

      function selectEstate(key) {
        closeToday({ render: false, restoreFocus: false });
        const estate = estatePins.find(pin => pin.key === key);
        if (!estate) return;
        state.selectedType = "estate";
        state.selectedId = key;
        state.selectedRows = estateTransactions(key);
        recordSelectionHistory();
        const navigationAnchor = estateNavigationAnchors.find(pin => pin.key === key);
        const center = estateCenter(navigationAnchor);
        if (map && center) map.jumpTo({ center, zoom: 12.8, padding: selectionMapPadding });
        renderAll();
      }

      function selectTown(key) {
        closeToday({ render: false, restoreFocus: false });
        const point = townGeoPoints[key];
        state.selectedType = "town";
        state.selectedId = key;
        state.selectedRows = rowsForTownKey(key);
        recordSelectionHistory();
        if (map && point) map.jumpTo({ center: point, zoom: 12.8, padding: selectionMapPadding });
        renderAll();
      }

      function selectProperty(id) {
        closeToday({ render: false, restoreFocus: false });
        const idText = propertyId(id);
        const item = transactionsById.get(idText);
        if (!item) return;
        state.selectedType = "property";
        state.selectedId = idText;
        state.selectedRows = [item];
        recordSelectionHistory();
        const point = transactionGeoPoint(item);
        const targetZoom = point[3] === "exact" || point[3] === "address" ? 14.8 : 14.4;
        if (map) map.jumpTo({ center: [point[0], point[1]], zoom: targetZoom, padding: selectionMapPadding });
        renderAll();
        if (window.requestAnimationFrame) window.requestAnimationFrame(applyMapStateToMap);
      }

      function selectSchool(id) {
        closeToday({ render: false, restoreFocus: false });
        const school = schoolById(id);
        if (!school) return;
        const point = schoolCoordinate(school);
        state.selectedType = "school";
        state.selectedId = schoolId(school);
        state.selectedRows = nearbyTransactionsForPoint(point, 2.5);
        recordSelectionHistory();
        if (map && point) map.easeTo({ center: point, zoom: Math.max(map.getZoom(), 14.2), padding: selectionMapPadding, duration: 650 });
        renderAll();
      }

      function selectStation(id) {
        closeToday({ render: false, restoreFocus: false });
        const station = stationById(id);
        if (!station) return;
        const point = stationCoordinate(station);
        state.selectedType = "station";
        state.selectedId = station.id;
        state.selectedRows = nearbyTransactionsForPoint(point, 3);
        recordSelectionHistory();
        if (map && point) map.easeTo({ center: point, zoom: Math.max(map.getZoom(), 13.8), padding: selectionMapPadding, duration: 650 });
        renderAll();
      }

      function selectAirport(id) {
        closeToday({ render: false, restoreFocus: false });
        const airport = airportById(id);
        if (!airport) return;
        const point = airportCoordinate(airport);
        state.selectedType = "airport";
        state.selectedId = airport.id;
        state.selectedRows = nearbyTransactionsForPoint(point, 18);
        recordSelectionHistory();
        if (map && point) map.easeTo({ center: point, zoom: Math.max(map.getZoom(), 11.6), padding: selectionMapPadding, duration: 650 });
        renderAll();
      }

      function recordSelectionHistory() {
        if (restoringSelectionHistory) return;
        const snapshot = { type: state.selectedType, id: state.selectedId == null ? null : String(state.selectedId) };
        const current = selectionHistory[selectionHistoryIndex];
        if (current && current.type === snapshot.type && current.id === snapshot.id) return;
        selectionHistory.splice(selectionHistoryIndex + 1);
        selectionHistory.push(snapshot);
        selectionHistoryIndex = selectionHistory.length - 1;
      }

      function navigateSelectionHistory(direction) {
        const nextIndex = clamp(0, selectionHistory.length - 1, selectionHistoryIndex + Number(direction || 0));
        if (nextIndex === selectionHistoryIndex) return false;
        selectionHistoryIndex = nextIndex;
        const snapshot = selectionHistory[selectionHistoryIndex];
        restoringSelectionHistory = true;
        try {
          if (snapshot.type === "overview") resetMap();
          else if (snapshot.type === "market") selectMarket(snapshot.id);
          else if (snapshot.type === "estate") selectEstate(snapshot.id);
          else if (snapshot.type === "town") selectTown(snapshot.id);
          else if (snapshot.type === "property") selectProperty(snapshot.id);
          else if (snapshot.type === "school") selectSchool(snapshot.id);
          else if (snapshot.type === "station") selectStation(snapshot.id);
          else if (snapshot.type === "airport") selectAirport(snapshot.id);
        } finally {
          restoringSelectionHistory = false;
        }
        return true;
      }

      window.INSIGHT_NAVIGATE_HISTORY = navigateSelectionHistory;

      function newsTimestamp(value) {
        const timestamp = Date.parse(String(value || ""));
        return Number.isFinite(timestamp) ? timestamp : 0;
      }

      function newsRelativeTime(value) {
        const timestamp = newsTimestamp(value);
        if (!timestamp) return "Recently";
        const seconds = Math.max(0, Math.round((Date.now() - timestamp) / 1000));
        if (seconds < 90) return "Just now";
        const minutes = Math.round(seconds / 60);
        if (minutes < 60) return `${minutes} min ago`;
        const hours = Math.round(minutes / 60);
        if (hours < 24) return `${hours} hr ago`;
        const days = Math.round(hours / 24);
        return days === 1 ? "Yesterday" : `${days} days ago`;
      }

      function newsPublisherKey(item) {
        return String(item?.publisherGroup || item?.sourceId || item?.source || item?.url || "")
          .trim()
          .toLowerCase();
      }

      function leadingNewsItems(items) {
        if (items.length <= newsCollapsedLimit) return items;
        const selected = [items[0]];
        for (const item of items.slice(1)) {
          if (!selected.some(existing => newsPublisherKey(existing) === newsPublisherKey(item))) selected.push(item);
          if (selected.length === newsCollapsedLimit) return selected;
        }
        for (const item of items.slice(1)) {
          if (!selected.includes(item)) selected.push(item);
          if (selected.length === newsCollapsedLimit) break;
        }
        return selected;
      }

      function renderNews() {
        if (!els.newsList) return;
        const valid = newsItems
          .filter(item => item && safeHttpsUrl(item.url) && item.title && Number(item.score) >= 0)
          .sort((left, right) => String(right.publishedAt || "").localeCompare(String(left.publishedAt || "")) || Number(right.score || 0) - Number(left.score || 0));
        const visible = newsExpanded ? valid.slice(0, newsExpandedLimit) : leadingNewsItems(valid);
        const previousTimestamp = newsTimestamp(newsPreviousVisit);
        const newCount = valid.filter(item => newsTimestamp(item.publishedAt) > previousTimestamp).length;

        if (els.newsNewCount) {
          els.newsNewCount.hidden = newCount === 0;
          els.newsNewCount.textContent = newCount ? `${Math.min(newCount, 99)} new` : "";
        }
        if (els.newsMoreButton) {
          els.newsMoreButton.hidden = valid.length <= newsCollapsedLimit;
          els.newsMoreButton.textContent = newsExpanded ? "Show less" : `View all ${Math.min(valid.length, newsExpandedLimit)}`;
          els.newsMoreButton.setAttribute("aria-expanded", newsExpanded ? "true" : "false");
        }
        els.newsList.classList.toggle("expanded", newsExpanded);

        if (!visible.length) {
          els.newsList.innerHTML = '<p class="news-empty">No relevant new stories. INSIGHT will keep checking.</p>';
        } else {
          els.newsList.innerHTML = visible.map(item => {
            const url = safeHttpsUrl(item.url);
            const isNew = newsTimestamp(item.publishedAt) > previousTimestamp;
            const topic = Array.isArray(item.topics) && item.topics.length ? item.topics[0] : "Property";
            const meta = [item.source, item.location, topic, newsRelativeTime(item.publishedAt)].filter(Boolean).join(" · ");
            return `
              <a class="news-item${isNew ? "" : " seen"}" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(item.title)}. ${escapeHtml(item.reason || meta)}">
                <span class="news-unread-dot" aria-hidden="true"></span>
                <span>
                  <span class="news-item-title">${escapeHtml(item.title)}</span>
                  <span class="news-item-meta">${escapeHtml(meta)}</span>
                </span>
              </a>`;
          }).join("");
        }

        if (els.newsFeedStatus) {
          const errors = Array.isArray(newsMeta.sourceErrors) ? newsMeta.sourceErrors.length : 0;
          const status = [];
          if (newsMeta.generatedAt) status.push(`Last checked ${newsRelativeTime(newsMeta.generatedAt)}`);
          if (valid[0]?.publishedAt) status.push(`Newest article ${newsRelativeTime(valid[0].publishedAt)}`);
          if (errors) status.push(`${errors} source${errors === 1 ? "" : "s"} delayed`);
          if (newsRuntimeStatus) status.push(newsRuntimeStatus);
          els.newsFeedStatus.textContent = status.join(" · ");
        }
      }

      function todayItems(value) {
        return Array.isArray(value) ? value.filter(item => item && typeof item === "object") : [];
      }

      function todayVelocitySnapshotForRows(rows, analysisThrough, activityOverride = null) {
        const activityRows = Array.isArray(activityOverride)
          ? activityOverride.slice()
          : activityRowsForProperties(rows);
        const snapshotStart = startOfUtcMonth(addMonths(analysisThrough, -(velocityWindowMonths - 1)));
        const snapshotBaselineStart = addMonths(snapshotStart, -(velocityBaselineYears * 12));
        const recent = activityRows.filter(item => {
          const observed = parseIso(item.date);
          return observed && observed >= snapshotStart && observed <= analysisThrough;
        });
        const baseline = activityRows.filter(item => {
          const observed = parseIso(item.date);
          return observed && observed >= snapshotBaselineStart && observed < snapshotStart;
        });
        const baselineTotal = baseline.length;
        const baselineAnnual = baselineTotal / velocityBaselineYears;
        const velocity = activityRows.length
          ? (recent.length + velocityPriorSales) / (baselineAnnual + velocityPriorSales)
          : 0;
        return {
          count: activityRows.length,
          recent: recent.length,
          baselineTotal,
          velocity,
          paceScore: activityRows.length
            ? Math.round(clamp(0, 100, paceScoreForRatio(velocity)))
            : 0,
          liquidityLog: Math.log1p(recent.length),
          rankEligible:
            recent.length >= velocityMinimumRecentSales &&
            baselineTotal >= velocityMinimumBaselineSales &&
            activityRows.length >= velocityMinimumHistorySales
        };
      }

      function todayVelocitySnapshotMatrix(entries) {
        const liquidityReference = Math.max(
          0,
          ...entries.map(entry => Number(entry.stats?.liquidityLog) || 0)
        );
        return Object.fromEntries(entries.map(entry => [
          entry.id,
          applyVelocityMatrix(entry.stats, liquidityReference)
        ]));
      }

      function todayVelocityRanks(entries, statsById) {
        const ranked = entries.filter(entry => statsById[entry.id]?.rankEligible).sort((left, right) => {
          const leftStats = statsById[left.id];
          const rightStats = statsById[right.id];
          return (
            rightStats.marketHeatScore - leftStats.marketHeatScore ||
            rightStats.paceScore - leftStats.paceScore ||
            rightStats.recent - leftStats.recent ||
            left.label.localeCompare(right.label)
          );
        });
        return new Map(ranked.map((entry, index) => [entry.id, index + 1]));
      }

      function buildTodayMarketChanges() {
        const previousAnalysisThrough = endOfUtcMonth(
          addMonths(startOfUtcMonth(velocityAnalysisEnd), -1)
        );
        const scopes = [
          {
            type: "market",
            label: "Authority",
            entries: marketDefinitions.map(market => ({
              id: market.id,
              label: market.short,
              rows: rowsForMarket(market.id)
            })),
            current: marketStats
          },
          {
            type: "town",
            label: "Town",
            entries: analyticalTownKeys.map(key => ({
              id: key,
              label: townDisplayName(key),
              rows: rowsForTownKey(key)
            })),
            current: townStats
          },
          {
            type: "estate",
            label: "Estate",
            entries: estatePins.map(pin => ({
              id: pin.key,
              label: pin.name,
              rows: estateTransactions(pin),
              activityRows: estateActivityRows(pin)
            })),
            current: estateStats
          }
        ];
        const candidates = [];
        scopes.forEach(scope => {
          const previousEntries = scope.entries.map(entry => ({
            id: entry.id,
            stats: todayVelocitySnapshotForRows(
              entry.rows,
              previousAnalysisThrough,
              entry.activityRows
            )
          }));
          const previous = todayVelocitySnapshotMatrix(previousEntries);
          const currentRanks = todayVelocityRanks(scope.entries, scope.current);
          const previousRanks = todayVelocityRanks(scope.entries, previous);
          scope.entries.forEach(entry => {
            const currentStats = scope.current[entry.id];
            const previousStats = previous[entry.id];
            if (!currentStats?.rankEligible || !previousStats?.rankEligible) return;
            const currentRank = currentRanks.get(entry.id);
            const previousRank = previousRanks.get(entry.id);
            const scoreDelta = currentStats.marketHeatScore - previousStats.marketHeatScore;
            const rankDelta = Number(previousRank) - Number(currentRank);
            const recentDelta = currentStats.recent - previousStats.recent;
            const previousBand = velocityRating(previousStats.marketHeatScore);
            const currentBand = velocityRating(currentStats.marketHeatScore);
            if (!scoreDelta && !rankDelta && !recentDelta) return;
            candidates.push({
              id: entry.id,
              name: entry.label,
              type: scope.type,
              scope: scope.label,
              previousScore: previousStats.marketHeatScore,
              currentScore: currentStats.marketHeatScore,
              scoreDelta,
              previousRank,
              currentRank,
              rankDelta,
              previousRecent: previousStats.recent,
              currentRecent: currentStats.recent,
              recentDelta,
              previousBand,
              currentBand,
              bandChanged: previousBand !== currentBand,
              material:
                Math.abs(scoreDelta) >= 3 ||
                Math.abs(rankDelta) >= 2 ||
                Math.abs(recentDelta) >= 2 ||
                previousBand !== currentBand
            });
          });
        });
        const material = candidates.filter(item => item.material);
        const selected = material.length ? material : candidates;
        return {
          previousAnalysisThrough: previousAnalysisThrough.toISOString().slice(0, 10),
          analysisThrough: velocityAnalysisEnd.toISOString().slice(0, 10),
          items: selected.sort((left, right) => (
            Number(right.bandChanged) - Number(left.bandChanged) ||
            Math.abs(right.scoreDelta) - Math.abs(left.scoreDelta) ||
            Math.abs(right.rankDelta) - Math.abs(left.rankDelta) ||
            Math.abs(right.recentDelta) - Math.abs(left.recentDelta) ||
            left.scope.localeCompare(right.scope) ||
            left.name.localeCompare(right.name)
          )).slice(0, 12)
        };
      }

      function todayMarketChangesData() {
        if (!todayMarketChangesCache) todayMarketChangesCache = buildTodayMarketChanges();
        return todayMarketChangesCache;
      }

      function buildTodayNewSales() {
        const latestValue = String(
          landRegMeta.latestObservedSaleDate ||
          transactionRows[0]?.date ||
          ""
        ).slice(0, 10);
        const through = parseIso(latestValue);
        if (!through) return { from: "", through: "", items: [] };
        const fromDate = addDays(through, -29);
        const seenProperties = new Set();
        const items = transactionRows.filter(item => {
          const observed = parseIso(String(item.date || "").slice(0, 10));
          if (!observed || observed < fromDate || observed > through) return false;
          const key = propertyRecordKey(item);
          if (!key || seenProperties.has(key)) return false;
          seenProperties.add(key);
          return true;
        }).map(item => {
          const navigationId = todayPropertyNavigationId({
            property: {
              transactionId: item.id,
              propertyId: item.propertyRecordId,
              address: item.address,
              postcode: item.postcode
            },
            propertyIds: item.propertyRecordId ? [item.propertyRecordId] : []
          });
          return {
            item,
            navigationId,
            propertyName: propertyDisplayName(item),
            address: propertyAddressWithoutName(item),
            place: townDisplayName(townKey(item.town)) || item.town || item.district || "",
            price: Number(item.price) || 0,
            transferDate: String(item.date || "").slice(0, 10)
          };
        }).filter(item => item.navigationId).sort((left, right) => (
          right.transferDate.localeCompare(left.transferDate) ||
          right.price - left.price ||
          left.propertyName.localeCompare(right.propertyName)
        ));
        return {
          from: fromDate.toISOString().slice(0, 10),
          through: through.toISOString().slice(0, 10),
          items: items.slice(0, 12)
        };
      }

      function todayNewSalesData() {
        if (!todayNewSalesCache) todayNewSalesCache = buildTodayNewSales();
        return todayNewSalesCache;
      }

      function insightViewDateParts(value) {
        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ""));
        if (!match) return null;
        const year = Number(match[1]);
        const month = Number(match[2]);
        const day = Number(match[3]);
        const date = new Date(Date.UTC(year, month - 1, day));
        if (
          date.getUTCFullYear() !== year ||
          date.getUTCMonth() !== month - 1 ||
          date.getUTCDate() !== day
        ) return null;
        return { date, year, month, day };
      }

      function insightViewOrdinal(value) {
        const day = Number(value);
        const remainder = day % 100;
        if (remainder >= 11 && remainder <= 13) return `${day}th`;
        return `${day}${({ 1: "st", 2: "nd", 3: "rd" })[day % 10] || "th"}`;
      }

      function insightViewDatedLine(value) {
        const parsed = insightViewDateParts(value);
        if (!parsed) return "";
        const weekday = new Intl.DateTimeFormat("en-GB", {
          weekday: "long",
          timeZone: "UTC"
        }).format(parsed.date);
        const month = new Intl.DateTimeFormat("en-GB", {
          month: "long",
          timeZone: "UTC"
        }).format(parsed.date);
        return `${weekday}, ${insightViewOrdinal(parsed.day)} ${month}`;
      }

      function insightViewObservationLabel(value, options = {}) {
        const text = String(value || "");
        if (/^\d{4}-\d{2}$/.test(text)) {
          return new Date(`${text}-01T00:00:00Z`).toLocaleDateString("en-GB", {
            month: options.short ? "short" : "long",
            year: "numeric",
            timeZone: "UTC"
          });
        }
        const parsed = insightViewDateParts(text);
        if (!parsed) return text;
        return parsed.date.toLocaleDateString("en-GB", {
          day: "numeric",
          month: options.short ? "short" : "long",
          year: options.year === false ? undefined : "numeric",
          timeZone: "UTC"
        });
      }

      function insightViewPercent(value) {
        const number = Number(value);
        return Number.isFinite(number) ? `${number.toFixed(2)}%` : "—";
      }

      function insightViewDecisionDetail(policy) {
        const remaining = Math.max(0, Math.round(Number(policy?.countdownDays) || 0));
        const time = String(policy?.nextDecisionTime || "");
        if (remaining === 0) return `The next MPC decision is today at ${time}`;
        if (remaining === 1) return `The next MPC decision is tomorrow at ${time}`;
        return `It is ${formatNumber(remaining)} days until the next MPC decision`;
      }

      function insightViewTrendSymbol(trend) {
        if (trend === "up") return " ↑";
        if (trend === "down") return " ↓";
        return "";
      }

      function insightViewTrendClass(trend) {
        if (trend === "down") return "today-direction-positive";
        if (trend === "up") return "today-direction-negative";
        return "";
      }

      function renderInsightView() {
        if (!els.todayInsightView) return;
        const view = insightView;
        const valid = view &&
          view.schemaVersion === 1 &&
          insightViewDateParts(view.briefingDate) &&
          view.policy &&
          view.mortgage &&
          Array.isArray(view.narrative) &&
          view.narrative.length === 2;
        if (!valid) {
          if (els.todayViewAnalysis) {
            els.todayViewAnalysis.innerHTML =
              "<p>The last validated rates and market snapshot could not be loaded.</p>";
          }
          if (els.todayViewStatus) {
            els.todayViewStatus.textContent =
              insightViewRuntimeStatus || "Waiting for a validated INSIGHT View";
          }
          return;
        }

        const policy = view.policy;
        const mortgage = view.mortgage;
        if (els.todayViewBankRate) {
          els.todayViewBankRate.textContent = insightViewPercent(policy.bankRate);
        }
        if (els.todayViewBankRateDetail) {
          els.todayViewBankRateDetail.textContent =
            `Observed ${insightViewObservationLabel(policy.bankRateObservedOn, { short: true })}`;
        }
        if (els.todayViewNextDecision) {
          els.todayViewNextDecision.textContent =
            `${insightViewObservationLabel(policy.nextDecisionDate, { year: false })} · ${policy.nextDecisionTime}`;
        }
        if (els.todayViewNextDecisionDetail) {
          els.todayViewNextDecisionDetail.textContent = insightViewDecisionDetail(policy);
        }
        if (els.todayViewPolicySignal) {
          els.todayViewPolicySignal.textContent = String(policy.signalValue || "—");
        }
        if (els.todayViewPolicySignalDetail) {
          els.todayViewPolicySignalDetail.textContent = String(policy.signalDetail || "");
        }
        if (els.todayViewMortgageRate) {
          els.todayViewMortgageRate.textContent =
            `${insightViewPercent(mortgage.rate)}${insightViewTrendSymbol(mortgage.trend)}`;
          els.todayViewMortgageRate.classList.remove(
            "today-direction-positive",
            "today-direction-negative"
          );
          const trendClass = insightViewTrendClass(mortgage.trend);
          if (trendClass) els.todayViewMortgageRate.classList.add(trendClass);
        }
        if (els.todayViewMortgageRateDetail) {
          const observation = insightViewObservationLabel(
            String(mortgage.observationDate || "").slice(0, 7),
            { short: true }
          );
          els.todayViewMortgageRateDetail.textContent =
            `${mortgage.qualifier || "BoE quoted · 75% LTV"} · ${observation}`;
        }
        if (els.todayViewAnalysis) {
          els.todayViewAnalysis.innerHTML = view.narrative
            .map((paragraph, index) => {
              const datedOpening = index === 0
                ? `It is <strong><time datetime="${escapeHtml(view.briefingDate)}">${escapeHtml(insightViewDatedLine(view.briefingDate))}</time></strong>. `
                : "";
              return `<p>${datedOpening}${escapeHtml(paragraph)}</p>`;
            })
            .join("");
        }
        if (els.todayViewSources) {
          els.todayViewSources.textContent = (view.sources || []).map(source => {
            const observed = insightViewObservationLabel(source.observedAt, { short: true });
            return observed ? `${source.name} · ${observed}` : source.name;
          }).join(" · ");
        }
        if (els.todayViewStatus) {
          const staleCount = Array.isArray(view.staleSources) ? view.staleSources.length : 0;
          const status = staleCount
            ? `Latest available official observations · ${formatNumber(staleCount)} source refresh delayed`
            : `Daily view updated ${newsRelativeTime(view.generatedAt)}`;
          els.todayViewStatus.textContent = [status, insightViewRuntimeStatus]
            .filter(Boolean)
            .join(" · ");
        }
      }

      function todayFilterKinds(item) {
        const typedKinds = Array.isArray(item?.attributes?.signalKinds)
          ? item.attributes.signalKinds.map(value => normalise(value || "")).filter(Boolean)
          : [];
        const kindFilters = {
          "PROPERTY PLANNING": "planning",
          "EPC OBSERVATION": "epc",
          "SALE AGE MILESTONE": "mature-holding"
        };
        const filters = new Set();
        typedKinds.forEach(text => {
          if (kindFilters[text]) filters.add(kindFilters[text]);
        });
        if (Number(item?.independentSourceCount || 0) >= 2) filters.add("hot");
        return Array.from(filters);
      }

      function todayOpportunityItems(value) {
        const seenPropertyIds = new Set();
        return todayItems(value).filter(item => {
          if (
            normalise(item?.lane || "") !== "OPPORTUNITIES" ||
            normalise(item?.kind || "") !== "PROPERTY OPPORTUNITY"
          ) return false;
          const propertyIds = Array.isArray(item?.propertyIds) ? item.propertyIds : [];
          const propertyId = String(item?.property?.propertyId || propertyIds[0] || item?.id || "").trim();
          if (!propertyId || seenPropertyIds.has(propertyId)) return false;
          seenPropertyIds.add(propertyId);
          return true;
        });
      }

      function todayMatchesFilter(item) {
        if (state.todayFilter === "all") return true;
        return todayFilterKinds(item).includes(state.todayFilter);
      }

      function todayItemTimestamp(item) {
        const value = item?.effectiveDate || item?.observedAt || item?.date || "";
        const timestamp = Date.parse(value);
        return Number.isFinite(timestamp) ? timestamp : 0;
      }

      function todayKindLabel(item) {
        const labels = todayFilterKinds(item).map(kind => ({
          planning: "Planning",
          epc: "EPC",
          "mature-holding": "Mature holding"
        })[kind]).filter(Boolean);
        if (labels.length) return labels.join(" + ");
        return String(item?.kind || "Property opportunity")
          .replace(/[_-]+/g, " ")
          .replace(/\b\w/g, letter => letter.toUpperCase());
      }

      function todayOpportunityLevel(item) {
        const level = normalise(item?.opportunityLevel || "");
        if (level === "VERY HOT") return "Very Hot";
        if (level === "HOT") return "Hot";
        return "Standard";
      }

      function todayDateLabel(item) {
        const value = item?.effectiveDate || item?.observedAt || item?.date || "";
        if (!value) return "Recently";
        const precision = normalise(item?.datePrecision || "");
        if (precision === "YEAR" && /^\d{4}/.test(value)) return String(value).slice(0, 4);
        if (precision === "MONTH" && /^\d{4}-\d{2}/.test(value)) {
          return new Date(`${String(value).slice(0, 7)}-01T00:00:00Z`).toLocaleDateString("en-GB", {
            month: "short",
            year: "numeric",
            timeZone: "UTC"
          });
        }
        const relative = newsRelativeTime(value);
        const formatted = formatPlanningDate(value);
        return formatted && relative !== formatted ? `${relative} · ${formatted}` : relative;
      }

      function todayPropertyNavigationId(item) {
        const property = item?.property && typeof item.property === "object" ? item.property : {};
        const flatPropertyIds = Array.isArray(item?.propertyIds) && item.propertyIds.length === 1
          ? item.propertyIds
          : [];
        const candidates = [
          property.transactionId,
          property.selectedId,
          property.id,
          item?.transactionId,
          item?.selectedId,
          property.propertyId,
          ...flatPropertyIds
        ].map(value => propertyId(value)).filter(Boolean);
        for (const candidate of candidates) {
          if (transactionsById.has(candidate)) return candidate;
        }
        const canonicalPropertyId = propertyId(property.propertyId || flatPropertyIds[0]);
        let match = canonicalPropertyId
          ? transactions.find(transaction => propertyRecordKey(transaction) === canonicalPropertyId || propertyId(transaction.propertyRecordId) === canonicalPropertyId)
          : null;
        if (!match && property.address) {
          const address = propertyAddressIdentity(property.address);
          const postcode = normalisePostcode(property.postcode);
          match = transactions.find(transaction => {
            return propertyAddressIdentity(transaction.address) === address &&
              (!postcode || normalisePostcode(transaction.postcode) === postcode);
          });
        }
        return match ? propertyId(match.id) : "";
      }

      function todayEvidenceLabel(item) {
        const directSource = normalise(item?.sourceFamily) === "INSIGHT" ? [] : [item?.source];
        const sources = [
          ...directSource,
          ...todayItems(item?.evidence).map(evidence => evidence.source)
        ].map(source => String(source || "").trim()).filter(Boolean);
        const uniqueSources = Array.from(new Set(sources)).slice(0, 3);
        const confidence = String(item?.confidence || "").trim();
        const confidenceLabel = confidence
          ? `${confidence.charAt(0).toUpperCase()}${confidence.slice(1).toLowerCase()} confidence`
          : "";
        return [confidenceLabel, uniqueSources.join(" + ")].filter(Boolean).join(" · ");
      }

      function todayCardHtml(item) {
        const property = item?.property && typeof item.property === "object" ? item.property : {};
        const propertyTitle = property.address || [property.town, property.postcode].filter(Boolean).join(" · ");
        const title = propertyTitle || item.title || "Property opportunity";
        const fact = item.fact || item.summary || item.title || "A qualifying property indicator has been recorded.";
        const why = item.why || "";
        const firstLimitation = Array.isArray(item.limitations)
          ? String(item.limitations.find(Boolean) || "")
          : "";
        const context = item.context || firstLimitation ||
          "This evidence warrants review, but it does not establish owner intent or a future transaction.";
        const navigationId = todayPropertyNavigationId(item);
        const evidence = todayEvidenceLabel(item);
        const opportunityLevel = todayOpportunityLevel(item);
        const opportunityLevelClass = opportunityLevel.toLowerCase().replace(/\s+/g, "-");
        return `
          <article class="today-card today-card-${opportunityLevelClass}" data-opportunity-level="${opportunityLevelClass}">
            <div class="today-card-meta">
              <span class="today-card-classification">
                <span class="today-card-kind">${escapeHtml(todayKindLabel(item))}</span>
                <span class="today-card-level today-card-level-${opportunityLevelClass}" aria-label="Opportunity level: ${opportunityLevel}">${opportunityLevel}</span>
              </span>
              <time datetime="${escapeHtml(item.effectiveDate || item.date || "")}">${escapeHtml(todayDateLabel(item))}</time>
            </div>
            <h4>${escapeHtml(title)}</h4>
            <p class="today-card-fact">${escapeHtml(fact)}</p>
            ${why ? `<div class="today-card-detail"><strong>Why it surfaced</strong><span>${escapeHtml(why)}</span></div>` : ""}
            <div class="today-card-detail today-card-context"><strong>Context</strong><span>${escapeHtml(context)}</span></div>
            ${evidence ? `<p class="today-card-evidence">${escapeHtml(evidence)}</p>` : ""}
            ${navigationId ? `<button class="today-open-property" type="button" data-today-property="${escapeHtml(navigationId)}">Open property</button>` : ""}
          </article>`;
      }

      function todaySignedNumber(value) {
        const number = Math.round(Number(value) || 0);
        if (!number) return "0";
        return `${number > 0 ? "+" : "−"}${formatNumber(Math.abs(number))}`;
      }

      function todayDirectionClass(value) {
        const number = Number(value) || 0;
        if (number > 0) return "today-direction-positive";
        if (number < 0) return "today-direction-negative";
        return "";
      }

      function todayMarketChangesHtml(data) {
        if (!data.items.length) {
          return '<div class="today-empty">No comparable market change clears the materiality and evidence gates at both mature cuts.</div>';
        }
        return `
          <div class="today-data-header" aria-hidden="true">
            <span>Place</span><span>Market heat</span><span>Rank</span><span>Mature sales</span>
          </div>
          ${data.items.map(item => `
            <article class="today-data-row">
              <div class="today-data-primary">
                <button class="today-entity-link" type="button" data-today-entity-type="${escapeHtml(item.type)}" data-today-entity-id="${escapeHtml(item.id)}">${escapeHtml(item.name)}</button>
                <small class="${todayDirectionClass(item.scoreDelta)}">${escapeHtml(item.scope)} · ${escapeHtml(item.previousBand)} → ${escapeHtml(item.currentBand)} · ${escapeHtml(todaySignedNumber(item.scoreDelta))}</small>
              </div>
              <div class="today-data-metric ${todayDirectionClass(item.scoreDelta)}"><strong>${formatNumber(item.previousScore)} → ${formatNumber(item.currentScore)}</strong><small>Market heat</small></div>
              <div class="today-data-metric ${todayDirectionClass(item.rankDelta)}"><strong>#${formatNumber(item.previousRank)} → #${formatNumber(item.currentRank)}</strong><small>Qualified rank</small></div>
              <div class="today-data-metric ${todayDirectionClass(item.recentDelta)}"><strong>${formatNumber(item.previousRecent)} → ${formatNumber(item.currentRecent)}</strong><small>Sales in mature 12m</small></div>
            </article>
          `).join("")}`;
      }

      function todayNewSalesHtml(data) {
        if (!data.items.length) {
          return '<div class="today-empty">No map-linked sale falls inside the latest loaded 30-day completion cohort.</div>';
        }
        return `
          <div class="today-data-header" aria-hidden="true">
            <span>Property</span><span>Place</span><span>Price</span><span>Transfer</span>
          </div>
          ${data.items.map(entry => `
            <article class="today-data-row">
              <div class="today-data-primary">
                <button class="today-entity-link" type="button" data-today-property="${escapeHtml(entry.navigationId)}">${escapeHtml(entry.propertyName)}</button>
                <small>${escapeHtml(entry.address)}</small>
              </div>
              <div class="today-data-metric"><strong>${escapeHtml(entry.place || "—")}</strong><small>Town</small></div>
              <div class="today-data-metric"><strong>£${formatNumber(entry.price)}</strong><small>Price Paid</small></div>
              <div class="today-data-metric"><strong>${escapeHtml(formatDate(entry.transferDate))}</strong><small>Transfer date</small></div>
            </article>
          `).join("")}`;
      }

      function todayAtAGlanceHtml(changes, sales, opportunities) {
        const change = changes.items[0];
        const sale = sales.items[0];
        const opportunity = opportunities[0]?.item;
        const opportunityProperty = opportunity?.property && typeof opportunity.property === "object"
          ? opportunity.property
          : {};
        const opportunityTitle = opportunityProperty.address || opportunity?.title || "No current property opportunity";
        const opportunityLevel = opportunity ? todayOpportunityLevel(opportunity) : "";
        const opportunityKinds = opportunity ? todayKindLabel(opportunity) : "INSIGHT will keep checking";
        return [
          {
            tab: "market-changes",
            label: "Market changes",
            title: change
              ? `${change.name} · ${formatNumber(change.previousScore)} → ${formatNumber(change.currentScore)}`
              : "No comparable material mover",
            detail: change
              ? `${change.scope} · ${change.previousBand} → ${change.currentBand} · ${todaySignedNumber(change.scoreDelta)} heat`
              : "Every visible cohort must qualify at both mature cuts"
          },
          {
            tab: "new-sales",
            label: "New sales",
            title: sale
              ? `${sale.propertyName} · £${formatNumber(sale.price)}`
              : "No sale in the latest loaded cohort",
            detail: sale
              ? `Latest loaded Price Paid sale · transferred ${formatDate(sale.transferDate)}`
              : "The source does not expose a first-seen registration date"
          },
          {
            tab: "opportunities",
            label: "Opportunities",
            title: opportunity
              ? `${opportunityTitle} · ${opportunityLevel}`
              : "No qualifying property opportunity",
            detail: opportunity ? `${opportunityKinds} evidence` : opportunityKinds
          }
        ].map(item => `
          <div class="today-glance-line">
            <button class="today-glance-link" type="button" data-today-route="${escapeHtml(item.tab)}">${escapeHtml(item.label)}</button>
            <span class="today-glance-copy"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.detail)}</span></span>
          </div>
        `).join("");
      }

      function setTodayTab(tabId, options = {}) {
        const next = els.todayTabButtons.some(button => button.dataset.todayTab === tabId)
          ? tabId
          : "briefing";
        state.todayTab = next;
        renderTodayDrawer();
        if (options.focus !== false) {
          window.requestAnimationFrame?.(() => {
            els.todayTabButtons.find(button => button.dataset.todayTab === next)?.focus();
          });
        }
      }

      function openTodayEntity(type, id) {
        if (type === "market") selectMarket(id);
        else if (type === "town") selectTown(id);
        else if (type === "estate") selectEstate(id);
      }

      function todayBriefingLabel(value = new Date()) {
        const hour = value instanceof Date ? value.getHours() : new Date(value).getHours();
        if (hour >= 17) return `Good Evening, ${todayUserName}`;
        if (hour >= 12) return `Good Afternoon, ${todayUserName}`;
        return `Good Morning, ${todayUserName}`;
      }

      function updateTodayBriefingLabel(value = new Date()) {
        if (els.todayKicker) els.todayKicker.textContent = todayBriefingLabel(value);
      }

      function scheduleTodayBriefingLabel() {
        if (todayBriefingTimer !== null) window.clearTimeout(todayBriefingTimer);
        const now = new Date();
        updateTodayBriefingLabel(now);
        const next = new Date(now);
        if (now.getHours() < 12) {
          next.setHours(12, 0, 0, 0);
        } else if (now.getHours() < 17) {
          next.setHours(17, 0, 0, 0);
        } else {
          next.setDate(next.getDate() + 1);
          next.setHours(0, 0, 0, 0);
        }
        const delay = Math.max(1000, next.getTime() - now.getTime() + 100);
        todayBriefingTimer = window.setTimeout(scheduleTodayBriefingLabel, delay);
      }

      function updateTodayVisibility() {
        const open = Boolean(state.todayOpen);
        if (els.app) els.app.dataset.todayOpen = open ? "true" : "false";
        if (els.todayDrawer) {
          els.todayDrawer.hidden = false;
          els.todayDrawer.setAttribute("aria-hidden", open ? "false" : "true");
          if (open) els.todayDrawer.removeAttribute("inert");
          else els.todayDrawer.setAttribute("inert", "");
        }
        if (els.brandTitle) els.brandTitle.setAttribute("aria-expanded", open ? "true" : "false");
        if (els.askForm) {
          if (open) {
            els.askForm.setAttribute("inert", "");
            els.askForm.setAttribute("aria-hidden", "true");
          } else {
            els.askForm.removeAttribute("inert");
            els.askForm.removeAttribute("aria-hidden");
          }
        }
        if (map && window.requestAnimationFrame) {
          window.requestAnimationFrame(() => map.resize());
        }
      }

      function renderTodayDrawer() {
        if (!els.todayDrawer || !els.todayCards) return;
        const opportunities = todayOpportunityItems(todayFeed.opportunities)
          .map((item, index) => ({ item, index })).sort((left, right) => {
          return todayItemTimestamp(right.item) - todayItemTimestamp(left.item) ||
            left.index - right.index;
        });
        const changes = todayMarketChangesData();
        const sales = todayNewSalesData();
        updateTodayBriefingLabel();
        renderInsightView();

        const tabCounts = {
          "market-changes": changes.items.length,
          "new-sales": sales.items.length,
          opportunities: opportunities.length
        };
        if (els.todayTabMarketChangesCount) {
          els.todayTabMarketChangesCount.textContent = formatNumber(tabCounts["market-changes"]);
        }
        if (els.todayTabNewSalesCount) {
          els.todayTabNewSalesCount.textContent = formatNumber(tabCounts["new-sales"]);
        }
        if (els.todayTabOpportunitiesCount) {
          els.todayTabOpportunitiesCount.textContent = formatNumber(tabCounts.opportunities);
        }
        els.todayTabButtons.forEach(button => {
          const tabId = button.dataset.todayTab || "briefing";
          const selected = tabId === state.todayTab;
          button.classList.toggle("active", selected);
          button.setAttribute("aria-selected", selected ? "true" : "false");
          button.setAttribute("tabindex", selected ? "0" : "-1");
          const count = tabCounts[tabId];
          const label = button.querySelector("span")?.textContent || tabId;
          button.setAttribute(
            "aria-label",
            Number.isFinite(count)
              ? `${label}, ${formatNumber(count)} item${count === 1 ? "" : "s"}`
              : label
          );
        });
        els.todayTabPanels.forEach(panel => {
          panel.hidden = panel.dataset.todayPanel !== state.todayTab;
        });

        if (els.todayAtAGlance) {
          els.todayAtAGlance.innerHTML = todayAtAGlanceHtml(changes, sales, opportunities);
        }
        if (els.todayMarketChanges) {
          els.todayMarketChanges.innerHTML = todayMarketChangesHtml(changes);
        }
        if (els.todayMarketChangesMeta) {
          els.todayMarketChangesMeta.textContent = `${formatNumber(changes.items.length)} qualified · ${formatDate(changes.previousAnalysisThrough)} → ${formatDate(changes.analysisThrough)}`;
        }
        if (els.todayNewSales) {
          els.todayNewSales.innerHTML = todayNewSalesHtml(sales);
        }
        if (els.todayNewSalesMeta) {
          els.todayNewSalesMeta.textContent = sales.through
            ? `${formatNumber(sales.items.length)} records · ${formatDate(sales.from)}–${formatDate(sales.through)}`
            : "Loaded Price Paid evidence";
        }

        els.todayFilters?.querySelectorAll("[data-today-filter]").forEach(button => {
          button.setAttribute("aria-pressed", button.dataset.todayFilter === state.todayFilter ? "true" : "false");
          const filter = button.dataset.todayFilter || "all";
          const count = filter === "all"
            ? opportunities.length
            : opportunities.filter(entry => todayFilterKinds(entry.item).includes(filter)).length;
          const countElement = button.querySelector("[data-today-filter-count]");
          if (countElement) countElement.textContent = formatNumber(count);
          button.setAttribute(
            "aria-label",
            `${button.querySelector("span")?.textContent || filter}, ${formatNumber(count)} ${count === 1 ? "opportunity" : "opportunities"}`
          );
        });

        const visibleItems = opportunities.filter(entry => todayMatchesFilter(entry.item));
        els.todayCards.innerHTML = visibleItems.map(entry => todayCardHtml(entry.item)).join("") ||
          '<div class="today-empty">No property opportunities match this filter. INSIGHT will keep checking the loaded evidence.</div>';

        if (els.todayFeedStatus) {
          const generatedAt = todayMeta.generatedAt || todayFeed.generatedAt || "";
          const status = [generatedAt
            ? `Briefing updated ${newsRelativeTime(generatedAt)}`
            : "Loaded briefing"];
          if (todayRuntimeStatus) status.push(todayRuntimeStatus);
          els.todayFeedStatus.textContent = status.join(" · ");
        }
        updateTodayVisibility();
      }

      function openToday(options = {}) {
        clearInsightQuestion(true);
        state.todayOpen = true;
        try {
          sessionStorage.setItem(todaySessionStateKey, "open");
        } catch (_error) {
          // A disabled session-storage policy should not affect the briefing.
        }
        renderInspector();
        renderLedger();
        updatePropertyMapSource();
        renderTodayDrawer();
        if (options.focus !== false && els.todayHeading) {
          window.requestAnimationFrame?.(() => els.todayHeading.focus());
        }
      }

      function closeToday(options = {}) {
        if (!state.todayOpen) return;
        state.todayOpen = false;
        try {
          sessionStorage.setItem(todaySessionStateKey, "closed");
        } catch (_error) {
          // A disabled session-storage policy should not affect the briefing.
        }
        updateTodayVisibility();
        if (options.render !== false) {
          renderInspector();
          renderLedger();
          updatePropertyMapSource();
        }
        if (options.restoreFocus !== false && els.brandTitle) els.brandTitle.focus();
      }

      function toggleToday() {
        if (state.todayOpen) closeToday();
        else openToday();
      }

      function renderAll() {
        renderLayers();
        renderNews();
        renderSummary();
        renderMarkets();
        renderEstates();
        renderTowns();
        renderInspector();
        renderLedger();
        renderLegend();
        renderTodayDrawer();
        updateZoomUi();
        applyMapStateToMap();
      }

      function mapStyleReady() {
        return Boolean(map && map.getStyle && map.getStyle() && map.getLayer("property-points"));
      }

      function applyMapStateToMap() {
        if (!mapStyleReady()) return;
        updatePropertyMapSource();
        applyLayerVisibility();
        applyRenderMode();
        applyEstatePointSelection();
      }

      function applyEstatePointSelection() {
        if (!map) return;
        if (map.getSource("estates")) {
          if (selectedEstatePointId) {
            map.setFeatureState({ source: "estates", id: selectedEstatePointId }, { selected: false });
          }
          const nextPointId = state.selectedType === "estate" ? String(state.selectedId || "") : "";
          selectedEstatePointId = estateNavigationAnchors.some(anchor => anchor.key === nextPointId) ? nextPointId : null;
          if (selectedEstatePointId) {
            map.setFeatureState({ source: "estates", id: selectedEstatePointId }, { selected: true });
          }
        }
      }

      function renderLayers() {
        els.layerList.innerHTML = layerRegistry.map(layer => `
          <div class="layer-row">
            <div>
              <strong>${escapeHtml(layer.label)}</strong>
              <small>${escapeHtml(layer.detail)}</small>
            </div>
            <button class="switch" type="button" aria-pressed="${state.layers[layer.id] ? "true" : "false"}" data-layer="${escapeHtml(layer.id)}"></button>
          </div>
        `).join("");
        els.layerList.querySelectorAll("[data-layer]").forEach(button => {
          button.addEventListener("click", () => {
            state.layers[button.dataset.layer] = !state.layers[button.dataset.layer];
            renderLayers();
            applyLayerVisibility();
          });
        });
      }

      function selectedPropertyItem() {
        return state.selectedType === "property" ? transactionsById.get(propertyId(state.selectedId)) || null : null;
      }

      function propertyMarketContext(item = selectedPropertyItem()) {
        if (!item) return null;
        const estate = estateForTransaction(item);
        if (estate) {
          return {
            kind: "estate",
            id: estate.key,
            rows: estateTransactions(estate.key)
          };
        }
        const marketId = item.market || marketDefinitions.find(market => market.district === item.district)?.id;
        return {
          kind: "market",
          id: marketId,
          rows: marketId ? rowsForMarket(marketId) : [item]
        };
      }

      function selectedSummaryRows() {
        return propertyMarketContext()?.rows || state.selectedRows;
      }

      function selectedContextStats(rows = state.selectedRows) {
        if (state.selectedType === "overview") return overallStats;
        if (state.selectedType === "market") return marketStats[state.selectedId] || statsForRows(rows);
        if (state.selectedType === "town") return townStats[state.selectedId] || statsForRows(rows);
        if (state.selectedType === "estate") {
          const estate = estatePins.find(pin => pin.key === state.selectedId);
          return estate ? statsForEstate(estate) : statsForRows(rows);
        }
        if (state.selectedType === "property") {
          const context = propertyMarketContext();
          if (context?.kind === "estate") {
            const estate = estatePins.find(pin => pin.key === context.id);
            if (estate) return statsForEstate(estate);
          }
          if (context?.kind === "market" && marketStats[context.id]) return marketStats[context.id];
        }
        return statsForRows(rows);
      }

      function activeMarketId() {
        if (state.selectedType === "market") return state.selectedId;
        const context = propertyMarketContext();
        return context?.kind === "market" ? context.id : null;
      }

      function activeEstateKey() {
        if (state.selectedType === "estate") return state.selectedId;
        const context = propertyMarketContext();
        return context?.kind === "estate" ? context.id : null;
      }

      function visibleRankedWithActive(ranked, activeId, getId, getStats, expanded, limit = 5) {
        if (expanded) return ranked;
        const visible = ranked.filter(item => getStats(item)?.rankEligible).slice(0, limit);
        if (!activeId) return visible;
        if (visible.some(item => getId(item) === activeId)) return visible;
        const active = ranked.find(item => getId(item) === activeId);
        return active ? [active, ...visible.filter(item => getId(item) !== activeId).slice(0, limit - 1)] : visible;
      }

      function compareVelocityMatrixStats(aStats, bStats) {
        if (aStats.rankEligible !== bStats.rankEligible) return bStats.rankEligible ? 1 : -1;
        if (aStats.rankEligible) {
          return bStats.marketHeatScore - aStats.marketHeatScore
            || bStats.paceScore - aStats.paceScore
            || bStats.liquidityScore - aStats.liquidityScore
            || bStats.velocityConfidence - aStats.velocityConfidence
            || bStats.recent - aStats.recent
            || bStats.count - aStats.count;
        }
        return bStats.recent - aStats.recent
          || bStats.baselineTotal - aStats.baselineTotal
          || bStats.count - aStats.count;
      }

      function velocityCardDetail(stats) {
        if (!(Number(stats?.count) > 0)) return `No qualifying ${compactPrice(landRegPriceFloor)}+ sales since ${coverageYear}`;
        const core = `Heat ${velocityLabel(stats)} · pace ${formatNumber(stats.paceScore)}/100 (${stats.velocity.toFixed(2)}x) · liquidity ${formatNumber(stats.liquidityScore)}/100`;
        const signal = stats.signalQualified
          ? `${formatNumber(stats.signalRecent)} in 120d · ${accelerationLabel(stats)}`
          : `120d signal unpublished (${formatNumber(stats.signalRecent)} current / ${formatNumber(stats.signalBaselineTotal)} baseline)`;
        return `${core} · ${formatNumber(stats.recent)} mature 12m sales · ${signal} · ${rankEvidenceLabel(stats)}`;
      }

      function renderSummary() {
        if (!els.summaryGrid || !els.summaryNote) return;
        const stats = selectedContextStats(selectedSummaryRows());
        const rows = [
          ["Market heat", velocityLabel(stats)],
          ["Pace", `${formatNumber(stats.paceScore)}/100 · ${stats.velocity.toFixed(2)}x`],
          ["Liquidity", `${formatNumber(stats.liquidityScore)}/100`],
          ["Mature 12m", formatNumber(stats.recent)]
        ];
        els.summaryGrid.innerHTML = rows.map(row => `<div class="metric"><span>${row[0]}</span><strong>${row[1]}</strong></div>`).join("");
        els.summaryNote.textContent = state.selectedType === "overview" ? "Surrey" : `${formatNumber(stats.count)} sales`;
      }

      function renderMarkets() {
        const ranked = marketDefinitions.slice().sort((a, b) => {
          const aStats = marketStats[a.id];
          const bStats = marketStats[b.id];
          return compareVelocityMatrixStats(aStats, bStats);
        });
        const marketActiveId = activeMarketId();
        const visibleMarkets = visibleRankedWithActive(ranked, marketActiveId, market => market.id, market => marketStats[market.id], state.marketListExpanded);
        const collapsedMarketCount = Math.min(5, ranked.filter(market => marketStats[market.id]?.rankEligible).length);
        els.marketTitle.textContent = "Local Authorities";
        els.marketRankNote.textContent = state.marketListExpanded ? "Qualified first · mature 12m heat" : "Top qualified · mature 12m heat";
        els.marketList.innerHTML = visibleMarkets.map(market => {
          const stats = marketStats[market.id];
          return `
            <article class="market-card${marketActiveId === market.id ? " active" : ""}" data-market="${escapeHtml(market.id)}" role="button" tabindex="0" aria-pressed="${marketActiveId === market.id}">
              <h3>${escapeHtml(market.short)}</h3>
              <p>${velocityCardDetail(stats)}</p>
              <div class="heat-bar" style="--w:${stats.marketHeatScore}%"><span></span></div>
            </article>`;
        }).join("") + (ranked.length > collapsedMarketCount ? `<button class="more-button" type="button" data-market-more aria-expanded="${state.marketListExpanded}">${state.marketListExpanded ? "Show less" : `More (${ranked.length - visibleMarkets.length})`}</button>` : "");
        els.marketList.querySelectorAll("[data-market]").forEach(card => {
          card.addEventListener("click", () => selectMarket(card.dataset.market));
          card.addEventListener("keydown", event => {
            if (event.key !== "Enter" && event.key !== " ") return;
            event.preventDefault();
            selectMarket(card.dataset.market);
          });
        });
        const more = els.marketList.querySelector("[data-market-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.marketListExpanded = !state.marketListExpanded;
            renderMarkets();
          });
        }
      }

      function renderEstates() {
        const ranked = estatePins.map(pin => {
          return { pin, stats: statsForEstate(pin) };
        }).sort((a, b) => {
          return compareVelocityMatrixStats(a.stats, b.stats);
        });
        const estateActiveKey = activeEstateKey();
        const visibleEstates = visibleRankedWithActive(ranked, estateActiveKey, item => item.pin.key, item => item.stats, state.estateListExpanded);
        const collapsedEstateCount = Math.min(5, ranked.filter(item => item.stats.rankEligible).length);
        els.estateTitle.textContent = "Private Estates";
        els.estateRankNote.textContent = state.estateListExpanded ? "Qualified first · mature 12m heat" : "Top qualified · mature 12m heat";
        els.estateList.innerHTML = visibleEstates.map(({ pin, stats }) => `
          <article class="estate-card${estateActiveKey === pin.key ? " active" : ""}" data-estate="${escapeHtml(pin.key)}" role="button" tabindex="0" aria-pressed="${estateActiveKey === pin.key}">
            <h3>${escapeHtml(pin.name)}</h3>
            <p>${velocityCardDetail(stats)}</p>
            <div class="heat-bar" style="--w:${stats.marketHeatScore}%"><span></span></div>
          </article>
        `).join("") + (ranked.length > collapsedEstateCount ? `<button class="more-button" type="button" data-estate-more aria-expanded="${state.estateListExpanded}">${state.estateListExpanded ? "Show less" : `More (${ranked.length - visibleEstates.length})`}</button>` : "");
        els.estateList.querySelectorAll("[data-estate]").forEach(card => {
          card.addEventListener("click", () => selectEstate(card.dataset.estate));
          card.addEventListener("keydown", event => {
            if (event.key !== "Enter" && event.key !== " ") return;
            event.preventDefault();
            selectEstate(card.dataset.estate);
          });
        });
        const more = els.estateList.querySelector("[data-estate-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.estateListExpanded = !state.estateListExpanded;
            renderEstates();
          });
        }
      }

      function renderTowns() {
        const ranked = Object.keys(townStats)
          .map(key => ({ key, stats: townStats[key] }))
          .filter(item => item.stats.count > 0)
          .sort((a, b) => {
            return compareVelocityMatrixStats(a.stats, b.stats);
          });
        const townActiveKey = state.selectedType === "town" ? state.selectedId : null;
        const visibleTowns = visibleRankedWithActive(ranked, townActiveKey, item => item.key, item => item.stats, state.townListExpanded);
        const collapsedTownCount = Math.min(5, ranked.filter(item => item.stats.rankEligible).length);
        els.townTitle.textContent = "Towns";
        els.townRankNote.textContent = state.townListExpanded ? "Qualified first · mature 12m heat" : "Top qualified · mature 12m heat";
        els.townList.innerHTML = visibleTowns.map(({ key, stats }) => `
          <article class="town-card${state.selectedType === "town" && state.selectedId === key ? " active" : ""}" data-town="${escapeHtml(key)}" role="button" tabindex="0" aria-pressed="${state.selectedType === "town" && state.selectedId === key}">
            <h3>${escapeHtml(townDisplayName(key))}</h3>
            <p>${velocityCardDetail(stats)}</p>
            <div class="heat-bar" style="--w:${stats.marketHeatScore}%"><span></span></div>
          </article>
        `).join("") + (ranked.length > collapsedTownCount ? `<button class="more-button" type="button" data-town-more aria-expanded="${state.townListExpanded}">${state.townListExpanded ? "Show less" : `More (${ranked.length - visibleTowns.length})`}</button>` : "");
        els.townList.querySelectorAll("[data-town]").forEach(card => {
          card.addEventListener("click", () => selectTown(card.dataset.town));
          card.addEventListener("keydown", event => {
            if (event.key !== "Enter" && event.key !== " ") return;
            event.preventDefault();
            selectTown(card.dataset.town);
          });
        });
        const more = els.townList.querySelector("[data-town-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.townListExpanded = !state.townListExpanded;
            renderTowns();
          });
        }
      }

      function contextSection(title, rows, listItems = []) {
        const rowHtml = rows && rows.length ? dataRows(rows) : "";
        const listHtml = listItems.length ? `<div class="context-list">${listItems.join("")}</div>` : "";
        if (!rowHtml && !listHtml) return "";
        return `<section class="context-section"><h3>${escapeHtml(title)}</h3>${rowHtml}${listHtml}</section>`;
      }

      function contextItem(title, meta) {
        return `<div class="context-item"><strong>${escapeHtml(title)}</strong>${meta ? `<span>${escapeHtml(meta)}</span>` : ""}</div>`;
      }

      function linkedContextItem(title, meta, link) {
        const safeLink = safeHttpsUrl(link);
        const content = `<strong>${escapeHtml(title)}</strong>${meta ? `<span>${escapeHtml(meta)}</span>` : ""}`;
        return safeLink
          ? `<a class="context-item context-item-link" href="${escapeHtml(safeLink)}" target="_blank" rel="noopener">${content}<em>Open</em></a>`
          : `<div class="context-item">${content}</div>`;
      }

      function textSection(title, body, link, marker = "") {
        if (!body) return "";
        const safeLink = safeHttpsUrl(link);
        const linkHtml = safeLink ? ` <a href="${escapeHtml(safeLink)}" target="_blank" rel="noopener">Open source</a>` : "";
        const markerAttr = marker ? ` ${marker}` : "";
        return `<section class="context-section"${markerAttr}><h3>${escapeHtml(title)}</h3><p class="context-copy">${escapeHtml(body)}${linkHtml}</p></section>`;
      }

      function insightLead(paragraphs) {
        return (Array.isArray(paragraphs) ? paragraphs : [paragraphs])
          .filter(Boolean)
          .map(paragraph => `<p class="insight-lead">${escapeHtml(paragraph)}</p>`)
          .join("");
      }

      function insightMetricGrid(metrics) {
        const cards = metrics.filter(metric => metric && metric.value !== undefined && metric.value !== null && metric.value !== "").map(metric => `
          <div class="insight-kpi">
            <span>${escapeHtml(metric.label)}</span>
            <strong>${escapeHtml(metric.value)}</strong>
            ${metric.detail ? `<small>${escapeHtml(metric.detail)}</small>` : ""}
          </div>
        `).join("");
        return cards ? `<div class="insight-metric-grid">${cards}</div>` : "";
      }

      function insightTable(headers, rows, caption = "") {
        if (!rows.length) return "";
        return `<div class="insight-table-wrap"><table class="insight-table">${caption ? `<caption>${escapeHtml(caption)}</caption>` : ""}<thead><tr>${headers.map(header => `<th scope="col">${escapeHtml(header)}</th>`).join("")}</tr></thead><tbody>${rows.map(row => `<tr>${row.map(cell => `<td>${escapeHtml(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
      }

      function insightBarList(items) {
        const maximum = Math.max(1, ...items.map(item => Math.abs(Number(item.value) || 0)));
        return `<div class="insight-bar-list">${items.map(item => `
          <div class="insight-bar-row">
            <span>${escapeHtml(item.label)}</span>
            <span class="insight-bar-track"><span style="--w:${clamp(2, 100, Math.abs(Number(item.value) || 0) / maximum * 100).toFixed(1)}%"></span></span>
            <strong>${escapeHtml(item.formatted)}</strong>
          </div>
        `).join("")}</div>`;
      }

      function insightCaveat(text) {
        return text ? `<p class="insight-caveat">${escapeHtml(text)}</p>` : "";
      }

      function insightEvidenceDetails(summary, content) {
        return content ? `<details class="insight-evidence"><summary>${escapeHtml(summary)}</summary>${content}</details>` : "";
      }

      function insightUniverseBoundary(extra = "") {
        const through = formatDate(landRegMeta.to || transactions[0]?.date || "");
        return `Universe: recorded Surrey residential transactions at or above ${compactPrice(landRegPriceFloor)}, through ${through || "the loaded feed date"}; this is not the whole property market.${extra ? ` ${extra}` : ""}`;
      }

      function estateRoadsSection(estate) {
        const roads = Array.from(new Set(
          privateEstateRules
            .filter(rule => rule.estateId === estate?.key)
            .map(rule => rule.canonicalStreet)
            .filter(Boolean)
        )).sort((left, right) => left.localeCompare(right));
        return roads.length ? contextSection("Estate roads", [], roads.map(road => contextItem(road, ""))) : "";
      }

      function humaniseKey(key) {
        return String(key || "")
          .replace(/([a-z])([A-Z])/g, "$1 $2")
          .replace(/[_-]+/g, " ")
          .replace(/\b[a-z]/g, letter => letter.toUpperCase());
      }

      function planningApplicationDate(application) {
        if (!application || typeof application !== "object") return "";
        return application.decisionDate || application.validatedDate || application.receivedDate ||
          application.submittedDate || application.registeredDate || application.startDate ||
          application.date || application.dateText || application.year ||
          application["decision-date"] || application["validated-date"] || application["received-date"] || "";
      }

      function formatPlanningDate(value) {
        const text = String(value || "").trim();
        if (!text) return "";
        if (/^(?:19|20)\d{2}$/.test(text)) return text;
        const date = new Date(/^\d{4}-\d{2}-\d{2}$/.test(text) ? `${text}T00:00:00Z` : text);
        if (Number.isNaN(date.getTime())) return text;
        return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(date);
      }

      function loadedSalesHistoryRecord(item) {
        if (!item) return {};
        const titleHistory = window.SURREY_SALES_HISTORY || {};
        const relatedRows = transactionRowsByProperty.get(propertyRecordKey(item)) || [item];
        return titleHistory[propertyId(item.id)] ||
          titleHistory[planningPropertyKey(item)] ||
          relatedRows.map(transaction => titleHistory[propertyId(transaction.id)] || titleHistory[planningPropertyKey(transaction)]).find(Boolean) || {};
      }

      function salesHistoryForTransaction(item) {
        if (!item) return [];
        const recordKey = propertyRecordKey(item);
        if (salesHistoryRowsCache.has(recordKey)) return salesHistoryRowsCache.get(recordKey).slice();
        const relatedRows = transactionRowsByProperty.get(recordKey) || [item];
        const complete = loadedSalesHistoryRecord(item);
        if (Array.isArray(complete.transactions) && complete.transactions.length) {
          const uniqueRows = new Map();
          [...complete.transactions, ...relatedRows].forEach(transaction => {
            const signature = `${String(transaction.date || "").slice(0, 10)}|${Number(transaction.price || 0)}`;
            if (!uniqueRows.has(signature) || String(transaction.source || "").includes("Price Paid Data")) {
              uniqueRows.set(signature, transaction);
            }
          });
          const completeRows = Array.from(uniqueRows.values()).sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
          salesHistoryRowsCache.set(recordKey, completeRows);
          return completeRows.slice();
        }
        const fallbackRows = relatedRows.slice().sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
        salesHistoryRowsCache.set(recordKey, fallbackRows);
        return fallbackRows.slice();
      }

      let propertySeedEntriesCache = null;

      function valueAtPath(value, path) {
        return String(path || "").split(".").reduce((current, key) => current && typeof current === "object" ? current[key] : undefined, value);
      }

      function propertySeedEntries() {
        if (propertySeedEntriesCache) return propertySeedEntriesCache;
        let source = propertyRecordsSeed;
        if (source && typeof source === "object" && !Array.isArray(source) && source.records && typeof source.records === "object") {
          source = source.records;
        }
        if (Array.isArray(source)) {
          propertySeedEntriesCache = source
            .filter(record => record && typeof record === "object" && !Array.isArray(record))
            .map(record => [String(record.propertyId || record.propertyRecordId || record.id || record.key || ""), record]);
        } else {
          propertySeedEntriesCache = Object.entries(source || {})
            .filter(([, record]) => record && typeof record === "object" && !Array.isArray(record));
        }
        return propertySeedEntriesCache;
      }

      function propertySeedForTransaction(item) {
        if (!item) return null;
        const canonicalAddress = propertyAddressIdentity(item.address);
        const postcode = normalisePostcode(item.postcode);
        const candidates = Array.from(new Set([
          String(item.propertyRecordId || "").trim(),
          propertyRecordKey(item),
          planningPropertyKey(item),
          `property:${addressKey(item.address)}|${postcode}`,
          `address:${canonicalAddress}|${postcode}`,
          propertyId(item.id)
        ].filter(Boolean)));
        const containers = [
          propertyRecordsSeed,
          propertyRecordsSeed?.records,
          propertyRecordsSeed?.byId
        ].filter(value => value && typeof value === "object" && !Array.isArray(value));
        for (const container of containers) {
          for (const key of candidates) {
            const record = container[key];
            if (record && typeof record === "object" && !Array.isArray(record)) return record;
          }
        }
        for (const [entryKey, record] of propertySeedEntries()) {
          const identifiers = [
            entryKey,
            record.propertyId,
            record.propertyRecordId,
            record.id,
            record.key,
            record.canonicalKey,
            valueAtPath(record, "identity.propertyRecordId"),
            valueAtPath(record, "identity.canonicalKey")
          ].map(value => String(value || "").trim()).filter(Boolean);
          if (identifiers.some(identifier => candidates.includes(identifier))) return record;
          const recordAddress = record.address || record.canonicalAddress || valueAtPath(record, "identity.address") || valueAtPath(record, "identity.canonicalAddress");
          const recordPostcode = record.postcode || valueAtPath(record, "identity.postcode");
          if (recordAddress && propertyAddressIdentity(recordAddress) === canonicalAddress && normalisePostcode(recordPostcode) === postcode) return record;
        }
        return null;
      }

      function latestEpcSnapshot(item) {
        if (!item) return { rating: "", date: "" };
        const recordKey = propertyRecordKey(item);
        if (latestEpcSnapshotCache.has(recordKey)) return latestEpcSnapshotCache.get(recordKey);
        const candidates = [];
        const addCandidate = (date, rating) => {
          const dateText = String(date || "").slice(0, 10);
          const ratingText = String(rating || "").slice(0, 1).toUpperCase();
          if (!/^(?:19|20)\d{2}-\d{2}-\d{2}$/.test(dateText) || !/^[A-G]$/.test(ratingText)) return;
          candidates.push({ date: dateText, rating: ratingText });
        };
        const relatedRows = transactionRowsByProperty.get(recordKey) || [item];
        relatedRows.forEach(row => addCandidate(
          row.epcRegistrationDate || row.registrationDate || row.lodgementDate,
          row.epcRating || row.rating
        ));
        (Array.isArray(item.epcHistory) ? item.epcHistory : []).forEach(observation => addCandidate(
          observation.epcRegistrationDate || observation.registrationDate || observation.lodgementDate || observation.date,
          observation.epcRating || observation.rating
        ));
        const seed = propertySeedForTransaction(item);
        addCandidate(valueAtPath(seed, "metrics.latestEpcDate"), valueAtPath(seed, "metrics.latestEpcRating"));
        (Array.isArray(seed?.evidence) ? seed.evidence : [])
          .filter(evidence => evidence?.type === "epc_certificate")
          .forEach(evidence => addCandidate(
            evidence.effectiveDate || evidence.data?.epcRegistrationDate || evidence.data?.date,
            evidence.data?.epcRating || evidence.data?.rating
          ));
        candidates.sort((left, right) => right.date.localeCompare(left.date));
        const latest = candidates[0] || {
          rating: String(item.epcRating || "").slice(0, 1).toUpperCase(),
          date: ""
        };
        latestEpcSnapshotCache.set(recordKey, latest);
        return latest;
      }

      function listedStatusTimestamp(...values) {
        for (const value of values) {
          const text = String(value || "");
          const match = text.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/);
          if (!match) continue;
          const [, year, month, day, hour, minute, second] = match.map(Number);
          const calendarCheck = new Date(Date.UTC(year, month - 1, day, hour, minute, second));
          if (
            calendarCheck.getUTCFullYear() !== year ||
            calendarCheck.getUTCMonth() !== month - 1 ||
            calendarCheck.getUTCDate() !== day ||
            calendarCheck.getUTCHours() !== hour ||
            calendarCheck.getUTCMinutes() !== minute ||
            calendarCheck.getUTCSeconds() !== second
          ) continue;
          const parsed = Date.parse(text);
          if (Number.isFinite(parsed)) return parsed;
        }
        return 0;
      }

      function listedStatusIsoDate(value) {
        const text = String(value || "");
        if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return false;
        const parsed = new Date(`${text}T00:00:00Z`);
        return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === text;
      }

      function normaliseListedStatusEntry(entry) {
        if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
        const requiredFields = ["listEntryNumber", "grade", "name", "url", "matchMethod", "matchConfidence"];
        const allowedFields = new Set([...requiredFields, "listDate", "amendDate", "distanceMetres"]);
        const fields = Object.keys(entry);
        if (
          requiredFields.some(field => !Object.prototype.hasOwnProperty.call(entry, field)) ||
          fields.some(field => !allowedFields.has(field))
        ) return null;
        const listEntryNumber = String(entry.listEntryNumber || "").trim();
        const grade = String(entry.grade || "").trim();
        const name = String(entry.name || "").trim();
        const url = String(entry.url || "").trim();
        const matchMethod = String(entry.matchMethod || "").trim();
        const matchConfidence = String(entry.matchConfidence || "").trim();
        if (
          !/^\d{7}$/.test(listEntryNumber) ||
          !["I", "II*", "II"].includes(grade) ||
          !name ||
          url !== `https://historicengland.org.uk/listing/the-list/list-entry/${listEntryNumber}` ||
          !["reviewed_override", "genuine_polygon_contains", "nearby_nhle_point"].includes(matchMethod) ||
          !["confirmed", "review_required"].includes(matchConfidence)
        ) return null;
        if (Object.prototype.hasOwnProperty.call(entry, "listDate") && !listedStatusIsoDate(entry.listDate)) return null;
        if (Object.prototype.hasOwnProperty.call(entry, "amendDate") && !listedStatusIsoDate(entry.amendDate)) return null;
        if (
          Object.prototype.hasOwnProperty.call(entry, "distanceMetres") &&
          (!Number.isInteger(entry.distanceMetres) || entry.distanceMetres < 0)
        ) return null;
        const normalised = {
          listEntryNumber,
          grade,
          name,
          url,
          matchMethod,
          matchConfidence
        };
        if (Object.prototype.hasOwnProperty.call(entry, "listDate")) normalised.listDate = entry.listDate;
        if (Object.prototype.hasOwnProperty.call(entry, "amendDate")) normalised.amendDate = entry.amendDate;
        if (Object.prototype.hasOwnProperty.call(entry, "distanceMetres")) normalised.distanceMetres = entry.distanceMetres;
        return normalised;
      }

      function normaliseListedStatusProjection(value, originPriority) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return null;
        const outerFields = ["status", "entries", "source", "checkedAt", "sourceUpdatedAt", "sourceSnapshot"];
        if (
          outerFields.some(field => !Object.prototype.hasOwnProperty.call(value, field)) ||
          Object.keys(value).some(field => !outerFields.includes(field))
        ) return null;
        const status = String(value.status || "").trim();
        if (!["confirmed_listed", "candidate_review", "no_direct_match", "unknown"].includes(status)) return null;
        const source = String(value.source || "").trim();
        const checkedAt = String(value.checkedAt || "").trim();
        const sourceUpdatedAt = String(value.sourceUpdatedAt || "").trim();
        const sourceSnapshot = String(value.sourceSnapshot || "").trim();
        if (
          source !== "Historic England NHLE" ||
          !listedStatusTimestamp(checkedAt) ||
          !listedStatusTimestamp(sourceUpdatedAt) ||
          !/^nhle-\d{4}-\d{2}-\d{2}-[0-9a-f]{12}$/.test(sourceSnapshot)
        ) return null;
        const rawEntries = Array.isArray(value.entries) ? value.entries : null;
        if (!rawEntries) return null;
        const entriesByNumber = new Map();
        let invalidEntry = false;
        rawEntries.forEach(rawEntry => {
          const entry = normaliseListedStatusEntry(rawEntry);
          if (!entry) {
            invalidEntry = true;
            return;
          }
          const validForStatus = status === "confirmed_listed"
            ? entry.matchConfidence === "confirmed" &&
              ["reviewed_override", "genuine_polygon_contains"].includes(entry.matchMethod)
            : status === "candidate_review"
              ? entry.matchConfidence === "review_required" &&
                entry.matchMethod === "nearby_nhle_point"
              : false;
          if (!validForStatus) {
            invalidEntry = true;
            return;
          }
          const existing = entriesByNumber.get(entry.listEntryNumber);
          if (!existing || Object.values(entry).filter(Boolean).length > Object.values(existing).filter(Boolean).length) {
            entriesByNumber.set(entry.listEntryNumber, entry);
          }
        });
        if (invalidEntry || entriesByNumber.size !== rawEntries.length) return null;
        const gradeOrder = { I: 0, "II*": 1, II: 2 };
        const entries = Array.from(entriesByNumber.values()).sort((left, right) =>
          gradeOrder[left.grade] - gradeOrder[right.grade] ||
          left.listEntryNumber.localeCompare(right.listEntryNumber)
        );
        if (
          (["confirmed_listed", "candidate_review"].includes(status) && !entries.length) ||
          (["no_direct_match", "unknown"].includes(status) && entries.length)
        ) return null;
        return {
          status,
          entries,
          source,
          checkedAt,
          sourceUpdatedAt,
          sourceSnapshot,
          sourceFreshness: listedStatusTimestamp(sourceUpdatedAt),
          checkedFreshness: listedStatusTimestamp(checkedAt),
          originPriority: Number(originPriority) || 0
        };
      }

      function listedStatusSnapshot(item, propertySeed = null) {
        if (!item) return { status: "unknown", entries: [], checkedAt: "" };
        const recordKey = propertyRecordKey(item);
        if (listedStatusSnapshotCache.has(recordKey)) return listedStatusSnapshotCache.get(recordKey);
        const candidates = [];
        const addCandidate = (value, originPriority) => {
          const candidate = normaliseListedStatusProjection(value, originPriority);
          if (candidate) candidates.push(candidate);
        };
        const relatedRows = transactionRowsByProperty.get(recordKey) || [item];
        relatedRows.forEach(row => addCandidate(row.historicEngland, 3));
        const seed = propertySeed || propertySeedForTransaction(item);
        addCandidate(valueAtPath(seed, "context.historicEngland"), 2);
        (Array.isArray(seed?.evidence) ? seed.evidence : []).forEach(evidence => {
          if (evidence?.type === "listed_building") addCandidate(evidence.data, 1);
          if (evidence?.type === "property_context") addCandidate(valueAtPath(evidence, "data.historicEngland"), 1);
        });
        candidates.sort((left, right) =>
          right.sourceFreshness - left.sourceFreshness ||
          right.checkedFreshness - left.checkedFreshness ||
          right.originPriority - left.originPriority ||
          right.entries.length - left.entries.length
        );
        const latest = candidates[0] || { status: "unknown", entries: [], checkedAt: "" };
        listedStatusSnapshotCache.set(recordKey, latest);
        return latest;
      }

      function listedStatusClass(snapshot) {
        if (!snapshot || typeof snapshot !== "object") return "";
        if (snapshot.status === "no_direct_match") return "unlisted";
        if (snapshot.status !== "confirmed_listed" || !Array.isArray(snapshot.entries) || !snapshot.entries.length) {
          return "";
        }
        const highestGrade = ["I", "II*", "II"].find(grade =>
          snapshot.entries.some(entry =>
            entry?.grade === grade &&
            entry.matchConfidence === "confirmed" &&
            ["reviewed_override", "genuine_polygon_contains"].includes(entry.matchMethod)
          )
        );
        return {
          I: "grade-i",
          "II*": "grade-ii-star",
          II: "grade-ii"
        }[highestGrade] || "";
      }

      function safeHistoricEnglandListEntryUrl(value, listEntryNumber) {
        const number = String(listEntryNumber || "").trim();
        if (!value || !/^\d{7}$/.test(number)) return "";
        try {
          const url = new URL(String(value));
          const expectedPath = `/listing/the-list/list-entry/${number}`;
          if (
            url.protocol !== "https:" ||
            url.hostname.toLowerCase() !== "historicengland.org.uk" ||
            url.port ||
            url.username ||
            url.password ||
            url.pathname !== expectedPath ||
            url.search ||
            url.hash
          ) return "";
          return `https://historicengland.org.uk${expectedPath}`;
        } catch (_error) {
          return "";
        }
      }

      function listedStatusEvidenceLinks(entries, status) {
        const confirmed = status === "confirmed_listed";
        const candidate = status === "candidate_review";
        if (!confirmed && !candidate) return [];
        const links = (Array.isArray(entries) ? entries : []).map(entry => {
          const validEvidence = confirmed
            ? entry?.matchConfidence === "confirmed" &&
              ["reviewed_override", "genuine_polygon_contains"].includes(entry.matchMethod)
            : entry?.matchConfidence === "review_required" &&
              entry.matchMethod === "nearby_nhle_point";
          if (!validEvidence) return null;
          const url = safeHistoricEnglandListEntryUrl(entry.url, entry.listEntryNumber);
          if (!url) return null;
          const number = String(entry.listEntryNumber);
          return {
            label: `${candidate ? "Potential " : ""}NHLE ${number}`,
            url,
            ariaLabel: `${candidate ? "Open potential" : "Open"} Historic England NHLE entry ${number}`
          };
        }).filter(Boolean);
        return candidate ? links.slice(0, 1) : links;
      }

      function listedStatusForDisplay(snapshot) {
        const value = snapshot && typeof snapshot === "object" ? snapshot : { status: "unknown", entries: [] };
        const entries = Array.isArray(value.entries) ? value.entries : [];
        const checked = value.checkedAt ? `checked ${formatPlanningDate(value.checkedAt)}` : "";
        const evidenceLinks = listedStatusEvidenceLinks(entries, value.status);
        if (value.status === "confirmed_listed" && entries.length) {
          return {
            value: `Grade ${entries[0].grade} Listed${entries.length > 1 ? ` · ${formatNumber(entries.length)} entries` : ""}`,
            subdetail: checked,
            evidenceLinks
          };
        }
        if (value.status === "candidate_review") {
          return {
            value: "Potential match — verify",
            subdetail: checked,
            evidenceLinks
          };
        }
        if (value.status === "no_direct_match") {
          return {
            value: "Unlisted",
            subdetail: ["No direct NHLE match", checked].filter(Boolean).join(" · ")
          };
        }
        return { value: "Status unavailable", subdetail: checked };
      }

      function seedStoryParagraphs(record) {
        if (!record || typeof record !== "object") return [];
        const values = [
          valueAtPath(record, "story.paragraphs"),
          record.storyParagraphs,
          valueAtPath(record, "analysis.paragraphs"),
          valueAtPath(record, "story.text"),
          valueAtPath(record, "story.summary"),
          typeof record.analysis === "string" ? record.analysis : "",
          record.narrative
        ];
        const paragraphs = [];
        values.forEach(value => {
          const candidates = Array.isArray(value) ? value : typeof value === "string" ? value.split(/\n\s*\n/) : [];
          candidates.forEach(candidate => {
            const text = typeof candidate === "string" ? candidate : candidate && typeof candidate === "object" ? candidate.text || candidate.body || "" : "";
            const clean = String(text || "").replace(/\s+/g, " ").trim();
            if (clean && !paragraphs.includes(clean)) paragraphs.push(clean);
          });
        });
        return paragraphs.slice(0, 2);
      }

      function seedEvidenceCount(record, kind) {
        if (!record || typeof record !== "object") return null;
        if (Array.isArray(record.events)) {
          const eventType = kind === "sales" ? "sale" : kind === "planning" ? "planning_application" : "epc_certificate";
          return record.events.filter(event => event && event.type === eventType).length;
        }
        const paths = kind === "sales"
          ? ["evidence.salesCount", "evidenceSummary.salesCount", "metrics.salesCount", "metrics.registeredSales", "sales.totalTransactions", "salesHistory.totalTransactions", "totalTransactions"]
          : kind === "planning"
            ? ["evidence.planningCount", "evidenceSummary.planningCount", "metrics.planningApplicationCount", "metrics.planningApplications", "planning.totalApplications", "planningHistory.totalApplications", "totalApplications"]
            : ["evidence.epcCount", "evidenceSummary.epcCount", "metrics.epcObservationCount", "epc.totalCertificates", "epcHistory.totalCertificates"];
        for (const path of paths) {
          const value = Number(valueAtPath(record, path));
          if (Number.isFinite(value) && value >= 0) return value;
        }
        const arrays = kind === "sales"
          ? [record.transactions, record.sales, record.salesHistory]
          : kind === "planning"
            ? [record.applications, record.planningApplications, valueAtPath(record, "planningHistory.applications")]
            : [record.epcHistory, record.epcCertificates, valueAtPath(record, "epc.certificates")];
        const matched = arrays.find(Array.isArray);
        return matched ? matched.length : null;
      }

      function propertySeedCoverage(record, source) {
        const coverage = record && typeof record === "object" && record.coverage && typeof record.coverage === "object"
          ? record.coverage
          : {};
        const aliases = source === "sales"
          ? ["sales", "salesHistory", "sales_history"]
          : source === "planning"
            ? ["planning", "planningHistory", "planning_history"]
            : ["epc", "epcHistory", "epc_history"];
        const match = aliases.map(alias => coverage[alias]).find(value => value && typeof value === "object" && !Array.isArray(value));
        return match || null;
      }

      function propertyCoverageStatus(entry) {
        return String(entry?.status || entry?.coverageStatus || "").trim().toLowerCase().replace(/[\s-]+/g, "_");
      }

      function propertyCoverageIsCheckedNone(entry) {
        if (!entry || typeof entry !== "object") return false;
        if (propertyCoverageStatus(entry) === "checked_none") return true;
        return entry.coverageMode === "full-available-history" &&
          entry.complete === true && Number(entry.recordCount) === 0;
      }

      function propertyPlanningEvidence(item) {
        const history = planningHistoryForTransaction(item);
        const applications = Array.isArray(history.applications)
          ? history.applications.filter(application => application && typeof application === "object")
          : [];
        applications.sort((left, right) => String(planningApplicationDate(right) || "").localeCompare(String(planningApplicationDate(left) || "")));
        const suppliedTotal = Number(history.totalApplications);
        const total = Number.isFinite(suppliedTotal) ? Math.max(suppliedTotal, applications.length) : applications.length;
        const loaded = Boolean(history && typeof history === "object" && Object.keys(history).length && (
          Array.isArray(history.applications) || history.totalApplications !== undefined || history.source || history.updatedAt
        ));
        const coverageStatus = propertyCoverageStatus(history);
        const checkedNone = !applications.length && total === 0 && (
          coverageStatus === "checked_none" ||
          (history.coverageMode === "full-available-history" && history.complete === true)
        );
        const complete = coverageStatus === "complete" || checkedNone;
        return { history, applications, total, loaded, checkedNone, complete, coverageStatus };
      }

      function datedEpcObservations(item) {
        const relatedRows = transactionRowsByProperty.get(propertyRecordKey(item)) || [item];
        const observations = [
          ...relatedRows,
          ...(Array.isArray(item?.epcHistory) ? item.epcHistory : [])
        ];
        const unique = new Map();
        observations.forEach(observation => {
          if (!observation || typeof observation !== "object" || observation.matched === false) return;
          const status = String(observation.status || "").toLowerCase();
          if (["failed", "no_match", "unmatched"].includes(status)) return;
          const date = observation.registrationDate || observation.epcRegistrationDate || observation.lodgementDate || observation.date || "";
          const year = String(date).match(/(?:19|20)\d{2}/)?.[0] || "";
          const suppliedSqft = Number(observation.floorAreaSqft);
          const suppliedSqm = Number(observation.floorAreaSqm ?? observation.floorArea);
          const sqft = suppliedSqft > 0 ? suppliedSqft : suppliedSqm > 0 ? suppliedSqm * 10.7639 : 0;
          if (!year || !(sqft > 0)) return;
          const key = `${String(date)}|${Math.round(sqft)}`;
          const candidate = { date: String(date), year, sqft };
          if (!unique.has(key)) unique.set(key, candidate);
        });
        return Array.from(unique.values()).sort((left, right) => left.date.localeCompare(right.date));
      }

      function epcAreaStoryData(item) {
        const observations = datedEpcObservations(item);
        let best = null;
        observations.forEach((from, fromIndex) => {
          observations.slice(fromIndex + 1).forEach(to => {
            const fromDate = Date.parse(from.date);
            const toDate = Date.parse(to.date);
            const difference = to.sqft - from.sqft;
            const relative = difference / Math.max(1, from.sqft);
            if (!Number.isFinite(fromDate) || !Number.isFinite(toDate) || toDate - fromDate < 180 * 86400000) return;
            if (difference < 250 || relative < .08 || to.sqft / from.sqft > 3) return;
            if (!best || difference > best.difference) best = { from, to, difference, relative };
          });
        });
        return best;
      }

      function conciseStoryText(value, maximum = 190) {
        const text = String(value || "").replace(/\s+/g, " ").trim();
        if (text.length <= maximum) return text;
        const cut = text.slice(0, maximum - 1);
        const boundary = cut.lastIndexOf(" ");
        return `${cut.slice(0, boundary > maximum * .65 ? boundary : cut.length).trim()}…`;
      }

      function planningStoryIsImplementationText(value) {
        return /(confirmation of compliance|discharge (?:of )?(?:planning )?conditions?|conditions? (approved|discharged)|details? (pursuant to|required by|reserved by) conditions?|(?:submission|approval) of (?:details?|materials?)(?: (?:pursuant to|required by|reserved by) conditions?)?|submission of .{0,120}? pursuant to conditions?|application (?:for|to) (?:approval of details|(?:the )?(?:proposed )?discharge (?:of )?(?:planning )?conditions?|remove (?:a |the )?(?:planning )?condition)|compliance with conditions?|relaxation of conditions?|(?:permission|details?) required by conditions?|non[- ]material (?:amendments?|changes?)|(?:minor material|material minor) amendment|(?:further )?amendments? to (?:planning )?(?:permission|application)|variation of (?:planning )?condition|vary(?:ing)? (?:a |the )?(?:planning )?condition|removal of (?:a |the )?(?:planning )?condition|section 73|s\.?73|approval of reserved matters|reserved matters (?:pursuant to|to|following)|renewal of .{0,80}? permission|certificate of (?:proposed |existing )?lawful development|certificate of lawfulness|retrospective|existing lawfulness|grant certificate|prior approval not required|lawful development certi\w*)/i.test(String(value || ""));
      }

      function planningStoryOutcome(application) {
        const decision = String(application?.decision || "").trim().toLowerCase();
        const status = String(application?.status || "").trim().toLowerCase();
        const outcome = `${decision} ${status}`;
        if (outcome.includes("allowed on appeal")) return "positive";
        if (/\b(refus|withdraw|dismiss|declin|invalid|lapse|reject)/i.test(outcome)) return "negative";
        const proposal = String(application?.proposal || application?.description || "");
        if (planningStoryIsImplementationText(outcome) || planningStoryIsImplementationText(proposal)) return "implementation";
        if (["approve", "approved", "granted", "approved with conditions", "approved with condition"].includes(decision) ||
          decision.startsWith("grant consent") || ["decided (approved)", "decided (permitted development)"].includes(status) ||
          status.startsWith("permitted subject to")) return "positive";
        return "unknown";
      }

      function planningStoryCategory(application) {
        const proposal = String(application?.proposal || application?.description || "").toLowerCase();
        const reference = String(application?.reference || application?.applicationReference || "");
        if (/(?:^|[/.-])(?:tpo|trees?)(?:$|[/.-])/i.test(reference) || /^\s*(?:see condition for .*?\.\s*)?(?:fell|prune|crown|tree|tpo)\b/i.test(proposal)) return "maintenance";
        if (planningStoryIsImplementationText(proposal)) return "implementation";
        if (/\b(demolition|replacement (house|dwelling)|new (house|dwelling)|erection of (a |one |1 ?no )?(detached )?(house|dwelling))\b/i.test(proposal)) return "replacement";
        if (/\b(extension|basement|loft conversion|roofspace|roof space|additional storey|two[- ]storey|first[- ]floor)\b/i.test(proposal)) return "enlargement";
        if (/\b(annexe|garage|pool|outbuilding|summerhouse|gym|tennis|orangery|conservatory)\b/i.test(proposal)) return "amenity";
        if (/\b(driveway|vehicular access|crossover|entrance gate|boundary wall|landscap)\b/i.test(proposal)) return "grounds";
        if (/\b(tree|tpo|crown|fell|prun|arbor)\b/i.test(proposal)) return "maintenance";
        return "other";
      }

      function planningStoryDateValue(application) {
        const supplied = String(planningApplicationDate(application) || "").trim();
        const year = supplied.match(/(?:19|20)\d{2}/)?.[0];
        if (year) {
          const exact = Date.parse(/^\d{4}-\d{2}-\d{2}$/.test(supplied) ? `${supplied}T00:00:00Z` : `${year}-07-01T00:00:00Z`);
          if (Number.isFinite(exact)) return new Date(exact);
        }
        const reference = String(application?.reference || application?.applicationReference || "");
        const shortYear = reference.match(/(?:^|[./-])(\d{2})[./-]\d/)?.[1] || reference.match(/^(\d{2})(?:[./-])/)?.[1];
        if (!shortYear) return null;
        const value = Number(shortYear);
        return new Date(Date.UTC(value >= 90 ? 1900 + value : 2000 + value, 6, 1));
      }

      function planningStoryDescription(application) {
        const supplied = conciseStoryText(application?.proposal || application?.description || application?.title || "planning work", 65).replace(/[.;:,]+$/, "");
        const description = supplied && !/^[A-Z]{2,}\b/.test(supplied) ? supplied.charAt(0).toLowerCase() + supplied.slice(1) : supplied;
        const date = planningStoryDateValue(application);
        return description + (date ? ` in ${date.getUTCFullYear()}` : "");
      }

      function planningStoryScore(application) {
        const category = planningStoryCategory(application);
        const categoryScore = { replacement: 8, enlargement: 6, amenity: 4, grounds: 2, implementation: 1, other: 1, maintenance: 0 }[category] || 0;
        const outcome = planningStoryOutcome(application);
        return categoryScore + (outcome === "positive" ? 3 : outcome === "implementation" ? 2 : 0);
      }

      function planningStoryHighlights(applications) {
        const ordered = applications.slice().sort((left, right) =>
          planningStoryScore(right) - planningStoryScore(left) ||
          String(planningApplicationDate(right) || "").localeCompare(String(planningApplicationDate(left) || ""))
        );
        const hasSubstantive = ordered.some(application => !["maintenance", "implementation"].includes(planningStoryCategory(application)));
        const result = [];
        ordered.forEach(application => {
          if (result.length >= 1) return;
          if (hasSubstantive && ["maintenance", "implementation"].includes(planningStoryCategory(application))) return;
          const description = planningStoryDescription(application);
          if (description && !result.includes(description)) result.push(description);
        });
        return result;
      }

      function joinStoryItems(values) {
        const items = values.filter(Boolean);
        if (items.length < 2) return items[0] || "";
        return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
      }

      function bestStoryPlanningEpisode(sales, applications, epcGrowth) {
        const ascendingSales = sales.slice().sort((left, right) => String(left.date || "").localeCompare(String(right.date || "")));
        let best = null;
        for (let index = 0; index < ascendingSales.length - 1; index++) {
          const earlierSale = ascendingSales[index];
          const laterSale = ascendingSales[index + 1];
          const start = Date.parse(String(earlierSale.date || "").slice(0, 10));
          const end = Date.parse(String(laterSale.date || "").slice(0, 10));
          if (!Number.isFinite(start) || !Number.isFinite(end)) continue;
          const episodeApplications = applications.filter(application => {
            const date = planningStoryDateValue(application)?.getTime();
            return Number.isFinite(date) && date >= start && date <= end;
          });
          if (!episodeApplications.length) continue;
          const structural = episodeApplications.filter(application => ["replacement", "enlargement", "amenity"].includes(planningStoryCategory(application)));
          const positiveStructural = structural.filter(application => planningStoryOutcome(application) === "positive");
          const implementation = episodeApplications.filter(application => planningStoryOutcome(application) === "implementation" || planningStoryCategory(application) === "implementation");
          const areaAligned = Boolean(epcGrowth && Date.parse(epcGrowth.from.date) <= end && Date.parse(epcGrowth.to.date) <= end && Date.parse(epcGrowth.to.date) >= start);
          const priceChange = Number(earlierSale.price) > 0 ? Number(laterSale.price) / Number(earlierSale.price) - 1 : NaN;
          const score = Math.max(0, ...episodeApplications.map(planningStoryScore)) + Math.min(3, positiveStructural.length * 2) + Math.min(2, implementation.length) + (areaAligned ? 4 : 0) + (priceChange > 0 ? 1 : 0);
          const candidate = { earlierSale, laterSale, applications: episodeApplications, structural, positiveStructural, implementation, areaAligned, priceChange, score };
          if (!best || candidate.score > best.score || (candidate.score === best.score && String(laterSale.date).localeCompare(String(best.laterSale.date)) > 0)) best = candidate;
        }
        return best;
      }

      function propertyStoryContextSentence(item) {
        const candidates = [];
        const point = transactionGeoPoint(item);
        const exactPoint = ["exact", "address"].includes(point?.[3]);
        const estate = estateForTransaction(item);
        if (estate && String(item?.estateEvidenceStatus || "").toLowerCase() === "verified") {
          candidates.push({ score: 9, kind: "estate", text: `Its place within ${estate.name} is likely to underpin scarcity and buyer appeal.` });
        }
        const constraints = item?.planningConstraints || {};
        if (constraints.floodRiskZone) {
          const zones = Array.from(String(constraints.floodRiskZone).matchAll(/(?:zone|\/)\s*(2|3)\b/gi), match => Number(match[1]));
          const zone = zones.includes(3) ? 3 : zones.includes(2) ? 2 : null;
          if (zone) candidates.push({ score: exactPoint ? 9 : 7, text: `${exactPoint ? "The property" : "The wider postcode setting"} carries a mapped Flood Zone ${zone} flag, which may narrow buyer appetite and weigh on resale.` });
        }
        if (constraints.aonb && constraints.greenBelt) {
          candidates.push({ score: exactPoint ? 8 : 5, text: `${exactPoint ? "Set" : "The wider postcode setting sits"} within the Surrey Hills National Landscape and Green Belt, reinforcing rural scarcity and lifestyle appeal.` });
        } else if (constraints.conservationArea) {
          candidates.push({ score: exactPoint ? 7 : 5, text: `${exactPoint ? "Its" : "The wider"} conservation-area setting reinforces character and makes the planning history especially relevant.` });
        }
        const school = Array.isArray(item?.ofsted?.nearestSchools) ? item.ofsted.nearestSchools[0] : null;
        const schoolMetres = Number(school?.metres || 0);
        if (school?.name && schoolMetres > 0 && schoolMetres <= (exactPoint ? 1000 : 500)) {
          candidates.push({ score: 6, kind: "school", text: `${school.name} is close by at around ${formatDistanceKm(schoolMetres / 1000)}, a location advantage likely to support family-buyer demand.` });
        }
        const station = nearestStations(transactionGeoPoint(item), 1)[0];
        if (station && station.distanceKm <= (exactPoint ? 2 : 1)) {
          candidates.push({
            score: 7,
            kind: "station",
            text: `${station.name} station lies around ${formatDistanceKm(station.distanceKm)} away, with ${station.london} services listed at roughly ${formatMinutes(station.fastestMins)}.`,
            compactText: `around ${formatDistanceKm(station.distanceKm)} from ${station.name} station (${station.london} from ${formatMinutes(station.fastestMins)})`
          });
        }
        const airport = nearestAirports(transactionGeoPoint(item), 1)[0];
        if (airport && airport.driveMins <= 30) {
          candidates.push({ score: 5, text: `${airport.name} is the closest tracked air link, at an indicative drive of about ${formatMinutes(airport.driveMins)}.` });
        }
        candidates.sort((left, right) => right.score - left.score);
        const first = candidates[0];
        const second = candidates.slice(1).find(candidate => first?.kind === "estate" && candidate.kind === "station" && candidate.score >= 6);
        return first ? {
          text: second ? `Within ${estate.name}, it is ${second.compactText}, reinforcing scarcity and practical access.` : first.text,
          score: first.score,
          kind: first.kind || ""
        } : null;
      }

      function propertyValuationRound(value) {
        const amount = Number(value) || 0;
        const step = amount < 2000000 ? 25000 : amount < 5000000 ? 50000 : amount < 10000000 ? 100000 : amount < 20000000 ? 250000 : 500000;
        return Math.round(amount / step) * step;
      }

      function propertyWeightedMedian(values) {
        const usable = values.filter(item => Number(item?.value) > 0 && Number(item?.weight) > 0).sort((left, right) => left.value - right.value);
        const total = usable.reduce((sum, item) => sum + item.weight, 0);
        let running = 0;
        for (const item of usable) {
          running += item.weight;
          if (running >= total / 2) return item.value;
        }
        return usable[usable.length - 1]?.value || 0;
      }

      function propertyValuationBase(item, sales, seed, areaStale = false, forceFresh = false) {
        const seeded = valueAtPath(seed, "story.valuation");
        const suppliedTargetArea = Number(item?.floorAreaSqft || 0);
        const targetArea = suppliedTargetArea > 0 ? suppliedTargetArea : 0;
        const targetType = normalise(item?.propertyType);
        const targetKey = propertyRecordKey(item);
        const targetEstateId = estateForTransaction(item)?.key || "";
        const targetTown = normalise(item?.town);
        const targetMarket = normalise(item?.market);
        const orderedSales = sales.slice().sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
        const latestSale = orderedSales[0] || item;
        const universeValues = transactions;
        const liveAsOf = [propertyRecordsMeta.asOf, landRegMeta.to, propertyValuationUniverseLatestSaleDate, latestSale.date]
          .map(value => String(value || "").slice(0, 10))
          .filter(value => /^\d{4}-\d{2}-\d{2}$/.test(value))
          .sort()
          .pop() || `${cpihReferenceYear}-12-31`;
        const asOf = parseIso(liveAsOf) || analysisEnd || new Date();
        const seedMatchesLiveEvidence = Number(seeded?.baseEstimate) > 0 &&
          seeded.modelVersion === "property-valuation-1" &&
          seeded.cpihVersion === cpihVersion &&
          String(seeded.asOf || "").slice(0, 10) === liveAsOf &&
          String(seeded.ownSaleDate || "").slice(0, 10) === String(latestSale.date || "").slice(0, 10) &&
          Number(seeded.ownSalePrice || 0) === Number(latestSale.price || 0) &&
          Number(seeded.targetFloorAreaSqft || 0) === targetArea &&
          normalise(seeded.targetPropertyType) === targetType &&
          Boolean(seeded.targetAreaStaleAfterPlanning) === Boolean(areaStale) &&
          Boolean(seeded.nearFloorPriceFallback) === Boolean(seeded.comparableChannel === "absolute-price" && Number(latestSale.price || 0) <= nearFloorPriceCeiling) &&
          Number(seeded.transactionUniverseCount || 0) === universeValues.length &&
          String(seeded.transactionUniverseLatestSaleDate || "").slice(0, 10) === propertyValuationUniverseLatestSaleDate &&
          Number(seeded.transactionUniversePriceTotal || 0) === propertyValuationUniversePriceTotal;
        if (!forceFresh && seedMatchesLiveEvidence) {
          return { ...seeded, comparables: Array.isArray(seeded.comparables) ? seeded.comparables : [] };
        }
        const candidates = universeValues.map(candidate => {
          if (propertyRecordKey(candidate) === targetKey || String(candidate.category || "").toUpperCase() !== "A") return null;
          if (!targetType || normalise(candidate.propertyType) !== targetType) return null;
          const date = parseIso(String(candidate.date || "").slice(0, 10));
          if (!date || date > asOf || (asOf - date) / 86400000 > 365.2425 * 12) return null;
          const suppliedCandidateArea = Number(candidate.floorAreaSqft || 0);
          const candidateArea = suppliedCandidateArea > 0 ? suppliedCandidateArea : 0;
          const areaSimilarity = targetArea && candidateArea ? Math.exp(-Math.abs(Math.log(candidateArea / targetArea)) * 1.8) : .35;
          const distance = distanceKm(transactionGeoPoint(item), transactionGeoPoint(candidate));
          const distanceScore = Number.isFinite(distance) ? Math.exp(-Math.min(30, distance) / 7) : .25;
          const ageYears = Math.max(0, (asOf - date) / (365.2425 * 86400000));
          const recencyScore = Math.exp(-ageYears / 6);
          const candidateEstateId = estateForTransaction(candidate)?.key || "";
          const estateMatch = targetEstateId && targetEstateId === candidateEstateId ? 1 : !targetEstateId && !candidateEstateId ? .5 : 0;
          const streetMatch = normalise(item.street) && normalise(item.street) === normalise(candidate.street) ? 1 : 0;
          const postcodeMatch = outwardPostcode(item.postcode) === outwardPostcode(candidate.postcode) ? 1 : 0;
          const score = 100 * (.28 * areaSimilarity + .15 + .14 * distanceScore + .13 * recencyScore + .08 * (targetMarket && targetMarket === normalise(candidate.market) ? 1 : 0) + .12 * estateMatch + .07 * streetMatch + .03 * postcodeMatch);
          const adjustedPrice = realPriceForSale(candidate);
          const adjustedPpsf = candidateArea > 0 ? adjustedPrice / candidateArea : 0;
          const candidateEpcDate = parseIso(String(candidate.epcRegistrationDate || "").slice(0, 10));
          const epcSaleGapYears = candidateEpcDate ? (date - candidateEpcDate) / (365.2425 * 86400000) : NaN;
          const candidateAreaStaleAtSale = Boolean(candidateEpcDate && propertyPlanningEvidence(candidate).applications.some(application => {
            const applicationDate = planningStoryDateValue(application)?.getTime();
            return planningStoryOutcome(application) === "positive" && ["replacement", "enlargement", "amenity"].includes(planningStoryCategory(application)) &&
              Number.isFinite(applicationDate) && applicationDate > candidateEpcDate.getTime() && applicationDate <= date.getTime();
          }));
          const trustedPpsf = Boolean(targetArea && candidateArea && candidateArea / targetArea >= .5 && candidateArea / targetArea <= 2 && Number.isFinite(epcSaleGapYears) && epcSaleGapYears >= -1 && epcSaleGapYears <= 5 && !candidateAreaStaleAtSale);
          return {
            candidate,
            propertyId: propertyRecordKey(candidate),
            transactionId: String(candidate.id || ""),
            category: String(candidate.category || "").toUpperCase(),
            date: String(candidate.date || "").slice(0, 10),
            price: Number(candidate.price || 0),
            floorAreaSqft: candidateArea,
            score,
            distance,
            adjustedPrice,
            adjustedPpsf,
            trustedPpsf,
            areaStaleAtSale: candidateAreaStaleAtSale,
            ageYears,
            estateId: candidateEstateId,
            town: normalise(candidate.town),
            market: normalise(candidate.market)
          };
        }).filter(Boolean).sort((left, right) => right.score - left.score || String(right.date).localeCompare(String(left.date)));

        const scopeDefinitions = [];
        if (targetEstateId) scopeDefinitions.push({ name: "estate", filter: candidate => candidate.estateId === targetEstateId });
        if (targetTown) scopeDefinitions.push({ name: "town", filter: candidate => candidate.town === targetTown });
        if (targetMarket) scopeDefinitions.push({ name: "market", filter: candidate => candidate.market === targetMarket });
        scopeDefinitions.push({ name: "surrey-prime", filter: () => true });
        let selected = [];
        let selectedScope = "surrey-prime";
        let selectedWindow = 12;
        let fallback = { values: [], scope: "surrey-prime", window: 12 };
        for (const scope of scopeDefinitions) {
          const scoped = candidates.filter(scope.filter);
          for (const window of [5, 7, 10, 12]) {
            const windowed = scoped.filter(candidate => candidate.ageYears <= window);
            if (windowed.length > fallback.values.length) fallback = { values: windowed, scope: scope.name, window };
            if (windowed.length >= 5) {
              selected = windowed.slice(0, 12);
              selectedScope = scope.name;
              selectedWindow = window;
              break;
            }
          }
          if (selected.length) break;
        }
        if (!selected.length) {
          selected = fallback.values.slice(0, 12);
          selectedScope = fallback.scope;
          selectedWindow = fallback.window;
        }

        const ppsfValues = selected.filter(candidate => targetArea > 0 && candidate.adjustedPpsf > 0 && candidate.trustedPpsf && !areaStale).map(candidate => ({ value: candidate.adjustedPpsf * targetArea, weight: candidate.score ** 2 }));
        const priceValues = selected.filter(candidate => candidate.adjustedPrice > 0).map(candidate => ({ value: candidate.adjustedPrice, weight: candidate.score ** 2 }));
        const comparableChannel = ppsfValues.length >= 3 ? "price-per-sq-ft" : "absolute-price";
        const chosenValues = comparableChannel === "price-per-sq-ft" ? ppsfValues : priceValues;
        const comparableCentre = propertyWeightedMedian(chosenValues);
        const comparablePpsf = propertyWeightedMedian(selected.filter(candidate => candidate.adjustedPpsf > 0 && candidate.trustedPpsf).map(candidate => ({ value: candidate.adjustedPpsf, weight: candidate.score ** 2 })));
        const selectedWeights = chosenValues.map(candidate => candidate.weight);
        const weightTotal = selectedWeights.reduce((sum, weight) => sum + weight, 0);
        const weightSquares = selectedWeights.reduce((sum, weight) => sum + weight ** 2, 0);
        const effectiveSampleSize = weightSquares > 0 ? weightTotal ** 2 / weightSquares : 0;
        const ownAnchor = inflationAdjustedPrice(latestSale);
        const latestSaleDate = parseIso(String(latestSale.date || "").slice(0, 10));
        const saleAgeYears = latestSaleDate ? Math.max(0, (asOf - latestSaleDate) / (365.2425 * 86400000)) : 12;
        const latestSaleCategory = String(latestSale.category || "").toUpperCase();
        const ownCategoryFactor = latestSaleCategory === "A" ? 1 : latestSaleCategory === "B" ? .35 : .2;
        let ownWeight = ownCategoryFactor * Math.exp(-saleAgeYears / 10);
        const scopeFactor = ({ estate: 1, town: .9, market: .75, "surrey-prime": .6 })[selectedScope] || .6;
        let comparableWeight = (comparableChannel === "price-per-sq-ft" ? 1 : .6) * Math.min(1, effectiveSampleSize / 8) * scopeFactor;
        const nearFloorPriceFallback = comparableChannel === "absolute-price" && Number(latestSale.price || 0) <= nearFloorPriceCeiling;
        if (nearFloorPriceFallback) {
          comparableWeight *= .35;
          ownWeight = Math.max(ownWeight, .7);
        }
        const splitSignal = Boolean(ownAnchor > 0 && comparableCentre > 0 && Math.max(ownAnchor, comparableCentre) / Math.min(ownAnchor, comparableCentre) > 1.35);
        if (splitSignal) comparableWeight *= .3;
        let rawBase = ownAnchor || comparableCentre || Number(item.price || 0);
        if (ownAnchor > 0 && comparableCentre > 0) {
          const totalWeight = ownWeight + comparableWeight;
          rawBase = totalWeight > 0
            ? Math.exp((ownWeight * Math.log(ownAnchor) + comparableWeight * Math.log(comparableCentre)) / totalWeight)
            : ownAnchor;
        }
        if (ownAnchor > 0) {
          const limits = saleAgeYears <= 3 ? [.8, 1.3] : saleAgeYears <= 7 ? [.7, 1.5] : [.6, 1.8];
          rawBase = clamp(ownAnchor * limits[0], ownAnchor * limits[1], rawBase);
        }
        let confidence = comparableChannel === "price-per-sq-ft" && effectiveSampleSize >= 8 && ownCategoryFactor === 1 ? "high" : effectiveSampleSize >= 3 ? "medium" : "low";
        if (nearFloorPriceFallback || splitSignal) confidence = "low";
        const baseEstimate = propertyValuationRound(rawBase);
        return {
          modelVersion: "property-valuation-1",
          cpihVersion,
          asOf: liveAsOf,
          baseEstimate,
          estimatedCurrentValue: baseEstimate,
          planningAdjustment: 0,
          confidence,
          targetFloorAreaSqft: targetArea,
          targetPropertyType: String(item?.propertyType || ""),
          ownSaleAnchor: Math.round(ownAnchor || 0),
          ownSaleDate: String(latestSale.date || "").slice(0, 10),
          ownSalePrice: Math.round(Number(latestSale.price || 0)),
          comparableCentre: Math.round(comparableCentre || 0),
          comparableMedianPricePerSqft: Math.round(comparablePpsf || 0),
          comparableCount: chosenValues.length,
          selectedComparableCount: selected.length,
          comparableChannel,
          comparableScope: selectedScope,
          comparableWindowYears: selectedWindow,
          effectiveSampleSize: Number(effectiveSampleSize.toFixed(2)),
          targetAreaStaleAfterPlanning: Boolean(areaStale),
          nearFloorPriceFallback,
          splitSignal,
          transactionUniverseCount: universeValues.length,
          transactionUniverseLatestSaleDate: propertyValuationUniverseLatestSaleDate,
          transactionUniversePriceTotal: propertyValuationUniversePriceTotal,
          comparables: selected.map(candidate => ({
            propertyId: candidate.propertyId,
            transactionId: candidate.transactionId,
            category: candidate.category,
            date: candidate.date,
            price: candidate.price,
            floorAreaSqft: candidate.floorAreaSqft,
            score: Number(candidate.score.toFixed(1)),
            distanceKm: Number.isFinite(candidate.distance) ? Number(candidate.distance.toFixed(2)) : null,
            adjustedPrice: Math.round(candidate.adjustedPrice || 0),
            adjustedPricePerSqft: Math.round(candidate.adjustedPpsf || 0),
            trustedPricePerSqft: candidate.trustedPpsf,
            areaStaleAtSale: candidate.areaStaleAtSale,
            ageYears: Number(candidate.ageYears.toFixed(2)),
            estateId: candidate.estateId,
            town: candidate.town,
            market: candidate.market,
            usedInChannel: comparableChannel === "absolute-price" ? candidate.adjustedPrice > 0 : candidate.trustedPpsf && !areaStale
          }))
        };
      }

      function planningAddedAreaSqft(application) {
        if (planningStoryCategory(application) !== "enlargement") return 0;
        const values = [];
        const addValue = (value, unit = "sq ft") => {
          const amount = Number(value || 0);
          const sqft = /(?:sq\.?\s*m|sqm|m2|m²|metre|meter)/i.test(String(unit)) ? amount * 10.7639 : amount;
          if (sqft >= 100 && sqft <= 10000) values.push(sqft);
        };
        addValue(application?.additionalFloorAreaSqft || application?.addedAreaSqft || application?.floorAreaIncreaseSqft);
        addValue(application?.additionalFloorAreaSqm || application?.addedAreaSqm || application?.floorAreaIncreaseSqm, "sqm");
        const existingSqft = Number(application?.existingFloorAreaSqft || 0);
        const proposedSqft = Number(application?.proposedFloorAreaSqft || 0);
        const existingSqm = Number(application?.existingFloorAreaSqm || 0);
        const proposedSqm = Number(application?.proposedFloorAreaSqm || 0);
        if (existingSqft > 0 && proposedSqft > existingSqft) addValue(proposedSqft - existingSqft);
        if (existingSqm > 0 && proposedSqm > existingSqm) addValue(proposedSqm - existingSqm, "sqm");

        const proposal = String(application?.proposal || application?.description || "").toLowerCase().replace(/,/g, "");
        const bothUnits = /\b(?:from|existing(?: floor area)?(?: of)?)\s*(\d+(?:\.\d+)?)\s*(sq\.?\s*ft|sqft|square feet|square foot|sq\.?\s*m|sqm|m2|m²|square metres?|square meters?).{0,80}?\b(?:to|proposed(?: floor area)?(?: of)?)\s*(\d+(?:\.\d+)?)\s*(sq\.?\s*ft|sqft|square feet|square foot|sq\.?\s*m|sqm|m2|m²|square metres?|square meters?)\b/gi;
        for (const match of proposal.matchAll(bothUnits)) {
          const before = /(?:sq\.?\s*m|sqm|m2|m²|metre|meter)/i.test(match[2]) ? Number(match[1]) * 10.7639 : Number(match[1]);
          const after = /(?:sq\.?\s*m|sqm|m2|m²|metre|meter)/i.test(match[4]) ? Number(match[3]) * 10.7639 : Number(match[3]);
          if (after > before) addValue(after - before);
        }
        const sharedUnit = /\b(?:from|existing(?: floor area)?(?: of)?)\s*(\d+(?:\.\d+)?)\s*.{0,30}?\b(?:to|proposed(?: floor area)?(?: of)?)\s*(\d+(?:\.\d+)?)\s*(sq\.?\s*ft|sqft|square feet|square foot|sq\.?\s*m|sqm|m2|m²|square metres?|square meters?)\b/gi;
        for (const match of proposal.matchAll(sharedUnit)) {
          const scale = /(?:sq\.?\s*m|sqm|m2|m²|metre|meter)/i.test(match[3]) ? 10.7639 : 1;
          if (Number(match[2]) > Number(match[1])) addValue((Number(match[2]) - Number(match[1])) * scale);
        }
        const incremental = /\b(?:additional|adding|adds?|added|another|increase(?:d|s|ing)?(?:\s+(?:in|of)\s+(?:the\s+)?(?:gross\s+|total\s+)?floor area)?\s+(?:by|of)|extend(?:ed|ing)?\s+by|extension\s+of)\s*(\d+(?:\.\d+)?)\s*(sq\.?\s*ft|sqft|square feet|square foot|sq\.?\s*m|sqm|m2|m²|square metres?|square meters?)\b/gi;
        for (const match of proposal.matchAll(incremental)) addValue(match[1], match[2]);
        const describedExtension = /\b(\d+(?:\.\d+)?)\s*(sq\.?\s*ft|sqft|square feet|square foot|sq\.?\s*m|sqm|m2|m²|square metres?|square meters?)\s+(?:extension|addition)\b/gi;
        for (const match of proposal.matchAll(describedExtension)) addValue(match[1], match[2]);
        return Math.round(Math.max(0, ...values));
      }

      function propertyCurrentValuation(item, sales, planningEvidence, seed) {
        const observations = datedEpcObservations(item);
        const latestEpcDate = observations.length ? Date.parse(observations[observations.length - 1].date) : NaN;
        const orderedSales = sales.slice().sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
        const latestSaleDate = Date.parse(String(orderedSales[0]?.date || item?.date || "").slice(0, 10));
        const evidenceDate = Math.max(...[latestEpcDate, latestSaleDate].filter(Number.isFinite));
        const isStructuralPositive = application => {
          return ["replacement", "enlargement", "amenity"].includes(planningStoryCategory(application)) && planningStoryOutcome(application) === "positive";
        };
        const postEpcStructuralPositive = planningEvidence.applications.filter(application => {
          const applicationDate = planningStoryDateValue(application)?.getTime();
          return isStructuralPositive(application) && Number.isFinite(latestEpcDate) && Number.isFinite(applicationDate) && applicationDate > latestEpcDate;
        });
        const structuralPositive = planningEvidence.applications.filter(application => {
          const applicationDate = planningStoryDateValue(application)?.getTime();
          return isStructuralPositive(application) &&
            (!Number.isFinite(evidenceDate) || Number.isFinite(applicationDate) && applicationDate > evidenceDate);
        });
        const areaStale = postEpcStructuralPositive.length > 0;
        const seededValuation = valueAtPath(seed, "story.valuation");
        const forceFresh = Boolean(seededValuation) && Boolean(seededValuation.targetAreaStaleAfterPlanning) !== areaStale;
        const valuation = propertyValuationBase(item, sales, seed, areaStale, forceFresh);
        const base = Number(valuation.baseEstimate || valuation.estimatedCurrentValue || 0);
        const earliestPositive = Math.min(...structuralPositive.map(application => planningStoryDateValue(application)?.getTime()).filter(Number.isFinite));
        const implementation = planningEvidence.applications.filter(application => {
          const applicationDate = planningStoryDateValue(application)?.getTime();
          return (planningStoryOutcome(application) === "implementation" || planningStoryCategory(application) === "implementation") &&
            (!Number.isFinite(earliestPositive) || Number.isFinite(applicationDate) && applicationDate >= earliestPositive);
        });
        let planningAdjustment = 0;
        let approvedAdditionalAreaSqft = 0;
        if (base > 0 && structuralPositive.length) {
          approvedAdditionalAreaSqft = Math.max(0, ...structuralPositive.map(planningAddedAreaSqft));
          const ppsf = Number(valuation.comparableMedianPricePerSqft || 0);
          if (approvedAdditionalAreaSqft && ppsf) {
            planningAdjustment = approvedAdditionalAreaSqft * ppsf * (implementation.length ? .6 : .25);
          } else {
            const strongest = structuralPositive.map(planningStoryCategory).sort((left, right) => ({ replacement: 3, enlargement: 2, amenity: 1 }[right] || 0) - ({ replacement: 3, enlargement: 2, amenity: 1 }[left] || 0))[0];
            const rate = Math.min(.08, ({ replacement: .04, enlargement: .03, amenity: .015 }[strongest] || .015) + (implementation.length ? .025 : 0));
            planningAdjustment = base * rate;
          }
          planningAdjustment = propertyValuationRound(Math.min(base * .25, planningAdjustment));
        }
        const estimatedCurrentValue = propertyValuationRound(base + planningAdjustment);
        const planningSignals = structuralPositive.length ? {
          postEvidenceApprovedSchemeCount: structuralPositive.length,
          implementationSignalCount: implementation.length,
          ...(approvedAdditionalAreaSqft ? { approvedAdditionalAreaSqft } : {}),
          references: structuralPositive.map(application => String(application?.reference || application?.applicationReference || "")).filter(Boolean)
        } : null;
        return { ...valuation, planningAdjustment, estimatedCurrentValue, ...(planningSignals ? { planningSignals } : {}) };
      }

      function valuationStoryParagraph(valuation) {
        const basis = [];
        if (Number(valuation.comparableCount) > 0) {
          basis.push(valuation.comparableChannel === "price-per-sq-ft"
            ? `${formatNumber(valuation.comparableCount)} floor-area comparable sales`
            : `${formatNumber(valuation.comparableCount)} recent comparable sales`);
        }
        if (Number(valuation.targetFloorAreaSqft) > 0) {
          basis.push(valuation.targetAreaStaleAfterPlanning
            ? `the ${compactSqft(valuation.targetFloorAreaSqft)} EPC as the pre-scheme baseline`
            : `the ${compactSqft(valuation.targetFloorAreaSqft)} EPC`);
        }
        if (Number(valuation.ownSaleAnchor) > 0) basis.push("inflation-adjusted sale history");
        let sentence = basis.length ? `The estimate uses ${joinStoryItems(basis)}.` : "The estimate is anchored to the house's sale evidence.";
        if (Number(valuation.planningAdjustment) > 0) {
          const approvedAdditionalAreaSqft = Number(valuation?.planningSignals?.approvedAdditionalAreaSqft || 0);
          const scheme = approvedAdditionalAreaSqft > 0 ? `${compactSqft(approvedAdditionalAreaSqft)} approved post-EPC scheme` : "approved post-EPC development";
          sentence += ` It adds ${compactPrice(valuation.planningAdjustment)} for the ${scheme}.`;
        }
        return `${sentence} Estimated current value — ${compactPrice(valuation.estimatedCurrentValue)}.`;
      }

      function livePropertyStoryParagraphs(item, sales, planningEvidence, seed = null) {
        const coverageStart = String(salesHistoryMeta.coverageFrom || landRegMeta.from || "1995").slice(0, 4);
        const orderedSales = sales.slice().sort((left, right) => String(right.date || "").localeCompare(String(left.date || "")));
        const latest = orderedSales[0] || item;
        const earliest = orderedSales[orderedSales.length - 1] || latest;
        const history = [];
        if (orderedSales.length > 1) {
          const nominalChange = Number(earliest.price) > 0 ? Number(latest.price) / Number(earliest.price) - 1 : NaN;
          const count = orderedSales.length === 2 ? "twice" : `${formatNumber(orderedSales.length)} times`;
          const start = parseIso(String(earliest.date || "").slice(0, 10));
          const end = parseIso(String(latest.date || "").slice(0, 10));
          const years = start && end ? Math.max(1, Math.round((end - start) / (365.2425 * 86400000))) : 0;
          const movement = Number.isFinite(nominalChange)
            ? `—a ${Math.abs(nominalChange * 100).toFixed(0)}% nominal ${nominalChange >= 0 ? "rise" : "fall"}${years ? ` over ${years} year${years === 1 ? "" : "s"}` : ""}`
            : "";
          history.push(`Sold ${count}: ${compactPrice(earliest.price)} in ${String(earliest.date || "").slice(0, 4)} to ${compactPrice(latest.price)} in ${String(latest.date || "").slice(0, 4)}${movement}.`);
        } else {
          const saleDate = parseIso(String(latest.date || "").slice(0, 10));
          const ageYears = saleDate && analysisEnd ? (analysisEnd - saleDate) / (365.2425 * 86400000) : 0;
          history.push(ageYears >= 15
            ? `A long-held house: last sold for ${compactPrice(latest.price)} in ${String(latest.date || "").slice(0, 4)}, with no later Price Paid sale.`
            : `The Price Paid record since ${coverageStart} shows one sale: ${compactPrice(latest.price)} in ${String(latest.date || "").slice(0, 4)}.`);
        }

        const epcGrowth = epcAreaStoryData(item);
        const episode = bestStoryPlanningEpisode(orderedSales, planningEvidence.applications, epcGrowth);
        if (episode) {
          const positives = episode.applications.filter(application => planningStoryOutcome(application) === "positive");
          const followOns = episode.applications.filter(application => planningStoryOutcome(application) === "implementation" || planningStoryCategory(application) === "implementation");
          const lead = followOns.length && followOns.length === episode.applications.length
            ? episode.applications.length === 1 ? "One planning follow-on record" : `A ${formatNumber(episode.applications.length)}-record planning follow-on sequence`
            : positives.length === episode.applications.length
            ? episode.applications.length === 1 ? "One approved planning application" : `${formatNumber(episode.applications.length)} approved planning applications`
            : positives.length
              ? `${formatCount(episode.applications.length, "planning application")}, including ${formatCount(positives.length, "explicit approval")}`
              : episode.applications.length === 1 ? "One planning record" : `A ${formatNumber(episode.applications.length)}-record planning sequence`;
          const highlights = planningStoryHighlights(episode.applications);
          const planningSentence = `${lead} between ${String(episode.earlierSale.date).slice(0, 4)} and ${String(episode.laterSale.date).slice(0, 4)}${highlights.length ? `, led by ${joinStoryItems(highlights)}` : ""}`;
          if (epcGrowth && episode.areaAligned) {
            history.push(`${planningSentence}.`);
            history.push(`EPC floor area then rose from ${compactSqft(epcGrowth.from.sqft)} in ${epcGrowth.from.year} to ${compactSqft(epcGrowth.to.sqft)} in ${epcGrowth.to.year}; together, the sequence suggests the house was materially enlarged before resale.`);
          } else if (episode.structural.length) {
            const contribution = Number.isFinite(episode.priceChange) ? ` behind the later ${Math.abs(episode.priceChange * 100).toFixed(0)}% ${episode.priceChange >= 0 ? "uplift" : "price movement"}` : " before resale";
            history.push(`${planningSentence}; the sequence suggests a development-led chapter${contribution}, alongside market movement.`);
          } else if (followOns.length) history.push(`${planningSentence}, showing an earlier permission moving through delivery details.`);
          else history.push(`${planningSentence}.`);
        } else if (planningEvidence.applications.length) {
          const applications = planningEvidence.applications;
          const highlights = planningStoryHighlights(applications);
          const positiveCount = applications.filter(application => planningStoryOutcome(application) === "positive").length;
          const followOnCount = applications.filter(application => planningStoryOutcome(application) === "implementation" || planningStoryCategory(application) === "implementation").length;
          const maintenanceCount = applications.filter(application => planningStoryCategory(application) === "maintenance").length;
          const dates = applications.map(planningStoryDateValue).filter(Boolean);
          const latestSaleDate = parseIso(String(latest.date || "").slice(0, 10));
          const timing = dates.length && latestSaleDate && dates.every(date => date > latestSaleDate) ? "since its latest sale" : dates.length && latestSaleDate && dates.every(date => date < latestSaleDate) ? "before its latest sale" : "around its recorded history";
          const focus = highlights.length ? ` focused on ${joinStoryItems(highlights)}` : "";
          if (followOnCount === applications.length) {
            history.push(`Its ${formatCount(applications.length, "follow-on planning record")} ${timing}${focus}, showing an earlier permission moving through delivery details.`);
          } else if (maintenanceCount === applications.length) {
            history.push(`Its ${formatCount(applications.length, "planning record")} ${timing}${focus}, reflecting ongoing management of the house and grounds.`);
          } else if (followOnCount + maintenanceCount === applications.length) {
            history.push(`Its ${formatCount(applications.length, "planning record")} ${timing}, covering delivery details and ongoing management of the grounds.`);
          } else {
            if (positiveCount) {
              const focusText = highlights.length ? ` and focus on ${joinStoryItems(highlights)}` : "";
              history.push(`Its ${formatCount(applications.length, "planning application")} ${timing} ${applications.length === 1 ? "includes" : "include"} ${formatCount(positiveCount, "explicit approval")}${focusText}, pointing to an active improvement chapter.`);
            } else {
              history.push(`Its ${formatCount(applications.length, "planning application")} ${timing}${focus}, pointing to an active improvement chapter.`);
            }
          }
        } else if (planningEvidence.checkedNone) {
          history.push(orderedSales.length === 1
            ? "With no property-linked applications in the completed planning search, its recent story is one of long ownership rather than documented redevelopment."
            : "No property-linked applications appear in the completed planning search, so the record reads as market resale rather than a documented redevelopment cycle.");
        }
        if (!(epcGrowth && episode?.areaAligned) && Number(item?.floorAreaSqft) > 0) {
          history.push(`The latest EPC records ${compactSqft(item.floorAreaSqft)}.`);
        }
        const contextSignal = propertyStoryContextSentence(item);
        if (contextSignal && contextSignal.score >= 5) history.push(contextSignal.text);
        const valuation = propertyCurrentValuation(item, orderedSales, planningEvidence, seed);
        return [history.join(" ").replace(/\s+/g, " ").trim(), valuationStoryParagraph(valuation)].filter(Boolean).slice(0, 2);
      }

      function materialisePropertyRecord(item) {
        const recordKey = propertyRecordKey(item);
        if (materialisedPropertyRecordCache.has(recordKey)) return materialisedPropertyRecordCache.get(recordKey);
        const seed = propertySeedForTransaction(item);
        const sales = salesHistoryForTransaction(item);
        const planningEvidence = propertyPlanningEvidence(item);
        const liveParagraphs = livePropertyStoryParagraphs(item, sales, planningEvidence, seed);
        const persistentParagraphs = seedStoryParagraphs(seed);
        const persistentStoryIsCurrent = persistentParagraphs.length === 2 && liveParagraphs.length === 2 &&
          persistentParagraphs.every((paragraph, index) => paragraph === liveParagraphs[index]);
        const paragraphs = persistentStoryIsCurrent ? persistentParagraphs : liveParagraphs;
        const record = {
          id: recordKey,
          seed,
          sales,
          planningEvidence,
          paragraphs: paragraphs.length ? paragraphs : persistentParagraphs,
          storyBasis: persistentStoryIsCurrent
            ? "Persistent evidence-backed property record"
            : seed ? "Persistent record refreshed from current property evidence" : "Current property evidence"
        };
        materialisedPropertyRecordCache.set(recordKey, record);
        return record;
      }

      function propertyStoryHtml(record) {
        const estimatePrefix = "Estimated current value — ";
        const paragraphs = record.paragraphs.slice(0, 2).map(paragraph => {
          const estimateIndex = paragraph.indexOf(estimatePrefix);
          if (estimateIndex < 0) return `<p>${escapeHtml(paragraph)}</p>`;
          const narrative = paragraph.slice(0, estimateIndex).trim();
          const estimate = paragraph.slice(estimateIndex).trim();
          return `${narrative ? `<p>${escapeHtml(narrative)}</p>` : ""}<p class="property-estimate"><strong>${escapeHtml(estimate)}</strong></p>`;
        }).join("");
        return `<section class="context-section property-story"><h3>Property Story</h3><div class="property-story-copy">${paragraphs}</div></section>`;
      }

      function propertyCoverageSummary(entry, fallbackCount, singular, plural) {
        if (!entry || typeof entry !== "object") return "";
        const status = propertyCoverageStatus(entry);
        const suppliedCount = Number(entry.recordCount);
        const count = Number.isFinite(suppliedCount) && suppliedCount >= 0 ? suppliedCount : Math.max(0, Number(fallbackCount) || 0);
        const noun = count === 1 ? singular : plural;
        const checkedAt = entry.checkedAt || entry.updatedAt || "";
        const checkedSuffix = checkedAt ? ` · checked ${formatPlanningDate(checkedAt)}` : "";
        if (propertyCoverageIsCheckedNone(entry)) {
          const scope = entry.coverageMode === "full-available-history" ? "Full available history checked" : "Source check complete";
          return `${scope} · no matched ${plural}${checkedSuffix}`;
        }
        if (status === "complete") return `${formatNumber(count)} matched ${noun} · complete available history${checkedSuffix}`;
        if (status === "partial") return `${formatNumber(count)} matched ${noun} · partial coverage${checkedSuffix}`;
        if (status === "failed") return `Source check failed${checkedSuffix}`;
        if (status === "not_checked") return "Source not yet checked";
        if (status === "unavailable") return "Source unavailable";
        return count > 0 ? `${formatNumber(count)} matched ${noun} · coverage extent not confirmed` : "Coverage extent not confirmed";
      }

      function propertyPlanningDataValue(record) {
        const planning = record.planningEvidence;
        if (planning.total > 0) return formatNumber(planning.total);
        if (planning.checkedNone) return "0 matched · full check";
        const seedCoverage = propertySeedCoverage(record.seed, "planning");
        if (propertyCoverageIsCheckedNone(seedCoverage)) return "0 matched · full check";
        const seedCount = seedEvidenceCount(record.seed, "planning");
        if (seedCount > 0) return formatNumber(seedCount);
        return "Full history unavailable";
      }

      function propertyEvidenceDetailsHtml(item, record) {
        const completeSales = loadedSalesHistoryRecord(item);
        const fullSalesLoaded = Array.isArray(completeSales.transactions);
        const seedSalesCoverage = propertySeedCoverage(record.seed, "sales");
        const salesCoverage = propertyCoverageSummary(seedSalesCoverage, record.sales.length, "transaction", "transactions") || (fullSalesLoaded
          ? `${formatNumber(record.sales.length)} matched transactions · ${String(salesHistoryMeta.coverageFrom || "1995").slice(0, 4)} onwards`
          : `${formatNumber(record.sales.length)} loaded transactions · filtered market feed`);
        const schoolCount = Array.isArray(item.ofsted?.nearestSchools) ? item.ofsted.nearestSchools.length : 0;
        const planning = record.planningEvidence;
        const seedPlanningCoverage = propertySeedCoverage(record.seed, "planning");
        const livePlanningCoverage = planning.loaded ? {
          ...planning.history,
          status: planning.coverageStatus,
          recordCount: planning.total,
          complete: planning.complete || planning.history.complete
        } : null;
        const planningCoverage = propertyCoverageSummary(livePlanningCoverage, planning.total, "application", "applications") ||
          propertyCoverageSummary(seedPlanningCoverage, seedEvidenceCount(record.seed, "planning"), "application", "applications") ||
          "Full property-level history unavailable";
        const seedEpcCoverage = propertySeedCoverage(record.seed, "epc");
        const epcObservationCount = datedEpcObservations(item).length || (item.epcMatched || Number(item.floorAreaSqft) > 0 ? 1 : 0);
        const epcCoverage = propertyCoverageSummary(seedEpcCoverage, epcObservationCount, "certificate observation", "certificate observations") ||
          (epcObservationCount ? `${formatNumber(epcObservationCount)} matched ${epcObservationCount === 1 ? "certificate snapshot" : "certificate observations"}` : "No matched certificate snapshot");
        const recordUpdatedAt = record.seed?.updatedAt || valueAtPath(record.seed, "story.updatedAt") || propertyRecordsMeta.updatedAt || "";
        const flood = item.environmentAgency || {};
        const floodCheckedAt = flood.checkedAt || flood.updatedAt || "";
        const floodMonitor = floodEvidenceIsFresh(item)
          ? `Current alert check loaded${floodCheckedAt ? ` · ${formatPlanningDate(floodCheckedAt)}` : ""}`
          : floodCheckedAt
            ? `Last available alert check · ${formatPlanningDate(floodCheckedAt)} · current status unconfirmed`
            : "Current alert check unavailable";
        const rows = [
          ["Permanent record", `${record.storyBasis}${recordUpdatedAt ? ` · ${formatPlanningDate(recordUpdatedAt)}` : ""}`],
          ["Sales evidence", salesCoverage],
          ["Planning evidence", planningCoverage],
          ["EPC evidence", epcCoverage],
          ["Nearby schools", schoolCount ? `${formatNumber(schoolCount)} loaded within ${item.ofsted?.searchRadius || "the search radius"}` : "No nearby-school lookup loaded"],
          ["Flood monitor", floodMonitor]
        ];
        const caveat = `<p class="property-evidence-note">${escapeHtml("Missing matches remain unknown. Planning applications record proposals and decisions; they do not establish that work was completed.")}</p>`;
        return `<details class="insight-evidence property-evidence-details"><summary>Evidence &amp; coverage</summary><div class="property-evidence-body">${dataRows(rows)}${caveat}</div></details>`;
      }

      function salesHistoryContextHtml(item) {
        const sales = salesHistoryForTransaction(item);
        const latest = sales[0] || item;
        const complete = loadedSalesHistoryRecord(item);
        const coverage = complete.transactions ? "All Price Paid records · 1995 onwards" : [
          `${compactPrice(landRegPriceFloor)}+`,
          landRegMeta.from ? `${String(landRegMeta.from).slice(0, 4)} onwards` : ""
        ].filter(Boolean).join(" · ");
        const saleItem = sale => contextItem(
          sale.priceText || compactPrice(sale.price),
          [formatDate(sale.date), sale.propertyType, sale.category].filter(Boolean).join(" · ")
        );
        const rows = [
          ["Registered sales", formatNumber(sales.length)],
          ["Latest sale", formatDate(latest.date)],
          ["Latest price", latest.priceText || compactPrice(latest.price)],
          ["Source", latest.source || "HM Land Registry Price Paid Data"],
          ["Coverage", coverage],
          ["Record type", "Price Paid transactions"]
        ];
        const historyList = sales.length
          ? `<div class="context-list sales-history-list">${sales.map(saleItem).join("")}</div>`
          : "";
        return `<section class="context-section sales-history-card"><h3>Transaction History</h3>${dataRows(rows)}${historyList}</section>`;
      }

      function planningContextHtml(item) {
        const planning = item.planning || {};
        const constraints = item.planningConstraints || {};
        const history = planningHistoryForTransaction(item);
        const historyApps = Array.isArray(history.applications) ? history.applications : [];
        const nearbyApps = Array.isArray(planning.recentApplications) ? planning.recentApplications : [];
        const apps = (historyApps.length ? historyApps : nearbyApps).filter(app => app && typeof app === "object");
        const planningCoverageStatus = String(planning.coverageStatus || planning.status || "").toLowerCase();
        const planningCoverageUnknown = ["unknown", "unavailable", "not_checked", "not-checked"].includes(planningCoverageStatus);
        const hasHistoryTotal = history.totalApplications !== undefined && history.totalApplications !== null;
        const hasPublicTotal = planning.recentApplicationCount !== undefined && planning.recentApplicationCount !== null && !planningCoverageUnknown;
        const total = Number(hasHistoryTotal ? history.totalApplications : hasPublicTotal ? planning.recentApplicationCount : apps.length);
        const latest = history.latestApplication && typeof history.latestApplication === "object" ? history.latestApplication : apps[0] || null;
        const coverageUnknown = planningCoverageUnknown && !hasHistoryTotal && !apps.length;
        const rows = [["Matched applications", coverageUnknown ? "Coverage unknown" : Number.isFinite(total) ? formatNumber(total) : "Coverage unknown"]];
        if (history.authority) rows.push(["Planning authority", history.authority]);
        if (history.updatedAt) rows.push(["Last checked", formatPlanningDate(history.updatedAt)]);
        Object.entries(constraints).forEach(([key, value]) => {
          if (["source", "updatedAt", "lookupStatus", "constraintCount"].includes(key) || !value) return;
          rows.push([humaniseKey(key), value]);
        });
        const applicationItem = app => {
          const title = app.proposal || app.description || app.title || app.application || app.reference || "Planning application";
          const applicationDate = planningApplicationDate(app);
          const meta = [
            applicationDate ? formatPlanningDate(applicationDate) : "Date not supplied",
            app.reference,
            app.decision || app.status
          ].filter(Boolean).join(" · ");
          return linkedContextItem(title, meta, app.portalUrl || app.url);
        };
        if (latest) rows.push(["Latest application", planningApplicationDate(latest) ? formatPlanningDate(planningApplicationDate(latest)) : "Date not supplied"]);
        const latestHtml = latest ? `<div class="planning-latest"><span>Most recent</span>${applicationItem(latest)}</div>` : "";
        const remaining = latest
          ? apps.filter((app, index) => !(index === 0 && (app === latest || app.reference === latest.reference)))
          : apps;
        const moreHtml = remaining.length
          ? `<details class="planning-history-more"><summary>More (${remaining.length})</summary><div class="context-list">${remaining.map(applicationItem).join("")}</div></details>`
          : "";
        const emptyHtml = !latest && !total
          ? `<p class="context-copy">${escapeHtml(coverageUnknown ? "The loaded public source cannot establish nearby planning coverage for this property." : "No matched property applications are loaded; absence of a match is not evidence that none exist.")}</p>`
          : "";
        return `<section class="context-section planning-history-card"><h3>Planning History</h3>${dataRows(rows)}${latestHtml}${moreHtml}${emptyHtml}</section>`;
      }

      function schoolsContextHtml(item) {
        const ofsted = item.ofsted || {};
        const nearest = Array.isArray(ofsted.nearestSchools) ? ofsted.nearestSchools.slice(0, 5) : [];
        const rows = [
          ["Search radius", ofsted.searchRadius],
          ["Best nearby rating", ofsted.bestNearbyRating]
        ];
        const list = nearest.map(school => {
          const meta = [
            school.phase,
            school.distance,
            school.walkTime,
            school.postcode
          ].filter(Boolean).join(" · ");
          return contextItem(school.name || "School", meta);
        });
        return contextSection("Nearby Schools", rows, list);
      }

      function transportContextHtml(item) {
        const point = transactionGeoPoint(item);
        const nearest = nearestStations(point, 3);
        if (!nearest.length) return "";
        const primary = nearest[0];
        const list = nearest.map(station => {
          const meta = [
            `${formatDistanceKm(station.distanceKm)} away`,
            `${station.london} c. ${formatMinutes(station.fastestMins)} fastest`,
            station.crs
          ].filter(Boolean).join(" · ");
          return contextItem(station.name, meta);
        });
        return contextSection("Rail Access", [
          ["Nearest station", `${primary.name} · ${formatDistanceKm(primary.distanceKm)}`],
          ["London terminal", primary.london],
          ["Fastest London", `c. ${formatMinutes(primary.fastestMins)}`],
          ["Typical London", `c. ${formatMinutes(primary.typicalMins)}`]
        ], list);
      }

      function airportContextHtml(item) {
        const point = transactionGeoPoint(item);
        const nearest = nearestAirports(point, 3);
        if (!nearest.length) return "";
        const list = nearest.map(airport => {
          const meta = [
            `${formatDistanceKm(airport.distanceKm)} direct`,
            `drive c. ${formatMinutes(airport.driveMins)}`,
            airport.type
          ].filter(Boolean).join(" · ");
          return contextItem(airport.name, meta);
        });
        return contextSection("Airport Access", [], list);
      }

      function nationalRailLiveUrl(station) {
        return `https://www.nationalrail.co.uk/live-trains/departures/${encodeURIComponent(station.crs)}/`;
      }

      function stationLiveSection(station) {
        const link = nationalRailLiveUrl(station);
        return `<section class="context-section" data-live-station="${escapeHtml(station.id)}">
          <h3>Live Train Times</h3>
          <p class="context-copy">Live in-app departures need a Rail Data Marketplace / Darwin feed connected. <a href="${escapeHtml(link)}" target="_blank" rel="noopener">Open live station board</a></p>
        </section>`;
      }

      function refreshLiveStationTimes(station) {
        const template = window.INSIGHT_RAIL_LIVE_ENDPOINT;
        if (!station || !template || !window.fetch) return;
        const wrapper = Array.from(document.querySelectorAll("[data-live-station]")).find(element => element.dataset.liveStation === station.id);
        const target = wrapper?.querySelector(".context-copy");
        if (!target) return;
        const endpoint = String(template).replace("{crs}", encodeURIComponent(station.crs));
        fetch(endpoint)
          .then(response => response.ok ? response.json() : null)
          .then(payload => {
            const services = payload?.trainServices || payload?.services || payload?.departures || [];
            if (!Array.isArray(services) || !services.length) return;
            const rows = services.slice(0, 5).map(service => {
              const due = service.std || service.time || service.scheduled || "";
              const destination = service.destination?.[0]?.locationName || service.destination || service.to || "";
              const status = service.etd || service.status || service.expected || "";
              return [due, destination, status].filter(Boolean).join(" · ");
            }).filter(Boolean);
            if (!rows.length) return;
            target.innerHTML = rows.map(row => `<span>${escapeHtml(row)}</span>`).join("");
          })
          .catch(() => {});
      }

      function stationProfileHtml(station, nearbyRows) {
        const stats = statsForRows(nearbyRows || []);
        const nearby = nearbyRows.slice(0, 5).map(item => {
          const meta = [
            item.priceText,
            formatDate(item.date),
            item.distanceFromSelection ? formatDistanceKm(item.distanceFromSelection) : ""
          ].filter(Boolean).join(" · ");
          return contextItem(propertyDisplayName(item), meta);
        });
        return dataRows([
          ["Station", station.name],
          ["CRS", station.crs],
          ["London terminal", station.london],
          ["Fastest London", `c. ${formatMinutes(station.fastestMins)}`],
          ["Typical London", `c. ${formatMinutes(station.typicalMins)}`],
          ["Operator", station.operator]
        ]) + stationLiveSection(station) + contextSection("Nearby Prime Sales", [
          ["Within", "3km"],
          ["Sales", formatNumber(stats.count)],
          ["Average", compactPrice(stats.avg)]
        ], nearby);
      }

      function airportProfileHtml(airport, nearbyRows) {
        const stats = statsForRows(nearbyRows || []);
        const nearby = nearbyRows.slice(0, 5).map(item => {
          const meta = [
            item.priceText,
            formatDate(item.date),
            item.distanceFromSelection ? formatDistanceKm(item.distanceFromSelection) : ""
          ].filter(Boolean).join(" · ");
          return contextItem(propertyDisplayName(item), meta);
        });
        return dataRows([
          ["Airport", airport.name],
          ["Type", airport.type],
          ["Base access", `drive c. ${formatMinutes(airport.driveBaseMins)} plus distance`]
        ]) + contextSection("Nearby Prime Sales", [
          ["Within", "18km"],
          ["Sales", formatNumber(stats.count)],
          ["Average", compactPrice(stats.avg)]
        ], nearby);
      }

      function formatSchoolDate(value) {
        if (!value) return "";
        const text = String(value);
        const match = text.match(/^(\d{2})-(\d{2})-(\d{4})$/);
        if (match) return `${match[1]} ${new Date(`${match[3]}-${match[2]}-${match[1]}T00:00:00Z`).toLocaleString("en-GB", { month: "short" })} ${match[3]}`;
        return text;
      }

      function schoolProfileHtml(school, nearbyRows) {
        const stats = statsForRows(nearbyRows || []);
        const rows = [
          ["School", school.name],
          ["Sector", schoolSector(school)],
          ["Type", school.type],
          ["Ages", schoolAgeRange(school)],
          ["Phase", school.phase],
          ["Gender", school.gender],
          ["Admissions", school.admissions],
          ["Status", school.status],
          ["Pupils", school.pupils ? formatNumber(school.pupils) : ""],
          ["Capacity", school.capacity ? formatNumber(school.capacity) : ""],
          ["Inspectorate", school.inspectorate],
          ["Ofsted rating", school.ofstedRating || "Not supplied in current feed"],
          ["Last inspection", formatSchoolDate(school.lastInspection)],
          ["Postcode", school.postcode],
          ["Website", school.website]
        ];
        const nearby = nearbyRows.slice(0, 5).map(item => {
          const meta = [
            item.priceText,
            formatDate(item.date),
            item.distanceFromSelection ? formatDistanceKm(item.distanceFromSelection) : ""
          ].filter(Boolean).join(" · ");
          return contextItem(propertyDisplayName(item), meta);
        });
        return dataRows(rows) + contextSection("Nearby Prime Sales", [
          ["Within", "2.5km"],
          ["Sales", formatNumber(stats.count)],
          ["Average", compactPrice(stats.avg)]
        ], nearby);
      }

      function applyInsightAnswerLayout(answer) {
        const layout = answer?.layout || "compact";
        if (els.app) {
          if (answer) els.app.dataset.answerLayout = layout;
          else delete els.app.dataset.answerLayout;
        }
        [els.mapKey, els.mapTopbar].filter(Boolean).forEach(element => {
          if (layout === "report" && answer) {
            element.setAttribute("inert", "");
            element.setAttribute("aria-hidden", "true");
          } else {
            element.removeAttribute("inert");
            element.removeAttribute("aria-hidden");
          }
        });
        if (els.askStatus) els.askStatus.textContent = answer ? `${answer.title || "Ask INSIGHT"} ready` : "";
        if (!map || !window.requestAnimationFrame) return;
        window.requestAnimationFrame(() => {
          map.resize();
          const panelWidth = Math.round(els.answerWorkspace?.getBoundingClientRect().width || 0);
          const mapWidth = Math.round(document.getElementById("map")?.getBoundingClientRect().width || 0);
          const desired = answer ? panelWidth + 28 : 306;
          const right = mapWidth ? Math.min(desired, Math.max(0, mapWidth - 120)) : desired;
          if (typeof map.setPadding === "function") map.setPadding({ top: 0, right, bottom: 0, left: 0 });
        });
      }

      function renderInspector() {
        const ask = currentInsightAnswer();
        if (ask) {
          applyInsightAnswerLayout(ask);
          if (els.inspectorTitle) els.inspectorTitle.textContent = ask.title;
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = ask.subtitle || "Loaded data only";
          els.profileHeading.textContent = ask.title;
          els.profileType.textContent = ask.subtitle || "Loaded data only";
          els.profilePanel.className = "";
          els.profilePanel.innerHTML = ask.html;
          return;
        }
        applyInsightAnswerLayout(null);
        els.profilePanel.className = "";
        const stats = selectedContextStats(state.selectedRows);
        if (state.selectedType === "property") {
          const item = transactionsById.get(propertyId(state.selectedId));
          if (!item) {
            els.profileHeading.textContent = "Property";
            els.profileType.textContent = "";
            els.profilePanel.innerHTML = '<div class="empty">Property not found.</div>';
            return;
          }
          const estate = estateForTransaction(item);
          const point = transactionGeoPoint(item);
          const station = nearestStations(point, 1)[0];
          const airport = nearestAirports(point, 1)[0];
          const propertyRecord = materialisePropertyRecord(item);
          const latestEpc = latestEpcSnapshot(item);
          const listedStatus = listedStatusForDisplay(listedStatusSnapshot(item, propertyRecord.seed));
          els.profilePanel.className = "property-profile";
          if (els.inspectorTitle) els.inspectorTitle.textContent = propertyDisplayName(item);
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "";
          els.profileHeading.textContent = propertyDisplayName(item);
          els.profileType.textContent = "";
          const propertyRows = [
            ["Address", propertyAddressWithoutName(item)],
            ["Sold price", item.priceText || compactPrice(item.price)],
            ["Sale date", formatDate(item.date)],
            ["Type", item.propertyType],
            ...(estate ? [["Private estate", estate.name]] : []),
            ["Listed status", listedStatus.value, listedStatus.subdetail, listedStatus.evidenceLinks],
            ["Market", marketById(item.market)?.short || item.district],
            ["£/sq ft", compactPpsf(item.pricePerSqft) || "Awaiting EPC"],
            ["EPC area", compactSqft(item.floorAreaSqft)],
            ["EPC rating", latestEpc.rating, latestEpc.date ? formatDate(latestEpc.date) : ""],
            ["Planning records", propertyPlanningDataValue(propertyRecord)],
            ["Flood status", floodStatusForDisplay(item)],
            ["Nearest station", station ? `${station.name} · ${formatDistanceKm(station.distanceKm)} · ${formatMinutes(station.fastestMins)} to ${station.london}` : ""],
            ["Nearest airport", airport ? `${airport.name} · drive c. ${formatMinutes(airport.driveMins)}` : ""]
          ];
          const existingPropertyContextHtml = salesHistoryContextHtml(item) + planningContextHtml(item) + schoolsContextHtml(item) + transportContextHtml(item) + airportContextHtml(item);
          els.profilePanel.innerHTML = `<section class="property-data-section" aria-label="Property data">${dataRows(propertyRows)}</section>` +
            propertyStoryHtml(propertyRecord) +
            existingPropertyContextHtml + propertyEvidenceDetailsHtml(item, propertyRecord);
          return;
        }
        if (state.selectedType === "market") {
          const market = marketById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = market?.name || "Market";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Local authority profile";
          els.profileHeading.textContent = market?.name || "Local Authority";
          els.profileType.textContent = "Local authority";
        } else if (state.selectedType === "estate") {
          const estate = estatePins.find(pin => pin.key === state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = estate?.name || "Estate";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Private estate";
          els.profileHeading.textContent = estate?.name || "Estate";
          els.profileType.textContent = "Private estate";
        } else if (state.selectedType === "town") {
          if (els.inspectorTitle) els.inspectorTitle.textContent = townDisplayName(state.selectedId);
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Town profile";
          els.profileHeading.textContent = townDisplayName(state.selectedId);
          els.profileType.textContent = "Town";
        } else if (state.selectedType === "school") {
          const school = schoolById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = school?.name || "School";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = [schoolSector(school), schoolAgeRange(school), school?.postcode].filter(Boolean).join(" · ");
          els.profileHeading.textContent = school?.name || "School";
          els.profileType.textContent = "School";
          els.profilePanel.innerHTML = school ? schoolProfileHtml(school, state.selectedRows) : '<div class="empty">School not found.</div>';
          return;
        } else if (state.selectedType === "station") {
          const station = stationById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = station?.name || "Station";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = station ? `${station.london} · ${station.crs}` : "";
          els.profileHeading.textContent = station?.name || "Station";
          els.profileType.textContent = "Station";
          els.profilePanel.innerHTML = station ? stationProfileHtml(station, state.selectedRows) : '<div class="empty">Station not found.</div>';
          refreshLiveStationTimes(station);
          return;
        } else if (state.selectedType === "airport") {
          const airport = airportById(state.selectedId);
          if (els.inspectorTitle) els.inspectorTitle.textContent = airport?.name || "Airport";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = airport?.type || "";
          els.profileHeading.textContent = airport?.name || "Airport";
          els.profileType.textContent = "Airport";
          els.profilePanel.innerHTML = airport ? airportProfileHtml(airport, state.selectedRows) : '<div class="empty">Airport not found.</div>';
          return;
        } else {
          if (els.inspectorTitle) els.inspectorTitle.textContent = "Overview";
          if (els.inspectorSubtitle) els.inspectorSubtitle.textContent = "Click a market, estate, property, or ledger item.";
          els.profileHeading.textContent = "Overview";
          els.profileType.textContent = "";
        }
        const scopedEvidenceRows = state.selectedType === "overview" ? [] : [
          ["Pace confidence", velocityConfidenceLabel(stats)],
          ["Ranking evidence", rankEvidenceLabel(stats)]
        ];
        const baseRows = [
          ["Market heat", velocityLabel(stats)],
          ["Pace score", `${formatNumber(stats.paceScore)}/100 · ${stats.velocity.toFixed(2)}x normal`],
          ["Liquidity score", `${formatNumber(stats.liquidityScore)}/100`],
          ["Mature 12m sales", formatNumber(stats.recent)],
          ["120d signal", stats.signalQualified ? `${formatNumber(stats.signalRecent)} sales · ${accelerationLabel(stats)}` : `Unpublished · ${formatNumber(stats.signalRecent)} current / ${formatNumber(stats.signalBaselineTotal)} baseline`],
          ...scopedEvidenceRows,
          ["Mature 24m context", formatNumber(stats.context24)],
          [`Sales since ${coverageYear}`, formatNumber(stats.count)],
          ["Average value", compactPrice(stats.avg)],
          ["Highest sale", compactPrice(stats.max)],
          ["Real price movement (p.a.)", priceMovementLabel(stats)],
          ["Repeat-sale evidence", `${priceMovementEvidenceLabel(stats)} · ${priceMovementConfidenceLabel(stats)}`],
          ["Median holding period", stats.priceMedianHoldYears ? `${stats.priceMedianHoldYears.toFixed(1)} years` : ""],
          ["Avg £/sq ft", compactPpsf(stats.ppsfAvg) || "Awaiting EPC"]
        ];
        if (state.selectedType === "estate") {
          const estate = estatePins.find(pin => pin.key === state.selectedId);
          const market = estate ? marketById(estate.market) : null;
          els.profilePanel.innerHTML = dataRows([
            ["Market", market?.short || ""],
            ["Latest recorded sale", stats.latest ? `${stats.latest.priceText || compactPrice(stats.latest.price)} · ${formatDate(stats.latest.date)}` : `No qualifying ${compactPrice(landRegPriceFloor)}+ sales`],
            ["Market heat", velocityLabel(stats)],
            ["Pace score", stats.count ? `${formatNumber(stats.paceScore)}/100 · ${stats.velocity.toFixed(2)}x` : "Insufficient evidence"],
            ["Liquidity score", stats.count ? `${formatNumber(stats.liquidityScore)}/100` : "Insufficient evidence"],
            ["Mature 12m sales", formatNumber(stats.recent)],
            ["120d signal", stats.signalQualified ? `${formatNumber(stats.signalRecent)} sales · ${accelerationLabel(stats)}` : "Unpublished · insufficient seasonal depth"],
            ["Pace confidence", velocityConfidenceLabel(stats)],
            ["Ranking evidence", rankEvidenceLabel(stats)],
            [`Sales since ${coverageYear}`, formatNumber(stats.count)],
            ["Average sale · last 24m", stats.context24Avg ? compactPrice(stats.context24Avg) : "No qualifying sales"],
            ["Average £/sq ft · last 24m", stats.context24PpsfAvg ? compactPpsf(stats.context24PpsfAvg) : "Insufficient evidence"],
            ["Highest recorded sale", compactPrice(stats.max)],
            ["Real price movement (p.a.)", priceMovementLabel(stats)],
            ["Repeat-sale evidence", `${priceMovementEvidenceLabel(stats)} · ${priceMovementConfidenceLabel(stats)}`],
            ["Median holding period", stats.priceMedianHoldYears ? `${stats.priceMedianHoldYears.toFixed(1)} years` : "Insufficient evidence"]
          ]) + estateRoadsSection(estate);
          return;
        }
        els.profilePanel.innerHTML = dataRows(baseRows);
      }

      function renderLedger() {
        const hasQuestion = Boolean(insightQuestion());
        const ask = hasQuestion ? currentInsightAnswer() : null;
        const hideForAnswer = ask?.showLedger === false;
        if (els.ledgerSection) els.ledgerSection.hidden = hideForAnswer || (state.selectedType === "property" && !hasQuestion);
        if (hideForAnswer || (state.selectedType === "property" && !hasQuestion)) return;
        const allRows = rowsMatchingSearch(state.selectedRows).slice();
        if (!hasQuestion) allRows.sort((a, b) => b.date.localeCompare(a.date));
        const limit = state.ledgerExpanded ? 50 : 10;
        const rows = allRows.slice(0, limit);
        els.ledgerCount.textContent = state.search
          ? `${formatNumber(rows.length)} of ${formatNumber(allRows.length)} results`
          : state.ledgerExpanded
            ? `Latest ${formatNumber(rows.length)} sales`
            : "Most recent sales";
        if (!rows.length) {
          els.ledgerList.innerHTML = '<div class="empty">No matching transactions.</div>';
          return;
        }
        els.ledgerList.innerHTML = rows.map(item => `
          <button class="ledger-card${propertyId(state.selectedId) === propertyId(item.id) ? " active" : ""}" type="button" data-property="${escapeHtml(propertyId(item.id))}">
            <span class="ledger-price">${escapeHtml(item.priceText)}</span>
            <span class="ledger-address">${escapeHtml(item.address)}</span>
            <span class="ledger-meta">${formatDate(item.date)} · ${escapeHtml(item.propertyType || "Property")} · ${escapeHtml(marketById(item.market)?.short || item.district || "")}</span>
          </button>
        `).join("") + (allRows.length > 10 ? `<button class="more-button" type="button" data-ledger-more>${state.ledgerExpanded ? "Show latest 10" : "More (50)"}</button>` : "");
        els.ledgerList.querySelectorAll("[data-property]").forEach(card => {
          card.addEventListener("click", () => selectProperty(card.dataset.property));
        });
        const more = els.ledgerList.querySelector("[data-ledger-more]");
        if (more) {
          more.addEventListener("click", () => {
            state.ledgerExpanded = !state.ledgerExpanded;
            renderLedger();
          });
        }
      }

      function renderLegend() {
        const breaks = breaksFor(state.renderMode);
        const labels = {
          velocity: ["Unranked", "Low heat", "Steady", "Active", "High heat"],
          value: ["Lower value", `${compactPrice(breaks[0])}+`, `${compactPrice(breaks[1])}+`, `${compactPrice(breaks[2])}+`],
          ppsf: ["Awaiting EPC", `£${formatNumber(breaks[0])}+`, `£${formatNumber(breaks[1])}+`, `£${formatNumber(breaks[2])}+`],
          growth: ["Insufficient evidence", "Declining (<−3%)", "Stable (−3% to +3%)", "Growth (+3% to +8%)", "Strong growth (+8%+)"],
          planning: ["None", `${formatNumber(breaks[0])}+`, `${formatNumber(breaks[1])}+`, `${formatNumber(breaks[2])}+`]
        }[state.renderMode];
        const colours = state.renderMode === "growth"
          ? ["#64748b", ...heatColours]
          : state.renderMode === "planning"
          ? ["#64748b", "#6f967b", "#c19a58", "#7c3f72"]
          : state.renderMode === "velocity" ? ["#64748b", ...velocityColours] : heatColours;
        els.legendMode.textContent = "Map Mode";
        els.keyModeOptions?.querySelectorAll("[data-render-mode]").forEach(button => {
          button.setAttribute("aria-pressed", button.dataset.renderMode === state.renderMode ? "true" : "false");
        });
        els.legend.innerHTML = labels.map((label, index) => `
          <div class="legend-row"><span class="swatch" style="background:${colours[index]}"></span><span>${escapeHtml(label)}</span></div>
        `).join("");
        const propertyLegends = {
          price: {
            labels: [
              `${compactPrice(landRegPriceFloor)}-${compactPrice(3000000)}`,
              "£3m-£5m",
              "£5m-£10m",
              "£10m+"
            ],
            colours: ["#006ab6", "#3f8f68", "#d5a53a", "#b63d42"]
          },
          ppsf: {
            labels: ["Unavailable", "Under £750", "£750-£999", "£1,000-£1,499", "£1,500+"],
            colours: ["#64748b", "#006ab6", "#3f8f68", "#d5a53a", "#b63d42"]
          },
          planning: {
            labels: ["No matched applications", "1 application", "2-3 applications", "4+ applications"],
            colours: ["#64748b", "#6f967b", "#c19a58", "#b63d42"]
          },
          epc: {
            labels: ["Unavailable", "A-B", "C", "D", "E-G"],
            colours: ["#64748b", "#3f8f68", "#d5a53a", "#db7f35", "#b63d42"]
          },
          recency: {
            labels: ["Over 2 years", "1-2 years", "Within 12 months", "Within 90 days"],
            colours: ["#006ab6", "#3f8f68", "#d5a53a", "#b63d42"]
          },
          uplift: {
            labels: ["No prior sale", "Below prior sale", "0-9%", "10-24%", "25%+"],
            colours: ["#64748b", "#006ab6", "#3f8f68", "#d5a53a", "#b63d42"]
          },
          listed: {
            labels: ["Unlisted", "Grade II Listed", "Grade II* Listed", "Grade I Listed"],
            colours: ["#64748b", "#3f8f68", "#006ab6", "#b63d42"],
            caption: "Potential matches and unavailable statuses are hidden. Unlisted means no direct NHLE match, not legal proof."
          }
        };
        const propertyLegend = propertyLegends[state.propertyRenderMode] || propertyLegends.price;
        const propertyLabels = propertyLegend.labels;
        const propertyColours = propertyLegend.colours;
        els.propertyModeOptions?.querySelectorAll("[data-property-mode]").forEach(button => {
          button.setAttribute("aria-pressed", button.dataset.propertyMode === state.propertyRenderMode ? "true" : "false");
        });
        if (els.propertyLegendTitle) els.propertyLegendTitle.textContent = "Property Mode";
        if (els.propertyLegend) {
          els.propertyLegend.innerHTML = propertyLabels.map((label, index) => `
            <div class="legend-row"><span class="swatch" style="background:${propertyColours[index]}"></span><span>${escapeHtml(label)}</span></div>
          `).join("") + (propertyLegend.caption
            ? `<span class="legend-caption" role="note">${escapeHtml(propertyLegend.caption)}</span>`
            : "");
        }
      }

      function updateZoomUi() {
        if (!map) return;
        const zoom = map.getZoom();
        const displayZoom = displayZoomFromMap(zoom);
        const percent = displayZoom;
        if (els.zoomSlider && document.activeElement !== els.zoomSlider) {
          els.zoomSlider.value = String(displayZoom);
        }
        if (els.zoomSlider) els.zoomSlider.style.setProperty("--w", percent.toFixed(1) + "%");
        if (els.zoomReadout) els.zoomReadout.textContent = String(displayZoom);
      }

      function dataRows(rows) {
        return rows.filter(row => row[1] !== undefined && row[1] !== null && row[1] !== "").map(row => `
          <div class="data-row"><span class="data-row-label">${escapeHtml(row[0])}</span><span class="data-row-value">${escapeHtml(row[1])}${dataRowLinksHtml(row[3])}${row[2] ? `<small>${escapeHtml(row[2])}</small>` : ""}</span></div>
        `).join("");
      }

      function dataRowLinksHtml(links) {
        const items = (Array.isArray(links) ? links : []).map(link => {
          const safeLink = safeHttpsUrl(link?.url);
          const label = String(link?.label || "").trim();
          if (!safeLink || !label) return "";
          const ariaLabel = String(link?.ariaLabel || `Open ${label}`).trim();
          return `<a href="${escapeHtml(safeLink)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(ariaLabel)}">${escapeHtml(label)}</a>`;
        }).filter(Boolean);
        return items.length ? `<small class="data-row-links">${items.join("")}</small>` : "";
      }

      function propertyDisplayName(item) {
        return String(item.address || "").split(",")[0].trim() || item.postcode || "Property";
      }

      function propertyRoadName(item) {
        const parts = String(item.address || "").split(",").map(part => part.trim()).filter(Boolean);
        const candidates = parts.slice(1).filter(part => {
          if (normalisePostcode(part) === normalisePostcode(item.postcode || "")) return false;
          return normalise(part) !== normalise(item.town || "");
        });
        const roadPattern = /\b(?:AVENUE|CLOSE|CRESCENT|DRIVE|GARDENS?|GROVE|HILL|LANE|MEAD|MEWS|PARK|PLACE|RIDE|RISE|ROAD|ROW|SQUARE|STREET|WAY|WALK)\b/i;
        return candidates.find(part => roadPattern.test(part)) || candidates.find(part => !/^\d+[A-Z]?(?:\s*[-–]\s*\d+[A-Z]?)?$/i.test(part)) || "";
      }

      function propertyAddressLabel(item) {
        const address = String(item.address || "").trim();
        const postcode = String(item.postcode || "").trim();
        const addressContainsPostcode = postcode && normalisePostcode(address).endsWith(normalisePostcode(postcode));
        return [address, addressContainsPostcode ? "" : postcode].filter(Boolean).join(" · ");
      }

      function propertyAddressWithoutName(item) {
        const address = String(item.address || "").trim();
        const parts = address.split(",").map(part => part.trim()).filter(Boolean);
        if (parts.length > 1) parts.shift();
        const streetAddress = parts.join(", ");
        const postcode = String(item.postcode || "").trim();
        const addressContainsPostcode = postcode && normalisePostcode(streetAddress).endsWith(normalisePostcode(postcode));
        return [streetAddress || address, addressContainsPostcode ? "" : postcode].filter(Boolean).join(" · ");
      }

      function escapeHtml(value) {
        return String(value ?? "")
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
      }

      function safeHttpsUrl(value) {
        if (!value) return "";
        try {
          const url = new URL(String(value));
          return url.protocol === "https:" ? url.href : "";
        } catch (_error) {
          return "";
        }
      }

      els.newsMoreButton?.addEventListener("click", () => {
        newsExpanded = !newsExpanded;
        renderNews();
      });

      els.todayCloseButton?.addEventListener("click", () => {
        closeToday();
      });

      els.todayDrawer?.addEventListener("click", event => {
        const tabButton = event.target.closest("[data-today-tab]");
        if (tabButton) {
          setTodayTab(tabButton.dataset.todayTab || "briefing");
          return;
        }
        const routeButton = event.target.closest("[data-today-route]");
        if (routeButton) {
          setTodayTab(routeButton.dataset.todayRoute || "briefing");
          return;
        }
        const entityButton = event.target.closest("[data-today-entity-type][data-today-entity-id]");
        if (entityButton) {
          openTodayEntity(
            entityButton.dataset.todayEntityType || "",
            entityButton.dataset.todayEntityId || ""
          );
          return;
        }
        const propertyButton = event.target.closest("[data-today-property]");
        if (propertyButton) {
          selectProperty(propertyButton.dataset.todayProperty);
        }
      });

      els.todayTabs?.addEventListener("keydown", event => {
        const supported = ["ArrowLeft", "ArrowRight", "Home", "End"];
        if (!supported.includes(event.key)) return;
        const buttons = els.todayTabButtons;
        const currentIndex = Math.max(0, buttons.findIndex(button => button === document.activeElement));
        let nextIndex = currentIndex;
        if (event.key === "Home") nextIndex = 0;
        else if (event.key === "End") nextIndex = buttons.length - 1;
        else if (event.key === "ArrowLeft") nextIndex = (currentIndex - 1 + buttons.length) % buttons.length;
        else if (event.key === "ArrowRight") nextIndex = (currentIndex + 1) % buttons.length;
        event.preventDefault();
        setTodayTab(buttons[nextIndex]?.dataset.todayTab || "briefing");
      });

      els.todayFilters?.querySelectorAll("[data-today-filter]").forEach(button => {
        button.addEventListener("click", () => {
          state.todayFilter = button.dataset.todayFilter || "all";
          renderTodayDrawer();
        });
      });

      scheduleTodayBriefingLabel();
      window.addEventListener("focus", scheduleTodayBriefingLabel);
      document.addEventListener("visibilitychange", () => {
        if (!document.hidden) scheduleTodayBriefingLabel();
      });

      els.leftPanel?.addEventListener("click", event => {
        if (event.target.closest("#todayHomeButton")) return;
        closeToday({ render: false, restoreFocus: false });
      });

      window.addEventListener("pagehide", () => {
        try {
          localStorage.setItem(newsVisitKey, new Date().toISOString());
        } catch (_error) {
          // A disabled local-storage policy should not affect the feed.
        }
      });

      els.keyModeOptions?.querySelectorAll("[data-render-mode]").forEach(button => {
        button.addEventListener("click", () => {
          state.renderMode = button.dataset.renderMode;
          els.keyModePicker?.removeAttribute("open");
          els.propertyModePicker?.removeAttribute("open");
          applyRenderMode();
        });
      });

      els.propertyModeOptions?.querySelectorAll("[data-property-mode]").forEach(button => {
        button.addEventListener("click", () => {
          state.propertyRenderMode = button.dataset.propertyMode;
          els.propertyModePicker?.removeAttribute("open");
          applyRenderMode();
        });
      });

      [els.keyModePicker, els.propertyModePicker].filter(Boolean).forEach(picker => {
        picker.addEventListener("toggle", () => {
          if (!picker.open) return;
          [els.keyModePicker, els.propertyModePicker].filter(other => other && other !== picker)
            .forEach(other => other.removeAttribute("open"));
        });
      });

      if (themeMedia.addEventListener) {
        themeMedia.addEventListener("change", () => {
          applyTheme();
          renderLegend();
        });
      }

      function clearInsightQuestion(resetContext = false) {
        if (els.searchBox) {
          els.searchBox.value = "";
          els.searchBox.blur();
        }
        state.search = "";
        state.insightAnswerCache = null;
        state.ledgerExpanded = false;
        if (resetContext) state.insightContext = null;
        if (els.askSubmit) els.askSubmit.disabled = true;
        if (els.askStatus) els.askStatus.textContent = "";
      }

      function submitInsightQuestion() {
        const next = String(els.searchBox.value || "").trim();
        if (!next) return;
        closeToday({ render: false, restoreFocus: false });
        if (state.search && normalise(state.search) !== normalise(next) && !state.insightAnswerCache?.answer?.preserveMap) rememberInsightQuery(effectiveInsightQuery(state.search));
        state.search = next;
        state.insightAnswerCache = null;
        state.ledgerExpanded = false;
        renderInspector();
        renderLedger();
        updatePropertyMapSource();
        if (state.insightAnswerCache?.answer?.preserveMap) state.insightContext = null;
        else rememberInsightQuery(effectiveInsightQuery(next));
      }

      els.askForm?.addEventListener("submit", event => {
        event.preventDefault();
        submitInsightQuestion();
      });

      els.searchBox.addEventListener("input", () => {
        const next = String(els.searchBox.value || "").trim();
        if (els.askSubmit) els.askSubmit.disabled = !next;
        if (next || !state.search) return;
        if (!state.insightAnswerCache?.answer?.preserveMap) rememberInsightQuery(effectiveInsightQuery(state.search));
        state.search = "";
        state.insightAnswerCache = null;
        state.ledgerExpanded = false;
        renderInspector();
        renderLedger();
        updatePropertyMapSource();
      });

      if (els.askSubmit) els.askSubmit.disabled = !String(els.searchBox.value || "").trim();

      if (els.zoomSlider) {
        els.zoomSlider.addEventListener("input", () => {
          const percent = clamp(0, 100, Number(els.zoomSlider.value));
          const zoom = mapZoomFromDisplay(percent);
          els.zoomSlider.style.setProperty("--w", percent.toFixed(1) + "%");
          if (els.zoomReadout) els.zoomReadout.textContent = String(Math.round(percent));
          if (map) map.easeTo({ zoom, duration: 80 });
        });
      }

      if (els.brandTitle) {
        els.brandTitle.addEventListener("click", () => {
          toggleToday();
        });
        els.brandTitle.addEventListener("keydown", event => {
          if (event.key !== "Enter" && event.key !== " ") return;
          event.preventDefault();
          toggleToday();
        });
      }

      function resetInsight() {
        els.mapDropdowns.forEach(dropdown => dropdown.removeAttribute("open"));
        els.keyModePicker?.removeAttribute("open");
        els.propertyModePicker?.removeAttribute("open");
        clearInsightQuestion(true);
        resetMap();
      }

      window.INSIGHT_RESET = resetInsight;

      window.addEventListener("keydown", event => {
        if (event.key !== "Escape") return;
        event.preventDefault();
        event.stopPropagation();
        if (state.todayOpen) {
          closeToday();
          return;
        }
        resetInsight();
      }, true);

      els.mapDropdowns.forEach(dropdown => {
        dropdown.addEventListener("toggle", () => {
          if (!dropdown.open) return;
          els.mapDropdowns.forEach(other => {
            if (other !== dropdown) other.removeAttribute("open");
          });
        });
      });

      document.addEventListener("click", event => {
        if (!event.target.closest("[data-map-dropdown]")) {
          els.mapDropdowns.forEach(dropdown => dropdown.removeAttribute("open"));
        }
        if (!event.target.closest("[data-map-key]")) {
          els.keyModePicker?.removeAttribute("open");
          els.propertyModePicker?.removeAttribute("open");
        }
      });

      // Open the complete interface immediately; MapLibre fills the map in place.
      renderAll();
      window.INSIGHT_BOOT_STAGE = "waiting-map";
      if (typeof maplibregl === "undefined") {
        window.INSIGHT_BOOT_STAGE = "map-unavailable";
      }
    })();
