# INSIGHT brand assets

- `insight-wordmark.svg` — primary dark wordmark for light backgrounds.
- `insight-wordmark-dark.svg` — light wordmark for dark backgrounds.
- `insight-wordmark.png` — 1024 × 192 transparent raster export.
- `insight-wordmark-dark.png` — 1024 × 192 transparent raster export for dark backgrounds.

The wordmark mirrors the product header: `INSIGHT` in a medium system/Inter weight with optical tracking equivalent to the header's spaced lettering.
