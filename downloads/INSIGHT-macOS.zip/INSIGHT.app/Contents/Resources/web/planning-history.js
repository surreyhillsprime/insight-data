window.SURREY_PLANNING_HISTORY = {};
window.SURREY_PLANNING_HISTORY_META = {"source":"Private local planning cache","propertiesWithHistory":0,"applicationsFound":0};
