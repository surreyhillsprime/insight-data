window.SURREY_ADDRESS_POINTS = {};
window.SURREY_ADDRESS_POINTS_META = {
  source: "Address-level coordinate enrichment",
  status: "pending",
  note: "Populate this file with transaction id or normalised address keys mapped to exact longitude/latitude coordinates.",
  matchedTransactions: 0
};
