window.SURREY_ADDRESS_POINTS = {};
window.SURREY_ADDRESS_POINTS_META = {
  source: "Address-level coordinate enrichment",
  status: "unavailable",
  coverageMode: "not-available",
  note: "No licensed address-level coordinate dataset is activated. Transaction rows use their validated postcode-centroid coordinates where available.",
  matchedTransactions: 0,
  exactCoordinates: 0
};
