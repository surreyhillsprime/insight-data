window.SURREY_POSTCODE_POINTS = {};
window.SURREY_POSTCODE_POINTS_META = {
  source: "OS Open UPRN postcode centroids",
  status: "unavailable",
  coverageMode: "not-available",
  note: "Current local OS Open UPRN extract has coordinates but no postcode column, so postcode centroids cannot yet be generated.",
  matchedPostcodes: 0,
  matchedTransactions: 0
};
